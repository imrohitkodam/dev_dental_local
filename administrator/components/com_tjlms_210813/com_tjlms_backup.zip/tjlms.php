<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access.
defined('_JEXEC') or die;
jimport('joomla.filesystem.file');

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_tjlms'))
{
	throw new Exception(JText::_('JERROR_ALERTNOAUTHOR'));
}

if (!defined('DS'))
{
	define('DS', '/');
}

global $wrapperDiv;

/* define wrapper div*/
if (JVERSION < '3.0')
{
	define('COM_TJLMS_WRAPPER_DIV', 'techjoomla-bootstrap tjlms-wrapper  row-fluid');
}
else
{
	define('COM_TJLMS_WRAPPER_DIV', 'tjlms-wrapper row-fluid');
}

$document = JFactory::getDocument();

// Load js assets
$tjStrapperPath = JPATH_SITE . '/media/techjoomla_strapper/tjstrapper.php';

if (JFile::exists($tjStrapperPath))
{
	require_once $tjStrapperPath;
	TjStrapper::loadTjAssets('com_tjlms');
}

$path = JPATH_SITE . '/components/com_tjlms/helpers/courses.php';

if (!class_exists('tjlmsCoursesHelper'))
{
	JLoader::register('tjlmsCoursesHelper', $path);
	JLoader::load('tjlmsCoursesHelper');
}

$helperPath = dirname(__FILE__) . DS . 'helpers' . DS . 'tjlms.php';

if (!class_exists('TjlmsHelper'))
{
	JLoader::register('TjlmsHelper', $helperPath);
	JLoader::load('TjlmsHelper');
}

$path = JPATH_SITE . '/components/com_tjlms/helpers/' . 'tjdbhelper.php';

if (!class_exists('tjlmsdbhelper'))
{
	JLoader::register('tjlmsdbhelper', $path);
	JLoader::load('tjlmsdbhelper');
}

/*$path = JPATH_COMPONENT . '/helpers/scormlib.php';

if (!class_exists('tjlmsscormlib'))
{
	JLoader::register('tjlmsscormlib', $path);
	JLoader::load('tjlmsscormlib');
}*/

$path = JPATH_SITE . '/components/com_tjlms/helpers/' . 'main.php';

if (!class_exists('comtjlmsHelper'))
{
	JLoader::register('comtjlmsHelper', $path);
	JLoader::load('comtjlmsHelper');
}

$path = JPATH_SITE . '/components/com_tjlms/helpers/' . 'tracking.php';

if (!class_exists('comtjlmstrackingHelper'))
{
	JLoader::register('comtjlmstrackingHelper', $path);
	JLoader::load('comtjlmstrackingHelper');
}

// Include dependancies
jimport('joomla.application.component.controller');
$controller = JControllerLegacy::getInstance('Tjlms');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
