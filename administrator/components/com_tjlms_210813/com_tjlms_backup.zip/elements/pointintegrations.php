<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
jimport('joomla.application.component.helper');
jimport('joomla.filesystem.folder');
jimport('joomla.form.formfield');

/**
 * Function to get points integration select box
 *
 * @since  1.0.0
 */
class JFormFieldPointintegrations extends JFormField
{
	/**
	 * Function to getInput
	 *
	 * @return  complete html.
	 *
	 * @since 1.0.0
	 */
	public function getInput()
	{
		return $this->fetchElement($this->name, $this->value, $this->element, $this->options['controls']);
	}

	/**
	 * Function fetchElement
	 *
	 * @param   STRING  $name          Name of the element
	 * @param   STRING  $value         Value of the element
	 * @param   STRING  &$node         Node
	 * @param   STRING  $control_name  control_name
	 *
	 * @return  complete html.
	 *
	 * @since 1.0.0
	 */
	public function fetchElement($name,$value,&$node,$control_name)
	{
		$communitymainfile = JPATH_SITE . '/components/com_community/libraries/core.php';
		$esfolder = JPATH_SITE . '/components/com_easysocial';
		$alphafolder = JPATH_SITE . '/components/com_alphauserpoints';

		// If point integration
		if ($name == 'jform[pt_option]')
		{
			$options[] = JHTML::_('select.option', 'no', JText::_('COM_TJLMS_NONE'));

			if (JFile::exists($communitymainfile))
			{
				$options[] = JHTML::_('select.option', 'jspt', JText::_('COM_TJLMS_JOMSOCIAL'));
			}

			if (JFolder::exists($esfolder))
			{
				$options[] = JHTML::_('select.option', 'espt', JText::_('COM_TJLMS_EASYSOCIAL'));
			}

			if (JFolder::exists($alphafolder))
			{
				$options[] = JHTML::_('select.option', 'alpha', JText::_('COM_TJLMS_ALPHA_POINTS'));
			}

			$fieldName = $name;

			return JHtml::_('select.genericlist',  $options, $fieldName, 'class="inputbox"  ', 'value', 'text', $value, $control_name . $name);
		}
	}
}
