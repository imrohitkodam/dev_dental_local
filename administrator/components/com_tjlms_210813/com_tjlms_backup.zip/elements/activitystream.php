<?php
/**
 * @version    SVN: <svn_id>
 * @package    Plg_System_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.form.formfield');

/**
 * Element for activity stream
 *
 * @since  1.0.0
 */
class JFormFieldActivitystream extends JFormField
{
	public $type = 'activitystream';

	/**
	 * Function to get the input
	 *
	 * @return  Filter
	 *
	 * @since  1.0.0
	 */
	public function getInput()
	{
		return self::fetchElement($this->name, $this->value, $this->element, $this->options['control']);
	}

	/**
	 * Function to get the activity stream filter
	 *
	 * @param   STRING  $name          name of the field
	 * @param   STRING  $value         value of the field
	 * @param   STRING  &$node         name of the field
	 * @param   STRING  $control_name  name of the field
	 *
	 * @return  Filter
	 *
	 * @since  1.0.0
	 */
	public function fetchElement($name, $value, &$node, $control_name)
	{
		$options[] = JHTML::_('select.option', 'onafterCourseCreate', JText::_('COM_TJLMS_ACTIVITY_AFTER_COURSE_CREATE'));
		$options[] = JHTML::_('select.option', 'onafterCourseEnroll', JText::_('COM_TJLMS_ACTIVITY_AFTER_COURSE_ENROLL'));
		$options[] = JHTML::_('select.option', 'onafterCourseRecommend', JText::_('COM_TJLMS_ACTIVITY_AFTER_COURSE_RECOMMEND'));
		$options[] = JHTML::_('select.option', 'onafterLessonAttemptStart', JText::_('COM_TJLMS_ACTIVITY_AFTER_LESSON_START'));
		$options[] = JHTML::_('select.option', 'onafterLessonAttemptEnd', JText::_('COM_TJLMS_ACTIVITY_AFTER_LESSON_END'));
		$options[] = JHTML::_('select.option', 'onaftercourseComplition', JText::_('COM_TJLMS_ACTIVITY_AFTER_COURSE_COMPLITE'));
		$options[] = JHTML::_('select.option', 'none', JText::_('COM_TJLMS_ACTIVITY_NONE'));
		$fieldName = $name;

		$default = array();
		$default[] = 'onafterCourseCreate';
		$default[] = 'onafterCourseEnroll';
		$default[] = 'onafterCourseRecommend';
		$default[] = 'onaftercourseComplition';
		$default[] = 'onafterLessonAttemptStart';
		$default[] = 'onafterLessonAttemptEnd';

		if (empty($value))
		{
			$value = $default;
		}

		$optionalField = 'class="inputbox activityStreamFilter"  multiple="multiple" size="10"';

		return JHTML::_('select.genericlist', $options, $fieldName, $optionalField, 'value', 'text', $value, $control_name . $name);
	}
}
