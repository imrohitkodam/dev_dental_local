ALTER TABLE `#__tjlms_coupons` change params couponParams text NOT NULL;
ALTER TABLE `#__tjlms_lessons` change despcription description text NOT NULL;
ALTER TABLE `#__tjlms_scorm_seq_rulecond` change refrencedobjective referencedobjective varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '';
