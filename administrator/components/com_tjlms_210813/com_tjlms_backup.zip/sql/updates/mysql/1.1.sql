ALTER TABLE `#__tjlms_courses` add column `featured` tinyint(1) NOT NULL AFTER `state`;
ALTER TABLE `#__tjlms_courses` add column `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `checked_out_time`;
ALTER TABLE `#__tjlms_courses` add column `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `created`;
ALTER TABLE `#__tjlms_courses` add column `alias` varchar(255) NOT NULL AFTER `title`;
ALTER TABLE `#__tjlms_courses` add column `certificate_id` int(11) NOT NULL DEFAULT '0' AFTER `certificate_term`;
ALTER TABLE `#__tjlms_courses` add column `expiry` int(11) NOT NULL DEFAULT '0' AFTER `certificate_id`;

ALTER TABLE `#__tjlms_course_track` MODIFY `status` VARCHAR(48) NOT NULL;
ALTER TABLE `#__tjlms_course_track` add column `timestart` datetime NOT NULL AFTER `user_id`;
ALTER TABLE `#__tjlms_course_track` add column `timeend` datetime NOT NULL AFTER `timestart`;
ALTER TABLE `#__tjlms_course_track` add column `no_of_lessons` int(11) NOT NULL AFTER `timeend`;
ALTER TABLE `#__tjlms_course_track` add column `completed_lessons` int(11) NOT NULL AFTER `no_of_lessons`;

ALTER TABLE `#__tjlms_enrolled_users` add column `assigned` int(11) NOT NULL AFTER `state`;
ALTER TABLE `#__tjlms_enrolled_users` add column `unlimited_plan` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `#__tjlms_enrolled_users` add column `params` varchar(255) NOT NULL DEFAULT '';

ALTER TABLE `#__tjlms_coupons` add column `course_id` varchar(255) NOT NULL AFTER `id`;
ALTER TABLE `#__tjlms_coupons` add column `used_count` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `#__tjlms_coupons` MODIFY `value` float( 10, 2 ) UNSIGNED;
ALTER TABLE `#__tjlms_coupons` add column `privacy` int(11) NOT NULL DEFAULT '0';

ALTER TABLE `#__tjlms_orders` add column `enrollment_id` int(11) NOT NULL AFTER `course_id`;

ALTER TABLE `#__tjlms_lessons` add column `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `image`;
ALTER TABLE `#__tjlms_lessons` add column `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `start_date`;
ALTER TABLE `#__tjlms_lessons` add column `alias` varchar(255) NOT NULL AFTER `name`;
ALTER TABLE `#__tjlms_lessons` add column `ideal_time` int(11) NOT NULL;

ALTER TABLE `#__tjlms_lesson_track` add column `modified_date` datetime NOT NULL AFTER `last_accessed_on`;

ALTER TABLE `#__tmt_tests` add column `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `created_on`;
ALTER TABLE `#__tmt_tests` add column `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `start_date`;
ALTER TABLE `#__tmt_tests` add column `parent_id` int(11) NOT NULL AFTER `id`;
ALTER TABLE `#__tmt_tests` add column `type` varchar(100) NOT NULL DEFAULT 'plain' AFTER `parent_id`;
ALTER TABLE `#__tmt_tests` add column `questions_shuffle` tinyint(1) NOT NULL DEFAULT '0' AFTER `answer_sheet`,
ALTER TABLE `#__tmt_tests` add column `answers_shuffle` tinyint(1) NOT NULL DEFAULT '0' AFTER `questions_shuffle`,

ALTER TABLE `#__tjlms_certificate` add column `type` VARCHAR(255) NULL DEFAULT '';
ALTER TABLE `#__tjlms_certificate` MODIFY `cert_id` VARCHAR(255) NOT NULL;
