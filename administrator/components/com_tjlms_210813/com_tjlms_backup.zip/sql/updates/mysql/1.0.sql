ALTER TABLE  `#__tjlms_activities` ADD INDEX actor_id (actor_id);
ALTER TABLE  `#__tjlms_activities` ADD INDEX comp_activity (action(50),element(50));

ALTER TABLE  `#__tjlms_associated_files` ADD INDEX lesson_id (lesson_id);

ALTER TABLE `#__tjlms_courses` ADD UNIQUE course_alias (alias);
ALTER TABLE `#__tjlms_courses` ADD INDEX cat_id (cat_id);

ALTER IGNORE TABLE `#__tjlms_course_track` ADD UNIQUE unique_course_completion (course_id, user_id);


ALTER TABLE `#__tjlms_enrolled_users` ADD INDEX user_id (user_id);

ALTER TABLE `#__tjlms_lessons` ADD UNIQUE lesson_alias (alias);
ALTER TABLE `#__tjlms_lessons` ADD INDEX course_id (course_id);

ALTER IGNORE TABLE `#__tjlms_lesson_track` ADD UNIQUE unique_lesson_entry (lesson_id, user_id, attempt);
ALTER TABLE `#__tjlms_lesson_track` ADD INDEX user_id (user_id);

ALTER TABLE `#__tjlms_modules` ADD INDEX course_id (course_id);

ALTER TABLE `#__tjlms_orders` ADD UNIQUE order_id (order_id);
ALTER TABLE `#__tjlms_orders` ADD INDEX course_id (course_id);
ALTER TABLE `#__tjlms_orders` ADD INDEX user_id (user_id);

ALTER TABLE `#__tjlms_scorm` ADD INDEX lesson_id (lesson_id);
ALTER TABLE `#__tjlms_scorm_scoes` ADD INDEX scorm_id (scorm_id);

ALTER TABLE `#__tjlms_scorm_scoes_track` ADD INDEX scoes_track (userid, scorm_id, sco_id);
ALTER TABLE `#__tjlms_subscription_plans` ADD INDEX course_id (course_id);

ALTER TABLE `#__tjlms_tmtquiz` ADD INDEX lesson_id (lesson_id);
ALTER TABLE `#__tjlms_tmtquiz` ADD INDEX test_id (test_id);
ALTER TABLE `#__tjlms_users` ADD INDEX user_id (user_id);


ALTER TABLE `#__tmt_answers` ADD INDEX question_id (question_id);
ALTER TABLE `#__tmt_questions` ADD INDEX category_id (category_id);

ALTER IGNORE TABLE `#__tmt_tests_answers` ADD UNIQUE unique_answer (question_id,user_id,invite_id);
ALTER TABLE `#__tmt_tests_answers` ADD INDEX user_id (user_id);
ALTER TABLE `#__tmt_tests_answers` ADD INDEX test_id (test_id);
ALTER TABLE `#__tmt_tests_answers` ADD INDEX invite_id (invite_id);

ALTER IGNORE TABLE `#__tmt_tests_attendees` ADD UNIQUE unique_test_attendee (invite_id, user_id);

ALTER IGNORE TABLE `#__tmt_tests_questions` ADD UNIQUE unique_test_question (test_id,question_id);
