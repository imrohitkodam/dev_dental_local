ALTER TABLE `#__tjlms_enrolled_users` add column `before_expiry_mail` tinyint(1) NOT NULL DEFAULT '0';
ALTER TABLE `#__tjlms_enrolled_users` add column `after_expiry_mail` tinyint(1) NOT NULL DEFAULT '0';
