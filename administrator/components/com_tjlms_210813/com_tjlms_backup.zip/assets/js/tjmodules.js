techjoomla.jQuery(window).load(function(){

	techjoomla.jQuery('.lesson_basic_form').each(function(){
		var tjlmsformid	= techjoomla.jQuery(this).attr('id');
		var formid	= tjlmsformid.replace("lesson-basic-form_", "");

		techjoomla.jQuery("fieldset.radio",this).each(function(){
			this.id= this.id + formid;
			techjoomla.jQuery(this).children('input').each(function () {
				this.id = this.id + formid;
			});
			techjoomla.jQuery(this).children('label').each(function () {
				techjoomla.jQuery(this).attr('for',techjoomla.jQuery(this).attr('for') + formid);
				techjoomla.jQuery(this).removeClass('active btn-success btn-danger')
			});
			var checkedInputID	=	techjoomla.jQuery(this).children('input:checked').attr('id');
			var checkedInputVal	=	techjoomla.jQuery(this).children('input:checked').val();
			if (checkedInputVal == 0) {
				techjoomla.jQuery("label[for=" + checkedInputID + "]").addClass('active btn-danger');
			} else {
				techjoomla.jQuery("label[for=" + checkedInputID + "]").addClass('active btn-success');
			}
		});
	});
    techjoomla.jQuery("fieldset.radio label").click(function()
    {
		var lessonform = techjoomla.jQuery(this).closest('.tjlms_add_lesson_form');
		var label = techjoomla.jQuery(lessonform).find(this);
		var input = techjoomla.jQuery( this ).siblings( '#' + label.attr('for') );
		techjoomla.jQuery(this).parent().find('label').removeClass('btn-success').removeClass('btn-danger');

		if (input.val() == '') {
			label.addClass('active btn-primary');
		} else if (input.val() == 0) {
			label.addClass('active btn-danger');
		} else {
			label.addClass('active btn-success');
		}
		input.prop('checked', true);

    });

	techjoomla.jQuery('.content-li').click(function(){
		var section_tr	=	techjoomla.jQuery(this).closest('li').attr('id');
		var module_id	=	section_tr.replace("modlist_", "");
		techjoomla.jQuery("#curriculum-lesson-ul_"+module_id).toggle();
	});


	/* This code is used so that Sorting can be possiable between to modules. */
	techjoomla.jQuery( "#course-modules .LessonsInModule" ).sortable({
		scroll: false,
		connectWith: ".connectedSortable",
		collapsible: true,
	});

	techjoomla.jQuery('#course-modules').sortable({
		handle:'.moduleSortingHandler',
		update: function() {
			var stringDiv = "";
			var course_id	= techjoomla.jQuery("#course_id", techjoomla.jQuery(this).closest('.curriculum-container')).val();

			/* All module ordering stored in stringDiv along with their ID as the key. */
			techjoomla.jQuery("#course-modules").children().each(function(i) {
				i++;
				var li = techjoomla.jQuery(this);
				stringDiv += " "+li.attr("id") + '=' + i + '&';
			});

			/* Ajax call to save the ordering. */
			techjoomla.jQuery.ajax({
				type: "POST",
				url: 'index.php?option=com_tjlms&task=modules.saveSortingForModules&course_id='+course_id,
				data: stringDiv

			});
		}
	});

	/* function call to able to sort the lessons of each module.*/
	sortLessons();


	/*VAISHALI for add lesson wizard*/
	techjoomla.jQuery('.module_actions .action').click(function()
	{

		var parent_mod	=	techjoomla.jQuery(this).closest('.mod_outer');
		var parent_mod_id	=  parent_mod.attr('id');
		var mod_id	=  parent_mod_id.replace('modlist_','');


		techjoomla.jQuery("#"+parent_mod_id + " .module_actions").hide();
		var module_lms	=	'modlist_'+mod_id;

		if(techjoomla.jQuery(this).hasClass( "btn-add-quizs" )){
			techjoomla.jQuery('#'+module_lms + " .add_quizs_wizard").show();
		}
		else if(techjoomla.jQuery(this).hasClass( "btn-add-lesson")){
			techjoomla.jQuery('#'+module_lms + " .add_lesson_wizard").show();
			techjoomla.jQuery('html,body').animate({
				 scrollTop: techjoomla.jQuery("#"+module_lms + " .add_lesson_wizard").offset().top},
				 'slow');
		}
		return false;

	});

	techjoomla.jQuery(".tjlms_add_lesson_form .nav-tabs li").click(function(e)
	{
		var tabToShow = techjoomla.jQuery('a',this).attr('href');
		var lessonform	=	techjoomla.jQuery(this).closest('.tjlms_add_lesson_form')
		var form_id	= lessonform.attr('id').replace('tjlms_add_lesson_form_','');

		if(tabToShow != '#general_' +  form_id)
		{
			/*Check if the first tab is validated*/
			if(validate_lessonactions(form_id) == 0)
			{
				return false;
			}

			/*if user is clicking on second tab get the we need to get the html of lesson type plugin:
			 By deafult it will be of scorm*/

			if(tabToShow == '#format_' +  form_id)
			{
				/*This is to get the lesson format html from respective plugin and show*/
				var format = techjoomla.jQuery('#format_' + form_id + ' #jform_format').val();
				var subformat = techjoomla.jQuery('#format_' + form_id + ' #jform_subformat').val();
				var lesson_id = techjoomla.jQuery('#format_' + form_id + ' #lesson_id').val();

				var lesson_basic_form	= techjoomla.jQuery('#lesson-basic-form_'+form_id);
				var mod_id = techjoomla.jQuery('#mod_id', lesson_basic_form).val();

				getsubFormatHTML(form_id,format,mod_id,lesson_id,subformat);
			}

			/* if associated files is clicked - check if format is uploaded : or save*/

			if(tabToShow == '#assocFiles_' +  form_id)
			{
				if (!formatactions(form_id, 0))
				{
					return false;
				}
			}
		}

		return true;
	});

	/* Durgesh Added for no_of_attempts validation */
	techjoomla.jQuery('.numberofattempts').blur(function()
	{
		newval = parseInt(this.value);
		var id = this.id;

		var msg = Joomla.JText._('COM_TJLMS_NO_OF_ATTEMPT_VALIDATION_MSG');
		var msg1;
		var lesson_basic_form	=	techjoomla.jQuery(this).closest('.lesson_basic_form');

		var original_attempt = techjoomla.jQuery('#no_attempts',lesson_basic_form).val();
		var max_attempt = techjoomla.jQuery('#max_attempt',lesson_basic_form).val();
		var form_id        = lesson_basic_form.attr('id').replace('lesson-basic-form_','');
		var conditionSatisfy = 1;
		var lessonform	=	techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id);
		techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[no_of_attempts]\"]').val(newval);

		// Check if attempt is less than original attempt
		if (newval != 0 && newval < max_attempt)
		{
				msg1 = Joomla.JText._('COM_TJLMS_MAX_ATTEMPT_VALIDATION_MSG1').concat(max_attempt) + Joomla.JText._('COM_TJLMS_MAX_ATTEMPT_VALIDATION_MSG2');
				techjoomla.jQuery('#system-message-container').html('');
				techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(msg1);
				techjoomla.jQuery(".tjlms_form_errors", lessonform).show();
				techjoomla.jQuery('#'+id,lesson_basic_form).val(original_attempt);
				techjoomla.jQuery('#'+id,lesson_basic_form).focus();
				conditionSatisfy = 0;
		}

		if (conditionSatisfy == 1)
		{
			techjoomla.jQuery(".tjlms_form_errors", lessonform).hide();
		}

		// Check if attempt empty
		if (newval== '' && original_attempt == '')
		{
			techjoomla.jQuery('#'+id,lesson_basic_form).val(0);
		}
	});
	/* Durgesh Added for no_of_attempts validation */

});


function moduleactions(thiselement,action,originalvalue)
{
	var moduleform	= techjoomla.jQuery(thiselement).closest('.tjlms_module_form');
	var course_id	= techjoomla.jQuery("#course_id", moduleform).val();
	var mod_id	= techjoomla.jQuery("#mod_id", moduleform).val();
	var mod_title = '';

	var moduleTitle = techjoomla.jQuery.trim(techjoomla.jQuery('#title',moduleform).val());
	moduleTitle = noScript(moduleTitle);
	techjoomla.jQuery('#title',moduleform).val(moduleTitle);


	/* populate the input task hidden field with module action*/
	techjoomla.jQuery("#task", moduleform).val(action);

	var moduleform	= techjoomla.jQuery('#tjlms_module_form_'+mod_id);
	if (action == 'module.cancel')
	{
		/* Get original mod title*/
		if (originalvalue)
		{
			mod_title = originalvalue;
		}

		/* Added to refesh textbox data on cancel button*/
		techjoomla.jQuery("#title", moduleform).val(mod_title);
		hideeditModule(course_id,mod_id);
		return false;
	}
	else
	{
		techjoomla.jQuery(moduleform).ajaxSubmit({
			beforeSend: function() {

				var moduleTitle = techjoomla.jQuery.trim(techjoomla.jQuery('#title',moduleform).val());

				if(moduleTitle == '')
				{
					techjoomla.jQuery(".tjlms_module_errors .msg", moduleform).html(Joomla.JText._('COM_TJLMS_VALID_MODULE_TITLE'));
					techjoomla.jQuery(".tjlms_module_errors", moduleform).show();
					return false;
				}
			},
			success: function(data)
			{
				hideeditModule(course_id,mod_id);
				success_popup(course_id,data);
			},
			complete: function(xhr) {

			}
		});

	}
	return false;
}

/*Function triggered by clicking on the "Save and next" of the 1st Basic details tab of lesson */
function lessonactions(form_id)
{
	if(validate_lessonactions(form_id) == 1)
	{
		/*Ater validating the next "format" should be avtive*/
		techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id + ' .nav-tabs li').removeClass('active');
		techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id + ' .tab-content .tab-pane').removeClass('active');


		techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id + ' a[href="#format_'+ form_id  +'"]').closest('li').addClass('active');
		techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id + ' .tab-content #format_' + form_id).addClass('active');
	}
}

function validate_lessonactions(form_id)
{
		var lesson_space_msg = Joomla.JText._('COM_TJLMS_EMPTY_TITLE_ISSUE');

		var lesson_basic_form	= techjoomla.jQuery('#lesson-basic-form_'+form_id);

		var lessonform	=	techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id);

		var return_var	=	1;

		/*Make the all form inputs Script safe*/
		formInputsWithoutScript(lesson_basic_form);

		if(document.formvalidator.isValid(lesson_basic_form))
		{
			if ( techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[name]\"]').val().trim() == '')
			{
				techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[name]\"]').val('');
				techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[name]\"]').focus();
				techjoomla.jQuery('#system-message-container').html('');
				techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(lesson_space_msg);
				techjoomla.jQuery(".tjlms_form_errors", lessonform).show();
				return_var =  0;
				return return_var;
			}

			var courseStartDate, courseEndDate;
			courseStartDate = techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[start_date]\"]').val();
			courseEndDate = techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[end_date]\"]').val();

			if (courseStartDate != '' && isValidDate(courseStartDate) == false)
			{
				var invalidStartDate = Joomla.JText._('COM_TJLMS_INVALID_START_DATE');
				techjoomla.jQuery('#system-message-container').html('');
				techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(invalidStartDate);
				techjoomla.jQuery(".tjlms_form_errors", lessonform).show();

				return false;
			}else if (courseEndDate != '' && isValidDate(courseEndDate) == false)	/*Validate course end date*/
			{
				var invalidEndDate = Joomla.JText._('COM_TJLMS_INVALID_END_DATE');
				techjoomla.jQuery('#system-message-container').html('');
				techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(invalidEndDate);
				techjoomla.jQuery(".tjlms_form_errors", lessonform).show();

				return false;
			}

			/* Validate time_finished_duration < time_duration */
			if (courseStartDate != '' && courseEndDate != '' )
			{
				if (courseStartDate > courseEndDate)
				{
					techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[end_date]\"]').focus();

					techjoomla.jQuery('#system-message-container').html('');
					techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(form_date_validation_failed);
					techjoomla.jQuery(".tjlms_form_errors", lessonform).show();
					return_var =  0;
					return return_var;
				}
			}

			// Check for only end date
			if (techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[end_date]\"]').val() != '')
			{
				var selectedDate = techjoomla.jQuery('#lesson-basic-form_'+form_id+' input[name=\"jform[end_date]\"]').val();
				var today = new Date();
				today.setHours(0, 0, 0, 0);
				lessonEndDate = new Date(selectedDate);
				lessonEndDate.setHours(0, 0, 0, 0);

				if(lessonEndDate < today)
				{
					var msg = Joomla.JText._('COM_TJLMS_END_DATE_CANTBE_GRT_TODAY');
					techjoomla.jQuery('#system-message-container').html('');
					techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(msg);
					techjoomla.jQuery(".tjlms_form_errors", lessonform).show();
					return_var =  0;
					return return_var;
					return false;
				}
			}

			techjoomla.jQuery(lesson_basic_form).ajaxSubmit({
				datatype:'json',
				async:false,
				beforeSend: function() {
					techjoomla.jQuery('.loading',lesson_basic_form).show();
				},
				success: function(data)
				{
					var response = jQuery.parseJSON(data)
					var output	=	response.OUTPUT;
					var res	=	output[0];
					var msg	=	output[1];

					if(res == 1)
					{
						//Remove shown errors above the form if any
						//show_lessonform_error(0,'',lessonform);

						var lesson_id  = msg;
						//if create lesson- update the id field
						if(techjoomla.jQuery('#jform_id',lesson_basic_form).val() == 0)
							techjoomla.jQuery('#jform_id',lesson_basic_form).val(lesson_id)

						techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id +' #format_'+ form_id + ' #lesson_id ').val(lesson_id);

						/*This is to get the lesson format html from respective plugin and show*/
						var format = techjoomla.jQuery('#format_' + form_id + ' #jform_format').val();
						var subformat = techjoomla.jQuery('#format_' + form_id + ' #jform_subformat').val();

						if(subformat == '')
						{
							lesson_format(format,form_id);
						}
						else
						{
							var mod_id = techjoomla.jQuery('#mod_id', lesson_basic_form).val();
							getsubFormatHTML(form_id,format,mod_id,lesson_id,subformat);
						}

						if (allow_associate_files == 1)
						{
							techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id +' #assocFiles_'+ form_id + ' #lesson_id ').val(lesson_id);
							techjoomla.jQuery('#tjlms_add_lesson_form_'+form_id +' #assocFiles_'+ form_id + ' #selectFileLink').attr('href','index.php?option=com_tjlms&view=modules&layout=selectassociatefiles&lesson_id='+msg+'&tmpl=component&form_id='+form_id);
						}

						return_var	= 1 ;
					}
					else
					{
						techjoomla.jQuery('#system-message-container').html('');
						techjoomla.jQuery(".tjlms_form_errors .msg", lessonform).html(msg);
						techjoomla.jQuery(".tjlms_form_errors", lessonform).show();
						return_var =  0;
						return return_var;
						return false;
					}
				},
				complete: function(xhr) {
					techjoomla.jQuery('.loading',lesson_basic_form).hide();
				}
			});
		}
		else
		{
			techjoomla.jQuery('#system-message-container').html('');
			formTrackinvalidFields(lesson_basic_form, lessonform);
			return_var =  0;
		}

		if (return_var == 1)
		{
			techjoomla.jQuery(".tjlms_form_errors", lessonform).hide();
		}

		// always return false to prevent standard browser submit and page navigation
		return return_var;
}

function associateaction(formid, reload)
{
	var lesson_format_form = techjoomla.jQuery('#lesson-associatefile-form_'+formid);
	var lessonform = techjoomla.jQuery('#tjlms_add_lesson_form_'+formid);
	var s_msg = Joomla.JText._('COM_TJLMS_LESSON_UPDATED_SUCCESSFULLY');

	techjoomla.jQuery(lesson_format_form).ajaxSubmit({
		datatype:'json',
		 beforeSend: function() {
			techjoomla.jQuery('.loading',lesson_format_form).show();
		},
		success: function(data)
		{
			var response = jQuery.parseJSON(data)
			var output	=	response.OUTPUT;
			var res	=	output[0];
			var msg	=	output[1];

			if(res == 1)
			{
				console.log('success');

				if (reload == 1)
				{
					alert(s_msg);
					success_popup('1',msg);
				}
			}
			else
			{
				show_lessonform_error(1,'something went wrong',lessonform);
			}
		},
		error: function()
		{
				show_lessonform_error(1,'something went wrong',lessonform);
		},
		complete: function(xhr) {
			techjoomla.jQuery('.loading',lesson_format_form).hide();
		}
	});
}

function validateResFormats(formid,format,subformat,media_id,lessonform)
{
	console.log(media_id+format+subformat);
	var function_to_call = 'validate'+format+subformat;
	var check_validation = eval(function_to_call)(formid,format,subformat,media_id);

	if (check_validation.check == '0')
	{
		show_lessonform_error(1, check_validation.message, lessonform);
		return false;
	}

	return true;
}

function formatactions(formid,reload)
{
	var lesson_format_form	=techjoomla.jQuery('#lesson-format-form_'+formid);
	var lessonform	=	techjoomla.jQuery('#tjlms_add_lesson_form_'+formid);

	var media_id = techjoomla.jQuery("#lesson_format_id",lesson_format_form).val();
	var format = techjoomla.jQuery("#jform_format",lesson_format_form).val();
	var subformat = techjoomla.jQuery("#jform_subformat",lesson_format_form).val();

	if (!validateResFormats(formid,format,subformat,media_id,lessonform))
	{
		return false;
	}

	// Submit file through Ajax
	techjoomla.jQuery(lesson_format_form).ajaxSubmit({
		datatype:'json',
		 beforeSend: function() {
			techjoomla.jQuery('.loadingsquares',lesson_format_form).show();
		},
		success: function(data)
		{
			var response = jQuery.parseJSON(data)
			var output	=	response.OUTPUT;
			var res	=	output['result'];
			var msg	=	output['msg'];

			if(res == 1)
			{
				if(output['media_id'])
				{
					techjoomla.jQuery("#lesson_format_id",lesson_format_form).val(output['media_id']);
				}

				techjoomla.jQuery('#tjlms_add_lesson_form_'+formid + ' .nav-tabs li').removeClass('active');
				techjoomla.jQuery('#tjlms_add_lesson_form_'+formid + ' .tab-content .tab-pane').removeClass('active');
				if(reload == 1)
				{
					success_popup('1',msg);
				}
				else
				{

					if (allow_associate_files == 1)
					{
						techjoomla.jQuery(".format_types",lesson_format_form).css('display','none');
						techjoomla.jQuery(format + "_subformat_options",lesson_format_form).css('display','none');

						techjoomla.jQuery('#tjlms_add_lesson_form_'+formid + ' a[href="#assocFiles_'+ formid  +'"]').closest('li').addClass('active');
						techjoomla.jQuery('#tjlms_add_lesson_form_'+formid + ' .tab-content #assocFiles_' + formid).addClass('active');
					}
					else
					{
						success_popup('1',msg);
					}
				}
			}
			else
			{
				show_lessonform_error(1,'something went wrong',lessonform);
			}
			techjoomla.jQuery('.loadingsquares',lesson_format_form).hide();
			techjoomla.jQuery('.tjlms_form_errors').hide();
		},
		error: function()
		{
				show_lessonform_error(1,'something went wrong',lessonform);
				techjoomla.jQuery('.loadingsquares',lesson_format_form).hide();
		},
		complete: function(xhr) {
			techjoomla.jQuery('.loadingsquares',lesson_format_form).hide();
		}
	});

	// always return false to prevent standard browser submit and page navigation
	return false;
}
function tjlms_addnewquiz(ele){

		var parent_mod	=	techjoomla.jQuery(ele).closest('.mod_outer');
		var parent_mod_id	=  parent_mod.attr('id');
		var mod_id	=  parent_mod_id.replace('modlist_','');
		techjoomla.jQuery('#modlist_'+mod_id+' .add_newquiz_wizard').show();
		tjiframeLoaded(mod_id,true);
		techjoomla.jQuery('html,body').animate({
				 scrollTop: techjoomla.jQuery('#modlist_'+mod_id+' .add_newquiz_wizard').offset().top - 135},
				 'slow');
		techjoomla.jQuery("#"+parent_mod_id + " .module_add").hide();

}

function tjiframeLoaded(unique, newFrame) {
	if(newFrame){
		var iFrameID =  jQuery('#modlist_' + unique + ' .add_newquiz_wizard iframe')[0];
	}else{
		var iFrameID = document.getElementById('idIframe_'+unique);
	}

	if(iFrameID) {
		// here you can make the height, I delete it first, then I make it again
		//            iFrameID.height = "";
		//            iFrameID.height = iFrameID.contentWindow.document.body.scrollHeight + "px";
		var oBody = iFrameID.contentWindow.document.body;//idIframe.document.body;
		//console.log(oBody.scrollHeight + (oBody.offsetHeight - oBody.clientHeight));
		//console.log(oBody.scrollWidth + (oBody.offsetWidth - oBody.clientWidth));
		iFrameID.height = oBody.scrollHeight + (oBody.offsetHeight - oBody.clientHeight);
		iFrameID.width = oBody.scrollWidth + (oBody.offsetWidth - oBody.clientWidth);
	}
}

function hide_add_lesson_wizard(mod_id)
{
	var module_lms	=	'modlist_'+mod_id;
	techjoomla.jQuery('#'+module_lms + " .add_lesson_wizard").hide();
	techjoomla.jQuery('#'+module_lms + " .add_quizs_wizard").hide();
	techjoomla.jQuery("#"+module_lms + " .module_actions").show();
	location.reload(true);
}
function hide_add_quizs_wizard(mod_id)
{
	var module_lms	=	'modlist_'+mod_id;
	techjoomla.jQuery('#'+module_lms + " .add_newquiz_wizard").hide();
	techjoomla.jQuery('#'+module_lms + " .add_quizs_wizard").show();
	location.reload(true);
}

/*preview of the uploaded lesson format*/
function previewlesson(thispreviewlink,lesson_id)
{
	var lesson_preview_link = root_url+ "index.php?option=com_tjlms&view=lesson&tmpl=component&lesson_id=" +  lesson_id + "&mode=preview";
	var wwidth = techjoomla.jQuery(window).width();
		var wheight = techjoomla.jQuery(window).height();
		SqueezeBox.open(lesson_preview_link, {
			handler: 'iframe',
			closable:false,
			size: {x: wwidth, y: wheight},
			//iframePreload:true,
			sizeLoading: { x: wwidth, y: wheight },
			classWindow: 'tjlms_lesson_screen',
			classOverlay: 'tjlms_lesson_screen_overlay',
		});
}

/*close preview*/
function closelesson_preview(thisclosebtn, lesson_id)
{
	techjoomla.jQuery('#tjlmslessonpreviewfor_' +lesson_id+ ' iframe').remove();
	console.log(techjoomla.jQuery("#tjlmslessonpreviewfor_"+lesson_id));
	techjoomla.jQuery("div#tjlmslessonpreviewfor_"+lesson_id).remove();
	techjoomla.jQuery(thisclosebtn).siblings('a').show();
	techjoomla.jQuery(thisclosebtn).hide();
}

/*open htmlcontentbuilder*/
function openHtmlContentbuilder1(thislink,action)
{
	var format_form	=	techjoomla.jQuery(thislink).closest('.lesson-format-form');
	var format_form_id	=	techjoomla.jQuery(format_form).attr('id');
	var form_id	=	format_form_id.replace('lesson-format-form_','')

	var lesson_id	=	techjoomla.jQuery('#lesson_id',format_form).val();

	var content_link = root_url+
							"index.php?option=com_tjlms&view=lesson&form_id="+ form_id +"&lesson_id=" + lesson_id +
							"&layout=default_html&sub_layout=creator&pluginToTrigger=' . $plugin_name . '&action="+ action +
							"&tmpl=component" ;
	var content_link1 = root_url+
	"index.php?option=com_tjlms&view=lesson&form_id="+ form_id +"&lesson_id=" + lesson_id +
	"&layout=htmlcreator&action="+ action +"&tmpl=component" ;

	var wwidth = techjoomla.jQuery(window).width()-10;
	var wheight = techjoomla.jQuery(window).height()-10;

	SqueezeBox.open(content_link, {
			handler: 'iframe',
			size: {x: wwidth, y: wheight},
			closable:false,
			onOpen:function() {

			},
			onClose:function() {
				console.log('close');
			}
		});
}

/*
*	Function helps to sort lessons pf each module.
*/
function sortLessons()
{
	techjoomla.jQuery('.LessonsInModule').sortable({
		scroll: false,
		handle:'.lessonSortingHandler',
		items: "> li:not(.non-sortable-lesson-li)",
		start: function(event, ui) {
			/*techjoomla.jQuery('.content-li').css({
				"z-index" : -1
			});*/

		},
		update: function() {

		/* get Id of the module on which the leeson is droped. */
		var mod_id = techjoomla.jQuery(this).parent().attr('id');

		var course_id	= techjoomla.jQuery("#course_id", techjoomla.jQuery(this).closest('.curriculum-container')).val();

		var lessonDiv='';
		var j=0;

			/* All Lessons ordering stored in lessonDiv along with their ID as the key. */
			techjoomla.jQuery('#'+mod_id).find('.LessonsInModule > li').each(function(j){
				j++
				lessonDiv += " "+techjoomla.jQuery(this).attr("id") + '=' + j + '&';
			});

			/* Ajax call to save the ordering. */
			techjoomla.jQuery.ajax({
						type: "POST",
						url: 'index.php?option=com_tjlms&task=lessons.saveSortingForLessons&course_id=' + course_id + '&mod_id='+mod_id,
						data: lessonDiv
			});
			hideDeleteIcon();
		}
	});
}

function hideDeleteIcon()
{
	techjoomla.jQuery(".LessonsInModule").each(function(){

		var res = techjoomla.jQuery(this).children('li');

		var mod_id = techjoomla.jQuery(this).parent('li').attr('id');

		techjoomla.jQuery("#"+ mod_id +" .moduledelete").hide();

		if (res.length == 0)
		{
			techjoomla.jQuery("#"+ mod_id +" .moduledelete").show();
		}
	});
}
/*
* This functions help to delete the module.
*/
function deleteModule(course_id,id)
{
	var comfirmDelete = confirm(Joomla.JText._('COM_TJLMS_SURE_DELETE_MODULE'));

	if(comfirmDelete == true)
	{
		jQuery.ajax({
				url: "index.php?option=com_tjlms&task=modules.deleteModule&course_id="+course_id+"&mod_id="+id,
				type: "GET",
				dataType: "json",
				success: function(msg)
				{
					console.log(msg);
					if(msg == 1)
					{
						alert(delete_success_msg);
						success_popup(course_id,delete_success_msg);
					}
					else
					return false;
				}

			});
	}
	else
	return false;
}
function success_popup(course_id,msg)
{
	//techjoomla.jQuery('#tjlmsModal .modal-body').html(msg);
	//techjoomla.jQuery('#tjlmsModal').modal('show');
	//techjoomla.jQuery('#course-modules').load("index.php?option=com_tjlms&view=modules&tmpl=component&layout=default_lessons&format=raw&course_id="+course_id);
	location.reload(true);
}

/*
* This functions help to delete the Lesson and rearrange the ordering.
*/
function deletLesson(id,course_id,mod_id,format)
{
	var comfirm_delete=confirm(delete_lesson_msg);
	if(comfirm_delete==true)
	{
		jQuery.ajax({
				url: "index.php?option=com_tjlms&task=lessons.deletLesson&course_id="+course_id+"&lesson_id="+id+"&mod_id="+mod_id,
				type: "GET",
				dataType: "json",
				success: function(msg)
				{
					if(msg==1)
					{
						if(format=='tmtQuiz'){

						alert(quiz_delete_success_msg);
						success_popup(course_id,msg);
						}
						else
						{
						alert(lesson_delete_success_msg);
						success_popup(course_id,msg);
						}
					}
					else
					return false;

				}
			});
	}
	else
	{
			return false;
	}
}


function showHideEditLesson(mod_id,lesson_id,show)
{
	var lesson_edit_li	=	'lesson_edit_li_'+ lesson_id;

	if(show == 1){
		techjoomla.jQuery('#'+lesson_edit_li).show();
		tjiframeLoaded(lesson_id);
		techjoomla.jQuery('.editmodulelink', '#lessonlist_' + lesson_id).hide();
	}
	else
	{
		techjoomla.jQuery('#'+lesson_edit_li).hide();
		techjoomla.jQuery('.editmodulelink', '#lessonlist_' + lesson_id).show();
		location.reload(true);
	}
}
function hide_edit_lesson_wizard(lesson_id)
{
	var lesson_edit_li	=	'lesson_edit_li_'+ lesson_id;
	techjoomla.jQuery('#'+lesson_edit_li).hide();
}
function editModule(course_id,mod_id)
{

	if(mod_id > 0){
		var module_lms	=	'modlist_'+mod_id;
		techjoomla.jQuery('#'+module_lms + " .tjlms_module").hide();
		techjoomla.jQuery('#'+module_lms + " .module-edit-form").show();
		techjoomla.jQuery('.module-title').focus();
	}
	else{
		var add_modulefor_course	=	'add_module_form_'+course_id
		techjoomla.jQuery('#'+add_modulefor_course).show();
		techjoomla.jQuery('.add-module-div').hide();
		techjoomla.jQuery('.module-title').focus();
	}
	return false;
}
function changeState(mod_id,state,name)
{
	var p_msg  = Joomla.JText._('COM_TJLMS_MODULE_PUBLISHED_SUCCESSFULLY');
	var up_msg = Joomla.JText._('COM_TJLMS_MODULE_UNPUBLISHED_SUCCESSFULLY');
	jQuery.ajax({
			url: "index.php?option=com_tjlms&task=modules.changeState&mod_id="+mod_id+"&state="+state,
			type: "GET",
			dataType: "json",
			success: function(msg)
			{
				if(msg == 1){
					if (state == 1)
					{
						alert(name+p_msg);
					}
					else
					{
						alert(name+up_msg);
					}
					success_popup(course_id,'');
				}
				else
				return false;
			},
			error: function(msg)
			{
				alert('Something went wrong');
			}


		});
}
function hideeditModule(course_id,mod_id)
{
	if(mod_id > 0){
		var module_lms	=	'modlist_'+mod_id;
		techjoomla.jQuery('#'+module_lms + " .tjlms_module").show();
		techjoomla.jQuery('#'+module_lms + " .module-edit-form").hide();
	}
	else{
		var add_modulefor_course	=	'add_module_form_'+course_id;
		techjoomla.jQuery('#'+add_modulefor_course).hide();
		techjoomla.jQuery('.add-module-div').show();
	}
	return false;
}
function show_lessonform_error(show,msg,addlessonform)
{
	if(show	== 1)
	{
		techjoomla.jQuery(".tjlms_form_errors .msg", addlessonform).html(msg);
		techjoomla.jQuery(".tjlms_form_errors", addlessonform).html(msg);
		techjoomla.jQuery(".tjlms_form_errors", addlessonform).show();
		techjoomla.jQuery(".tjlms_form_errors .msg", addlessonform).show();
	}
	else
	{
		techjoomla.jQuery(".tjlms_form_errors", addlessonform).hide();
	}

}
function checkforuploadedformat(addlessonformatform)
{
	if(techjoomla.jQuery("#lesson_format_id",addlessonformatform).val() == 0)
		return false;
	else
		return true;
}
function checkifFileisPendingforUpload(format,format_lesson_form)
{

	var input_for_file	=   format+"_upload";
	var file	=	techjoomla.jQuery("#lesson_format #"+format + " #"+input_for_file, format_lesson_form)[0].files[0];
	return file;

}

/*Get the all the plugins for selected format
 * formatid can be video, tincanlrs or document
 * form_id is the unique id appended to id of each lesson form
 * */
function lesson_format(formatid,form_id)
{
	var format_lesson_form	= techjoomla.jQuery('#lesson-format-form_'+form_id);
	//var formatsWithTjplugin = ['video','document','tincanlrs','textmedia'];

	techjoomla.jQuery('#lesson_format_msg',format_lesson_form).hide();

	var mod_les_arr = form_id.split("_");
	var mod_id = mod_les_arr[0];

	//var lesson_id = mod_les_arr[1];

	var lesson_id = techjoomla.jQuery('#lesson_id',format_lesson_form).val();;

	techjoomla.jQuery('#lesson_format .lesson_format', format_lesson_form).hide();

	/*If selected format has plugins written for it*/
	//if(techjoomla.jQuery.inArray(formatid, formatsWithTjplugin) > -1)
	{
		techjoomla.jQuery.ajax({
			url: "index.php?option=com_tjlms&task=modules.getSubFormats&lesson_format="+formatid,
			type: "GET",
			dataType: "json",
			beforeSend: function() {
				loadingImage(format_lesson_form);
				changeformatbtnstate(form_id,1);
			},
			success: function(data)
			{
				if(data.result == 1)
				{
					if(data.html == '')
					{
						techjoomla.jQuery('#'+formatid+' .lesson_format_msg',format_lesson_form).show();
					}
					else
					{
						formatdata = data.html;
						datahtml = '<select id="lesson_format'+formatid+'_subformat" name="lesson_format['+formatid+'_subformat]" class="class_'+formatid+'_subformat" onchange="getsubFormatHTML(\''+form_id+'\',\''+formatid+'\','+mod_id+','+lesson_id+',this.value);">';
						for (i=0;i<formatdata.length;i++)
						{
							var selected_opt = '';

							datahtml += '<option value="'+formatdata[i].id+ '" ' +selected_opt+ '>'+formatdata[i].name+'</option>';
						}
						datahtml += '</select>';
						techjoomla.jQuery('#'+formatid+'_subformat_options',format_lesson_form).html(datahtml);

						if(formatdata.length == 1){
							techjoomla.jQuery('#'+formatid+'_subformat_options',format_lesson_form).parent().hide();
						}
						else{
							techjoomla.jQuery('#'+formatid+'_subformat_options',format_lesson_form).parent().show();
						}

						var subformat = techjoomla.jQuery('#lesson_format'+formatid+'_subformat',format_lesson_form).val();
						techjoomla.jQuery('#jform_subformat',format_lesson_form).val(subformat);

						getsubFormatHTML(form_id,formatid,mod_id,lesson_id,subformat);
					}
				}
				else
				{
					console.log('something went wrong11');
					//show_lessonform_error(1,'something went wrong',lessonform);
				}
			},
			error: function() {
				console.log('something went wrong');
			},
		});
	}
	// make the format link active
	techjoomla.jQuery('.format_types a',format_lesson_form).removeClass('active');
	techjoomla.jQuery('.format_types a.' + formatid, format_lesson_form).addClass('active');

	//populate the hidden field with selected format
	techjoomla.jQuery('#jform_format',format_lesson_form).val(formatid);

	/*techjoomla.jQuery('#lesson_format',format_lesson_form).show();

	// First hide all divs with class lesson_format
	// and then Only show div having id as selected format
	techjoomla.jQuery('#lesson_format .lesson_format',format_lesson_form).hide();
	techjoomla.jQuery('#lesson_format .lesson_format[id="'+formatid+'"]',format_lesson_form).show();*/
}

/*respective HTML to show depending on sub format...*/
function getsubFormatHTML(form_id,format,mod_id,lesson_id,subformat)
{
	var format_lesson_form = techjoomla.jQuery('#lesson-format-form_'+form_id);

	techjoomla.jQuery('#lesson-format-form_'+form_id + ' #jform_subformat').val(subformat);
	techjoomla.jQuery.ajax({
		/*url: "index.php?option=com_tjlms&task=modules.getSubFormatHTML&lesson_format="+format+"&lesson_subformat="+thiselementval+"&mod_id="+mod_id+"&lesson_id="+lesson_id+"&media_id="+formatMediaId,*/
		url: "index.php?option=com_tjlms&task=modules.getSubFormatHTML&lesson_id="+lesson_id+"&lesson_format="+format+"&lesson_subformat="+subformat,
		type: "GET",
		dataType: 'text',
		beforeSend: function() {
			loadingImage(format_lesson_form);
			changeformatbtnstate(form_id,1);
		},
		success: function(data) {
			var output = techjoomla.jQuery.parseJSON(data);
			var res	 =	output['result'];
			var html	=	output['html'];
			if(res == 1)
			{
				techjoomla.jQuery('#lesson_format',format_lesson_form).show();

				// First hide all divs with class lesson_format
				// and then Only show div having id as selected format
				techjoomla.jQuery('#lesson_format .lesson_format',format_lesson_form).hide();

				techjoomla.jQuery('.'+format+'_subformat',format_lesson_form).html(html);
				techjoomla.jQuery('.'+format+'_subformat',format_lesson_form).show();
				techjoomla.jQuery('.lesson_format#'+ format, format_lesson_form).show();
				hideImage(format_lesson_form);
			}
			else
			{
				console.log('something went wrong');
				show_lessonform_error(1,'something went wrong',format_lesson_form);
			}
		},
		error: function() {
			console.log('something went wrong');
			//show_lessonform_error(1,'something went wrong',format_lesson_form);
		},
		complete: function(xhr) {
			hideImage(format_lesson_form);
			changeformatbtnstate(form_id,0);
		}
	});
}

function formInputsWithoutScript(givenform)
{
	techjoomla.jQuery('input[type=text], textarea',givenform).each(
    function(){
        var input = techjoomla.jQuery(this);
		var noScriptVal = noScript(input.val())
        techjoomla.jQuery(this).val(noScriptVal);
		}
	);

}

/*TO remove the script tags from str*/
function noScript(str)
{
	var div = techjoomla.jQuery('<div>').html(str);
	div.find('script').remove();

	var noscriptStr = str = div.html();
	return noscriptStr;
}

/*Validate date in this format yyyy:mm:dd*/
function isValidDate(dateVal)
{
	dateVal = dateVal.split(" ");
	var validDate = dateVal[0].match(/^\d{4}[-](0?[1-9]|1[012])[-](0?[1-9]|[12][0-9]|3[01])$/);
	if (validDate !=  null)
	{
		return true;
	}
	return false;
}

