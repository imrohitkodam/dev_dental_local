techjoomla.jQuery(document).ready(function(){
	techjoomla.jQuery('#j-sidebar-container').closest('.row-fluid').addClass('tjlms-wrapper');
});
