<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      TechJoomla <extensions@techjoomla.com> - http://www.techjoomla.com
 */

// no direct access
defined('_JEXEC') or die;
include_once JPATH_COMPONENT.'/js_defines.php';
JHtml::script(JUri::root().'administrator/components/com_tmt/assets/js/ajax_file_upload.js');
JHtml::script(JUri::root().'administrator/components/com_tjlms/assets/js/tjlms.js');
JHtml::script(JUri::root().'administrator/components/com_tjlms/assets/js/ajax_file_upload.js');
$jinput = JFactory::getApplication()->input;
$view = $jinput->get('view', '', 'string');
if ($view == 'enrolment')
{
	$filepath = JUri::root() . 'administrator/components/com_tjlms/csv/userDataSingle.csv';
}
else
{
	$filepath = JUri::root() . 'administrator/components/com_tjlms/csv/userData.csv';
}
?>
<div id="tjlms_import-csv" class="tjlms-wrapper row-fluid">
	<div id="import" style="width:80%" class="modal hide fade form-horizontal"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel"><?php echo JText::_("COM_TJLMS_ENROLLMENT_CSV_UPLOAD_FILE");?></h3>
		</div>
		<div class="control-group" >
				<div class="control-label"><?php echo JText::_("COM_TJLMS_ENROLLMENT_CSV_SELECT_FILE");?></div>
				<div class="controls">
					<div class="fileupload fileupload-new pull-left" data-provides="fileupload">
						<div class="input-append">
							<div class="uneditable-input span4">
								<span class="fileupload-preview">
									<?php echo JText::_("COM_TJLMS_ENROLLMENT_CSV_IMPORT_FILE");?>
								</span>
							</div>
							<span class="btn btn-file">
								<span class="fileupload-new"><?php echo JText::_("COM_TJLMS_BROWSE");?></span>
								<input type="file" id="user-csv-upload" name="question-csv-upload" onchange="validate_file(this,'','userImport')">
							</span>
						</div>
					</div>
					<div style="clear:both"></div>
				</div>
			</div>
			<hr class="hr hr-condensed">
			<div class="help-block center">
				<?php
					$link = '<a href="' . $filepath . '">' . JText::_("COM_TJLMS_ENROLLMENT_CSV_SAMPLE") . '</a>';
				echo JText::sprintf('COM_TJLMS_ENROLLMENT_CSVHELP', $link);
				?>
			</div>
			<hr class="hr hr-condensed">
		</div>
	</div>

<?php

