<?php
/**
 * @package	Jticketing
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */

// no direct access
	defined('_JEXEC') or die('Restricted access');
jimport('joomla.filesystem.file');

require_once JPATH_SITE . "/components/com_tjlms/helpers/emogrifier.php";
require_once JPATH_ADMINISTRATOR . "/components/com_tjlms/certificate.php";

$app = JFactory::getApplication();
?>

<div class="<?php echo COM_TJLMS_WRAPPER_DIV ?>">

	<form method="POST" name="adminForm" action="" id="adminForm">
		<?php
			ob_start();
			include JPATH_BASE . '/components/com_tjlms/layouts/header.sidebar.php';
			$layoutOutput = ob_get_contents();
			ob_end_clean();
			echo $layoutOutput;
		?> <!--// JHtmlsidebar for menu ends-->

		<div class="tjlms-tbl row-fluid">
				<div class="span9"><?php
						//Code to Read CSS File
						if(!function_exists('mb_convert_encoding'))		// condition to check if mbstring is enabled
						{
							echo JText::_("MB_EXT");
							$emorgdata = $certificate['message_body'];
						}
						else
						{
							$cssfile = JPATH_SITE.DS."components".DS."com_tjlms".DS."assets".DS."css".DS."certificate.css";
							$cssdata = file_get_contents($cssfile);
							//End Code to Read CSS File

							$emogr = new Emogrifier($certificate['message_body'],$cssdata);
							$emorgdata = $emogr->emogrify();
						}
						$editor      =JFactory::getEditor();
						echo $editor->display("data[message_body]",stripslashes($emorgdata),670,600,60,20,true);
						?>
				</div>
				<div class="span3">
						<table>
							<tr>
								<td colspan="2"><div class="alert alert-info"><?php echo JText::_('COM_TJLMS_CSS_EDITOR_MSG') ?> <br/></div>
									<textarea name="data[template_css]" rows="10" cols="90"><?php echo trim($cssdata); ?></textarea>
								</td>
							</tr>
							<tr>
								<td colspan="2"><div class="alert alert-info"><?php echo JText::_('COM_TJLMS_EB_TAGS_DESC') ?> <br/></div>
												</tr>

							<tr>
								<td width="30%"><b>&nbsp;&nbsp;[STUDENTNAME] </b> </td>
								<td><?php echo JText::_('COM_TJLMS_TAG_STUDENTNAME'); ?></td>
							</tr>
							<tr>
								<td width="30%"><b>&nbsp;&nbsp;[STUDENTUSERNAME] </b> </td>
								<td><?php echo JText::_('COM_TJLMS_TAG_STUDENTUSERNAME'); ?></td>
							</tr>

							<tr>
								<td><b>&nbsp;&nbsp;[COURSE]</b></td>
								<td><?php echo JText::_('COM_TJLMS_TAG_COURSE'); ?></td>

							</tr>
							<tr>
								<td><b>&nbsp;&nbsp;[DATE]</b></td>
								<td><?php echo JText::_('COM_TJLMS_TAG_DATE'); ?></td>

							</tr>
						</table>
					</div>
				</div>
				<?php
				if(JVERSION < "1.6.0"){
					echo "<strong>".JText::_("EB_EDITOR_NOT_LOADING_NOTICE")."</strong>";
				}


				?>

				<input type="hidden" name="option" value="com_tjlms" />
				<input	type="hidden" name="task" value="save" />
				<input type="hidden"	name="controller" value="certificate" />
				<input type="hidden"	name="view" value="certificate" />
				<?php echo JHTML::_( 'form.token' ); ?>

			</div><!--j-main-container ENDS-->
	</form>
</div> <!--techjoomla-bootstrap-->


