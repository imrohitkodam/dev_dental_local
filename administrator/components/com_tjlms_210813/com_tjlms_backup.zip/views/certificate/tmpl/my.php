<?php
/**
 * @package	Jticketing
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */

// No direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filesystem.file');

require_once JPATH_SITE . "/components/com_tjlms/helpers/emogrifier.php";
require_once JPATH_ADMINISTRATOR . "/components/com_tjlms/certificate.php";

$app = JFactory::getApplication();
if (!empty($this->Items))
{?>
<div class="<?php echo COM_TJLMS_WRAPPER_DIV ?>">
	<form method="POST" name="adminForm" action="" id="adminForm">
		<?php
			ob_start();
			include JPATH_BASE . '/components/com_tjlms/layouts/header.sidebar.php';
			$layoutOutput = ob_get_contents();
			ob_end_clean();
			echo $layoutOutput;
			?>
		<div class="tjlms-tbl row-fluid">
			<div class="span9">
				<?php
					$template_body = $this->Items[0]->body;
					$cssdata = $this->Items[0]->css;
					$editor      =JFactory::getEditor();
					echo $editor->display("data[message_body]", stripslashes($template_body),670,600,60,20,true);
					/* JHtmlsidebar for menu ends */
					?>
			</div>
			<div class="span3">
				<table>
					<tr>
						<td colspan="2">
							<div class="alert alert-info"><?php echo JText::_('COM_TJLMS_CSS_EDITOR_MSG') ?> <br/></div>
							<textarea name="data[template_css]" rows="10" cols="90"><?php echo trim($cssdata); ?></textarea>
						</td>
					</tr>
					<tr>
						<td colspan="2">
							<div class="alert alert-info"><?php echo JText::_('COM_TJLMS_EB_TAGS_DESC') ?> <br/></div>
						</td>
					</tr>
					<tr>
						<td width="30%"><b>&nbsp;&nbsp;[STUDENTNAME] </b> </td>
						<td><?php echo JText::_('COM_TJLMS_TAG_STUDENTNAME'); ?></td>
					</tr>
					<tr>
						<td width="30%"><b>&nbsp;&nbsp;[STUDENTUSERNAME] </b> </td>
						<td><?php echo JText::_('COM_TJLMS_TAG_STUDENTUSERNAME'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[COURSE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_COURSE'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[DATE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_DATE'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[COURSE_TOTAL_TIME_SPENT]</b></td>
						<td><?php echo JText::_('COURSE_TOTAL_TIME_SPENT'); ?></td>
					</tr>

					<tr>
						<td><b>&nbsp;&nbsp;[COURSE_COMPLETION_DATE]</b></td>
						<td><?php echo JText::_('COURSE_COMPLETION_DATE'); ?></td>
					</tr>

					<tr>
						<td><b>&nbsp;&nbsp;[ES_PROF_REG]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_ES_PRN'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[TJFIELD_CPD_HOURS]</b></td>
						<td><?php echo JText::_('COM_TJFIELD_CPD_HOURS'); ?></td>
					</tr>

					<tr>
						<td><b>&nbsp;&nbsp;[TJFIELD_GDC_RECOMMENDED_TOPIC]</b></td>
						<td><?php echo JText::_('COM_TJFIELD_GDC_RECOMMENDED_TOPIC'); ?></td>
					</tr>

					<tr>
						<td><b>&nbsp;&nbsp;[TJFIELD_GDC_HIGHLY_RECOMMENDED_SUBJECT]</b></td>
						<td><?php echo JText::_('COM_TJFIELD_GDC_HIGHLY_RECOMMENDED_SUBJECT'); ?></td>
					</tr>
				</table>
			</div>
		</div>
		<?php
			if(JVERSION < "1.6.0")
			{
				echo "<strong>".JText::_("EB_EDITOR_NOT_LOADING_NOTICE")."</strong>";
			}
			?>
		<input type="hidden" name="option" value="com_tjlms" />
		<input	type="hidden" name="task" value="save_custom" />
		<input type="hidden"	name="controller" value="certificate" />
		<input type="hidden"	name="view" value="certificate" />
		<?php echo JHTML::_( 'form.token' ); ?>
	</form>
</div>
<?php }
else
{
	ob_start();
	include JPATH_BASE . '/components/com_tjlms/views/certificate/tmpl/default.php';
	$layoutOutput = ob_get_contents();
	ob_end_clean();
	echo $layoutOutput;
}
