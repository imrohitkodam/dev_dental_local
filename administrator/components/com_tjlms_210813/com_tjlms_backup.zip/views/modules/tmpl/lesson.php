<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      TechJoomla <extensions@techjoomla.com> - http://www.techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;
JHTML::_('behavior.modal', 'a.modal');

$params	=	$this->params;
$this->form	=	$this->lessonform;

$form_id = $mod_id;
if(!empty($lesson))
{
	$this->form->bind($lesson);
	$lesson_id  = $lesson->id;
	$form_id .= '_'.$lesson_id;
}
else
{
	$this->form->reset();
	$lesson_id = 0;
/*$format = 'video';
$format = 'tjlms'.$format;
$comp_params = $params;
JPluginHelper::importPlugin($format);
$dispatcher = JDispatcher::getInstance();
$videoSubFormats_HTML = $dispatcher->trigger( 'getSubFormat_ContentHTML',array($mod_id , $lesson_id, $lesson, $comp_params)); //Call the plugin and get the result
*/

}
$course_id	= $this->course_id;
$allow_paid_courses = $params->get('allow_paid_courses','0','INT');

?>
<div class="form-horizontal tjlms_add_lesson_form" id="tjlms_add_lesson_form_<?php echo $form_id;?>">
	<fieldset>
		<?php if($lesson_id == 0){ ?>
			<legend><h2><?php echo JText::_('COM_TJLMS_TITLE_ADD_LESSON')?></h2></legend>
		<?php } ?>
		<div class="tjlms_form_errors alert alert-danger">
			<div class="msg"></div>
		</div>

		<?php echo JHtml::_('bootstrap.startTabSet', 'tjlmsTab_'.$form_id, array('active' => 'general_'.$form_id)); ?>

		<?php echo JHtml::_('bootstrap.addTab', 'tjlmsTab_'.$form_id, 'general_'.$form_id, JText::_('COM_TJLMS_TITLE_LESSON_DETAILS', true)); ?>

			<?php
				// echo $this->loadTemplate('basic');
				$basic = '';
				$tjlmshelperObj	=	new comtjlmsHelper();
				$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','default_basic','ADMIN','ADMIN');
				ob_start();
				include($layout);
				$basic.= ob_get_contents();
				ob_end_clean();
				echo $basic;
			?>


			<!--GENERAL TAB ENDS-->
		<?php echo JHtml::_('bootstrap.endTab'); ?>

		<?php echo JHtml::_('bootstrap.addTab', 'tjlmsTab_'.$form_id, 'format_'.$form_id, JText::_('COM_TJLMS_TITLE_LESSON_FORMAT', true)); ?>

				<?php
					//echo $this->loadTemplate('format');
					$format='';
					$tjlmshelperObj	=	new comtjlmsHelper();
					$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','default_format','ADMIN','ADMIN');
					ob_start();
					include($layout);
					$format.= ob_get_contents();
					ob_end_clean();
					echo $format;
				?>
		<?php echo JHtml::_('bootstrap.endTab'); ?>

		<!--ASSOCIATE FILES STARTS-->
		<?php $allowAssocFiles = $params->get('allow_associate_files','0','INT'); ?>

		<?php if ($allowAssocFiles == 1): ?>

			<?php echo JHtml::_('bootstrap.addTab', 'tjlmsTab_'.$form_id, 'assocFiles_'.$form_id, JText::_('COM_TJLMS_TITLE_LESSON_ASSOCIATE_FILES', true)); ?>

				<?php
					//echo $this->loadTemplate('format');
					$assoFile = '';
					$tjlmshelperObj	=	new comtjlmsHelper();
					$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','default_associatefiles','ADMIN','ADMIN');
					ob_start();
					include($layout);
					$assoFile .= ob_get_contents();
					ob_end_clean();
					echo $assoFile;
				?>

			<?php echo JHtml::_('bootstrap.endTab'); ?>

		<?php endif; ?>
			<!--ENDS-->

	<?php echo JHtml::_('bootstrap.endTabSet'); ?>
	</fieldset>
</div>


