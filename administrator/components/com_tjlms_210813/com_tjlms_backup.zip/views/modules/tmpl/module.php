<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Aniket <aniket_c@tekdi.net> - http://www.techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;
?>

<form action="<?php echo JRoute::_('index.php?option=com_tjlms&view=modules&course_id='. $this->course_id); ?>" name="add-module-form" class="tjlms_module_form" id="tjlms_module_form_<?php echo $mod_id;?>" method="POST" onsubmit="return false;">
	<div class="tjlms_module_errors alert alert-danger">
		<div class="msg"></div>
	</div>

	<input type="hidden" value="<?php	echo	$mod_id;	?>" name="tjlms_module[id]" id="mod_id">
	<input type="hidden" value="<?php	echo	$course_id;	?>" name="tjlms_module[course_id]" id="course_id">
	<div class="manage-fields-wrapper add-module-style">
		<div id="form-item-title" class="row-fluid non-labeled">
			<div class="span2 module-title-lable tjlms_text_right">
				<?php echo JText::_("COM_TJLMS_FORM_LBL_TJMODULE_NAME").' : ';?>
			</div>
			<div style=" " class="span10 tooltip-reference" id="tooltip-reference-title">
				<input type="text" value="<?php	echo $mod_name;	?>" maxlength="80" data-show-counter="1" data-max-length="80" class="text-input ch-count-field ud-textinput input-block-level module-title" name="tjlms_module[name]" id="title" >
				<span class="ch-count" id="title-counter">64</span>
			</div>
		</div>
	</div>
	<div class="row-fluid">
		<div class="span2"></div>
		<div class="span10 submit-row">
			<input type="button" data-loading-text="Save Section" class="btn btn-primary" value="<?php echo JText::_("COM_TJLMS_SAVE_MODULE")?>" onclick="moduleactions(this,'module.save')">

			<!--<a data-wrapcss="static-content-wrapper" class="cancel-link" onclick="hideeditModule('<?php echo $course_id; ?>','<?php echo $mod_id; ?>')"> cancel </a>-->
			<a data-wrapcss="static-content-wrapper" class="cancel-link btn btn-primary" onclick="moduleactions(this,'module.cancel' ,'<?php echo $mod_name; ?>')"> <?php echo JText::_("COM_TJLMS_CANCEL_BUTTON")?> </a>

			<span class="ajax-loader-tiny js-bottom-loader hidden"></span>
		</div>
	</div>
	<input type="hidden" value="<?php	echo $mod_state;	?>" name="tjlms_module[state]">
	<input type="hidden" name="option" value="com_tjlms" />
	<input type="hidden" name="task" id="task" value="" />

	<?php echo JHtml::_('form.token'); ?>
</form>
