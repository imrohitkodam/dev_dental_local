<?php
/**
 * @version    SVN: <svn_id>
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access.
defined('_JEXEC') or die;

	$input = JFactory::getApplication()->input;

	foreach($this->moduleData as $moduleData)
	{
		$modUnpubClass = '';

		if ($moduleData->state != 1)
		{
			$modUnpubClass = 'modUnpublish';
		}
	?>
		<!--Here the LI represents all modules in a particular course-->
		<li id="modlist_<?php	echo	$moduleData->id;	?>" class=" mod_outer ">
			<div class="row-fluid tjlms_module <?php echo $modUnpubClass; ?>">

				<div class="content-li   span10">
					<i class="icon-menu moduleSortingHandler" title="<?php echo JText::_('COM_TJLMS_SORT_MODULE'); ?>"></i>
					<i class="icon-book icon-white"></i><span class="tjlms_module_title"><?php	echo $moduleData->name;	?></span>
				</div>
				<div class="tjlms-actions btn-group non-accordian span2" >
					<div class="module-functionality-icons row-fluid" >
						<!--STATE MODULE BUTTON-->
						<a class="module_state" title="<?php echo ($moduleData->state == 0) ? JText::_('COM_TJLMS_MODULE_CHANGE_STATE_PUBLISH') : JText::_('COM_TJLMS_MODULE_CHANGE_STATE_UNPUBLISH'); ?>" onclick="changeState('<?php echo $moduleData->id; ?>',<?php echo ($moduleData->state == 1) ? '0' : '1';?>,'<?php echo $moduleData->name; ?>')">
							<i class="<?php echo ($moduleData->state == 1) ? 'icon-publish' : 'icon-unpublish';?>"></i>
						</a>
						<!--EDIT MODULE BUTTON-->
						<a class="editmodulelink" title="<?php echo JText::_('COM_TJLMS_EDIT_MODULE'); ?>" onclick="editModule('<?php echo $this->course_id; ?>','<?php echo $moduleData->id; ?>')">
							<span class="icon-edit"></span>
						</a>
						<?php
						$deleteBtnCLass = 'tjlms_display_none';

						if(count($moduleData->lessons) == 0)
						{
							$deleteBtnCLass = "";
						} ?>
						<!--DELETE MODULE BUTTON-->
						<a class="moduledelete <?php echo $deleteBtnCLass; ?>" title="<?php echo JText::_('COM_TJLMS_MODULE_DELET'); ?>" onclick="deleteModule('<?php echo $this->course_id; ?>','<?php	echo $moduleData->id;	?>');" >
							<span class="icon-trash"></span>
						</a>

					</div>
				</div>
			</div>
			<div class="module-edit-form editing">
				<?php
					$module_html='';
					$mod_id = $moduleData->id;
					$mod_name = $moduleData->name;
					$mod_state = $moduleData->state;
					$course_id	= $this->course_id;
					$tjlmshelperObj	=	new comtjlmsHelper();
					$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','module','ADMIN','ADMIN');
					ob_start();
					include($layout);
					$module_html.= ob_get_contents();
					ob_end_clean();
					echo $module_html;
				?>
			</div>
			<!--UL containing all lessons of a modules-->
			<ul id="curriculum-lesson-ul_<?php echo $moduleData->id; ?>" class="LessonsInModule connectedSortable curriculum-lesson-ul">
				<?php
				if(!empty($moduleData->lessons))
				{
					foreach($moduleData->lessons as $m_lesson)
					{

						$m_lesson_status_class	=	'unpublished';
						if( $m_lesson->format == '')
							$m_lesson_status_class	=	'no_content';
						else if($m_lesson->state == 1)
							$m_lesson_status_class	=	'published';
						else
							$m_lesson_status_class	=	'unpublished';

					?>
						<!--LI for lessons-->
						<li id="lessonlist_<?php if($m_lesson->format != 'tmtQuiz') echo $m_lesson->id; else echo $m_lesson->id; ?>" class="curriculum-lesson-li <?php echo $m_lesson_status_class;?>" onchange="sortLessons(this.id,<?php	echo $moduleData->id;	?>)" style="padding: 0.4em;">
							<ul class="unstyled_list non-sortable-lesson-li">
								<li class="lesson_main_li non-sortable-lesson-li">
									<i class="icon-menu lessonSortingHandler" title="<?php echo JText::_('COM_TJLMS_SORT_LESSON'); ?>"></i>
									<?php if($m_lesson->format != ''){ ?>

										<img class="" alt="<?php echo $m_lesson->format; ?>" title="<?php echo $m_lesson->format; ?>" src="<?php echo JUri::root().'media/com_tjlms/images/default/icons/'.$m_lesson->format.'.png';?>"/>

									<?php }else{ ?>

										<img class="" src="<?php echo JUri::root().'media/com_tjlms/images/default/icons/noformat.png';?>"/>

									<?php } ?>
									<span class="title"><?php echo $m_lesson->name;?></span>
									<div class="tjlms-actions" style="float:right; ">

										<!--<a class="marginLeftOf5" title="<?php echo JText::_('COM_TJLMS_EDIT_LESSON'); ?>" href="index.php?option=com_tjlms&view=lesson&layout=edit&id=<?php	echo	$m_lesson->id;	?>&course_id=<?php	echo $input->get('course_id',0,'INT');	?>&mod_id=<?php	echo $moduleData->id;	?>" >
											<span class="icon-edit"></span>
										</a>
										<a class="marginLeftOf5" title="<?php echo JText::_('COM_TJLMS_LESSON_DELET'); ?>" href="#" onclick="deletLesson('<?php	echo $m_lesson->id;	?>','<?php	echo $this->course_id;	?>','<?php	echo $moduleData->id;	?>');" >
											<span class="icon-trash"></span>
										</a>-->

										<!--EDIT LESSON BUTTON-->
										<a class="editmodulelink" title="<?php if($m_lesson->format != 'tmtQuiz') echo JText::_('COM_TJLMS_EDIT_LESSON'); else echo JText::_('COM_TJLMS_EDIT_QUIZ'); ?>" onclick="showHideEditLesson('<?php	echo $moduleData->id;	?>','<?php if($m_lesson->format != 'tmtQuiz') echo $m_lesson->id; else echo $m_lesson->id ?>',1);">
											<span class="icon-edit"></span>
										</a>
										<!--DELETE LESSON BUTTON-->
										<a class="" title="<?php if($m_lesson->format != 'tmtQuiz') echo JText::_('COM_TJLMS_LESSON_DELET'); else echo JText::_('COM_TJLMS_QUIZ_DELET'); ?>" onclick="deletLesson('<?php	echo $m_lesson->id;	?>','<?php	echo $this->course_id;	?>','<?php	echo $moduleData->id;	?>','<?php echo $m_lesson->format; ?>');"  >
											<span class="icon-trash"></span>
										</a>

									</div>
									<div style="clear:both"></div>
								</li>
								<?php if($m_lesson->format != 'tmtQuiz'){ ?>
								<li class="lesson_edit_li" id="lesson_edit_li_<?php echo $m_lesson->id ?>">
										<?php
											$lesson_html='';
											$mod_id = $moduleData->id;
											$lesson = $m_lesson;
											$tjlmshelperObj	=	new comtjlmsHelper();
											$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','lesson','ADMIN','ADMIN');
											ob_start();
											include($layout);
											$lesson_html.= ob_get_contents();
											ob_end_clean();
											echo $lesson_html;
										?>
								</li>
								<?php }else{ ?>
									<li class="lesson_edit_li" id="lesson_edit_li_<?php echo $m_lesson->id ?>" >
									<iframe id="idIframe_<?php echo $m_lesson->id ?>" frameborder="0" width="100%" src='index.php?option=com_tmt&view=test&id=<?php echo $m_lesson->quiz_id ?>&tmpl=component&addquiz=1&course_id=<?php echo JFactory::getApplication()->input->get('course_id',0,'INT');?>&mod_id=<?php echo $moduleData->id ?>&unique=<?php echo $m_lesson->id; ?>'></iframe>
									</li>
								<?php } ?>
							</ul>

						</li>
			<?php
					}
				}
				?>

			</ul><!--UI for lessons ends-->

			<div class="module_actions module_add row-fluid">
				<ul>
					<li class="span6">
						<span class="action btn btn-add-lesson" title="<?php echo JText::_('COM_TJLMS_TITLE_ADD_LESSON'); ?>">
							<?php echo JText::_('COM_TJLMS_TITLE_ADD_LESSON'); ?>
						</span>
					</li>
					<?php if ($this->quiz_init ){ ?>
					<li class="span6" >
						<span class="action btn <?php if($this->one_quiz != '0'){ ?>btn-add-lesson btn-add-quizs <?php } ?>" <?php if($this->one_quiz == '0'){ ?> onclick="tjlms_addnewquiz(this);" <?php } ?> title="<?php echo JText::_('COM_TJLMS_ADD_QUIZ'); ?>">
							<?php echo JText::_('COM_TJLMS_ADD_QUIZ'); ?>
						</span>
					</li>
					<?php } ?>
				</ul>
			</div>
			<?php if ($this->quiz_init ){ ?>
			<ul class="unstyled_list module_actions1 add_quizs_wizard module_add" style="display:none;">
				<li>
					<?php if($this->one_quiz != '0'){ ?>
					<div class="span5">
						<span onclick="opentjlmsSqueezeBox('index.php?option=com_tmt&view=tests&tmpl=component&addquiz=1&course_id=<?php echo $moduleData->course_id; ?>&mod_id=<?php echo $moduleData->id; ?>')" class="btn btn-info quizaction btn btn-add-existquiz" title="<?php echo JText::_('COM_TJLMS_ADD_EXISTQUIZ'); ?>">
							<?php echo JText::_('COM_TJLMS_ADD_EXISTQUIZ'); ?>
						</span>
					</div>
				<?php } ?>
					<div class="span5" >
						<span onclick="tjlms_addnewquiz(this);" class="btn btn-primary quizaction btn btn-add-newquiz" title="<?php echo JText::_('COM_TJLMS_ADD_NEWQUIZ'); ?>">
							<?php echo JText::_('COM_TJLMS_ADD_NEWQUIZ'); ?>
						</span>
					</div>
					<div class="span2" >
						<button type="button" class="btn btn-danger" onclick="hide_add_lesson_wizard('<?php echo $moduleData->id; ?>')" ><?php echo JText::_('COM_TJLMS_ADD_QUIZ_CANCEL'); ?></button>
					</div>
					<div style="clear:both"></div>
				</li>
			</ul>
			<ul class="unstyled_list">
			  <li>
				<div class="add_newquiz_wizard" style="display:none;">

					<iframe id="idIframe_<?php echo $moduleData->id; ?>" frameborder="0" width="100%" src='index.php?option=com_tmt&view=test&tmpl=component&addquiz=1&course_id=<?php echo JFactory::getApplication()->input->get('course_id',0,'INT');?>&mod_id=<?php echo $moduleData->id ?>&unique=<?php echo $moduleData->id; ?>'></iframe>
				</div>
			  </li>
			 </ul>
			<?php } ?>

			<ul class="unstyled_list">
				<li>
					<div class="add_lesson_wizard" style="display:none;">

							<?php
								$lesson_html='';
								$mod_id = $moduleData->id;
								$lesson = '';
								$tjlmshelperObj	=	new comtjlmsHelper();
								$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','lesson','ADMIN','ADMIN');
								ob_start();
								include($layout);
								$lesson_html .= ob_get_contents();
								ob_end_clean();
								echo $lesson_html;
							?>
					</div>
				</li>
			</ul>


		</li><!--LI for each module ends-->
<?php
	}
