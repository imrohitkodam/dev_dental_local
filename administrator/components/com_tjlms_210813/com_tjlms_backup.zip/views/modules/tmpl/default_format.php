<?php
/**
 * @version    SVN: 539
 * @package    Shika
 * @author     TechJoomla | <extensions@techjoomla.com>
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 *
 */
// No direct access
defined('_JEXEC') or die;

if (!empty($lesson->format_details))
{
	$lang_con_for_upload_formt_file	= "COM_TJLMS_UPLOAD_NEW_FORMAT";
}
else
{
	$lang_con_for_upload_formt_file	= "COM_TJLMS_UPLOAD_FORMAT";
}

$lesson_formats_array = array('scorm','htmlzips','tincanlrs','video','document','textmedia','externaltool','event', 'survey');

?>

<div class="<?php echo COM_TJLMS_WRAPPER_DIV; ?>">

<form action="<?php echo JRoute::_('index.php?option=com_tjlms&view=modules&course_id='. $this->course_id); ?>" method="post" name="adminForm" id="lesson-format-form_<?php echo $form_id;?>" class="form-validate form-horizontal lesson-format-form" >

	<div class="row-fulid">

		<?php if(empty($lesson->format)){ ?>
			<div class="format_types">
				<?php

				foreach($lesson_formats_array as $format_name)
				{
					/* Check if any of the plugin of provided lesson format is enabled*/
					$plugformat = 'tj' . $format_name;
					$dispatcher = JEventDispatcher::getInstance();
					JPluginHelper::importPlugin($plugformat);

					// Call the plugin and get the result
					$results = $dispatcher->trigger('GetSubFormat_tj' . $format_name . 'ContentInfo');

					if(!empty($results))
					{
						if(empty($formattoset))
						{
							$formattoset = $format_name;
						}
					?>
						<a  class="lecture-icons <?php echo $format_name ?>" data-type="<?php echo ucfirst($format_name)?>" onclick="lesson_format('<?php echo $format_name ?>','<?php echo $form_id;?>');">

							<?php
								$var = strtoupper($format_name);
								$lang_var = "COM_TJLMS_" . $var . "_LESSON";
							?>

							<span><?php echo  JText::_($lang_var); ?></span>
						</a>

				<?php } ?>
			<?php } ?>

				<!--<a class="lecture-icons tjscorm" data-type="Tjscorm" onclick="lesson_format('tjscorm','<?php echo $form_id;?>');">
					<span><?php echo  JText::_("COM_TJLMS_TJSCROM_LESSON"); ?></span>
				</a>
				<a class="lecture-icons tincanlrs" data-type="Tincan" onclick="lesson_format('tincanlrs','<?php echo $form_id;?>');">
					<span><?php echo  JText::_("COM_TJLMS_TINCAN_LESSON"); ?></span>
				</a>
				<a class="lecture-icons video" data-type="Video" onclick="lesson_format('video','<?php echo $form_id;?>');">
					<span><?php echo  JText::_("COM_TJLMS_VIDEO_LESSON"); ?></span>
				</a>
				<a class="lecture-icons document" data-type="Document" onclick="lesson_format('document','<?php echo $form_id;?>');">
					<span><?php echo  JText::_("COM_TJLMS_DOCUMENT_LESSON"); ?></span>
				</a>
				<a class="lecture-icons textmedia"  data-type="Textmedia" onclick="lesson_format('textmedia','<?php echo $form_id;?>')" class="lecture-icons">
					<span><?php echo  JText::_("COM_TJLMS_TEXT_N_MEDIA_LESSON"); ?></span>
				</a>--->
			</div>
		<?php } ?>

			<!--div for show selected formats options -->
			<div id="lesson_format">

				<div class="formatloadingcontainer tjlmscenter">
					<img class="formatloading" src="<?php echo JUri::root() . '/components/com_tjlms/assets/images/ajax.gif';?>">
				</div>

				<?php
				if(empty($lesson->format)){
				?>
					<div id="lesson_format_msg" class="alert alert-info" >
						<?php echo JText::_("COM_TJLMS_FORMAT_CHOOSE_MSG");?>
					</div>
				<?php
				}

				foreach($lesson_formats_array as $lesson_format)
				{
					$format_class = "tjlms_display_none";
					if(!empty($lesson->format) && $lesson->format == $lesson_format){
						$format_class	= "";
					}
					?>

					<!-- Form elements to show lesson format -->
					<div class="lesson_format <?php echo $format_class; ?>" id="<?php echo $lesson_format ?>">
						<div style="display:none">
								<div class="control-label"><label title="<?php echo JText::_("COM_TJLMS_".strtoupper($lesson_format)."_SUBFORMAT_OPTIONS");?>" ><?php echo JText::_("COM_TJLMS_".strtoupper($lesson_format)."_SUBFORMAT_OPTIONS");?></label></div>
								<div class="controls" id="<?php echo $lesson_format ?>_subformat_options">

								</div>
						</div>

						<div class="<?php echo $lesson_format ?>_subformat  form-horizontal subformat">

						</div>
					</div>
			<?php
				}
				?>

			</div>	<!--div lesson_format ENDS -->
			<!--HTML regarding lesson format-->
			<!--<input type="hidden" id="uploded_lesson_file" name="uploded_lesson_file" value=""/>-->

			<?php
			/*if ($this->item->id && $this->item->format == 'video')
			{

				?>
					<div class="control-group" class="span6" >
						<label id="format_label" class="control-label"><?php	echo JText::_('COM_TJLMS_SELECTED_VIDEO');	?></label>
						<div id="video_area" class="controls">
								<?php

									if($this->item->format_details['sub_format'] != 0)
									{
												if($this->item->format_details['sub_format'] == 1)
												{
													$video_path = $this->item->format_details['source'];
												}
												else if($this->item->format_details['sub_format'] == 2)
												{
													$video_path = JURI::root().'media/com_tjlms/lessons/'.$this->item->format_details['saved_filename'];
												}

												?>

												<iframe width="300" height="300" src="<?php	echo $video_path;	?>" frameborder="0" allowfullscreen></iframe>
							<?php	}
									else
									{
										echo $this->item->format_details['source'];
									}
									?>
						</div>
					</div>
		<?php }*/ ?>

		<div class="form-actions">
			<img class="loadingsquares tjlms_display_none" src="<?php echo JUri::root() . 'components/com_tjlms/assets/images/loading_squares.gif';?>">

			<button type="button" class="btn btn-primary" onclick="lessonBackButton('<?php echo  $form_id ?>')">
				<i class="fa fa-arrow-circle-o-left"></i><?php echo JText::_('COM_TJLMS_PREV'); ?>
			</button>
			<?php $allowAssocFiles = $params->get('allow_associate_files','0','INT'); ?>
					<?php if ($allowAssocFiles == 1): ?>
			<button type="button" class="btn btn-primary" onclick="formatactions('<?php echo  $form_id ?>', 0 )">
						<?php echo JText::_('COM_TJLMS_SAVE_NEXT'); ?>



				<i class="fa fa-arrow-circle-o-right"></i>
			</button>
			<?php endif; ?>
			<button type="button" class="btn btn-primary" onclick="formatactions('<?php echo  $form_id ?>', 1 )"><?php echo JText::_('COM_TJLMS_SAVE_CLOSE'); ?></button>

			<!--<?php if($lesson_id > 0){ ?>
				<button type="button" class="btn" onclick="showHideEditLesson('<?php echo $mod_id; ?>','<?php echo $lesson_id; ?>',0)"><?php echo JText::_('COM_TJLMS_CANCEL_BUTTON');	?></button>
			<?php }else{ ?>
				<button type="button" class="btn" onclick="hide_add_lesson_wizard('<?php echo $mod_id; ?>')"><?php echo JText::_('COM_TJLMS_CANCEL_BUTTON');	?></button>
			<?php } ?>
-->
		</div>

		<!--END-->
		<input type="hidden" name="task" value="lesson.updateformat" />
		<input type="hidden" name="lesson_format[format]" id="jform_format" value="<?php echo (!empty($lesson->format)) ? $lesson->format : $formattoset;?>">

		<?php
		$sub_format = '';
		if(!empty($lesson->format))
		{
			$sub_format = explode('.', $lesson->sub_format);
		}
		?>

		<input type="hidden" name="lesson_format[subformat]" id="jform_subformat" value="<?php echo (!empty($sub_format)) ? $sub_format[0]: '';?>">
		<input type="hidden" name="lesson_format[format_id]" id="lesson_format_id" value="<?php echo (!empty($lesson->format)) ? $lesson->media_id: 0;?>">
		<input type="hidden" name="lesson_format[id]" id="lesson_id" value="<?php echo (!empty($lesson->id)) ? $lesson->id : 0;?>">
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
</div>

