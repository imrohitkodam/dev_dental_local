<?php
/**
 * @version    SVN: <svn_id>
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
JHtml::_('behavior.formvalidation');
JHTML::_('behavior.modal');

include_once JPATH_COMPONENT.'/js_defines.php';

$input = JFactory::getApplication()->input;

if (JVERSION >= '3.0')
{
	JHtml::_('bootstrap.tooltip');
	JHtml::_('behavior.multiselect');
}

$course_id	= $this->course_id;
?>

<script>

	techjoomla.jQuery(window).load(function(){
		techjoomla.jQuery(".module-functionality-icons a").show();
		techjoomla.jQuery(".tjlms-actions a").show();
		techjoomla.jQuery(".module-functionality-icons .tjlms_display_none").hide();
	});


	techjoomla.jQuery(document).ready(function(){

			techjoomla.jQuery(".module-functionality-icons a").hide();
			techjoomla.jQuery(".tjlms-actions a").hide();


			/* Change calendar id*/
			var i = 0;

			techjoomla.jQuery('.lesson_basic_form').each(function()
			{
				if(i != 0)
				{
					var tjlmsformid	= techjoomla.jQuery(this).attr('id');
					var formid	= tjlmsformid.replace("lesson-basic-form_", "");

					if (!formid)
					{
						var formid	= tjlmsformid.replace("lesson-add-form_", "");
					}

					var newCalendarId = "jform_start_date"+formid;
					var newCalendarBtnId = "jform_start_date_img"+formid;

					//techjoomla.jQuery(this '#jform_start_date').val()
					techjoomla.jQuery(this).find('#jform_start_date').attr("id",newCalendarId);
					techjoomla.jQuery(this).find('#jform_start_date_img').attr("id",newCalendarBtnId);

					/* Change Label Id for Error Message*/
					techjoomla.jQuery(this).find('label[for="jform_start_date"]').attr("for",newCalendarId);

					/* Start date calendar script load*/
					loadScriptForcalendar(newCalendarId, newCalendarBtnId);

					var newCalendarId = "jform_end_date"+formid;
					var newCalendarBtnId = "jform_end_date_img"+formid;

					//techjoomla.jQuery(this '#jform_start_date').val()
					techjoomla.jQuery(this).find('#jform_end_date').attr("id",newCalendarId);
					techjoomla.jQuery(this).find('#jform_end_date_img').attr("id",newCalendarBtnId);

					/* Change Label Id for Error Message*/
					techjoomla.jQuery(this).find('label[for="jform_end_date"]').attr("for",newCalendarId);

					/* Start date calendar script load*/
					loadScriptForcalendar(newCalendarId, newCalendarBtnId);
				}

				i++;
			});


	});

	function loadScriptForcalendar(newCalendarId, newCalendarBtnId)
	{
		window.addEvent('load', function() {Calendar.setup({
					// Id of the input field
					inputField: newCalendarId,
					// Format of the input field
					ifFormat: "%Y-%m-%d %H:%M:%S",
					// Trigger for the calendar (button ID)
					button: newCalendarBtnId,
					// Alignment (defaults to "Bl")
					align: "Tl",
					singleClick: true,
					firstDay: 0
					});
				});
	}
</script>

<div class="<?php echo COM_TJLMS_WRAPPER_DIV ?>">
	<?php
		ob_start();
		include JPATH_BASE . '/components/com_tjlms/layouts/header.sidebar.php';
		$layoutOutput = ob_get_contents();
		ob_end_clean();
		echo $layoutOutput;
	?> <!--// JHtmlsidebar for menu ends-->


		<div class="modal hide fade" id="tjlmsModal">
		  <div class="modal-body">

		  </div>
			<div class="modal-footer">
				<a class="btn btn-primary" data-dismiss="modal">Close</a>
			</div>
		</div>


		<div class="curriculum-container">
			<?php if (empty($this->CourseInfo)){ ?>

			<div class="alert alert-danger">
				<span><?php echo JText::_('COM_TJLMS_COURSE_INVALID_URL');?></span>
			</div>

		<?php }else { ?>
			<div class="help-bolck">
				<div class="media">
					<div class="pull-left" >
						<img class="media-object" src="<?php echo $this->CourseInfo->image; ?>">
					</div>
					<div class="media-body">
						<a title="<?php echo JText::_('COM_TJLMS_COURSE_EDIT_LINK'); ?>" href="index.php?option=com_tjlms&view=course&layout=edit&id=<?php echo $this->CourseInfo->id; ?>">
							<strong><?php echo $this->CourseInfo->title; ?></strong>
						</a>
						<div class="media">
							<span ><?php echo $this->CourseInfo->short_desc; ?></span>
						</div>
					</div>
				</div>
			</div>

			<div style="clear:both"></div>

			<?php if(empty($this->moduleData)){ ?>

				<div class="alert alert-info">
					<?php echo JText::_("COM_TJLMS_TRAININGMATERIAL_MESSGE");?>
				</div>

			<?php } ?>

			<!--UL containing all modules-->
			<ul id="course-modules" class=" curriculum-ul">
				<?php
					echo $this->loadTemplate('lessons');
				?>
			</ul><!--UI for Modules ends-->

			<div class="add-module-div" onclick="editModule('<?php echo $this->course_id;?>',0)" >
				<img alt="Add module" src="<?php echo JUri::root(true).'/media/com_tjlms/images/default/icons/add-module.png'; ?>"  title="<?php echo JText::_('COM_TJLMS_ADD_MULTIPLE_LESSONS');	?>"/>
				<span><?php	echo JText::_('COM_TJLMS_ADD_MODULE');	?></span>
			</div>

			<div class="module-edit-form" id="add_module_form_<?php echo $this->course_id;?>">
				<?php
					$module_html='';
					$mod_id = 0;
					$mod_name = '';
					$mod_state	= 1;
					$tjlmshelperObj	=	new comtjlmsHelper();
					$layout = $tjlmshelperObj->getViewpath('com_tjlms','modules','module','ADMIN','ADMIN');
					ob_start();
					include($layout);
					$module_html.= ob_get_contents();
					ob_end_clean();
					echo $module_html;
				?>
			</div>
				<input type="hidden" name="option" value="com_tjlms" />
				<input type="hidden" id="course_id" name="course_id" value="<?php echo $course_id; ?>" />
				<input type="hidden" id="task" name="task" value="" />
				<input type="hidden" name="view" value="modules" />
				<input type="hidden" name="controller" value="modules" />
				<input type="hidden" name="controller" value="modules" />
		<?php } ?>
		</div>
	</div>
</div>
