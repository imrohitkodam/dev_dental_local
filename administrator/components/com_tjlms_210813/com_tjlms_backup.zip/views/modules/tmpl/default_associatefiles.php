<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      TechJoomla <extensions@techjoomla.com> - http://www.techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

JHTML::_('behavior.modal', 'a.modal');
?>

<script type="text/javascript">

var clone_variable = 0;

/*function addClone(rId,rClass, formid)
{
	var lesson_associatefile_form	=techjoomla.jQuery('#lesson-associatefile-form_'+formid);
	var lessonform	=	techjoomla.jQuery('#tjlms_add_lesson_form_'+formid);

	var pre = clone_variable;
	clone_variable++;
		var removeButton="<div id='remove_btn_id"+pre+"' class='com_tjlms_file_remove_button span1'>";
		removeButton+="<button class='btn btn-small btn-danger' type='button' id='remove"+pre+"'";
		removeButton+="onclick=\"removeClone('file_container"+pre+"','remove_btn_id"+pre+"','"+formid+"');\" title=\"<?php echo JText::_('COM_TJLMS_REMOVE_TOOLTIP');?>\" >";
		removeButton+="<i class=\"icon-minus icon-white\"></i></button>";
		removeButton+="</div>";

		var newElem = techjoomla.jQuery('#'+rId+pre).clone().attr('id',rId+clone_variable);

		newElem.find('.statusbar').remove();
		newElem.find('.fileupload-preview').html("<?php echo JText::sprintf('COM_TJLMS_UPLOAD_FILE_WITH_EXTENSION','any',$this->params->get('lesson_upload_size','0','INT'));?>");
		newElem.find('input[name=\"lesson_files['+pre+'][file]\"]').attr({'name': 'lesson_files[' + clone_variable + '][file]','value':''});
		newElem.find('input[name=\"lesson_files['+pre+'][media_id]\"]').attr({'name': 'lesson_files[' + clone_variable + '][media_id]','value':''});

		newElem.find('input[id=\"lesson_files'+pre+'\"]').attr({'id': 'lesson_files'+clone_variable,'value':''});
		newElem.find('input[id=\"assocFileMedia'+pre+'\"]').attr({'id': 'assocFileMedia'+clone_variable,'value':''});


		//techjoomla.jQuery('#'+rId+pre, lesson_associatefile_form).after(newElem);
		var lastchild = techjoomla.jQuery(lesson_associatefile_form).find('.file_container').last();
		lastchild.after(newElem);

		//techjoomla.jQuery('#'+rId+pre, lesson_associatefile_form).after(removeButton);
		lastchild.after(removeButton)
}

function removeClone(rId, rbtnId, formid){

		var lesson_associatefile_form	=techjoomla.jQuery('#lesson-associatefile-form_'+formid);
		var lessonform	=	techjoomla.jQuery('#tjlms_add_lesson_form_'+formid);

		techjoomla.jQuery('#'+rId, lesson_associatefile_form).remove();
		techjoomla.jQuery('#'+rbtnId, lesson_associatefile_form).remove();
}*/
</script>

<?php	$k=0;	?>
<div class="<?php echo COM_TJLMS_WRAPPER_DIV; ?>">
	<form action="<?php echo JRoute::_('index.php?option=com_tjlms&view=modules&course_id='. $this->course_id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="lesson-associatefile-form_<?php echo $form_id;?>" class="form-validate lesson-associatefile-form" >

		<div class="oldassocfiles">

		<?php
			$tableclass = '';
			if (empty($lesson->oldAssociateFiles))
			{
				$tableclass = "tjlms_display_none";
			}
			?>

			<table id="list_selected_files" class="table table-hover table-responsive list_selected_files <?php echo $tableclass;?>">
				  <caption><?php echo JText::_('COM_TJLMS_YOUR_ASSOC_FILES'); ?></caption>

					<tr class="tableheading">
						<th align="center"><?php echo JText::_('COM_TJLMS_FILENAME'); ?></th>
						<th class="tjlmscenter"><?php echo JText::_('COM_TJLMS_REMOVE_FILE'); ?></th>
					</tr>

				<?php if (!empty($lesson->oldAssociateFiles)){ ?>

					<?php foreach($lesson->oldAssociateFiles as $assocfiles): ?>

						<tr id="assocfiletr_<?php echo $assocfiles->media_id; ?>">
							<td><span><?php echo $assocfiles->filename; ?></span></td>
							<td class="tjlmscenter"><i id="removeFile<?php echo $assocfiles->media_id; ?>" onclick="removeAssocFile(this.id,'<?php echo $form_id;?>')" title="<?php echo JText::_('COM_TJLMS_REMOVE_FILE_TITLE'); ?>" class="icon-remove"></i></td>
						</tr>

					<?php endforeach; ?>

				<?php } ?>
			</table>

			<?php
			$alertclass = '';
			if (!empty($lesson->oldAssociateFiles)){
				$alertclass = "tjlms_display_none";
			 }?>

			<div class="alert alert-info no_selected_files  <?php echo $alertclass;?>">
				<?php echo JText::_('COM_TJLMS_NO_ASSOC_FILES'); ?>
			</div>


		</div>

		<div style="clear:both"></div>

		<div class="row-fluid">
			<div class="span6 center">
				<span class="help-block"><?php echo JText::_('COM_TJLMS_SELECT_ASSOC_FILES'); ?></span>
				<hr class="hr hr-condensed">
					<div class="selectfilebtn">
						<a id="selectFileLink" class="btn btn-primary modal "  onclick="opentjlmsSqueezeBox('index.php?option=com_tjlms&view=modules&layout=selectassociatefiles&lesson_id=<?php echo ($lesson) ? $lesson->id : 0;?>&tmpl=component&form_id=<?php echo $form_id; ?>')" ><?php echo JText::_('COM_TJLMS_SELECT'); ?></a>
					</div>
			</div>
			<div class="span6 center">
				<span class="help-block"><?php echo JText::_('COM_TJLMS_NEW_ASSOC_FILES'); ?></span>
				<hr class="hr hr-condensed">
				<div id="file_container<?php echo $k; ?>" class="file_container form-inline ">
					<div class="controls file_browse_area">
						<div id="associate" class="fileupload fileupload-new" data-provides="fileupload">
							<div class="input-append">
								<div class="uneditable-input span3">
									<span class="fileupload-preview">
										<?php echo JText::sprintf('COM_TJLMS_UPLOAD_FILE_WITH_EXTENSION','any',$this->params->get('lesson_upload_size','0','INT'));?>
									</span>
								</div>
								<span class="btn btn-file">
									<span class="fileupload-new"><?php echo JText::_("COM_TJLMS_BROWSE");?></span>
									<input type="file" id="lesson_files<?php echo $k; ?>" name="lesson_files[<?php echo  $k; ?>][file]" onchange="validate_file(this,'<?php echo $mod_id;?>','')";>
									<input type="hidden" id="assocFileMedia<?php echo $k; ?>" class="assocFileMedia" name="lesson_files[][media_id]" value=""/>
								</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--div class="span1">
			<button class="btn btn-small btn-success" type="button" id='add' onclick="addClone('file_container','file_container','<?php echo $form_id; ?>');" 	title='<?php echo JText::_('COM_TJLMS_ADD_BUTTON');?>'>
			<i class="icon-plus icon-white"></i>
			</button>
		</div-->

		<div style="clear:both"></div>

		<!--END-->
		<input type="hidden" name="task" value="lesson.updateassocfiles" />
		<input type="hidden" name="lesson_format[format]" id="jform_format" value="associate">
		<input type="hidden" name="lesson_format[format_id]" id="lesson_format_id" value="0">
		<input type="hidden" name="lesson_format[id]" id="lesson_id" value="<?php echo ($lesson) ? $lesson->id : 0;?>">
		<?php echo JHtml::_('form.token'); ?>

		<div class="form-actions">
			<img class="loading" src="<?php echo JUri::root() . 'components/com_tjlms/assets/images/loading_squares.gif';?>">
			<button type="button" class="btn btn-primary" onclick="lessonBackButton('<?php echo  $form_id ?>')">
				<i class="fa fa-arrow-circle-o-left"></i><?php echo JText::_('COM_TJLMS_PREV'); ?>
			</button>
			<button type="button" class="btn btn-primary" onclick="associateaction('<?php echo  $form_id ?>', 1)"><?php echo JText::_('COM_TJLMS_SAVE_CLOSE'); ?></button>

		<!--	<?php if($lesson_id > 0){ ?>
				<button type="button" class="btn" onclick="showHideEditLesson('<?php echo $mod_id; ?>','<?php echo $lesson_id; ?>',0)"><?php echo JText::_('COM_TJLMS_CANCEL_BUTTON');	?></button>
			<?php }else{ ?>
				<button type="button" class="btn" onclick="hide_add_lesson_wizard('<?php echo $mod_id; ?>')"><?php echo JText::_('COM_TJLMS_CANCEL_BUTTON');	?> </button>
			<?php } ?>-->

		</div>
	</form>
</div>
<style>
.lesson-associatefile-form .controls{margin-left:0px;}
</style>
