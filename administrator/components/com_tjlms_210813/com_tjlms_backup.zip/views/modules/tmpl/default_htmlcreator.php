<?php
/**
 * @package Tjlms
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
defined('_JEXEC') or die('Restricted access');

include_once JPATH_ROOT.DS.'administrator/components/com_tjlms/js_defines.php';

$html = '';

if (isset ($this->item->format_details['content']))
{
	$html = $this->item->format_details['content'];
}
?>



<link type="text/css" rel="stylesheet" href="<?php echo JURI::root().'administrator/components/com_tjlms/assets/htmlbuilder/assets/default/content.css'; ?>" />
<link href="<?php echo JURI::root().'administrator/components/com_tjlms/assets/htmlbuilder/scripts/contentbuilder.css'; ?>" rel="stylesheet" type="text/css" />
<!--<style>
    #divTool {right:200px;display:block !important}
</style>-->

<div class="tjlms_htmlcontainer">
	<div class="row clearfix">
		<div class="column full center">
			<br /><br /><br />
			<button onclick="save()" class="btn btn-primary"> Save </button>
		</div>
	</div>
</div>
<div id="contentarea" class="tjlms_htmlcontainer">
	<?php if ($html): ?>
		<?php echo $html; ?>
	<?php else: ?>
		<!-- This is just a sample content -->
		<div class="row clearfix">
			<div class="column full display">
				<h1>The Cafe</h1>
				<p>Fresh roasted coffee, exclusive teas &amp; light meals</p>
			</div>
		</div>
		<div class="row clearfix">
			<div class="column half">
				<img src="<?php echo JUri::root().'media/com_tjlms/lessons/htmlbuilder/assets/cafe.jpg'; ?>">
			</div>
			<div class="column half">
				<p>Welcome to the website of the Cafe on the Corner. We are situated, yes you've guessed it, on the corner of This Road and That Street in The Town.</p>
				<p>We serve freshly brewed tea and coffee, soft drinks and a section of light meals and tasty treats and snacks. We are open for breakfast, lunch and afternoon tea from 8 am to 5 pm and unlike any other cafe in the town, we are open 7 days per week.</p>
		   </div>
		</div>
		<div class="row clearfix">
			<div class="column full">
				<p>A truly family run business, we aim to create a cosy and friendly atmosphere in the cafe with Mum and Auntie doing the cooking and Dad and the (grown-up) children serving front of house. We look forward to welcoming you to the Cafe on the Corner very soon.</p>
			</div>
		</div>
	<?php endif; ?>
</div>
<?php
$document =	JFactory::getDocument();

//$document->addScript(JURI::root().'administrator/components/com_tjlms/assets/htmlbuilder/scripts/jquery-1.11.1.min.js');
$document->addScript(JURI::root().'administrator/components/com_tjlms/assets/htmlbuilder/scripts/jquery-ui.min.js');
$document->addScript(JURI::root().'administrator/components/com_tjlms/assets/htmlbuilder/scripts/contentbuilder.js');
$document->addScript(JURI::root().'administrator/components/com_tjlms/assets/htmlbuilder/scripts/saveimages.js');
$sniffetFilePath = JUri::root().'administrator/components/com_tjlms/assets/htmlbuilder/assets/default/snippets.html';

$input = JFactory::getApplication()->input;
$lesson_id = $input->get('lesson_id','0','INT');
$user_id = JFactory::getUser()->id;
$media_id = $input->get('media_id','0','INT');
?>
<script type="text/javascript">
	techjoomla.jQuery(document).ready(function ($) {

		techjoomla.jQuery("#contentarea").contentbuilder({
			zoom: 0.85,
			snippetFile: '<?php echo $sniffetFilePath; ?>'
		});

	});


	function save() {

		//Save Images
		techjoomla.jQuery("#contentarea").saveimages({
			handler: 'index.php?option=com_tjlms&task=lesson.saveHtmlImages',
			onComplete: function () {

				//Get Content
				var sHTML = techjoomla.jQuery('#contentarea').data('contentbuilder').html();
				//Save Content
				techjoomla.jQuery.ajax({
					type: "POST",
					url: "index.php?option=com_tjlms&task=lesson.saveHtmlContent",
					data: {
						user_id: <?php echo $user_id; ?>,
						lesson_id: <?php echo $lesson_id; ?>,
						media_id: <?php echo $media_id; ?>,
						htmlcontent: sHTML
					},
					dataType: "JSON",
					success: function(data) {
						window.parent.techjoomla.jQuery("input[name=media_id]").val(data);
						window.parent.SqueezeBox.close();
						window.parent.document.location.reload(true);
					},
					error: function(){
						alert('Eror');
					}

				});

			}
		});
		techjoomla.jQuery("#contentarea").data('saveimages').save();

	}
</script>

