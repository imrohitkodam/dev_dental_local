<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * View class for a list of Tjlms.
 *
 * @since  1.0.0
 */
class TjlmsViewCourses extends JViewLegacy
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise a Error object.
	 */
	public function display($tpl = null)
	{
		$canDo = TjlmsHelper::getActions();

		if (!$canDo->get('view.courses'))
		{
			JError::raiseError(500, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->pagination = $this->get('Pagination');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		TjlmsHelper::addSubmenu('courses');

		$comtjlmsHelper = new comtjlmsHelper;

		// Get component params
		$this->tjlmsparams = $comtjlmsHelper->getcomponetsParams('com_tjlms');

		// Get Item ID for the link
		$linkOfFrontendDashboard = 'index.php?option=com_tjlms&view=teacher_report';
		$this->teacherCourseDashboardItemid = $comtjlmsHelper->getitemid($linkOfFrontendDashboard);
		$this->addToolbar();

		if (JVERSION >= '3.0')
		{
			$this->sidebar = JHtmlSidebar::render();
		}

		if (JVERSION < '3.0')
		{
			// Creating status filter.
			$sstatus = array();
			$sstatus[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_SELONE_STATE'));
			$sstatus[] = JHTML::_('select.option', 1, JText::_('JPUBLISHED'));
			$sstatus[] = JHTML::_('select.option', 0, JText::_('JUNPUBLISHED'));
			$this->sstatus = $sstatus;

			$cType = array();
			$cType[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_SELONE_TYPE'));
			$cType[] = JHTML::_('select.option', 0, JText::_('COM_TJLMS_FREE'));
			$cType[] = JHTML::_('select.option', 1, JText::_('COM_TJLMS_PAID'));
			$this->cType = $cType;
		}

		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  Toolbar instance
	 *
	 * @since	1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT . '/helpers/tjlms.php';

		$state = $this->get('State');
		$canDo = TjlmsHelper::getActions();

		if (JVERSION >= '3.0')
		{
			JToolBarHelper::title(JText::_('COM_TJLMS_TITLE_COURSES'), 'book');
		}
		else
		{
			JToolBarHelper::title(JText::_('COM_TJLMS_TITLE_COURSES'), 'courses.png');
		}

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/course';

		if (file_exists($formPath))
		{
			if ($canDo->get('core.create'))
			{
				JToolBarHelper::addNew('course.add', 'JTOOLBAR_NEW');
			}

			if ($canDo->get('core.edit') && isset($this->items[0]))
			{
				JToolBarHelper::editList('course.edit', 'JTOOLBAR_EDIT');
			}
		}

		if ($canDo->get('core.edit.state'))
		{
			if (isset($this->items[0]->state))
			{
				JToolBarHelper::divider();
				JToolBarHelper::custom('courses.publish', 'publish.png', 'publish_f2.png', 'JTOOLBAR_PUBLISH', true);
				JToolBarHelper::custom('courses.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
				JToolbarHelper::custom('courses.featured', 'featured.png', 'featured_f2.png', 'JFEATURE', true);
				JToolbarHelper::custom('courses.unfeatured', 'unfeatured.png', 'featured_f2.png', 'JUNFEATURE', true);
			}
			elseif (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				JToolBarHelper::deleteList('COM_TJLMS_COURSES_DELETE_MSG', 'courses.delete', 'JTOOLBAR_DELETE');
			}

			if (isset($this->items[0]->checked_out))
			{
				JToolBarHelper::custom('courses.checkin', 'checkin.png', 'checkin_f2.png', 'JTOOLBAR_CHECKIN', true);
			}
		}

		// Show trash and delete for components that uses the state field
		if (isset($this->items[0]->state))
		{
			if ($state->get('filter.state') == -2 && $canDo->get('core.delete'))
			{
				JToolBarHelper::deleteList('COM_TJLMS_COURSES_DELETE_MSG', 'courses.delete', 'JTOOLBAR_EMPTY_TRASH');
				JToolBarHelper::divider();
			}
			elseif ($canDo->get('core.edit.state'))
			{
				JToolBarHelper::trash('courses.trash', 'JTOOLBAR_TRASH');
				JToolBarHelper::divider();
			}
		}

		if ($canDo->get('core.admin'))
		{
			JToolBarHelper::preferences('com_tjlms');
		}
	}

	/**
	 * Function use to get all sort fileds
	 *
	 * @return  void
	 *
	 * @since  1.0.0
	 */
	protected function getSortFields()
	{
		return array(
		'a.id' => JText::_('JGRID_HEADING_ID'),
		'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
		'a.state' => JText::_('JSTATUS'),
		'a.created_by' => JText::_('COM_TJLMS_COURSES_CREATED_BY'),
		'a.cat_id' => JText::_('COM_TJLMS_COURSES_CAT_ID'),
		'a.title' => JText::_('COM_TJLMS_COURSES_TITLE'),
		'a.start_date' => JText::_('COM_TJLMS_COURSES_START_DATE'),
		'a.type' => JText::_('COM_TJLMS_COURSES_TYPE'),
		);
	}
}
