<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      TechJoomla <extensions@techjoomla.com> - http://www.techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidator');
JHtml::_('behavior.keepalive');

if(JVERSION >= '3.0')
{
	JHtml::_('bootstrap.tooltip');
	JHtml::_('formbehavior.chosen', 'select');
	JHtml::_('behavior.multiselect');
}


// Import CSS
$document = JFactory::getDocument();

// import js
$document->addScript(JUri::root(true).'/administrator/components/com_tjlms/assets/js/tjlms.js');
?>
<script type="text/javascript">
	var oldCouponCode = '<?php echo str_replace("'", "\'", $this->form->getValue('code')); ?>';
	Joomla.submitbutton = function(task)
	{
		if (task == 'coupon.cancel') {
			Joomla.submitform(task, document.getElementById('coupon-form'));
		}
		else
		{
			if(techjoomla.jQuery.trim(techjoomla.jQuery('#jform_value').val()) == '0')
			{
				techjoomla.jQuery('#jform_value').val('');
			}

			if (task != 'coupon.cancel' && document.formvalidator.isValid(document.id('coupon-form')))
			{

				var from_date = techjoomla.jQuery('#jform_from_date').val();
				var exp_date = techjoomla.jQuery('#jform_exp_date').val();

				if (from_date !== '' &&  exp_date !== '')
				{
					from_date = new Date(from_date);
					exp_date = new Date(exp_date);

					if(from_date > exp_date)
					{
						var dateValidationmsg = Joomla.JText._('COM_TJLMS_DATE_RANGE_VALIDATION');
						enqueueSystemMessage(dateValidationmsg, ".admin.com_tjlms.view-coupon");
						return false;
					}
				}

				var max_use = techjoomla.jQuery('#jform_max_use').val();
				var max_per_user = techjoomla.jQuery('#jform_max_per_user').val();

				if ((!max_use && max_per_user) || parseInt(max_use, 10) < parseInt(max_per_user, 10))
				{
						var maxvalidate = Joomla.JText._('COM_TJLMS_MAX_USER_VALIDATION');
						enqueueSystemMessage(maxvalidate, ".admin.com_tjlms.view-coupon");
						return false;
				}

				var couponElem = document.getElementById('jform_code');
				validatecode(couponElem,task);
			}
		}
	}

	function validatecode(obj,task)
	{
		dispEnqueueMessage('','samecoupon');
		var course_id = techjoomla.jQuery('#jform_course_id').val();
		var codes = obj.value;
		var code = techjoomla.jQuery.trim(codes);
		obj.value = code;
		// If code value is not empety check for validation
		if (code && code != oldCouponCode)
		{
			techjoomla.jQuery.ajax
			({
				url:"index.php?option=com_tjlms&task=coupon.validatecode",
				type: "POST",
				data:{couponcode:code, course_id:course_id},
				success: function(data)
				{
					if (data == 1)
					{
						dispEnqueueMessage('<?php echo $this->escape(JText::_('COM_TJLMS_COUPON_CODE_VALIDATION')); ?>','samecoupon');
						jQuery('#jform_code').val('');
						jQuery( "#jform_code" ).focus();
					}else if(task){
						Joomla.submitform(task, document.getElementById('coupon-form'));
					}
				}
			});
		}else if(task){
			Joomla.submitform(task, document.getElementById('coupon-form'));
		}
	}

</script>


<div class="<?php echo COM_TJLMS_WRAPPER_DIV; ?>">


<form action="<?php echo JRoute::_('index.php?option=com_tjlms&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="coupon-form" class="form-validate">

	<div class="form-horizontal">

		<div class="row-fluid">
			<div class="span10 form-horizontal">
				<fieldset class="adminform">

					<div class="control-group" style="display:none">
						<div class="control-label"><?php echo $this->form->getLabel('id'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('id'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('name'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('name'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('course_id'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('course_id'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('created_by'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('created_by'); ?></div>
					</div>

					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('code'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('code'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('value'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('value'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('val_type'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('val_type'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('from_date'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('from_date'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('exp_date'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('exp_date'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('max_use'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('max_use'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('max_per_user'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('max_per_user'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
					</div>
					<div class="control-group">
						<div class="control-label"><?php echo $this->form->getLabel('couponParams'); ?></div>
						<div class="controls"><?php echo $this->form->getInput('couponParams'); ?></div>
					</div>
					<div class="controls"><?php echo $this->form->getInput('privacy'); ?></div>
				</fieldset>
			</div>
		</div>

		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>

	</div>
</form>

</div>

