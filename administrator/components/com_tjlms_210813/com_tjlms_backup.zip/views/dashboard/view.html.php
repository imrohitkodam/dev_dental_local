<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;
jimport('joomla.application.component.view');

/**
 * View class for a list of Tjlms.
 *
 * @since  1.0.0
 */
class TjlmsViewDashboard extends JViewLegacy
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise a Error object.
	 *
	 * @since  1.0.0
	 */
	public function display($tpl = null)
	{
		TjlmsHelper::addSubmenu('dashboard');
		$this->comtjlmsHelper = new comtjlmsHelper;
		$this->tjlmsCoursesHelper = new tjlmsCoursesHelper;

		// Get component params
		$this->tjlmsparams = JComponentHelper::getParams('com_tjlms');
		$this->show_user_or_username = $this->tjlmsparams->get('show_user_or_username', '0', 'INT');

		$model	= $this->getModel('dashboard');
		$this->DashboardDetails = $this->get('DashboardDetails');
		$this->popularCourses = $this->get('popularCourses');
		$this->popularStudent = $this->get('popularStudent');
		$this->mostLikedCourses = '';
		$this->state = $this->get('State');

		// Get download id
		$this->downloadid = $this->tjlmsparams->get('downloadid');

		// Get installed version from xml file
		$xml     = JFactory::getXML(JPATH_COMPONENT . '/tjlms.xml');
		$version = (string) $xml->version;
		$this->version = $version;

		$model = $this->getModel();
		$model->refreshUpdateSite();

		// Get new version
		$this->latestVersion = $this->get('LatestVersion');

		// Check if jlike installed.
		if (JFile::exists(JPATH_ROOT . DS . 'components' . DS . 'com_jlike' . DS . 'jlike.php'))
		{
			if (JComponentHelper::isEnabled('com_jlike', true))
			{
				$this->mostLikedCourses = $this->get('mostLikedCourses');
			}
		}

		$this->yourActivities = $model->getactivity();
		$this->allow_paid_courses = $this->tjlmsparams->get('allow_paid_courses', '0', 'INT');
		$this->admin_approval = $this->tjlmsparams->get('admin_approval', '0', 'INT');
		$this->paid_course_admin_approval = $this->tjlmsparams->get('paid_course_admin_approval', '0', 'INT');

		if ($this->allow_paid_courses == 1)
		{
			$this->revenueData = $model->getrevenueData();
		}

		$this->userDefaultImg = JUri::root() . 'media/com_tjlms/images/default/user.png';

		$this->addToolbar();

		$this->sidebar = JHtmlSidebar::render();

		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  toolbar
	 *
	 * @since  1.6
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT . '/helpers/tjlms.php';
		JToolBarHelper::title(JText::_('COM_TJLMS_TITLE_DASHBOARD'), 'home');
		JToolBarHelper::preferences('com_tjlms');
		JToolbarHelper::custom('fixdatabase', 'refresh', 'refresh', 'COM_TJLMS_TOOLBAR_DATABASE_MIGRATE', false);
		JToolbarHelper::custom('fixColumnIndexes', 'refresh', 'refresh', 'COM_TJLMS_TOOLBAR_DATABASE_INDEX', false);
	}
}
