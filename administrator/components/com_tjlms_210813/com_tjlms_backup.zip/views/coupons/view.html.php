<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');
jimport('techjoomla.common');

/**
 * View class for a list of Tjlms.
 *
 * @since  1.0.0
 */
class TjlmsViewCoupons extends JViewLegacy
{
	protected $items;

	protected $pagination;

	protected $state;

	/**
	 * Execute and display a template script.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise a Error object.
	 */
	public function display($tpl = null)
	{
		$canDo = TjlmsHelper::getActions();

		if (!$canDo->get('view.coupons'))
		{
			JError::raiseError(500, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		$this->techjoomlacommon = new TechjoomlaCommon;
		$this->state		= $this->get('State');
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');
		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
		$this->ComtjlmsHelper = new ComtjlmsHelper;
		$this->tjlmsCoursesHelper = new TjlmsCoursesHelper;
		$input = JFactory::getApplication()->input;

		// Get component params
		$this->lmsparams = $this->ComtjlmsHelper->getcomponetsParams('com_tjlms');
		require_once JPATH_SITE . '/components/com_tjlms/helpers/courses.php';
		require_once JPATH_ADMINISTRATOR . '/components/com_tjlms/models/coupons.php';
		$this->tjlmsCoursesHelper = new TjlmsModelCoupons;

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		TjlmsHelper::addSubmenu('coupons');

		$this->addToolbar();

		if (JVERSION >= '3.0')
		{
			$this->sidebar = JHtmlSidebar::render();
		}

		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  Toolbar instance
	 *
	 * @since	1.0.0
	 */
	protected function addToolbar()
	{
		require_once JPATH_COMPONENT . '/helpers/tjlms.php';

		$state	= $this->get('State');
		$canDo	= TjlmsHelper::getActions($state->get('filter.category_id'));

		if (JVERSION >= '3.0')
		{
			JToolBarHelper::title(JText::_('COM_TJLMS_TITLE_COUPONS'), 'list');
		}
		else
		{
			JToolBarHelper::title(JText::_('COM_TJLMS_TITLE_COUPONS'), 'coupons.png');
		}

		// Check if the form exists before showing the add/edit buttons
		$formPath = JPATH_COMPONENT_ADMINISTRATOR . '/views/coupon';

		if (file_exists($formPath))
		{
			if ($canDo->get('core.create'))
			{
				JToolBarHelper::addNew('coupon.add', 'JTOOLBAR_NEW');
			}

			if ($canDo->get('core.edit') && isset($this->items[0]))
			{
				JToolBarHelper::editList('coupon.edit', 'JTOOLBAR_EDIT');
			}
		}

		if ($canDo->get('core.edit.state'))
		{
			if (isset($this->items[0]->state))
			{
				JToolBarHelper::divider();
				JToolBarHelper::custom('coupons.publish', 'publish.png', 'publish_f2.png', 'JTOOLBAR_PUBLISH', true);
				JToolBarHelper::custom('coupons.unpublish', 'unpublish.png', 'unpublish_f2.png', 'JTOOLBAR_UNPUBLISH', true);
			}
			elseif (isset($this->items[0]))
			{
				// If this component does not use state then show a direct delete button as we can not trash
				JToolBarHelper::deleteList('COM_TJLMS_SURE_DELETE', 'coupons.delete', 'JTOOLBAR_DELETE');
			}

			if (isset($this->items[0]->checked_out))
			{
				JToolBarHelper::custom('coupons.checkin', 'checkin.png', 'checkin_f2.png', 'JTOOLBAR_CHECKIN', true);
			}
		}

		// Show trash and delete for components that uses the state field
		if (isset($this->items[0]->state))
		{
			if ($state->get('filter.state') == -2 && $canDo->get('core.delete'))
			{
				JToolBarHelper::deleteList('COM_TJLMS_SURE_DELETE', 'coupons.delete', 'JTOOLBAR_EMPTY_TRASH');
				JToolBarHelper::divider();
			}
			elseif ($canDo->get('core.edit.state'))
			{
				JToolBarHelper::trash('coupons.trash', 'JTOOLBAR_TRASH');
				JToolBarHelper::divider();
			}
		}

		if ($canDo->get('core.admin'))
		{
			JToolBarHelper::preferences('com_tjlms');
		}

		// Set sidebar action - New in 3.0
		if (JVERSION >= '3.0')
		{
			JHtmlSidebar::setAction('index.php?option=com_tjlms&view=coupons');
		}

		$this->extra_sidebar = '';
	}

	/**
	 * Function use to get all sort fileds
	 *
	 * @return  void
	 *
	 * @since  1.0.0
	 */
	protected function getSortFields()
	{
		return array(
		'a.id' => JText::_('JGRID_HEADING_ID'),
		'a.ordering' => JText::_('JGRID_HEADING_ORDERING'),
		'a.published' => JText::_('COM_TJLMS_COUPONS_PUBLISHED'),
		'a.checked_out' => JText::_('COM_TJLMS_COUPONS_CHECKED_OUT'),
		'a.checked_out_time' => JText::_('COM_TJLMS_COUPONS_CHECKED_OUT_TIME'),
		'a.created_by' => JText::_('COM_TJLMS_COUPONS_CREATED_BY'),
		'a.name' => JText::_('COM_TJLMS_COUPONS_NAME'),
		'a.code' => JText::_('COM_TJLMS_COUPONS_CODE'),
		'a.value' => JText::_('COM_TJLMS_COUPONS_VALUE'),
		'a.val_type' => JText::_('COM_TJLMS_COUPONS_VAL_TYPE'),
		'a.max_use' => JText::_('COM_TJLMS_COUPONS_MAX_USE'),
		'a.max_per_user' => JText::_('COM_TJLMS_COUPONS_MAX_PER_USER'),
		'a.from_date' => JText::_('COM_TJLMS_COUPONS_FROM_DATE'),
		'a.exp_date' => JText::_('COM_TJLMS_COUPONS_EXP_DATE'),
		);
	}
}
