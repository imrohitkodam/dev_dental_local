<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      TechJoomla <extensions@techjoomla.com> - www.techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
jimport('joomla.filesystem.file');

if(JVERSION >= '3.0')
{
	JHtml::_('bootstrap.tooltip');
	// JHtml::_('formbehavior.chosen', 'select');
	JHtml::_('behavior.multiselect');
}

include_once JPATH_COMPONENT.'/js_defines.php';

$allow_paid_courses = $this->tjlmsparams->get('allow_paid_courses','0','INT');

// Import helper for declaring language constant
JLoader::import('TjlmsHelper', JUri::root().'administrator/components/com_tjlms/helpers/tjlms.php');
// Call helper function
TjlmsHelper::getLanguageConstant();

?>

<script type="text/javascript">
	techjoomla.jQuery(window).load(function() {

		var show_subscription_div = techjoomla.jQuery('input[name="jform[type]\"]:checked').val();

		<?php if ($allow_paid_courses == 1) : ?>
		/*call to openSubscriptionDiv function to auto show and hide for subscription div on page reload if course selected as paid...*/
			openSubscriptionDiv(show_subscription_div);
		<?php endif; ?>

		/*on click of course type open subs plans div*/
		techjoomla.jQuery('input[name="jform[type]\"]').click(function(){
			var coursetype = techjoomla.jQuery(this).val();

			if (coursetype == 0)
			{
				var confirmMsgString = Joomla.JText._('COM_TJLMS_SURE_PAID_TO_FREE');
				var isSure = confirm(confirmMsgString);

				if (isSure)
				{
					techjoomla.jQuery('#subs_plan_div input').val('');
					document.getElementById('subs_plan_div').style.display='none';
				}
				else
				{
					techjoomla.jQuery('label[for="jform_type0"]').removeClass('active');
					techjoomla.jQuery('label[for="jform_type0"]').removeClass('btn-danger');
					techjoomla.jQuery('label[for="jform_type1"]').addClass('active');
					techjoomla.jQuery('label[for="jform_type1"]').addClass('btn-success');
					techjoomla.jQuery('#jform_type1').trigger('click');
				}
			}
			else
			{
				document.getElementById('subs_plan_div').style.display='block';
			}
		});

		var current_entered_char = techjoomla.jQuery("#jform_short_desc").val().length;
		var characters = lesson_characters_allowed;

		var sht_desc_length_onload = characters - current_entered_char;

		techjoomla.jQuery( '#max_body1' ).html(sht_desc_length_onload);

		techjoomla.jQuery("#jform_title").blur(function(){
				techjoomla.jQuery(this).val(techjoomla.jQuery.trim(techjoomla.jQuery(this).val()));
		});

		techjoomla.jQuery("#jform_short_desc").blur(function(){
				techjoomla.jQuery(this).val(techjoomla.jQuery.trim(techjoomla.jQuery(this).val()));
		});

	});

	Joomla.submitbutton = function(task)
	{
		if (task == 'course.cancel') {
			Joomla.submitform(task, document.getElementById('course-form'));
		}
		else
		{
			var certReq = jQuery('#jform_certificate_id').is(':visible');
			if(certReq){
				jQuery('#jform_certificate_id').addClass('required');
			}else{
				jQuery('#jform_certificate_id').removeClass('required');
			}

			if (document.formvalidator.isValid(document.id('course-form')))
			{
				//var ispaid = techjoomla.jQuery('.lms_course_type').val();

				var ispaid = techjoomla.jQuery('input[name="jform[type]"]:checked', '#course-form').val();

				//check date
				<?php if (empty($this->item->id)) : ?>

					var selectedDate = techjoomla.jQuery('#jform_start_date').val();
					courseStartDate = new Date(selectedDate);
					courseStartDate.setHours(0, 0, 0, 0);

				<?php endif; ?>

				if (ispaid == 1)
				{
					// If course is guest then it can be paid course
					var accessLevel = techjoomla.jQuery('#jform_access').val();

					if (accessLevel == 5)
					{
						enqueueSystemMessage("<?php	echo JText::_('COM_TJLMS_GUESTCOURSE_PAID_VALIDATION');	?>",".admin.com_tjlms.view-course");
						return false;
					}

					/* can select any number of subs plans aslo when any number of clone are made. */
					var flag = 0;

					techjoomla.jQuery('.com_tjlms_repeating_block').each(function()
					{
						var duration = techjoomla.jQuery('.subs_plan_duration').val();
						var price = techjoomla.jQuery('.subs_plan_price').val();

						if (duration != '' && price != '')
						{
							flag = 1;

							return false;
						}
					});

					if(flag == 0)
					{
						enqueueSystemMessage("<?php	echo JText::_('LMS_SUBSCRIPTION_PLAN_VALIDATION');	?>",".admin.com_tjlms.view-course");
						techjoomla.jQuery('.subs_plan_duration').focus();

						return false;
					}
				}
				<?php echo $this->form->getField('description')->save() ?>;
				techjoomla.jQuery(".btn-small").attr('disabled', true);

				Joomla.submitform(task, document.getElementById('course-form'));
			}
		}
	}

	jQuery(document).keypress(function (e) {
		if(e.which == 13 && e.target.nodeName != "TEXTAREA") return false;
	});
</script>

<div class="<?php echo COM_TJLMS_WRAPPER_DIV ?>">
		<form action="<?php echo JRoute::_('index.php?option=com_tjlms&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="course-form" class="form-validate">
			<div class="form-horizontal">

				<!-- Add tabs in case of only paid,extra or permission data  -->
				<?php if ($this->form_extra || $allow_paid_courses == 1 || $this->canDo->get('core.admin')) : ?>
						<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

						<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_TJLMS_TITLE_COURSE', true)); ?>
				<?php endif; ?>
				<!-- End add tabs in case of only paid,extra or permission data  -->

				<!-- General tabs starts here  -->
				<div class="row-fluid">
					<div class="span10 form-horizontal">
						<fieldset class="adminform">
							<div class="control-group" style="display:none">
								<div class="control-label"><?php echo $this->form->getLabel('id'); ?></div>
								<div class="controls"><?php echo $this->form->getInput('id'); ?></div>
							</div>

							<?php echo $this->form->renderField('created_by'); ?>

							<?php echo $this->form->renderField('title'); ?>

							<?php echo $this->form->renderField('alias'); ?>

							<?php echo $this->form->renderField('cat_id'); ?>

							<div class="control-group">
								<div class="control-label"><?php echo $this->form->getLabel('short_desc'); ?></div>
								<div class="controls">
									<?php echo $this->form->getInput('short_desc'); ?>
									<div class="sa_charlimit help-inline">
										<span id ="max_body1" ><?php echo $this->characters_allowed; ?></span>
										<span id="sBann1"><?php echo JText::_('COM_TJLMS_LEFT_CHAR');?></span>
									</div>
								</div>
							</div>

							<div class="control-group">
								<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
								<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
							</div>

							<div class="control-group">
								<div class="control-label"><?php echo $this->form->getLabel('image'); ?></div>
								<div class="controls ">
									<?php echo $this->form->getInput('image'); ?>
									<span class="help-block">
										<?php echo JText::_('COM_TJLMS_SUPPORTED_MEDIA_FILES_COURSE'); ?>
									</span>
								</div>
							</div>

							<input type="hidden" name="jform[image]" id="jform_image_hidden" value="<?php echo $this->item->image ?>" />

							<?php if (!empty($this->item->image)) : ?>
								<div class="control-group">
									<div class="controls "><img src="<?php echo $this->courseImage ?>"></div>
								</div>
							<?php endif; ?>
							
							<?php echo $this->form->renderField('metadesc'); ?>
							
							<?php echo $this->form->renderField('metakey'); ?>
							
							<?php echo $this->form->renderField('state'); ?>
							
							<?php echo $this->form->renderField('featured'); ?>
							
							<?php echo $this->form->renderField('start_date'); ?>
							
							<?php echo $this->form->renderField('access'); ?>
							
							<?php echo $this->form->renderField('certificate_term'); ?>
							
							<?php echo $this->form->renderField('certificate_id'); ?>
							
							<?php echo $this->form->renderField('expiry'); ?>

							<?php if ($this->tjlmsparams->get('social_integration', '', 'STRING') == 'easysocial'): ?>
								<div class="control-group">
									<div class="control-label"><?php echo $this->form->getLabel('esbadges'); ?></div>
									<div class="controls"><?php echo $this->form->getInput('esbadges'); ?></div>
								</div>
							<?php endif; ?>

								<?php if ($this->enable_tags == 1): ?>
									<div class="control-group">
										<div class="control-label"><?php echo $this->form->getLabel('tags'); ?></div>
										<div class="controls"><?php echo $this->form->getInput('tags'); ?></div>
									</div>
								<?php endif; ?>
							<?php echo $this->form->getInput('group_id'); ?>

						</fieldset>
					</div>
				</div>

				<!--GENERAL TAB ENDS-->
				<?php if ($this->form_extra || $allow_paid_courses == 1 || $this->canDo->get('core.admin')) : ?>
					<?php echo JHtml::_('bootstrap.endTab'); ?>
				<?php endif; ?>
				<!-- Details tabs ends here  -->


				<!--PRICING TAB STRAT-->
				<?php if ($allow_paid_courses == 1): ?>
						<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'pricing', JText::_('COM_TJLMS_TITLE_TAB_PRICING', true)); ?>
					<fieldset class="adminform">
						<div class="control-group">
							<div class="control-label"><?php echo $this->form->getLabel('type'); ?></div>
							<div class="controls"><?php echo $this->form->getInput('type'); ?></div>
						</div>

						<div class="control-group" id="subs_plan_div">
							<div class="control-label"><?php echo $this->form->getLabel('subsplans'); ?></div>
							<div class="controls"><?php echo $this->form->getInput('subsplans'); ?></div>
						</div>
					</fieldset>
					<!--PRICING TAB ENDS-->
						<?php echo JHtml::_('bootstrap.endTab'); ?>
					<?php endif; ?>

				<?php /*@TODO : add commened code for tjField integration*/ ?>
				<!-- Other Details tab -->
				<?php

					if ($this->canDo->get('core.admin')) : ?>
					<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'otherdetails', JText::_('COM_TJLMS_OTHER_DETAILS', true)); ?>

					<?php
					if (!empty($this->item->id))
					{
						echo $this->loadTemplate('extrafields');
					}
					else
					{
					?>
						<div class="alert alert-info">
							<?php echo JText::_('COM_TJLMS_SAVE_OTHER_DETAILS_MSG');?>
						</div>
					<?php
					}
					?>
					<?php echo JHtml::_('bootstrap.endTab'); ?>
				<?php endif; ?>
				<!-- Other Details tab Ends-->

				<!-- Permission tab -->
				<?php if ($this->canDo->get('core.admin')) : ?>
					<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'permissions', JText::_('COM_TJLMS_FIELDSET_RULES', true)); ?>
					<?php echo $this->form->getInput('rules'); ?>
					<?php echo JHtml::_('bootstrap.endTab'); ?>
				<?php endif; ?>
				<!-- Permission tab End-->

				<!-- Add tabs in case of only paid,extra or permission data  -->
				<?php if ($this->form_extra || $allow_paid_courses == 1 || $this->canDo->get('core.admin')) : ?>

					<?php echo JHtml::_('bootstrap.endTabSet'); ?>
				<?php endif; ?>
				<!-- Add tabs in case of only paid,extra or permission data  -->

				<input type="hidden" name="task" value="" />
				<?php echo JHtml::_('form.token'); ?>
			</div>
		</form>
	</div> <!--techjoomla-bootstrap-->
