<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Certificates
 * @author     Parth Lawate <contact@techjoomla.com>
 * @copyright  2016 Parth Lawate
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;
JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');
$document = JFactory::getDocument();
$document->addScriptDeclaration("var usedCertCount='{$this->usedCertCount}';");
?>
<script type="text/javascript">
jQuery(document).ready(function(){
	if (usedCertCount >0){
		jQuery("#jform_access0").attr('disabled' , true);
		jQuery("#jform_access").parent(".controls").append("<div class='alert alert-info'>" + Joomla.JText._('COM_TJLMS_CERTIFICATE_ACCESS_MSG') + "</div>");
	}
});

	js = jQuery.noConflict();
	Joomla.submitbutton = function (task) {
		if (task == 'certificatetemplate.cancel') {
			Joomla.submitform(task, document.getElementById('certificatetemplate-form'));
		}
		else {

			if (task != 'certificatetemplate.cancel' && document.formvalidator.isValid(document.id('certificatetemplate-form'))) {
				<?php echo $this->form->getField('body')->save() ?>;
				Joomla.submitform(task, document.getElementById('certificatetemplate-form'));
			}
			else {
				alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}
	}
</script>
<form
	action="<?php echo JRoute::_('index.php?option=com_tjlms&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="certificatetemplate-form" class="form-validate">

	<div class="form-horizontal">
		<div class="row-fluid">
			<div class="tjlms-tbl row-fluid">
			<div class="span9 form-horizontal">
				<fieldset class="adminform">
				<?php
				echo $this->form->renderField('id'); 
				echo $this->form->renderField('created_by'); 
				echo $this->form->renderField('modified_by'); 
				echo $this->form->renderField('modified_date'); 
				echo $this->form->renderField('ordering'); 
				echo $this->form->renderField('state'); 
				echo $this->form->renderField('checked_out'); 
				echo $this->form->renderField('checked_out_time'); 
				echo $this->form->renderField('title');
				echo $this->form->renderField('body');
				echo $this->form->renderField('access'); ?>
				</fieldset>
			</div>
			<div class="span3">
				<table class="table">
					<tr>
						<td colspan="2"><div class="alert alert-info"><?php echo JText::_('COM_TJLMS_CSS_EDITOR_MSG') ?> </div>
							<?php echo $this->form->getInput('template_css');?>
						</td>
					</tr>
					<tr>
						<td colspan="2"><div class="alert alert-info"><?php echo JText::_('COM_TJLMS_EB_TAGS_DESC') ?> </div>
					</tr>
					<tr>
						<td width="30%"><b>&nbsp;&nbsp;[STUDENTNAME] </b> </td>
						<td><?php echo JText::_('COM_TJLMS_TAG_STUDENTNAME'); ?></td>
					</tr>
					<tr>
						<td width="30%"><b>&nbsp;&nbsp;[STUDENTUSERNAME] </b> </td>
						<td><?php echo JText::_('COM_TJLMS_TAG_STUDENTUSERNAME'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[COURSE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_COURSE'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[GRANTED_DATE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_CER_GRANT_DATE'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[DATE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_CER_PRINTED_DATE'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[EXPIRY_DATE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_CER_EXPIRY_DATE'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[TOTAL_TIME]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_CER_TIME_SPENT'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[CERT_ID]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_CER_ID'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[jsfield:FIELD_CODE]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_JS_FIELD'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[esfield:unique_key]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_ES_FIELD'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[TJFIELD_CPD_HOURS]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_TJFIELD_CPD_HOURS'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[TJFIELD_GDC_RECOMMENDED_TOPIC]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_TJFIELD_GDC_RECOMMENDED_TOPIC'); ?></td>
					</tr>
					<tr>
						<td><b>&nbsp;&nbsp;[TJFIELD_GDC_HIGHLY_RECOMMENDED_SUBJECT]</b></td>
						<td><?php echo JText::_('COM_TJLMS_TAG_TJFIELD_GDC_HIGHLY_RECOMMENDED_SUBJECT'); ?></td>
					</tr>
				</table>
			</div>
			</div>

		</div>
		<input type="hidden" name="task" value=""/>
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
