<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Tjlms
 * @author     Parth Lawate <contact@techjoomla.com>
 * @copyright  2016 Parth Lawate
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Certificatetemplate controller class.
 *
 * @since  1.6
 */
class TjlmsControllerCertificatetemplate extends JControllerForm
{
	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'certificates';
		parent::__construct();
	}
}
