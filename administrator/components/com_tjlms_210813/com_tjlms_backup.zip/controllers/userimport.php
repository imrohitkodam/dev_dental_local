<?php
/**
 * @package    Shika
 * @author     TechJoomla | <extensions@techjoomla.com>
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;
define('REGISTER_USER_ID', 2);
jimport('joomla.application.component.controllerform');
jimport('joomla.filesystem.folder');
jimport('joomla.html.html');
jimport('joomla.application.component.model');

/**
 * File upload controller class.
 *
 * @since  1.0.0
 */
class TjlmsControllerUserimport extends JControllerForm
{
	/**
	 * CSV file data store in entroll table of Tjlms.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	public function csvImport()
	{
		header('Cache-Control: no-cache, must-revalidate');
		header('Content-type: application/json');

		$oluser_id = JFactory::getUser()->id;

		/* If user is not logged in*/
		if (!$oluser_id)
		{
			$ret['OUTPUT']['flag']	=	0;
			$ret['OUTPUT']['msg']	=	JText::_('COM_TJLMS_MUST_LOGIN_TO_UPLOAD');
			echo json_encode($ret);
			jexit();
		}

		$input = JFactory::getApplication()->input;
		$tjlmsparams = JComponentHelper::getParams('com_tjlms');

		$files = $input->files;
		$post = $input->post;

		$file_to_upload	=	$files->get('FileInput', '', 'ARRAY');
		$filepath = 'media/com_tjlms/userimport/';
		$notify_user	=	$post->get('notify_user_import', '', 'INT');

		$return = 1;
		$msg = '';

		$file_attached	= $file_to_upload['tmp_name'];
		$filename = $file_to_upload['name'];
		$filepath_with_file = $filepath . $filename;
		$newfilename = $filename;

			/* Save csv content to question table */
		$result = $this->saveCsvContent($file_to_upload, $notify_user);

		$filename = $file_to_upload['name'];

		/*$return = $result['return'];
		$msg = $result['msg'];
		$msg1 = $result['msg1'];*/

		$ret['OUTPUT'] = $result;
		echo json_encode($ret);
		jexit();
	}

	/**
	 * Save question to table from csv
	 *
	 * @param   MIXED  $file_to_upload  file object
	 * @param   INT    $notify_user     notify user
	 *
	 * @return  ARRAY
	 *
	 * @since  1.0.0
	 */
	public function saveCsvContent($file_to_upload, $notify_user)
	{
		$input = JFactory::getApplication()->input;
		$lmsparams   = JComponentHelper::getParams('com_tjlms');
		$adminApproval = $lmsparams->get('admin_approval');

		$least_data = 0;
		$handle    = fopen($file_to_upload['tmp_name'], 'r');
		$rowNum = '';

		while (($data = fgetcsv($handle)) !== false)
		{
			if ($rowNum == 0)
			{
				// Parsing the CSV header
				$headers = array();

				foreach ($data as $d)
				{
					$headers[] = preg_replace('/[^A-Za-z0-9\-]/', '', $d);
				}
			}
			else
			{
				// Parsing the data rows
				$rowData = array();

				foreach ($data as $d)
				{
					$rowData[] = $d;
				}

				if (count($headers) == count($rowData))
				{
					$userData[] = array_combine($headers, $rowData);
				}
			}

			$rowNum++;
		}

		$valueArray = array ('FirstName','LastName','username','email','StartDate','DueDate');

		foreach ($headers as $key => $value)
		{
			if (!in_array($value, $valueArray))
			{
				if (strpos($value, 'course') || strpos($value, 'groupId'))
				{
					$output['return'] = 1;
					$output['errormsg'] = JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_ERROR_MSG', $value, '');
					$output['successmsg'] = '';

					return $output;
				}
			}
		}

		$acceptedQues = 0;

		$db = JFactory::getDbo();

		/*$bad = $notinsert = $new = $success = $newbad = $bad_user = $no_users = $bad_course = 0;*/

		$alreadyEnrolledCnt = $bad_group = $bad_user = $bad_course = $new_user = $enrol_success = 0;
		$col_value = $assign_success = $start_gt_due = $start_less_today = 0;
		$invalid_date = $alreadyassignedupdated = 0;

		$miss_col = 0;
		$emptyfile = 0;

		if (!empty($userData))
		{
			$totalUser = count($userData);

			if ($totalUser < 1)
			{
				$emptyfile = 1;
			}
			else
			{
				foreach ($userData as $eachUser)
				{
					if (!empty($eachUser))
					{
						$lname = '';
						$username = "";
						$start_date = '';
						$due_date = '';

						if (trim($eachUser['FirstName']) == '' || trim($eachUser['email']) == '')
						{
							$col_value++;
						}
						else
						{
							foreach ($eachUser as $key => $value)
							{
								if (!array_key_exists('FirstName', $eachUser) || !array_key_exists('LastName', $eachUser) || !array_key_exists('email', $eachUser))
								{
									$miss_col = 1;
									break;
								}

								if (!empty($value))
								{
									if ($key == 'FirstName')
									{
										$fname = $value;
									}

									if ($key == 'LastName')
									{
										$lname = $value;
									}

									if ($key == 'username')
									{
										$username = $value;
									}

									if ($key == 'StartDate')
									{
										$start_date = $value;
									}

									if ($key == 'DueDate')
									{
										$due_date = $value;
									}

									if ($key == 'email')
									{
										$userexist = $this->checkUserExit($value);

										if (!$userexist)
										{
											/*$no_users ++;*/
											$userid = $this->createUser($value, $fname, $lname, $username);

											if ($userid > 0)
											{
												$new_user ++;
											}
											else
											{
												// User already present or invalid user id
												$bad_user ++;
											}
										}
										else
										{
											// If old user check alredy entry created for enrollment for same user same course.
											$userid = $userexist;
										}
									}

									if ($key != 'Id' && $key != 'email' && $key != 'FirstName' && $key != 'LastName' && $key != 'username' && strpos($key, 'ourse'))
									{
										if (is_numeric($value))
										{
											$CourseExit = $this->checkCourseExit($value);

											if ($userid > 0 && $CourseExit['id'] > 0)
											{
												$alreadyEnrolled = $this->checkIfuserEnrolled($userid, $value);

												if ($alreadyEnrolled == 0 && $value != 0)
												{
													$obj['id']          = '';
													$obj['course_id']   = $value;
													$obj['cid']         = array($userid);
													$obj['csv']         = 1;

													$tjlmsCoursesHelper = new tjlmsCoursesHelper;

													// Import CSV notify users by only one mail after Enroll/Assign
													if (!empty($start_date) && !empty($due_date))
													{
														$notify_user_enroll = 0;
													}
													else
													{
														$notify_user_enroll = $notify_user;
													}

													// Check admin approval is enable or not
													if ($adminApproval == 1)
													{
														$successfulEnroled = $tjlmsCoursesHelper->enroll_user(1, 0, $obj, 1, $notify_user_enroll);
													}
													else
													{
														$successfulEnroled = $tjlmsCoursesHelper->enroll_user(0, 0, $obj, 1, $notify_user_enroll);
														$enrol_success ++;
													}
												}
												else
												{
													$alreadyEnrolledCnt ++;
												}

												// Course assignment CSV Import
												// If start date and Due date then assign User
												if (!empty($start_date) && !empty($due_date))
												{
													if (!($this->checkDateTime($start_date)) || !($this->checkDateTime($due_date)))
													{
														$invalid_date ++;
													}
													elseif (date("Y-m-d", strtotime($start_date)) < date("Y-m-d"))
													{
														$start_less_today ++;
													}
													elseif (date("Y-m-d", strtotime($start_date)) > date("Y-m-d", strtotime($due_date)))
													{
														$start_gt_due ++;
													}
													else
													{
														// Valid Course
														if ($value != 0)
														{
														$data = array();
														$alreadyassigned = $this->checkIfuserAssigned($userid, $value);

															// Already assigned then take id of the record and increment count
															if (isset($alreadyassigned))
															{
																$data['todo_id']    = $alreadyassigned;
																$alreadyassignedupdated ++;
															}

															$data['type']              = 'assign';
															$data['sender_msg']        = '';
															$data['start_date']        = date("Y-m-d", strtotime($start_date));
															$data['due_date']          = date("Y-m-d", strtotime($due_date));
															$data['recommend_friends'] = array($userid);

															$input = JFactory::getApplication()->input;

															$plg_name   = 'jlike_tjlms';
															$plg_type   = 'content';
															$element    = 'com_tjlms.course';
															$element_id = $value;

															$options = array('element' => $element, 'element_id' => $element_id, 'plg_name' => $plg_name, 'plg_type' => $plg_type);

															// Include path of jlike model file and call api to assign user
															include_once JPATH_SITE . '/components/com_jlike/models/recommend.php';

															if (class_exists('JlikeModelRecommend'))
															{
																$JlikeModelRecommend = new JlikeModelRecommend;
																$successfulRecommend = $JlikeModelRecommend->assignRecommendUsers($data, $options, $notify_user);
															}

															// If user not aready assigned then increment assigned count
															if (!isset($alreadyassigned))
															{
																$assign_success ++;
															}
														}
													}
												}
											}
											else
											{
												// Invalid or unpublished course id
												$bad_course ++;
											}
										}
										else
										{
											// Invalid or unpublished course id
											$bad_course  ++;
										}
									}

									elseif ($key != 'Id' && $key != 'email' && $key != 'FirstName' && $key != 'LastName' && $key != 'username' && strpos($key, 'roup'))
									{
										// Group Mapp
										if (is_numeric($value))
										{
											$GroupExit = $this->checkGroupExit($value);

											if ($GroupExit)
											{
												require_once JPATH_ADMINISTRATOR . '/components/com_users/models/user.php';
												$userModel            = new UsersModelUser;
												$userData             = array();
												$userData['id']    = $userid;
												$userData['groups']    = array($value);
												$userData['block']    = 0;

												if ($userModel->save($userData))
												{
													$success ++;
												}
											}
											else
											{
												$bad_group ++;
											}
										}
										else
										{
											$bad_group ++;
										}
									}
									else
									{
										// Not yet
									}
								}
							}
						}
					}
				}
			}
		}

		/*if ($bad == 1)
		{
			$newbad ++;
		}*/

		$output['return'] = 1;
		$output['successmsg'] = '';
		$output['errormsg'] = '';

		if (empty($userData))
		{
			$output['errormsg'] = JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_BLANK_FILE');
		}
		else
		{
			if ($emptyfile == 1)
			{
				$output['successmsg'] = "";
				$output['errormsg'] .= JText::_('COM_TJLMS_CSV_IMPORT_EMPTY_FILE');
			}
			else
			{
				if ($miss_col)
				{
					$output['successmsg'] = "";
					$output['errormsg'] = JText::_('COM_TJLMS_CSV_IMPORT_COLUMN_MISSING');
				}
				else
				{
					$output['successmsg'] = JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_IMPORT_TOTAL_ROWS_CNT_MSG', count($userData));

					if ($new_user > 0)
					{
						if ($new_user == 1)
						{
							$output['successmsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_NEW_USER_MSG', $new_user);
						}
						else
						{
							$output['successmsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_NEW_USERS_MSG', $new_user);
						}
					}

					if ($adminApproval == 1)
					{
						$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_USER_NEED_ADMIN_APPROVAL');
					}

					if ($enrol_success > 0)
					{
						if ($enrol_success == 1)
						{
							$output['successmsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_NEWLY_SINGLE_USER_ENROLLED_MSG', $enrol_success);
						}
						else
						{
							$output['successmsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_NEWLY_ENROLLED_MSG', $enrol_success);
						}
					}

					if ($assign_success > 0)
					{
						if ($assign_success == 1)
						{
							$output['successmsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_NEWLY_SINGLE_USER_ASSIGN_MSG', $assign_success);
						}
						else
						{
							$output['successmsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_NEWLY_ASSIGN_MSG', $assign_success);
						}
					}

					if ($alreadyEnrolledCnt > 0)
					{
						if ($alreadyEnrolledCnt == 1)
						{
							$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_ALREADY_ENROLLED_MSG_ONE', $alreadyEnrolledCnt);
						}
						else
						{
							$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_ALREADY_ENROLLED_MSG', $alreadyEnrolledCnt);
						}
					}

					if ($alreadyassignedupdated > 0)
					{
						if ($alreadyassignedupdated == 1)
						{
							$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_ALREADY_ASSIGNED_MSG_ONE', $alreadyassignedupdated);
						}
						else
						{
							$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_ALREADY_ASSIGNED_MSG', $alreadyassignedupdated);
						}
					}

					if ($bad_user > 0)
					{
						if ($bad_user == 1)
						{
							$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_TITLE_MANAGEENROLLMENTS_IMPORT_ALREADY_ENROLLED_MSG_ONE', $bad_user);
						}
						else
						{
							$output['errormsg'] .= "<br />" . JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_BAD_USERDATA', $bad_user);
						}
					}

					if ($bad_course > 0)
					{
						if ($bad_course == 1)
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_BAD_COURSE_ONE', $bad_course);
						}
						else
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_BAD_COURSE', $bad_course);
						}
					}

					if ($bad_group > 0)
					{
						if ($bad_group == 1)
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_BAD_GROUP_ONE', $bad_group);
						}
						else
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_BAD_GROUP', $bad_group);
						}
					}

					if ($col_value > 0)
					{
						if ($col_value == 1)
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_MANDATORY_FIELDS_ONE', $col_value);
						}
						else
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_MANDATORY_FIELDS', $col_value);
						}
					}

					if ($start_less_today > 0)
					{
						if ($start_less_today == 1)
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_ASSIGNMENT_START_DATE_NOT_VALID_ONE', $start_less_today);
						}
						else
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_ASSIGNMENT_START_DATE_NOT_VALID', $start_less_today);
						}
					}

					if ($start_gt_due > 0)
					{
						if ($start_gt_due == 1)
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_ASSIGNMENT_START_GT_DUEDATE_ONE', $start_gt_due);
						}
						else
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_ASSIGNMENT_START_GT_DUEDATE', $start_gt_due);
						}
					}

					if ($invalid_date > 0)
					{
						if ($invalid_date == 1)
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_ASSIGNMENT_INVALID_DATE_ONE', $invalid_date);
						}
						else
						{
							$output['errormsg'] .= "<br />";
							$output['errormsg'] .= JText::sprintf('COM_TJLMS_MANAGEENROLLMENTS_ASSIGNMENT_INVALID_DATE', $invalid_date);
						}
					}
				}
			}
		}

		return $output;
	}

	/**
	 * Check user exist in joomla.
	 *
	 * @param   string  $useremail  login user email.
	 *
	 * @return  int  Return user id.
	 *
	 * @since   1.0
	 */
	public function checkUserExit($useremail)
	{
		if ($useremail)
		{
			$db = JFactory::getDbo();

			// Check the customer id (in users table) already exist or not
			$query = $db->getQuery(true);
			$query->select('id');
			$query->from('`#__users`');
			$query->where('email = ' . $db->Quote($useremail));
			$db->setQuery($query);

			return $db->loadResult();
		}
	}

	/**
	 * Check course exist in lms.
	 *
	 * @param   INT  $courseId  login user email.
	 *
	 * @return  int  Return course id.
	 *
	 * @since   1.0
	 */
	public function checkCourseExit($courseId)
	{
		if ($courseId)
		{
			$db = JFactory::getDbo();

			// Check the customer id (in users table) already exist or not
			$query = $db->getQuery(true);
			$query->select('id,state');
			$query->from('`#__tjlms_courses`');
			$query->where('id = ' . ($courseId));
			$db->setQuery($query);

			return $db->loadAssoc();
		}
	}

	/**
	 * Create joomla user.
	 *
	 * @param   RAW     $useremail  A record object formfield.
	 * @param   STRING  $fname      A record object formfield.
	 * @param   STRING  $lname      A record object formfield.
	 * @param   STRING  $username   A record object formfield.
	 *
	 * @return  int  Return user id.
	 *
	 * @since   1.0
	 */
	public function createUser($useremail,$fname,$lname,$username = "")
	{
			$db = JFactory::getDbo();

			// Create a new user
			require_once JPATH_ADMINISTRATOR . '/components/com_users/models/user.php';
			$userModel            = new UsersModelUser;
			$userData             = array();
			$userData['name']     = $fname . ' ' . $lname;

			if ($username)
			{
				$userData['username'] = $username;
			}
			else
			{
				$userData['username']    = trim($useremail);
			}

			$userData['email']    = trim($useremail);
			$userData['block']    = 0;

			if ($userModel->save($userData))
			{
				$userid = (int) $userModel->getState('user.id');
			}

			if (isset($userid))
			{
				if ($userid)
				{
					$userGroupData             = new stdClass;
					$userGroupData->user_id    = $userid;
					$userGroupData->group_id   = REGISTER_USER_ID;

					$db->insertObject('#__user_usergroup_map', $userGroupData, 'user_id');

					return $userid;
				}
			}
	}

	/**
	 * For user enroll data
	 *
	 * @param   Int  $userId    User id.
	 * @param   Int  $courseId  course id.
	 *
	 * @return  array  Return User Enroll Data.
	 *
	 * @since   1.0
	 */

	public function checkIfuserEnrolled($userId,$courseId)
	{
		if ($userId && $courseId)
		{
			$db = JFactory::getDbo();

			// Check the customer id (in users table) already exist or not
			$query = $db->getQuery(true);
			$query->select('id');
			$query->from('`#__tjlms_enrolled_users`');
			$query->where('user_id = ' . ($userId));
			$query->where('course_id = ' . ($courseId));
			$db->setQuery($query);

			return $db->loadResult();
		}
	}

	/**
	 * For user ASSIGN data
	 *
	 * @param   Int  $userId    User id.
	 * @param   Int  $courseId  course id.
	 *
	 * @return  array  Return User Assign Data.
	 *
	 * @since   1.0
	 */

	public function checkIfuserAssigned($userId,$courseId)
	{
		if ($userId && $courseId)
		{
			$db = JFactory::getDbo();

			// Check if user already assigned
			$query = $db->getQuery(true);
			$query->select('id');
			$query->from('`#__jlike_todos`');
			$query->where('assigned_to = ' . ($userId));
			$query->where('title = ' . ($courseId));
			$db->setQuery($query);

			return $db->loadResult();
		}
	}

	/**
	 * Check user exist in joomla.
	 *
	 * @param   INT  $gid  Gourp Id.
	 *
	 * @return  int  Return user id.
	 *
	 * @since   1.0
	 */
	public function checkGroupExit($gid)
	{
		if ($gid)
		{
			$db = JFactory::getDbo();

			// Check the customer id (in users table) already exist or not
			$query = $db->getQuery(true);
			$query->select('id');
			$query->from('`#__usergroups`');
			$query->where('id = ' . $db->Quote($gid));
			$db->setQuery($query);

			return $db->loadResult();
		}
	}

	/**
	 * Check if valid date.
	 *
	 * @param   Date  $data  date.
	 *
	 * @return  boolean
	 *
	 * @since   1.0
	 */
	public function checkDateTime($data)
	{
		if (date('Y-m-d', strtotime($data)) == $data)
		{
			date('Y-m-d', strtotime($data));

			return true;
		}
		else
		{
			date('Y-m-d', strtotime($data));

			return false;
		}
	}
}
