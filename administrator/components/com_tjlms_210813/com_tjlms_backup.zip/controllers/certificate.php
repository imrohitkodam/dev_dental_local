<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');

/**
 * Courses list controller class.
 *
 * @since  1.0.0
 */
class TjlmsControllerCertificate extends JControllerAdmin
{
	/**
	 * Function to save user enrollment
	 * Call from backend enrollment view and from frontend while enrolling
	 *
	 * @return  boolean  true or false
	 *
	 * @since 1.0.0
	 */
	public function apply()
	{
		$model	= $this->getModel('certificate');

		if ($model->save())
		{
			$msg = JText::_('MENU_ITEM_SAVED');
		}
		else
		{
			$msg = JText::_('ERROR_SAVING_MENU_ITEM');
		}

		$this->setRedirect('index.php?option=com_tjlms&view=certificate');
	}
}
