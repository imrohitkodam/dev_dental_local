<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Coupon controller class.
 *
 * @since  1.0.0
 */
class TjlmsControllerDashboard extends JControllerForm
{
	/**
	 * Constructor.
	 *
	 * @see     JControllerLegacy
	 *
	 * @since   1.0.0
	 *
	 * @throws  Exception
	 */
	public function __construct()
	{
		// Get download id
		$params           = JComponentHelper::getParams('com_tjlms');
		$this->downloadid = $params->get('downloadid');

		// Setup vars
		$this->updateStreamName = 'Shika Package';
		$this->updateStreamType = 'collection';
		$this->updateStreamUrl  = "https://techjoomla.com/updates/packages/all?dummy=tjlms.xml";
		$this->extensionElement = 'pkg_shika';
		$this->extensionType    = 'package';

		parent::__construct();
	}

	/**
	 * Function getLatestVersion for getting the latest version
	 *
	 * @return  obj extension object
	 */
	public function getLatestVersion()
	{
		// Get current extension ID
		$extension_id = $this->getExtensionId();

		if (!$extension_id)
		{
			return 0;
		}

		$db = JFactory::getDbo();

		// Get current extension ID
		$query = $db->getQuery(true)
			->select($db->qn(array('version', 'infourl')))
			->from($db->qn('#__updates'))
			->where($db->qn('extension_id') . ' = ' . $db->q($extension_id));
		$db->setQuery($query);

		$latestVersion = $db->loadObject();

		if (empty($latestVersion))
		{
			echo json_encode(0);
			jexit();
		}
		else
		{
			echo json_encode($latestVersion);
			jexit();
		}
	}

	/**
	 * Function getExtensionId for getting extension id.
	 *
	 * @return   integer  $extension_id  The id is returned
	 */
	public function getExtensionId()
	{
		$db = JFactory::getDbo();

		// Get current extension ID
		$query = $db->getQuery(true)
			->select($db->qn('extension_id'))
			->from($db->qn('#__extensions'))
			->where($db->qn('type') . ' = ' . $db->q($this->extensionType))
			->where($db->qn('element') . ' = ' . $db->q($this->extensionElement));
		$db->setQuery($query);

		$extension_id = $db->loadResult();

		if (empty($extension_id))
		{
			return 0;
		}
		else
		{
			return $extension_id;
		}
	}

	/**
	 * This prints the html to show the version is outdated
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function generateOutput()
	{
		header('Content-type: text/html; UTF-8');
		$input = JFactory::getApplication()->input;
		$currVer = $input->get('currVer', 0, 'STRING');
		$latestVar = $input->get('latestver', 0, 'STRING');

		ob_start();

		if ($currVer === $latestVar || $latestVar == 0)
		{
			include JPATH_BASE . '/components/com_tjlms/layouts/version.latest.php';
		}
		else
		{
			include JPATH_BASE . '/components/com_tjlms/layouts/version.outdated.php';
		}

		$layoutOutput = ob_get_contents();
		ob_end_clean();
		echo $layoutOutput;
		jexit();
	}
}
