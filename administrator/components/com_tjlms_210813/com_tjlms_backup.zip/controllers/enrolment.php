<?php
/**
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
// No direct access.
defined('_JEXEC') or die;
jimport('joomla.application.component.controlleradmin');

/**
 * Methods to get a list of enrollment users
 *
 * @since  1.0.0
 */
class TjlmsControllerEnrolment extends JControllerAdmin
{
	/**
	 * construct for enrollment
	 *
	 * @param   ARRAY  $config  Array
	 *
	 * @since  1.0.0
	 */
	public function __construct($config = array())
	{
		$this->_db = JFactory::getDbo();

		// Include helper of tjlms
		$path = JPATH_SITE . '/components/com_tjlms/helpers/main.php';
		$this->comtjlmsHelper = '';

		if (JFile::exists($path))
		{
			if (!class_exists('comtjlmsHelper'))
			{
				JLoader::register('comtjlmsHelper', $path);
				JLoader::load('comtjlmsHelper');
			}

			$this->comtjlmsHelper = new comtjlmsHelper;
		}

		// Load jlike model to call api function for assigndetails and other
		$path = JPATH_SITE . '/components/com_jlike/models/recommendations.php';
		$this->JlikeModelRecommendations = "";

		if (JFile::exists($path))
		{
			if (!class_exists('JlikeModelRecommendations'))
			{
				JLoader::register('JlikeModelRecommendations', $path);
				JLoader::load('JlikeModelRecommendations');
			}

			$this->JlikeModelRecommendations = new JlikeModelRecommendations;
		}

		// Load jlike admin model content form to call api to get content id
		$path = JPATH_SITE . '/administrator/components/com_jlike/models/contentform.php';

		$this->JlikeModelContentForm = "";

		if (JFile::exists($path))
		{
			if (!class_exists('JlikeModelContentForm'))
			{
				JLoader::register('JlikeModelContentForm', $path);
				JLoader::load('JlikeModelContentForm');
			}

			$this->JlikeModelContentForm = new JlikeModelContentForm;
		}

		parent::__construct($config);
	}

	/**
	 * Proxy for getModel.
	 *
	 * @param   STRING  $name    model name
	 * @param   STRING  $prefix  model prefix
	 * @param   ARRAY   $config  Array
	 *
	 * @return  void
	 *
	 * @since  1.0.0
	 */
	public function getModel($name = 'enrolment', $prefix = 'TjlmsModel', $config = array())
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));

		return $model;
	}

	/**
	 * function to enroll user from backend new
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	public function enrolUser()
	{
		$app       = JFactory::getApplication('administrator');
		$input     = JFactory::getApplication()->input;
		$post      = $input->post;

		$cid       = JFactory::getApplication()->input->get('cid', array(), 'array');
		$course_id = $post->get('course_id', '', 'INT');

		if (!$course_id)
		{
			$course_id            = $post->get('selectedcourse', '', 'array');

			// Filter for selected courses
			$selectedcoursefilter = $app->getUserStateFromRequest('com_tjlms.enrolment.filter.selectedcourse', 'selectedcourse', '', 'ARRAY');
			$this->getModel()->setState('filter.selectedcourse', $selectedcoursefilter);
		}

		$course_al = $post->get('course_al', '', 'STRING');
		$notify_user = ($post->get('notify_user_enroll', '', 'INT')) ? $post->get('notify_user_enroll', '', 'INT') : 0;
		$adminId   = JFactory::getUser()->id;
		$post->set('enrolled_by', $adminId, 'INT');

		// Call courses helper... Enroll user function is made common which is used fron frontend and backend.
		$tjlmsCoursesHelper = new tjlmsCoursesHelper;

		if (is_array($course_id))
		{
			$msg = JText::_('COM_TJLMS_COURSE_ENROLL_SUCCESS');

			foreach ($course_id AS $key => $val)
			{
				$post->set('course_id', $val, 'INT');
				$successfulEnroled = $tjlmsCoursesHelper->enroll_user(0, 0, $post, 0, $notify_user);
			}

			$this->setRedirect('index.php?option=com_tjlms&view=enrolment&tmpl=component', $msg);
		}
		else
		{
			$msg               = JText::_('COM_TJLMS_COURSE_ENROLL_SUCCESS');
			$successfulEnroled = $tjlmsCoursesHelper->enroll_user(0, 0, $post, 0, $notify_user);
			$this->setRedirect('index.php?option=com_tjlms&view=enrolment&tmpl=component&course_id=' . $course_id . '&course_al=' . $course_al, $msg);
		}

		$this->setRedirect('index.php?option=com_tjlms&view=enrolment&tmpl=component&course_id=' . $course_id . '&course_al=' . $course_al, $msg);
	}

	/**
	 * Assign User to particular course
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	public function assignUser()
	{
		$app                     = JFactory::getApplication('administrator');
		$model                   = $this->getModel('manageenrollments');
		$query                   = $this->_db->getQuery(true);
		$mainframe               = JFactory::getApplication();
		$input                   = JFactory::getApplication()->input;
		$post                    = $input->post;

		$batch_assign_start_date = $post->get('start_date', '', 'DATE');
		$batch_assign_end_date   = $post->get('due_date', '', 'DATE');
		$cids                    = $post->get('cid', '', 'ARRAY');
		$course_id               = $post->get('course_id', '', 'INT');
		$selectedcourse          = $post->get('selectedcourse', '', 'ARRAY');

		if ($selectedcourse)
		{
			// Filter for selected courses
			$selectedcoursefilter = $app->getUserStateFromRequest('com_tjlms.enrolment.filter.selectedcourse', 'selectedcourse', '', 'ARRAY');
			$this->getModel()->setState('filter.selectedcourse', $selectedcoursefilter);
		}

		$post->set('type', 'assign', 'ARRAY');
		$course_al = $post->get('course_al', '', 'STRING');

		// Loop through each user
		foreach ($cids AS $key => $cid)
		{
			foreach ($selectedcourse AS $course)
			{
				// Get content Id
				$data               = array();
				$data['element']    = 'com_tjlms.course';
				$data['element_id'] = $course;
				$course_url         = 'index.php?option=com_tjlms&view=course&id=' . $course;

				if ($this->comtjlmsHelper)
				{
					$itemId      = $this->comtjlmsHelper->getitemid($course_url);
					$data['url'] = $course_url . '&Itemid=' . $itemId;
				}
				else
				{
					$data['url'] = $course_url;
				}

				$content_id         = $this->JlikeModelContentForm->getConentId($data);

				// Get assignment Details
				$this->JlikeModelRecommendations = new JlikeModelRecommendations;

				if ($content_id)
				{
					$this->JlikeModelRecommendations->setState("content_id", $content_id);
				}

				$this->JlikeModelRecommendations->setState("type", "myassign");
				$this->JlikeModelRecommendations->setState("user_id", $cid);

				$assigndetails     = $this->JlikeModelRecommendations->getItems();

				$post->set('recommend_friends', $cid, 'ARRAY');

				if (isset($assigndetails[0]->id))
				{
					$post->set('todo_id', $assigndetails[0]->id, 'INT');
				}
				else
				{
					$post->set('todo_id', '', 'INT');
				}

				$post->set('element_id', $course, 'INT');
				$post->set('start_date', $batch_assign_start_date, 'DATE');
				$post->set('due_date', $batch_assign_end_date, 'DATE');

				// Call change due date to coursr for manage enrollments
				$res = $model->changeDateCourse();
			}
		}

		if ($res)
		{
			// Add a message to the message queue
			$mainframe->enqueueMessage(JText::_('COM_TJLMS_COURSE_ASSIGN_SUCCESS'), 'success');
		}
		else
		{
			// Add a message to the message queue
			$mainframe->enqueueMessage(JText::_('COM_TJLMS_COURSE_ASSIGN_FALIED'), 'error');
		}

		$this->setRedirect('index.php?option=com_tjlms&view=enrolment&tmpl=component&course_id=' . $course_id . '&course_al=' . $course_al);
	}

	/**
	 * change Due date
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	public function batchAssign()
	{
		$model     = $this->getModel('manageenrollments');
		$query     = $this->_db->getQuery(true);
		$mainframe = JFactory::getApplication();
		$input     = JFactory::getApplication()->input;
		$post      = $input->post;

		// Get data passed by the post from the view
		$batch_assign_start_date = $post->get('batch_start_date', '', 'DATE');
		$batch_assign_end_date   = $post->get('batch_due_date', '', 'DATE');

		if (empty($batch_assign_start_date))
		{
			$batch_assign_start_date = $post->get('start_date', '', 'DATE');
		}

		if (empty($batch_assign_end_date))
		{
			$batch_assign_end_date = $post->get('due_date', '', 'DATE');
		}

		$cids = $post->get('cid', '', 'ARRAY');
		$post->set('type', 'assign', 'ARRAY');

		$notify_user = $post->get('notify_user_batch', '', 'INT');
		$post->set('notify_user', $notify_user, 'INT');

		// Loop through data of each enrolment
		foreach ($cids AS $key => $cid)
		{
			$enrollmentdetails = $model->getenrollmentdetails($cid);

			if ($enrollmentdetails)
			{
				// Get content Id
				$data               = array();
				$data['element']    = 'com_tjlms.course';
				$data['element_id'] = $enrollmentdetails->course_id;
				$course_url         = 'index.php?option=com_tjlms&view=course&id=' . $enrollmentdetails->course_id;

				if ($this->comtjlmsHelper)
				{
					$itemId      = $this->comtjlmsHelper->getitemid($course_url);
					$data['url'] = $course_url . '&Itemid=' . $itemId;
				}
				else
				{
					$data['url'] = $course_url;
				}

				$content_id         = $this->JlikeModelContentForm->getConentId($data);

				// Get assignment Details
				$this->JlikeModelRecommendations = new JlikeModelRecommendations;

				if ($content_id)
				{
					$this->JlikeModelRecommendations->setState("content_id", $content_id);
				}

				$this->JlikeModelRecommendations->setState("type", "myassign");
				$this->JlikeModelRecommendations->setState("user_id", $enrollmentdetails->user_id);

				$assigndetails     = $this->JlikeModelRecommendations->getItems();

				$post->set('recommend_friends', $enrollmentdetails->user_id, 'ARRAY');

				if ($assigndetails[0]->id)
				{
					$post->set('todo_id', $assigndetails[0]->id, 'INT');
				}
				else
				{
					$post->set('todo_id', '', 'INT');
				}

				$post->set('element_id', $enrollmentdetails->course_id, 'INT');
				$post->set('start_date', $batch_assign_start_date, 'DATE');
				$post->set('due_date', $batch_assign_end_date, 'DATE');
			}
			// Call change due date to coursr for manage enrollments
			$res = $model->changeDateCourse();
		}

		if ($res)
		{
			// Add a message to the message queue
			$mainframe->enqueueMessage(JText::_('COM_TJLMS_ASSIGN_DUEDATE_CHANGE'), 'success');
		}
		else
		{
			// Add a message to the message queue
			$mainframe->enqueueMessage(JText::_('COM_TJLMS_BATCH_UPDATED_SUCCESSFULLY'), 'error');
		}

		$this->setRedirect('index.php?option=com_tjlms&view=manageenrollments');
	}
}
