<?php
/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Aniket <aniket_c@tekdi.net> - http://www.techjoomla.com
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Module controller class.
 */
class TjlmsControllerModule extends JControllerForm
{

	function __construct() {
		$this->view_list = 'modules';
		parent::__construct();
	}


	/**
	 * Function to save the module as per the course ID
	 *
	 */

	public function save($key = NULL, $urlVar = NULL)
	{

		$input = JFactory::getApplication()->input;
		$post = $input->post;

		$model = $this->getModel( 'module' );
		$data = $post->get('tjlms_module','','ARRAY');
		$mod_id = $data['id'];

		//save the module and the course ID along with that
		$savedTjmoduleID = $model->saveTjmodule( $data );

		$ret['OUTPUT'][0] = $savedTjmoduleID;

		if($mod_id > 0)
			echo JText::_('COM_TJLMS_MODULE_UPDATED_SUCCESSFULLY');
		else
			echo  JText::_('COM_TJLMS_MODULE_CREATED_SUCCESSFULLY');

		die();
		jexit();

		/*if( $savedTjmoduleID )
		{
				//$ntext = JText::_('COM_TJLMS_MODULE_CREATED_SUCCESSFULLY');
		}
		else
		{
				//$ntext = JText::_('COM_TJLMS_ERROR_MSG');
		}*/

		/*$this->setMessage(JText::plural($ntext, 1));

		if ($task == 'apply')
		{
			$link = JRoute::_('index.php?option=com_tjlms&view=module&layout=edit&id='.$savedTjmoduleID.'&course_id='.$courseId,false);
		}
		else if ($task == 'save')
		{
			$link = JRoute::_('index.php?option=com_tjlms&view=modules&course_id='.$courseId,false);
		}*/
		echo json_encode( $savedTjmoduleID );
		jexit();
		//$this->setRedirect($link,$ntext);
	}

	/**
	 * Redirect link for cancel button
	 */
	 /*
	public function cancel()
	{
		$input = JFactory::getApplication()->input;
		$post = $input->post;
		$data = $post->get('jform','','ARRAY');
		$courseId = $data['course_id'];
		$link = JRoute::_('index.php?option=com_tjlms&view=modules&course_id='.$courseId,false);
		$this->setRedirect($link);
	}
	* */

	/**
	 * Gets the URL arguments to append to an item redirect.
	 *
	 * @param   integer  $recordId  The primary key id for the item.
	 * @param   string   $urlVar    The name of the URL variable for the id.
	 *
	 * @return  string  The arguments to append to the redirect URL.
	 *
	 * @since   1.6
	 */
	/*protected function getRedirectToItemAppend($recordId = null, $urlVar = 'id')
	{
		$append = parent::getRedirectToItemAppend($recordId);
		$append .= '&course_id=' . $this->course_id;

		return $append;
	}*/

	/**
	 * Gets the URL arguments to append to a list redirect.
	 *
	 * @return  string  The arguments to append to the redirect URL.
	 *
	 * @since   1.6
	 */
	/*protected function getRedirectToListAppend()
	{
		$append = parent::getRedirectToListAppend();
		$append .= '&course_id=' . $this->course_id;

		return $append;
	}*/

}
