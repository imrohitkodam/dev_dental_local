<?php
/**
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
// No direct access.
defined('_JEXEC') or die;
jimport('joomla.application.component.controlleradmin');
jimport('joomla.filesystem.folder');

/**
 * Lessons list controller class.
 *
 * @since  1.0
 */
class TjlmsControllerLessons extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    The model name. Optional.
	 * @param   string  $prefix  The class prefix. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return  object  The model.
	 *
	 * @since   1.0
	 */
	public function getModel($name = 'lesson', $prefix = 'TjlmsModel', $config = array())
	{
		$model = parent::getModel($name, $prefix, array( 'ignore_request' => true ));

		return $model;
	}

	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$input = JFactory::getApplication()->input;
		$pks = $input->post->get('cid', array(), 'array');
		$order = $input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}

	/**
	 * Function used for saving ordering for lessons
	 *
	 * @return  void
	 *
	 * @since  1.0
	 */
	public function saveSortingForLessons()
	{
		$input = JFactory::getApplication()->input;

		// Get course ID
		$courseId = $input->get('course_id', 0, 'INT');

		// Get module ID
		$modId_str = $input->get('mod_id', '', 'STRING');
		$modIdar = explode('_', $modId_str);
		$modId = $modIdar[1];
		$model = $this->getModel('lessons');
		$post = $input->post;

		if (!empty($_POST))
		{
			// First check if the lesson belongs to module. if not update the lesson module ID
			foreach ($_POST as $key => $value)
			{
				if (strpos($key, 'lessonlist_') !== false)
				{
					// Get leson ID form "lessonlist_1"
					$lessonId = explode('_', $key);

					// Here we get lesson ID as 1
					$lessonId = $lessonId[1];

					// Update lesson module ID
					$model->updateLessonsModule($lessonId, $modId, $courseId);
				}
			}

			// Get ordering of all lessons in that module
			$data = $model->getLessonsOrderList($courseId, $modId);

			foreach ($_POST as $key => $value)
			{
				if (strpos($key, 'lessonlist_') !== false)
				{
					$key_order = explode('_', $key);
					$key_order = $key_order[1];

					// Rank obtain after sorting
					$newRank = $value;

					// Ranks bedore sorting..which is store in DB
					$currentRank = $data[$key_order];

					if ($currentRank != $newRank)
					{
						$model->switchOrderLesson($key_order, $newRank, $courseId, $modId);
					}
				}
			}
		}
	}

	/**
	 * Function called from ajax from modules view
	 * Used to delete lesson
	 *
	 * @return  JSON
	 *
	 * @since  1.0
	 */
	public function deletLesson()
	{
		$input = JFactory::getApplication()->input;
		$courseId = $input->get('course_id', 0, 'INT');
		$modId = $input->get('mod_id', 0, 'INT');
		$lessonId = $input->get('lesson_id', 0, 'INT');
		$model = $this->getModel('lessons');

		// ADDED BY RENU
		// $deletLesson = $model->deletLesson($courseId, $modId, $lessonId);
		require_once JPATH_SITE . '/components/com_tjlms/helpers/lesson.php';
		$this->lessonHelper = new TjlmsLessonHelper;
		$deletLesson = $this->lessonHelper->deletLesson($courseId, $modId, $lessonId);

		// Delete quiz if any in the lesson
		if (JFolder::exists(JPATH_SITE . '/components/com_tmt'))
		{
			jimport('joomla.application.component.modellist');
			JLoader::import('tests', JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_tmt' . DS . 'models');

			$testsModel = new TmtModeltests;
			$testsModel->delete_lessonquiz($lessonId);
		}

		if (is_dir(JPATH_SITE . '/components/com_tjlms' . '/lessons/' . $lessonId))
		{
			JFolder::delete(JPATH_SITE . '/components/com_tjlms' . '/lessons/' . $lessonId);
		}

		echo json_encode($deletLesson);
		jexit();
	}

	/**
	 * Function used to remove associated files
	 *
	 * @return  JSON
	 *
	 * @since  1.0
	 */
	public function removeAssocFiles()
	{
		$input = JFactory::getApplication()->input;
		$mediaId = $input->get('media_id', '0', 'INT');
		$lessonId = $input->get('lesson_id', '0', 'INT');
		$model = $this->getModel('lessons');
		$removeAssocFiles = $model->removeAssocFiles($mediaId, $lessonId);
		echo json_encode($removeAssocFiles);
		jexit();
	}
}
