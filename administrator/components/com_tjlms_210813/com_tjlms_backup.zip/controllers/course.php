<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Coupon controller class.
 *
 * @since  1.0.0
 */
class TjlmsControllerCourse extends JControllerForm
{
	/**
	 * Constructor.
	 *
	 * @see     JControllerLegacy
	 *
	 * @since   1.0.0
	 *
	 * @throws  Exception
	 */
	public function __construct()
	{
		parent::__construct();

		$this->view_list = 'courses';
		$this->text_prefix = 'COM_TJLMS_COURSE';
	}

	/**
	 * Method to save course information
	 *
	 * @param   string  $key     TO ADD
	 * @param   string  $urlVar  TO ADD
	 *
	 * @return    void
	 *
	 * @since    1.6
	 */
	public function save($key = null, $urlVar = null)
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Initialise variables.
		$app   = JFactory::getApplication();
		$model = $this->getModel('Course', 'TjlmsModel');

		// Get the user data.
		$data = JFactory::getApplication()->input->get('jform', array(), 'array');

		// Jform tweaing starts.
		// JForm tweak - Save all jform array data in a new array for later reference.
		$all_jform_data = $data;

		// Jform tweak - Get all posted data.
		$post = JFactory::getApplication()->input->post;

		// Validate the posted data.
		$form = $model->getForm();

		if (!$form)
		{
			JError::raiseError(500, $model->getError());

			return false;
		}

		// Validate the posted data.
		$data = $model->validate($form, $data);

		// Check for errors.
		if ($data === false)
		{
			// Get the validation messages.
			$errors = $model->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++)
			{
				if ($errors[$i] instanceof Exception)
				{
					$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				}
				else
				{
					$app->enqueueMessage($errors[$i], 'warning');
				}
			}

			// Save the data in the session.
			// Tweak.
			$app->setUserState('com_tjlms.edit.course.data', $all_jform_data);

			// Tweak *important
			$app->setUserState('com_tjlms.edit.course.id', $all_jform_data['id']);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_tjlms.edit.course.id');
			$this->setRedirect(JRoute::_('index.php?option=com_tjlms&view=course&layout=edit&id=' . $id, false));

			return false;
		}

		// Jform tweaking - get data for extra fields jform.
		$extra_jform_data = array_diff_key($all_jform_data, $data);

		/* Attempt to save the data.
		$return = $model->save($data);
		Tweaked. */
		$return = $model->save($data, $extra_jform_data, $post);

		// Check for errors.
		if ($return === false)
		{
			/* Save the data in the session.
			$app->setUserState('com_tjlms.edit.event.data', $data);
			Tweak.*/
			$app->setUserState('com_tjlms.edit.course.data', $all_jform_data);

			/* Tweak *important.
			$app->setUserState('com_tjlms.edit.event.id', $all_jform_data['id']);*/

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_tjlms.edit.course.id');
			$this->setMessage(JText::sprintf('COM_TJLMS_COURSE_ERROR_MSG_SAVE', $model->getError()), 'warning');
			$this->setRedirect(JRoute::_('index.php?option=com_tjlms&&view=course&layout=edit&id=' . $id, false));

			return false;
		}

		$msg      = JText::_('COM_TJLMS_COURSE_CREATED_SUCCESSFULLY');
		$input = JFactory::getApplication()->input;
		$id = $input->get('id');

		if (empty($id))
		{
			$id = $return;
		}

		$task = $input->get('task');

		if ($task == 'apply')
		{
			$redirect = JRoute::_('index.php?option=com_tjlms&&view=course&layout=edit&id=' . $id, false);
			$app->redirect($redirect, $msg);
		}

		if ($task == 'save2new')
		{
			$redirect = JRoute::_('index.php?option=com_tjlms&&view=course&layout=edit', false);
			$app->redirect($redirect, $msg);
		}

		// Clear the profile id from the session.
		$app->setUserState('com_tjlms.edit.course.id', null);

		// Check in the profile.
		if ($return)
		{
			$model->checkin($return);
		}

		// Redirect to the list screen.
		$redirect = JRoute::_('index.php?option=com_tjlms&view=courses', false);
		$app->redirect($redirect, $msg);

		// Flush the data from the session.
		$app->setUserState('com_tjlms.edit.course.data', null);
	}

	/**
	 * Redirect to manage training material page
	 *
	 * @return    void
	 * 
	 * @since    1.1
	 */
	public function managematerial()
	{
		$app = JFactory::getApplication();

		$url = 'index.php?option=com_tjlms&view=modules&course_id=' . $app->input->get('id');
		$app->redirect($url);
	}
}
