<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');
jimport('techjoomla.common');

/**
 * Courses list controller class.
 *
 * @since  1.0.0
 */
class TjlmsControllerActivities extends JControllerAdmin
{
	/**
	 * Function used to export data in csv format
	 *
	 * @return  jexit
	 *
	 * @since   1.0.0
	 */
	public function csvexport()
	{
		$this->techjoomlacommon = new TechjoomlaCommon;
		$lmsparams   = JComponentHelper::getParams('com_tjlms');
		$date_format_show = $lmsparams->get('date_format_show', 'Y-m-d H:i:s');

		$input      = Jfactory::getApplication()->input;
		$post       = $input->post;
		$com_params = JComponentHelper::getParams('com_tjlms');
		$model      = $this->getModel('activities');
		$data       = $model->getItems();

		// Create CSV headers
		$csvData       = null;
		$csvData_arr[] = JText::_('COM_TJLMS_ACTIVITY_TEXT');

		$csvData .= implode(',', $csvData_arr);
		$csvData .= "\n";
		echo $csvData;

		$csvData = '';
		$filename = "lms_activities_report_" . date("Y-m-d_H-i", time());

		// Set CSV headers
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename=" . $filename . ".csv");
		header("Pragma: no-cache");
		header("Expires: 0");

		$comtjlmstrackingHelper = new comtjlmstrackingHelper;

		foreach ($data as $activityData)
		{
			$csvData      = '';
			$csvData_arr1 = array();

			$csvData_arr1[] = strip_tags($activityData->actionString);

			if (!empty($activityData->added_time))
			{
				if ($activityData->added_time != '-')
				{
					$activityData->added_time = $this->techjoomlacommon->getDateInLocal($activityData->added_time, 0, $date_format_show);
				}

				if ($activityData->added_time == '0000-00-00 00:00:00')
				{
					$activityData->added_time = '-';
				}
			}

			$csvData_arr1[] = $activityData->added_time;
			$csvData_arr1[] = $activityData->action;

			// TRIGGER After csv body add extra fields
			$csvData = implode(',', $csvData_arr1);
			echo $csvData . "\n";
		}

		jexit();
	}
}
