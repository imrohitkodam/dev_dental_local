<?php

/**
 * @version     1.0.0
 * @package     com_tjlms
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      TechJoomla <extensions@techjoomla.com> - www.techjoomla.com
 */
// No direct access
defined('_JEXEC') or die;


class TjlmsTableStorages3 extends JTable
{

	var $storageid = null;
	var $resource_path = null;


	public function __construct(&$db) {
		parent::__construct('#__tjlms_storage_s3', 'storageid', $db);
	}

	public function store($updateNulls = null) {
		$k = $this->_tbl_key;

		if (empty($this->$k)) {
			return false;
		}

		$db = $this->getDBO();

		$query = 'SELECT count(*)'
				. ' FROM ' . $this->_tbl
				. ' WHERE ' . $this->_tbl_key . ' = ' . $db->Quote($this->storageid);
		$db->setQuery($query);
		$isExist = $db->loadResult();

		if (!$isExist) {
			$query = 'INSERT INTO ' . $this->_tbl
					. ' SET ' . $db->quoteName('storageid') . '=' . $db->Quote($this->storageid)
					. ' , ' . $db->quoteName('resource_path') . '= ' . $db->Quote($this->resource_path);
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				JError::raiseError(500, $db->stderr());
			}
		} else {
			$query = 'UPDATE ' . $this->_tbl
					. ' SET ' . $db->quoteName('resource_path') . '= ' . $db->Quote($this->resource_path)
					. ' WHERE ' . $db->quoteName('storageid') . '=' . $db->Quote($this->storageid);
			$db->setQuery($query);
			$db->query();
			if ($db->getErrorNum()) {
				JError::raiseError(500, $db->stderr());
			}
		}

		return true;
	}

}
