<?php
/**
 * @version    SVN: <svn_id>
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');
jimport('joomla.filesystem.folder');
/**
 * Methods supporting a list of Tjlms records.
 *
 * @since  1.0
 */
class TjlmsModelModules extends JModelList
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see  JController
	 *
	 * @since    1.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'created_by', 'a.created_by',
				'name', 'a.name',
				'course_id', 'a.course_id',

			);
		}

		parent::__construct($config);
		parent::__construct();
		$this->tjlmsHelper   = new TjlmsHelper;
	}

	/**
	 * Method to auto-populate the model state.
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   String  $ordering   optional Ordering
	 *
	 * @param   String  $direction  optional direction
	 *
	 * @return  void
	 *
	 * @since	1.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
		$app = JFactory::getApplication('administrator');

		// Load the filter state.
		$search = $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$published = $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_published', '', 'string');
		$this->setState('filter.state', $published);

		// Load the parameters.
		$params = JComponentHelper::getParams('com_tjlms');
		$this->setState('params', $params);

		// List state information.
		parent::populateState('a.name', 'asc');
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since	1.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return	JDatabaseQuery
	 *
	 * @since	1.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
				$this->getState(
						'list.select', 'a.*'
				)
		);
		$query->from('`#__tjlms_modules` AS a');

		// Join over the users for the checked out user
		$query->select("uc.name AS editor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");

		/* Join over the user field 'created_by'
		/*$query->select('created_by.name AS created_by');
		$query->join('LEFT', '#__users AS created_by ON created_by.id = a.created_by');*/

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.name LIKE ' . $search . ' )');
			}
		}

		// Add the list ordering clause.
		$orderCol = $this->state->get('list.ordering');
		$orderDirn = $this->state->get('list.direction');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get Items
	 *
	 * @return	void
	 *
	 * @since	1.0
	 */
	public function getItems()
	{
		$items = parent::getItems();

		// Convert date from utc to local
		return $items;
	}

	/**
	 * Function used to get the module data for a course.
	 * Used in module list view for a course. Lessons info is append to the array of the module data.
	 * Also this function is used when only module data is needed
	 *
	 * @param   INT  $modId  optional id of the module
	 *
	 * @return  void
	 *
	 * @since	1.0
	 */
	public function getModuleData($modId='')
	{
		$db	= JFactory::getDBO();
		$input = JFactory::getApplication()->input;
		$courseId = $input->get('course_id', 0, 'INT');
		$params = JComponentHelper::getParams('com_tjlms');
		$allowAssocFiles = $params->get('allow_associate_files', '0', 'INT');

		if ($modId)
		{
			// Added to query id the module ID is present so only single module data is genarated.
			$where = " AND id=" . $modId;
		}
		else
		{
			$where = " ORDER BY  `ordering` ASC ";
		}

		$query = $db->getQuery(true);

		$query->select('* FROM #__tjlms_modules');
		$query->where('course_id=' . $courseId . ' ' . $where . ' ');

		$db->setQuery($query);

		if ($modId)
		{
			// As single data has been fetch
			$moduleData = $db->loadAssoc();
		}
		else
		{
			$moduleData = $db->loadobjectlist();

			// For each added to append lesson data for each Module. require for module list page of a course.
			foreach ($moduleData as $modData)
			{
				$config = JFactory::getConfig();
				$offset = $config->get('offset');

				// Get leesons info for each module
				$queryForLessons = $db->getQuery(true);
				$queryForLessons->select('l.* ');
				$queryForLessons->from('#__tjlms_lessons as l');
				$queryForLessons->where('l.mod_id=' . $modData->id);

				$queryForLessons->order('`ordering` ASC');
				$db->setQuery($queryForLessons);
				$moduleLessons = $db->loadobjectlist();

				foreach ($moduleLessons as $ind => $l_obj)
				{
					$format = $l_obj->format;

					if ($format == 'tmtQuiz')
					{
						if (JFolder::exists(JPATH_SITE . '/components/com_tmt'))
						{
							$queryForFormat = $db->getQuery(true);
							$queryForFormat->select('q.test_id as quiz_id');
							$queryForFormat->FROM("#__tjlms_tmtquiz as q");
							$queryForFormat->where("q.lesson_id = " . $l_obj->id);
							$db->setQuery($queryForFormat);
							$l_obj->quiz_id = $db->loadResult();
						}
					}
					else
					{
						if (!empty($l_obj->media_id))
						{
							$queryForFormat = $db->getQuery(true);
							$queryForFormat->select('m.sub_format,m.format');
							$queryForFormat->from('#__tjlms_media as m');
							$queryForFormat->join('LEFT', '#__tjlms_lessons as l ON l.media_id=m.id');
							$queryForFormat->where("l.id = " . $l_obj->id);
							$db->setQuery($queryForFormat);
							$res = $db->loadObject();

							$l_obj->sub_format = $l_obj->format = '';

							if (!empty($res))
							{
								$plg_type = 'tj' . $res->format;

								$format_subformat = explode('.', $res->sub_format);
								$plg_name = $format_subformat[0];

								JPluginHelper::importPlugin($plg_type);
								$dispatcher = JDispatcher::getInstance();
								$checkFormat = $dispatcher->trigger('additional' . $plg_name . 'FormatCheck', array($l_obj->id, $res));

								if (!empty($checkFormat[0]))
								{
									$format_res = $checkFormat[0];

									if ($format_res)
									{
										$l_obj->sub_format = $format_res->sub_format;
										$l_obj->format = $format_res->format;
									}
								}
							}
						}
					}

					/* Date value changed froom utc to local
					$format = $l_obj->format;

					if ($format == 'scorm' || $format == 'tjscorm')
					{
						$query = "SELECT id,package FROM #__tjlms_scorm WHERE lesson_id=" . $l_obj->id . ' ORDER BY id DESC LIMIT 1';
						$db->setQuery($query);
						$scorm_details = $db->loadAssoc();
						$l_obj->format_details['id'] = $scorm_details['id'];
						$l_obj->format_details['org_filename'] = $scorm_details['package'];
						$l_obj->format_details['source'] = $scorm_details['package'];
					}
					else
					{
						$query = "SELECT * FROM #__tjlms_media WHERE id=" . $l_obj->media_id;
						$db->setQuery($query);
						$l_obj->format_details = $db->loadAssoc();

						if ($l_obj->format_details['sub_format'])
						{
							$sub_format = explode('.', $l_obj->format_details['sub_format']);
							$l_obj->lessonSubFormat_HTML[$format] = $this->getallSubFormats_HTML($format, $sub_format[0], $modData->id, $l_obj->id, $l_obj);
							$l_obj->lessonSubFormats[$format] = $this->getallSubFormats($format);
						}
					}*/

					if ($allowAssocFiles == 1)
					{
							$query = " SELECT af.id , af.`media_id`,f.`org_filename` as filename FROM `#__tjlms_media` as f
										INNER JOIN `#__tjlms_associated_files` as af
										ON af.media_id=f.id
										WHERE af.`lesson_id`=" . $l_obj->id;
							$db->setQuery($query);
							$l_obj->oldAssociateFiles = $db->loadObjectList();
					}

					/* Durgesh added for max no_of_attempts */
					$query = $db->getQuery(true);
					$query->select('max(attempt) as total,l.no_of_attempts');
					$query->from('#__tjlms_lesson_track as lt');
					$query->leftjoin('#__tjlms_lessons as l ON l.id = lt.lesson_id');
					$query->where('lesson_id  = ' . $l_obj->id);
					$db->setQuery($query);
					$result = $db->loadobject();
					$l_obj->max_attempt = $result->total;
					/* Durgesh added for max no_of_attempts */
				}

				$modData->lessons = $moduleLessons;
			}
		}

		return $moduleData;
	}

	/**
	 * function is used to save sorting of modules.
	 *
	 * @param   int  $courseId  Course id
	 *
	 * @return  boolean
	 *
	 * @since   1.0
	 **/
	public function getModuleOrderList($courseId)
	{
		$db	= JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('id,ordering FROM #__tjlms_modules');
		$query->where('course_id=' . $courseId);
		$db->setQuery($query);
		$moduleOrder = $db->loadobjectlist();

		if (!empty($moduleOrder) && count($moduleOrder) > 0)
		{
			$list = array();

			foreach ($moduleOrder as $key => $m_order)
			{
				$list[ $m_order->id ] = $m_order->ordering;
			}

			return $list;
		}
		else
		{
			return false;
		}
	}

	/**
	 *	Save ordering for modules whose ordering has been change
	 *
	 * @param   int  $key       module_id
	 *
	 * @param   int  $newRank   new ordering
	 *
	 * @param   int  $courseId  Course id
	 *
	 * @return boolean
	 *
	 * @since	1.0
	 **/
	public function switchOrder($key, $newRank, $courseId)
	{
		$db	= JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->update('#__tjlms_modules');
		$query->set('ordering=' . $newRank);
		$query->where('id=' . $key . ' AND course_id=' . $courseId);
		$db->setQuery($query);
		$db->execute();

		return true;
	}

	/**
	 * Function used to delete the module of a course.
	 *	Ordering of rest of the module is updated accordingly
	 *
	 * @param   int  $courseId  Course id
	 *
	 * @param   int  $moduleId  module id
	 *
	 * @return boolean
	 *
	 * @since  1.0
	 **/
	public function deleteModule($courseId, $moduleId)
	{
		// Get the order of the module which has to be deleted
		$db	= JFactory::getDBO();
		$query = "SELECT `ordering` FROM `#__tjlms_modules` WHERE course_id=" . $courseId . " AND id=" . $moduleId;
		$db->setQuery($query);
		$currentOrder = $db->loadResult();

		// Update the order for rest of the module
		$query = "UPDATE `#__tjlms_modules` SET `ordering`=`ordering`-1 WHERE `ordering`>" . $currentOrder . " AND course_id=" . $courseId;
		$db->setQuery($query);
		$db->execute();

		// Delete the module
		$query = "DELETE FROM #__tjlms_modules WHERE id =" . $moduleId . " AND course_id=" . $courseId;
		$db->setQuery($query);

		if ($db->execute())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	/**
	 * Function used to chage the state of the module
	 *
	 * @param   int  $moduleId  module id
	 *
	 * @param   int  $state     State to be assigned
	 *
	 * @return boolean
	 *
	 * @since  1.0
	 **/
	public function changeState($moduleId, $state)
	{
		$db = JFactory::getDBO();

		// Update the state  of the module
		$query = "UPDATE `#__tjlms_modules` SET `state`= $state WHERE id =" . $moduleId;
		$db->setQuery($query);

		if ($db->execute())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	/**
	 * Function used to get the current course Info
	 *
	 * @param   INT  $courseId  id out the course
	 *
	 * @return Object of the course
	 *
	 * @since	1.0
	 * */
	public function getPresentCourseInfo($courseId)
	{
		$courseInfo = '';

		if ($courseId)
		{
			$tjlmsCoursesHelper = new tjlmsCoursesHelper;
			$courseInfo = $tjlmsCoursesHelper->getcourseInfo($courseId);

			if ($courseInfo)
			{
				// Get image to be shown for course
				$courseInfo->image = $tjlmsCoursesHelper->getCourseImage((array) $courseInfo, 'S_');
			}

			return $courseInfo;
		}
	}

	/**
	 * Function used to get Jform of lesson
	 *
	 * @param   array    $data      data to be used for form
	 *
	 * @param   boolean  $loadData  boolean value
	 *
	 * @return Object of the form
	 *
	 * @since	1.0
	 * */
	public function getLessonForm($data = array(), $loadData = true)
	{
		// Initialise variables.
		$app	= JFactory::getApplication();

		// Get the form.
		$form = $this->loadForm('com_tjlms.lesson', 'lesson', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Function used to get all associate files
	 *
	 * @param   INT  $lesson_id  lesson id
	 *
	 * @return  Object list of files
	 *
	 * @since  1.0.0
	 */
	public function getallAssociatedFiles($lesson_id)
	{
		$db	= JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('m.org_filename as filename,m.source as path, af.id, af.media_id');
		$query->from('#__tjlms_media as m');
		$query->join('INNER', '#__tjlms_associated_files as af ON af.media_id=m.id');
		$query->where('format="associate"');
		$query->where('af.media_id NOT IN  (SELECT DISTINCT(taf.media_id) FROM #__tjlms_associated_files as taf WHERE lesson_id = ' . $lesson_id . ' )');

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			$query->where('( m.org_filename LIKE ' . $search . ' )');
		}

		$db->setQuery($query);

		$select_files = $db->loadObjectList('media_id');

		return $select_files;
	}

	/**
	 * Function used to get all sub formats
	 *
	 * @param   string  $format_name  name of the format
	 *
	 * @return select list of sub formats
	 *
	 * @since  1.0.0
	 */
	public function getallSubFormats($format_name)
	{
		$format_name = 'tj' . $format_name;
		JPluginHelper::importPlugin($format_name);
		$dispatcher = JDispatcher::getInstance();
		$formats = $dispatcher->trigger('getSubFormat_' . $format_name . 'ContentInfo');

		if (!empty($formats))
		{
			return $formats;
		}
		else
		{
			return '';
		}

		$subformat = array();

		foreach ($formats as $format)
		{
			$subformat[] = JHTML::_('select.option', $format['id'], $format['name']);
		}

		$subformat_options = JHTML::_('select.genericlist', $subformat, "lesson_format[" . $format_name . "_subformat]",
							'class="class_' . $format_name . '_subformat" onchange="getVideosubFormat(this);"', "value", "text");

		return $subformat_options;
	}

	/**
	 * Function used to get all sub formats
	 *
	 * @param   INT     $lesson_id   lesson_id
	 * @param   string  $format      format of the lesson
	 * @param   string  $sub_format  sub format of the lesson
	 *
	 * @return  Object list of files
	 *
	 * @since  1.0.0
	 *
	 * public function getallSubFormats_HTML($format, $sub_format, $mod_id, $lesson_id, $media_id)*/
	public function getallSubFormats_HTML($lesson_id, $format, $sub_format)
	{
		$db	= JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('l.id as lesson_id,l.mod_id,l.media_id,l.course_id');
		$query->select('m.id as media_id,m.sub_format,m.format,m.params,m.org_filename,m.source');
		$query->from('#__tjlms_lessons as l');
		$query->join('LEFT', '#__tjlms_media as m ON l.media_id=m.id');
		$query->where('l.id = ' . $lesson_id);
		$db->setQuery($query);

		$lesson = $db->loadObject();

		$lesson_id = $lesson->lesson_id;
		$mod_id = $lesson->mod_id;
		$format = 'tj' . $format;
		$comp_params = JComponentHelper::getParams('com_tjlms');

		/*$sub_format_options =	explode('.', $lesson->sub_format);
		$sub_format = $sub_format_options[0];*/
		/*$format = 'tj' . $format;

		$comp_params = JComponentHelper::getParams('com_tjlms');


		$db	= JFactory::getDBO();
		$query = "SELECT * FROM #__tjlms_lessons WHERE id=" . $lesson_id . ' LIMIT 1';
		$db->setQuery($query);
		$lesson = $db->loadObject();


		if ($format == 'scorm' || $format == 'tjscorm')
		{
			$query = "SELECT id,package FROM #__tjlms_scorm WHERE lesson_id=" . $l_obj->id . ' ORDER BY id DESC LIMIT 1';
			$db->setQuery($query);
			$scorm_details = $db->loadAssoc();
			$lesson->format_details['id'] = $scorm_details['id'];
			$lesson->format_details['org_filename'] = $scorm_details['package'];
			$lesson->format_details['source'] = $scorm_details['package'];
		}
		else
		{
			$query = "SELECT * FROM #__tjlms_media WHERE id=" . $media_id;
			$db->setQuery($query);
			$lesson->format_details = $db->loadAssoc();
		}
*/
		$dispatcher = JEventDispatcher::getInstance();
		JPluginHelper::importPlugin($format, $sub_format);

		// Call the plugin and get the result
		$results = $dispatcher->trigger('getSubFormat_' . $sub_format . 'ContentHTML', array($mod_id, $lesson_id, $lesson, $comp_params));

		if (!empty($results))
		{
			if (!empty($lesson_id))
			{
			}

			return $results[0];
		}
		else
		{
			return '';
		}
	}
}
