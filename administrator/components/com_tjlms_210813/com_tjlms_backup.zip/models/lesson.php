<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.modeladmin');
jimport('joomla.filesystem.folder');
jimport('techjoomla.common');

/**
 * Tjlms model.
 *
 * @since  1.0.0
 */
class TjlmsModelLesson extends JModelAdmin
{
	protected $text_prefix = 'COM_TJLMS';

	/**
	 * Constructor.
	 *
	 * @see     JControllerLegacy
	 *
	 * @since   1.0.0
	 *
	 * @throws  Exception
	 */
	public function __construct()
	{
		$this->tjlmsHelper   = new TjlmsHelper;
		$this->tjlmsdbhelper = new tjlmsdbhelper;
		$this->ComtjlmsHelper   = new ComtjlmsHelper;
		$this->techjoomlacommon = new TechjoomlaCommon;
		parent::__construct();
	}

	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param   type    $type    The table type to instantiate
	 * @param   string  $prefix  A prefix for the table class name. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return    JTable    A database object
	 *
	 * @since    1.6
	 */
	public function getTable($type = 'Lesson', $prefix = 'TjlmsTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   array    $data      An optional array of data for the form to interogate.
	 * @param   boolean  $loadData  True if the form is to load its own data (default case), false if not.
	 *
	 * @return    JForm    A JForm object on success, false on failure
	 *
	 * @since    1.0.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Initialise variables.
		$app = JFactory::getApplication();

		// Get the form.
		$form = $this->loadForm('com_tjlms.lesson', 'lesson', array(
				'control' => 'jform',
				'load_data' => $loadData
				)
			);

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return   mixed  The data for the form.
	 *
	 * @since   1.0.0
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_tjlms.edit.lesson.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	/**
	 * Method to get a single record.
	 *
	 * @param   integer  $pk  The id of the primary key.
	 *
	 * @return   mixed  Object on success, false on failure.
	 *
	 * @since  1.0.0
	 */
	public function getItem($pk = null)
	{
		if ($item = parent::getItem($pk))
		{
			// Do any procesing on fields here if needed
			if ($item->id)
			{
				$db    = JFactory::getDBO();
				$query = " SELECT af.`media_id`,f.`filename`,f.`path` FROM `#__tjlms_files` as f
						INNER JOIN `#__tjlms_associated_files` as af
						ON af.media_id=f.id
						WHERE af.`lesson_id`=" . $item->id;
				$db->setQuery($query);
				$item->oldAssociateFiles = $db->loadObjectList();
				$format                   = $item->format;
				$item->format_field       = '';
				$item->format_scorm_field = '';
				$item->format_video_field = '';
				$item->format_media_field = '';

				if ($format == 'scorm' || $format == 'tjscorm')
				{
					$query = "SELECT * FROM #__tjlms_scorm WHERE lesson_id=" . $item->id;
					$db->setQuery($query);
					$scorm_details                          = $db->loadAssoc();
					$item->format_details['saved_filename'] = $scorm_details['package'];
				}
				else
				{
					// Take media id
					$query = "SELECT * FROM #__tjlms_media WHERE id=" . $item->media_id;
					$db->setQuery($query);
					$item->format_details = $db->loadAssoc();
				}
			}
		}

		return $item;
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @param   ARRAY  $table  Table instance
	 *
	 * @return  void
	 *
	 * @since    1.6
	 */
	protected function prepareTable($table)
	{
		jimport('joomla.filter.output');

		if (empty($table->id))
		{
			// Set ordering to the last item if not set
			if (@$table->ordering === '')
			{
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__tjlms_lessons');
				$max             = $db->loadResult();
				$table->ordering = $max + 1;
			}
		}
	}

	/**
	 * Method to lessons along with course ID and module ID
	 *
	 * @param   ARRAY  $post   Post Array
	 * @param   ARRAY  $files  Files Array
	 *
	 * @return  INT
	 *
	 * @since    1.0.0
	 **/
	public function saveLesson($post, $files)
	{
		$db = JFactory::getDBO();
		$lesson_data = $post->get('jform', '', 'ARRAY');

		if (!empty($lesson_data['start_date']))
		{
			$lesson_data['start_date'] = $this->techjoomlacommon->getDateInUtc($lesson_data['start_date']);
		}

		if (!empty($lesson_data['end_date']))
		{
			$lesson_data['end_date'] = $this->techjoomlacommon->getDateInUtc($lesson_data['end_date']);
		}

		if (!empty($lesson_data['eligibility_criteria']))
		{
			$lesson_data['eligibility_criteria'] = ',' . implode(',', $lesson_data['eligibility_criteria']) . ',';
		}
		else
		{
			$lesson_data['eligibility_criteria'] = '';
		}

		if (empty($lesson_data['image']))
		{
			unset($lesson_data['image']);
		}

		$lesson_data['created_by'] = JFactory::getUser()->id;

		$table = $this->getTable();

		if ($table->save($lesson_data) === true)
		{
			$id = $table->id;
		}

		$courseId = $lesson_data['course_id'];
		$modId    = $lesson_data['mod_id'];

		if (isset($id) && $id)
		{
			// Code to upload image file of lesson
			$jformfiles = $post->files->get('jform', '', 'array');

			if (!empty($jformfiles))
			{
				$lesson_img = $jformfiles['image'];

				if (!empty($lesson_img['name']))
				{
					// Save uploaded image.
					require_once JPATH_SITE . "/components/com_tjlms/helpers/media.php";
					$tjlmsmediaHelper  = new tjlmsmediaHelper;
					$orginale_filename = $tjlmsmediaHelper->imageupload('lesson', $id);

					if (!$orginale_filename)
					{
						return -2;
					}

					// Save event id into integration xref table.
					$obj        = new stdclass;
					$obj->id    = $id;
					$obj->image = $orginale_filename;
					$obj->storage = 'local';
					$db = JFactory::getDBO();

					if ($orginale_filename)
					{
						$this->removeLessonImage($id);

						if (!$db->updateObject('#__tjlms_lessons', $obj, 'id'))
						{
							echo $db->stderr();

							return -1;
						}
					}
				}
			}
		}
		else
		{
			return -3;
		}

		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');

		// Trigger all "sytem" plugins OnAfterLessonCreation method
		$dispatcher->trigger('OnAfterLessonCreation', array(
															$courseId,
															$id,
															$lesson_data
														)
							);

		return $id;
	}

	/**
	 * Function to update lesson format
	 *
	 * Array
	 * (
	 * [video_subformat] => jwplayer
	 * [jwplayer] => Array
	 * (
	 * [subformatoption] => url
	 * [url] => sdfsd
	 * [upload] =>
	 * )
	 * [upload] =>
	 * [format] => video
	 * [format_id] => 0
	 * [id] => 23
	 * )
	 *
	 * @param   ARRAY  $post  Post Array
	 *
	 * @return  boolean
	 *
	 * @since  1.0.0
	 */
	public function updateformat($post)
	{
		$db          = JFactory::getDBO();
		$format_data = $post->get('lesson_format', '', 'ARRAY');
		$lesson_obj       = new stdclass;
		$lesson_obj->id     = $format_data['id'];
		$lesson_obj->format = $format_data['format'];

		$subfomatopt = $format_data['subformat'];

		$media_id = 0;

		if (!empty($format_data[$subfomatopt]))
		{
			$subformatdata = $format_data[$subfomatopt];

			if ($subformatdata['subformatoption'] != 'upload')
			{
				$option = $subformatdata['subformatoption'];

				$lessonformat_data             = new stdclass;
				$lessonformat_data->format     = $lesson_obj->format;
				$lessonformat_data->sub_format = $subfomatopt . '.' . $option;

				$formatsource  = $subformatdata[$option];

				if ($formatsource)
				{
					$lessonformat_data->source     = $formatsource;
				}

				if (!empty($subformatdata['params']))
				{
					$lessonformat_data->params     = $subformatdata['params'];
				}

				if (!empty($format_data['format_id']))
				{
					$lessonformat_data->id     = $format_data['format_id'];
					$db->updateObject('#__tjlms_media', $lessonformat_data, 'id');

					// Id of the inserted media
					$lesson_obj->media_id = $media_id = $format_data['format_id'];
				}
				else
				{
					$db->insertObject('#__tjlms_media', $lessonformat_data);

					// Id of the inserted media
					$lesson_obj->media_id = $media_id = $db->insertid();
				}
			}

			if (!$db->updateObject('#__tjlms_lessons', $lesson_obj, 'id'))
			{
				echo $db->stderr();

				return false;
			}

			$format = 'tj' . $lesson_obj->format;
			$dispatcher = JEventDispatcher::getInstance();
			JPluginHelper::importPlugin($format);

			$results = $dispatcher->trigger('OnAfter' . $subfomatopt . 'FormatUploaded', array($format_data));
		}
		/*if ($format_data['format'] != 'scorm' && $format_data['format'] != 'tjscorm')
		{
			$obj->media_id = $format_data['format_id'];

			/* If video and other than upload we need to make entry in media*//*
			if ($format_data['format'] == 'video')
			{
				$subformat = $format_data['video_subformat'];

				if ($format_data["$subformat"]['video_source'] != 'upload')
				{
					$video_data             = new stdclass;
					$video_data->format     = $format_data['format'];
					$video_data->sub_format = $subformat . '.' . $format_data[$subformat]['video_source'];
					$video_data->source     = $format_data[$subformat]['video_format_source'];
					$db->insertObject('#__tjlms_media', $video_data, 'id');

					/* Id of the inserted media*//*
					$obj->media_id = $db->insertid();
				}
			}
		}*/

		/*if ($format_data['format'] == 'scorm')
		{
			$obj                = new stdclass;
			$obj->lesson_id     = $format_data['id'];
			$obj->passing_score = $format_data['passing_score'];
			$obj->grademethod   = $format_data['grademethod'];
			$db->updateObject('#__tjlms_scorm', $obj, 'lesson_id');
		}*/
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');

		// Trigger all "sytem" plugins OnAfterLessonCreation method
		$dispatcher->trigger('OnAfterLessonFormatUploaded', array(
															$format_data['id'],
															$format_data['format_id']
														)
							);

		$return = array('result' => true);

		if ($media_id)
		{
			$return['media_id'] = $media_id;
		}

		return $return;
	}

	/**
	 * Function to upload associate files
	 *
	 * @param   ARRAY  $post  Post Array
	 *
	 * @return  boolean
	 *
	 * @since  1.0.0
	 */
	public function updateassocfiles($post)
	{
		$db            = JFactory::getDBO();
		$lesson_format = $post->get('lesson_format', '', 'ARRAY');

		$assocFiles = $post->get('lesson_files', '', 'ARRAY');

		foreach ($assocFiles as $assocFile)
		{
			if (!empty($assocFile['media_id']))
			{
				// Check if already entry exists
				$query = $db->getQuery(true);

				// Select all records from the user profile table where key begins with "custom.".
				// Order it by the ordering field.
				$query->select($db->quoteName(array('id')));
				$query->from($db->quoteName('#__tjlms_associated_files'));
				$query->where($db->quoteName('lesson_id') . ' = ' . $db->quote($lesson_format['id']));
				$query->where($db->quoteName('media_id') . ' = ' . $db->quote($assocFile['media_id']));

				// Reset the query using our newly populated query object.
				$db->setQuery($query);

				// Load the results as a list of stdClass objects (see later for more options on retrieving data).
				$mediaFileId = $db->loadResult();

				if (empty($mediaFileId))
				{
					$fileData            = new stdClass;
					$fileData->id        = '';
					$fileData->lesson_id = $lesson_format['id'];
					$fileData->media_id  = $assocFile['media_id'];
					$db->insertObject('#__tjlms_associated_files', $fileData, 'id');
				}
			}
		}

		return true;
	}

	/**
	 * Check for the format of the lesson if change during edit. And also delete the data related to it.
	 *
	 * @param   INT  $lessonid       Lesson ID
	 * @param   INT  $currentFormat  Current Lesson format
	 *
	 * @return  boolean
	 *
	 * @since  1.0.0
	 */
	public function changeLessonFormat($lessonid, $currentFormat)
	{
		$db    = JFactory::getDBO();
		$query = " SELECT format,media_id from #__tjlms_lessons WHERE id=" . $lessonid;
		$db->setQuery($query);
		$lessonDetails = $db->loadAssoc();

		// Select repected table
		if ($lessonDetails['format'] == 'scorm' || $lessonDetails['format'] == 'tjscorm')
		{
			$format_table = " #__tjlms_scorm ";
			$where        = " WHERE lesson_id=" . $lessonid;
		}
		else
		{
			$format_table = " #__tjlms_media ";
			$where        = " WHERE id=" . $lessonDetails['media_id'];
		}

		if ($lessonDetails['format'] != $currentFormat)
		{
			$query = " DELETE FROM " . $format_table . $where;
			$db->setQuery($query);
			$db->execute();

			return 0;
		}
		else
		{
			return 1;
		}
	}

	/**
	 * Store associate files for a lesson
	 *
	 * @param   ARRAY  $selected_files  Files ARRAY
	 * @param   INT    $lesson_id       Lesson ID
	 *
	 * @return  void
	 *
	 * @since  1.0.0
	 */
	public function storeAssociateFiles($selected_files, $lesson_id)
	{
		$db = JFactory::getDBO();

		// Get the already attache associate file of the lesson incase of edit
		$original_files = $this->getlessonFiles($lesson_id);
		$files_present  = array();

		foreach ($original_files as $ind => $files)
		{
			$files_present[$ind] = $files->media_id;
		}

		// Array to collect the files which has to be delete
		$delete_files = array();

		// Array to collect the files which has to be keep as it is
		$dont_edit = array();

		foreach ($files_present as $f_p)
		{
			if (!in_array($f_p, $selected_files))
			{
				$delete_files[] = $f_p;
			}
			else
			{
				$dont_edit[] = $f_p;
			}
		}

		foreach ($delete_files as $d_f)
		{
			$query = "DELETE FROM #__tjlms_associated_files WHERE media_id =" . $d_f . " AND lesson_id=" . $lesson_id;
			$db->setQuery($query);
			$db->execute();
		}

		$insert_file = array();

		foreach ($selected_files as $s_p)
		{
			if (!in_array($s_p, $dont_edit))
			{
				$insert_file[] = $s_p;
			}
		}

		return $insert_file;
	}

	/**
	 * Delete the unused files of the lesson
	 *
	 * @param   ARRAy  $format_data  Data
	 *
	 * @return  void
	 *
	 * @since  1.0.0
	 */
	public function deleteunusedfiles($format_data)
	{
		// Delete previously uploaded scorm or video files
		$directory = JPATH_SITE . '/media/com_tjlms' . '/lessons/' . $lessonid;
		$files     = JFolder::files($directory);

		$img = $this->tjlmsdbhelper->get_records('image ', 'tjlms_lessons', array('id' => $lessonid), '', 'loadResult');

		$files_to_delete = array_diff($files, array($img));

		foreach ($files_to_delete as $f)
		{
			JFile::delete($directory . '/' . $f);
		}
	}

	/**
	 * Function used to get Associate files for a lesson
	 *
	 * @return  Array
	 *
	 * @since  1.0.0
	 */
	public function getselectAllAssociatedFiles()
	{
		$db    = JFactory::getDBO();
		$query = " SELECT * FROM #__tjlms_files ";
		$db->setQuery($query);
		$select_files = $db->loadObjectList('id');

		return $select_files;
	}

	/**
	 * Function used to get Associate files for a lesson
	 *
	 * @param   INT  $l_id  Lesson ID
	 *
	 * @return  Array
	 *
	 * @since  1.0.0
	 */
	public function getlessonFiles($l_id)
	{
		$input = JFactory::getApplication()->input;

		if (!$l_id)
		{
			$l_id = $input->get('lesson_id', '', 'INT');
		}

		$db    = JFactory::getDBO();
		$query = " SELECT af.`media_id`,f.`filename`,f.`path` FROM `#__tjlms_files` as f
						INNER JOIN `#__tjlms_associated_files` as af
						ON af.media_id=f.id
						WHERE af.`lesson_id`=" . $l_id;
		$db->setQuery($query);
		$res = $db->loadObjectList();

		return $res;
	}

	/**
	 * Function used to remove old lesson image
	 *
	 * @param   INT  $l_id  Lesson ID
	 *
	 * @return  Array
	 *
	 * @since  1.0.0
	 */
	public function removeLessonImage($l_id)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('image,storage');
		$query->from($db->quoteName('#__tjlms_lessons') . ' as l');
		$query->where('l.id = ' . (int) $l_id);
		$db->setQuery($query);
		$lesson = $db->loadAssoc();

		if (empty($lesson))
		{
			return false;
		}

		require_once JPATH_ROOT . '/components/com_tjlms/libraries/storage.php';
		$Tjstorage = new Tjstorage;

		// Get image to be shown for course
		$tjlmsparams  	= JComponentHelper::getParams('com_tjlms');

		if (!empty($lesson['image']) && $lesson['storage'] != 'invalid')
		{
			$lessonImage 	= $lesson['image'];
			$storage   		= $Tjstorage->getStorage($lesson['storage']);
			$imageSizes 	= array('', 'L_', 'M_', 'S_');

			foreach ($imageSizes as $imageSize)
			{
				$storage->delete($tjlmsparams->get('lesson_image_upload_path') . $imageSize . $lesson['image']);
			}
		}
	}
}
