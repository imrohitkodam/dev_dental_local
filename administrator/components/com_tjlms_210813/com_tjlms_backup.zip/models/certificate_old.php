<?php
/**
 * @package	Jticketing
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
	
// no direct access
	defined('_JEXEC') or die('Restricted access'); 

jimport('joomla.application.component.model');
jimport('joomla.filesystem.file');

class TjlmsModelCertificate extends JModelLegacy
{
    /*
     Function saves configuration data to a file
     */
    function store(){

        $app 		= JFactory::getApplication();
        $config		= JRequest::getVar('data', '', 'post', 'array', JREQUEST_ALLOWRAW );

       	$db=JFactory::getDBO();
				$query="SELECT namekey from `#__tjlms_config`";
			  $db->setQuery($query);
			  $config_rows=$db->loadResultArray();	

        if ($config)
        {
					foreach($config as $k=>$v)
					{
          		$c_data = new stdClass;
							$c_data->namekey 	=	$k;
							$c_data->value= $v;
							if(!in_array($k,$config_rows))
							{
									//$inv_config[$k]			= $v;
									$db->insertObject( '#__tjlms_config', $c_data, 'id' );
							}
							else
							{
									$query="SELECT id from `#__tjlms_config` where namekey='".$k."'";
									$db->setQuery($query);
									$c_data->id 	=	$db->loadResult();
									$db->updateObject( '#__tjlms_config', $c_data, 'id' );
							}
				}
        return true;
		
			}
			else
			 return false;
    }//store() ends


  
}
