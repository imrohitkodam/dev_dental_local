<?php
/**
 * @version    SVN: <svn_id>
 *
 * @package    Com_Tjlms
 *
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 *
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *
 */

defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');
jimport('techjoomla.common');

/**
 * Methods supporting a list of Tjlms records.
 *
 * @since  1.0.0
 */

class TjlmsModelCourses extends JModelList
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see        JController
	 *
	 * @since    1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'created_by', 'a.created_by',
				'category_id', 'a.cat_id',
				'title', 'a.title',
				'img', 'a.img',
				'short_desc', 'a.short_desc',
				'description', 'a.description',
				'start_date', 'a.start_date',
				'certificate_term', 'a.certificate_term',
				'type', 'a.type'

			);
		}

		$this->ComtjlmsHelper = new ComtjlmsHelper;
		$this->tjlmsHelper   = new TjlmsHelper;
		$this->techjoomlacommon = new TechjoomlaCommon;
		$this->columnsWithoutDirectSorting = array('enrolled_users');

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   int  $ordering   course_id
	 * @param   int  $direction  course_id
	 *
	 * @return  JDatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
		$app = JFactory::getApplication('administrator');

		// Set ordering.
		$orderCol = $app->getUserStateFromRequest($this->context . '.filter_order', 'filter_order');

		$this->setState('list.ordering', $orderCol);

		// Set ordering direction.
		$listOrder = $app->getUserStateFromRequest($this->context . 'filter_order_Dir', 'filter_order_Dir');

		if (!in_array(strtoupper($listOrder), array('ASC', 'DESC', '')))
		{
			$listOrder = 'DESC';
		}

		$this->setState('list.direction', $listOrder);

		// Load the filter state.
		$search = $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$published = $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_published', '', 'string');

		$this->setState('filter.state', $published);

		// Filtering cat_id
		$this->setState('filter.catfilter', $app->getUserStateFromRequest($this->context . '.filter.category_id', 'filter_category_id', '', 'string'));

		// Filtering type
		$this->setState('filter.type', $app->getUserStateFromRequest($this->context . '.filter.type', 'filter_type', '', 'string'));

		// Load the parameters.
		$params = JComponentHelper::getParams('com_tjlms');
		$this->setState('params', $params);

		// List state information.
		parent::populateState('a.id', 'desc');
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return	string		A store id.
	 *
	 * @since	1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		$id .= ':' . $this->getState('filter.type');
		$id .= ':' . $this->getState('filter.category_id');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return	JDatabaseQuery
	 *
	 * @since	1.6
	 */
	protected function getListQuery()
	{
		$user = JFactory::getUser();
		$olUserid = $user->id;
		$isroot = $user->authorise('core.admin');

		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select($this->getState('list.select', 'a.*'));
		$query->from('`#__tjlms_courses` AS a');
		$query->JOIN('INNER', '`#__categories` AS c ON c.id=a.cat_id');
		$query->where('c.published <> -2');

		// Join over the users for the checked out user
		$query->select("uc.name AS editor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");

		// Join over the user field 'created_by'
		$query->select('created_by.id AS created_by');
		$query->join('LEFT', '#__users AS created_by ON created_by.id = a.created_by');

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.state IN (0, 1))');
		}
		else
		{
			// Do later.
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.title LIKE ' . $search . ' )');
			}
		}

		// Filtering cat_id
		$filter_cat_id = $this->state->get("filter.category_id");

		if ($filter_cat_id)
		{
			$query->where("a.cat_id = '" . $db->escape($filter_cat_id) . "'");
		}

		// Filtering type
		$filter_type = $this->getState("filter.type");

		if ($filter_type != '')
		{
			$query->where("a.type = '" . $db->escape($filter_type) . "'");
		}

		if (!$isroot)
		{
			$query->where('a.created_by=' . $olUserid);
		}

		// Add the list ordering clause.
		$orderCol = $this->state->get('list.ordering');
		$orderDirn = $this->state->get('list.direction');

		if ($orderCol && $orderDirn)
		{
			if (!in_array($orderCol, $this->columnsWithoutDirectSorting))
			{
				$query->order($db->escape($orderCol . ' ' . $orderDirn));
			}
		}

		return $query;
	}

	/**
	 * get items
	 *
	 * @return  JDatabaseQuery
	 *
	 * @since   1.0.0
	 */
	public function getItems()
	{
		$items = parent::getItems();
		$db	= JFactory::getDBO();

		$lmsparams = JComponentHelper::getParams('com_tjlms');
		$date_format_show = $lmsparams->get('date_format_show', 'Y-m-d H:i:s');

		foreach ($items as $ind => $obj)
		{
			$obj->start_date = $this->techjoomlacommon->getDateInLocal($obj->start_date, 0, $date_format_show);

			if (!empty($obj->end_date) &&  $obj->end_date != '0000-00-00 00:00:00')
			{
				$obj->end_date = $this->techjoomlacommon->getDateInLocal($obj->end_date, 0, $date_format_show);
			}

			// Get category name form ID
			$query = "SELECT title,published FROM #__categories WHERE id='" . $obj->cat_id . "' && extension='com_tjlms'";
			$db->setQuery($query);
			$catDetails = $db->loadAssoc();
			$items[$ind]->cat = $catDetails['title'];
			$items[$ind]->cat_status = $catDetails['published'];

			// Get access level titles.
			$query = "SELECT title FROM #__viewlevels WHERE id='" . $obj->access . "'";
			$db->setQuery($query);
			$items[$ind]->access_level_title = $db->loadResult();

			// Get subscription titles
			$subscription_plans = $this->subs_plan($obj->id);
			$level_str = '';

			foreach ($subscription_plans as $s_plan)
			{
				$subs_plan = $s_plan->time_measure == 'unlimited' ? $s_plan->time_measure : $s_plan->duration . '-' . $s_plan->time_measure;

				if ($level_str)
				{
					$level_str .= "<br />";
				}

				$level_str .= $subs_plan;
			}

			$items[$ind]->subscription_plans = $level_str;

			// Get total enrolled users
			$options['IdOnly'] = 1;
			$items[$ind]->enrolled_users = count($this->ComtjlmsHelper->getCourseEnrolledUsers($obj->id, $options));

			$tjlmsparams = JComponentHelper::getParams('com_tjlms');
			$show_user_or_username = $tjlmsparams->get('show_user_or_username', '0', 'INT');

			if ($show_user_or_username == 'username')
			{
				$items[$ind]->created_by = JFactory::getUser($obj->created_by)->username;
			}
			elseif ($show_user_or_username == 'name')
			{
				$items[$ind]->created_by = JFactory::getUser($obj->created_by)->name;
			}
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering');
		$orderDirn = $this->state->get('list.direction');

		if (in_array($orderCol, $this->columnsWithoutDirectSorting))
		{
			$items = $this->ComtjlmsHelper->multi_d_sort($items, $orderCol, $orderDirn);
		}

		return $items;
	}

	/**
	 * get subscription plan data as per the course ID
	 *
	 * @param   int  $course_id  course_id
	 *
	 * @return  JDatabaseQuery
	 *
	 * @since   1.0.0
	 */
	public function subs_plan($course_id)
	{
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__tjlms_subscription_plans');
		$query->where('course_id=' . $course_id);
		$db->setQuery($query);
		$subscription_plans = $db->loadobjectlist();

		return $subscription_plans;
	}

	/**
	 * Mathod to Get all access levels of joomla
	 *
	 * @return  JDatabaseQuery
	 *
	 * @since   1.0.0
	 */
	public function getJoomlaAccessLevels()
	{
		$TjlmsHelper = new TjlmsHelper;
		$jaccess_levels = $TjlmsHelper->getJoomlaAccessLevels();

		return $jaccess_levels;
	}
}
