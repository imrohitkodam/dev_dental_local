<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;
jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Tjlms records.
 *
 * @since  1.0.0
 */
class TjlmsModelReports extends JModelList
{
	/**
	 * Build an SQL query to load the list data.
	 *
	 * @param   ARRAY   $filters      The Filters which are used
	 * @param   ARRAY   $colNames     The columns which need to show
	 * @param   int     $rowsTofetch  Total number of rows to fetch
	 * @param   int     $limit_start  Fetch record fron nth row
	 * @param   STRING  $sortCol      The column which has to be sorted
	 * @param   STRING  $sortOrder    The order of sorting
	 * @param   STRING  $action       Which action has cal this function
	 *
	 * @return    JDatabaseQuery
	 *
	 * @since    1.0
	 */
	public function getData($filters = array(), $colNames = array(), $rowsTofetch = 20, $limit_start = 0,  $sortCol = '', $sortOrder = '', $action = '')
	{
		$input = JFactory::getApplication()->input;
		$mainframe  = JFactory::getApplication('admin');
		$reportName = $input->get('reportToBuild', '', 'STRING');

		if (empty($reportName))
		{
			$reportName = $mainframe->getUserState('com_tjlms' . '.reportName', '');
		}

		$isSaveQuery = $input->get('savedQuery', '0', 'INT');

		if ($isSaveQuery == 1)
		{
			// Get saved data
			$queryId = $input->get('queryId', '0', 'INT');

			if ($queryId != 0)
			{
				$queryData = $this->getQueryData($queryId, '');

				if (!empty($queryData))
				{
					$reportName = $queryData->report_name;
					$colNames = json_decode($queryData->colToshow);
					$filters = json_decode($queryData->filters);
					$filters = (array) $filters;
					$sort = json_decode($queryData->sort);

					$sortCol = '';
					$sortOrder = '';

					if (!empty($sort))
					{
						$sortCol = $sort[0];
						$sortOrder = $sort[1];
					}
				}
			}
		}

		if (empty($colNames))
		{
			$colNames = $this->getColNames();
		}

		if (!array_key_exists("0", $colNames) && isset($colNames))
		{
			foreach ($colNames as $colName)
			{
				$allColName[] = $colName;
			}

			unset($colNames);
			$colNames = $allColName;
		}

		$this->setAllUserPreference($reportName, $sortCol, $sortOrder, $colNames, $filters);

		// Get all fields
		$colNames      = $mainframe->getUserState('com_tjlms' . '.' . $reportName . '_table_colNames', '');
		$filters       = $mainframe->getUserState('com_tjlms' . '.' . $reportName . '_table_filters', '');
		$sortCol       = $mainframe->getUserState('com_tjlms' . '.' . $reportName . '_table_sortCol', '');
		$sortOrder     = $mainframe->getUserState('com_tjlms' . '.' . $reportName . '_table_sortOrder', '');

		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('tjlmsreports');
		$data = $dispatcher->trigger('plg' . $reportName . 'RenderPluginHTML', array
																					(
																						$filters, $colNames, $rowsTofetch, $limit_start, $sortCol, $sortOrder, $action, ''
																					)
									);

		if (isset($data[0]) && !empty($data[0]))
		{
			return $data[0];
		}

		return false;
	}

	/**
	 * Save user preferences
	 *
	 * @param   STRING  $reportName  The name of the report
	 * @param   STRING  $sortCol     The column which has to be sorted
	 * @param   STRING  $sortOrder   The order of sorting
	 * @param   ARRAY   $colNames    The columns which need to show
	 * @param   ARRAY   $filters     The Filters which are used
	 *
	 * @return    JDatabaseQuery
	 *
	 * @since    1.0
	 */
	public function setAllUserPreference($reportName, $sortCol, $sortOrder, $colNames, $filters)
	{
		$mainframe = JFactory::getApplication('admin');

		$mainframe->setUserState('com_tjlms' . '.reportName', $reportName);
		$mainframe->setUserState('com_tjlms' . '.' . $reportName . '_table_colNames', $colNames);
		$mainframe->setUserState('com_tjlms' . '.' . $reportName . '_table_filters', $filters);

		if (!empty($sortCol) && !empty($sortOrder))
		{
			$mainframe->setUserState('com_tjlms' . '.' . $reportName . '_table_sortCol', $sortCol);
			$mainframe->setUserState('com_tjlms' . '.' . $reportName . '_table_sortOrder', $sortOrder);
		}
	}

	/**
	 * Get all columns names
	 *
	 * @return    object
	 *
	 * @since    1.0
	 */
	public function getColNames()
	{
		$input = JFactory::getApplication()->input;
		$reportName = $input->get('reportToBuild', '', 'STRING');

		if (empty($reportName))
		{
			$mainframe  = JFactory::getApplication('admin');
			$reportName = $mainframe->getUserState('com_tjlms' . '.reportName', '');
		}

		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('tjlmsreports');
		$data = $dispatcher->trigger('plg' . $reportName . 'getColNames', array());

		if (isset($data[0]) && !empty($data[0]))
		{
			return $data[0];
		}

		return false;
	}

	/**
	 * Get all saved queries
	 *
	 * @return    object
	 *
	 * @since    1.0
	 */
	public function getSavedQueries()
	{
		$ol_user = JFactory::getUser()->id;
		$db        = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('id, query_name as name, report_name');
		$query->from('#__tjlms_reports_queries');
		$query->where('creator_id=' . $ol_user);

		$db->setQuery($query);
		$savedQueries = $db->loadObjectList();

		return $savedQueries;
	}

	/**
	 * Get all columns names
	 *
	 * @param   INT    $queryId      Query ID
	 * @param   ARRAy  $colToSelect  Columns to be selected from query
	 *
	 * @return    object
	 *
	 * @since    1.0
	 */
	public function getQueryData($queryId, $colToSelect)
	{
		$ol_user = JFactory::getUser()->id;
		$db        = JFactory::getDBO();
		$query = $db->getQuery(true);

		if (!empty($colToSelect))
		{
			$colToSelect = implode(',', $colToSelect);
			$query->select($colToSelect);
		}
		else
		{
			$query->select('*');
		}

		$query->from('#__tjlms_reports_queries');
		$query->where('creator_id=' . $ol_user);
		$query->where('id=' . $queryId);

		$db->setQuery($query);
		$queryData = $db->loadObject();

		return $queryData;
	}

	/**
	 * Get all plugins names
	 *
	 * @return    object
	 *
	 * @since    1.0
	 */
	public function getenableReportPlugins()
	{
		$db = JFactory::getDBO();
		$condtion = array(0 => '\'tjlmsreports\'');
		$condtionatype = join(',', $condtion);

		$query = "SELECT extension_id as id,name,element,enabled as published FROM #__extensions WHERE folder in (" . $condtionatype . ") AND enabled=1";

		$db->setQuery($query);
		$reportPlugins = $db->loadobjectList();

		return $reportPlugins;
	}

	/**
	 * Function to get the course filter
	 *
	 * @return  object
	 *
	 * @since 1.0.0
	 */
	public function getCourseFilter()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('DISTINCT(id) as id,title');
		$query->from('#__tjlms_courses');

		$db->setQuery($query);
		$courses = $db->loadObjectList();

		$courseFilter[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_FILTER_SELECT_COURSE'));

		if (!empty($courses))
		{
			foreach ($courses as $eachCourse)
			{
				$courseFilter[] = JHTML::_('select.option', $eachCourse->id, $eachCourse->title);
			}
		}

		return $courseFilter;
	}

	/**
	 * Function to get the lesson filter
	 *
	 * @return  object
	 *
	 * @since 1.0.0
	 */
	public function getLessonFilter()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('DISTINCT(id) as id,name');
		$query->from('#__tjlms_lessons');

		$db->setQuery($query);
		$lessons = $db->loadObjectList();

		$lessonFilter[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_FILTER_SELECT_LESSON'));

		if (!empty($lessons))
		{
			foreach ($lessons as $eachLessons)
			{
				$lessonFilter[] = JHTML::_('select.option', $eachLessons->id, $eachLessons->name);
			}
		}

		return $lessonFilter;
	}

	/**
	 * Function to get the user filter
	 *
	 * @return  object
	 *
	 * @since 1.0.0
	 */
	public function getUserFilter()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('u.id,u.username');
		$query->from('#__users as u');

		// $query->join('LEFT', '#__users as u ON lt.user_id=u.id');
		$db->setQuery($query);
		$users = $db->loadObjectList();

		$userFilter[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_FILTER_SELECT_USER'));

		if (!empty($users))
		{
			foreach ($users as $eachUser)
			{
				$userFilter[] = JHTML::_('select.option', $eachUser->id, $eachUser->username);
			}
		}

		return $userFilter;
	}

	/**
	 * Function to get the category filter
	 *
	 * @return  object
	 *
	 * @since 1.0.0
	 */
	public function getCatFilter()
	{
		$db = JFactory::getDbo();

		$query = $db->getQuery(true);
		$query->select('id,title');
		$query->from('#__categories');
		$query->where('extension="com_tjlms"');
		$query->where('published=1');

		$db->setQuery($query);
		$cats = $db->loadObjectList();

		if (!empty($cats))
		{
			$catFilter[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_FILTER_SELECT_COURSE_CATEGORY'));

			foreach ($cats as $eachCat)
			{
				$catFilter[] = JHTML::_('select.option', $eachCat->id, $eachCat->title);
			}
		}

		return $catFilter;
	}
}
