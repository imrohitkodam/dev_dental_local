<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.modeladmin');

/**
 * Methods supporting a list of Tjlms records.
 *
 * @since  1.0.0
 */
class TjlmsModelDashboard extends JModelLegacy
{
	/**
	 * @var		string	The prefix to use with controller messages.
	 * @since	1.6
	 */
	protected $text_prefix = 'COM_TJLMS';

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.7
	 * @see     JController
	 */
	public function __construct($config = array())
	{
		// Get download id
		$params           = JComponentHelper::getParams('com_tjlms');
		$this->downloadid = $params->get('downloadid');

		// Setup vars
		$this->updateStreamName = 'Shika Package';
		$this->updateStreamType = 'collection';
		$this->updateStreamUrl  = "https://techjoomla.com/updates/packages/all?dummy=tjlms.xml";
		$this->extensionElement = 'pkg_shika';
		$this->extensionType    = 'package';

		parent::__construct();
	}

	/**
	 * Get most of the info for dashboard
	 *
	 * @return  ARRAY $dashboardDetails
	 *
	 * @since   1.0.0
	 */
	public function getDashboardDetails()
	{
		$user = JFactory::getUser();
		$olUserid = $user->id;
		$isroot = $user->authorise('core.admin');

		// Get course Data
		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('COUNT(c.id) as total_course, COUNT(IF(c.type="1",1, NULL)) as paid_courses , COUNT(IF(c.type="0",1, NULL)) as free_course');
		$query->from('#__tjlms_courses as c');
		$query->JOIN('INNER', '`#__categories` AS cat ON cat.id=c.cat_id');
		$query->where('cat.published <> -2');
		$query->where('c.state=1');

		if (!$isroot)
		{
			$query->where('created_by=' . $olUserid);
		}

		$db->setQuery($query);
		$courseData = $db->loadAssoc();

		$totalcourse = $courseData['total_course'];
		$totalPaidcourse = $courseData['paid_courses'];
		$totalFreecourse = $courseData['free_course'];

		// Get Enrollment Data
		$query = $db->getQuery(true);
		$query->select('COUNT(DISTINCT eu.user_id) as enrolled_student, COUNT(IF(eu.state="0",1, NULL)) as pending_enrollment');
		$query->from('#__tjlms_enrolled_users as eu');
		$query->join('LEFT', '#__tjlms_courses as c ON c.id = eu.course_id');
		$query->where('c.state=1 and eu.state=1');

		if (!$isroot)
		{
			$query->where('c.created_by=' . $olUserid);
		}

		$db->setQuery($query);
		$EnrollmentData = $db->loadAssoc();

		$db->setQuery($query);
		$EnrollmentData = $db->loadAssoc();

		$totalStudents = $EnrollmentData['enrolled_student'];
		$TotalPendingEnrollment = $EnrollmentData['pending_enrollment'];

		// Get order and revenue data
		$query = $db->getQuery(true);
		$query->select('COUNT(o.id) as orders, SUM(o.amount) as amount');
		$query->from('#__tjlms_orders as o');
		$query->join('LEFT', '#__tjlms_courses as c ON c.id = o.course_id');
		$query->where('o.status="C"');

		if (!$isroot)
		{
			$query->where('c.created_by=' . $olUserid);
		}

		$db->setQuery($query);
		$OrderData = $db->loadAssoc();

		$totalOrders = $OrderData['orders'];
		$totalRevenueAmount = $OrderData['amount'];

		$dashboardDetails = array();
		$dashboardDetails['TotalCourse'] = $totalcourse;
		$dashboardDetails['TotalFreeCourse'] = $totalFreecourse;
		$dashboardDetails['TotalPaidCourse'] = $totalPaidcourse;
		$dashboardDetails['TotalStudents'] = $totalStudents;
		$dashboardDetails['TotalPendingEnrollment'] = $TotalPendingEnrollment;
		$dashboardDetails['totalOrders'] = $totalOrders;
		$dashboardDetails['totalRevenueAmount'] = $totalRevenueAmount;

		return $dashboardDetails;
	}

	/**
	 * Get popular student for dashboard based on active courses
	 *
	 * @return  ARRAY $popularStudent
	 *
	 * @since  1.0.0
	 */
	public function getpopularStudent()
	{
		$user = JFactory::getUser();
		$olUserid = $user->id;
		$isroot = $user->authorise('core.admin');

		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('eu.user_id,COUNT(*) as enrolledIn, u.name, u.username');
		$query->from('#__tjlms_enrolled_users as eu');
		$query->join('INNER', '#__users as u ON u.id=eu.user_id');
		$query->join('INNER', '#__tjlms_courses as c ON c.id=eu.course_id');
		$query->join('INNER', '#__categories as cat ON cat.id=c.cat_id');
		$query->where('eu.state=1 AND c.state=1 AND cat.published=1');

		if (!$isroot)
		{
			$query->where('c.created_by=' . $olUserid);
		}

		$query->group('eu.user_id ORDER BY enrolledIn DESC LIMIT 0,4');

		$db->setQuery($query);
		$popularStudent = $db->loadobjectlist();

		return $popularStudent;
	}

	/**
	 * Get popular student for dashboard based on active courses
	 *
	 * @return  ARRAY $mostLikedCourses
	 *
	 * @since  1.0.0
	 */
	public function getmostLikedCourses()
	{
		$user = JFactory::getUser();
		$olUserid = $user->id;
		$isroot = $user->authorise('core.admin');

		$db = $this->getDbo();
		$query = $db->getQuery(true);
		$query->select('c.title, l.like_cnt,c.image,c.storage');
		$query->from('#__tjlms_courses as c');
		$query->join('INNER', '#__jlike_content as l ON l.element_id=c.id');

		if (!$isroot)
		{
			$query->where('c.created_by=' . $olUserid);
		}

		$query->where('l.element="com_tjlms.course" AND l.like_cnt > 0 AND c.state=1 ORDER BY l.like_cnt DESC LIMIT 0,4');
		$db->setQuery($query);
		$mostLikedCourses = $db->loadObjectlist();

		return $mostLikedCourses;
	}

	/**
	 * Get activity of student for dashboard based on active courses
	 *
	 * @return  ARRAY $yourActivities
	 *
	 * @since  1.0.0
	 */
	public function getactivity()
	{
		// Set start and end date
		$start = $this->getState('filter.begin');
		$end   = $this->getState('filter.end');

		require_once JPATH_SITE . '/components/com_tjlms/helpers/tracking.php';
		$comtjlmstrackingHelper = new comtjlmstrackingHelper;

		// Get activity for all students
		$activitydata = array();
		$activitydata['user_id']   = '';
		$activitydata['start']     = date("Y-m-d", strtotime($start));
		$activitydata['end']       = date("Y-m-d", strtotime($end));
		$activitydata['course_id'] = '';

		$yourActivities = $comtjlmstrackingHelper->getactivity($activitydata);

		return $yourActivities;
	}

	/**
	 * Get revenue data
	 *
	 * @return  ARRAY $revenueData
	 *
	 * @since  1.0.0
	 */
	public function getrevenueData()
	{
		$start = $this->getState('filter.begin');
		$end   = $this->getState('filter.end');

		$comtjlmsHelper = new comtjlmsHelper;
		$data = array();
		$data['start'] = $start;
		$data['end'] = $end;
		$revenueData = $comtjlmsHelper->getrevenueData($data);

		return $revenueData;
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * @param   string  $ordering   ordering of the search result
	 * @param   string  $direction  direction of search result
	 *
	 * @return  array  An array of conditions to add to add to ordering queries.
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
		$app   = JFactory::getApplication();
		$begin = $app->getUserStateFromRequest('filter.begin', 'filter_begin', '', 'string');

		if (empty($begin))
		{
			$begin = JHtml::date($input = 'now -1 month', 'Y-m-d', false);
		}

		$this->setState('filter.begin', $begin);

		$end = $app->getUserStateFromRequest('filter.end', 'filter_end', '', 'string');

		if (empty($end))
		{
			$end = JHtml::date($input = 'now +1 day', 'Y-m-d', false);
		}

		$this->setState('filter.end', $end);

		// List state information.
		parent::populateState($ordering, $direction);
	}

	/**
	 * Function getStoreId for getting all id.
	 *
	 * @param   integer  $id  the current id
	 *
	 * @return   integer  $id  The id is returned
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Function getExtensionId for getting extension id.
	 *
	 * @return   integer  $extension_id  The id is returned
	 */
	public function getExtensionId()
	{
		$db = $this->getDbo();

		// Get current extension ID
		$query = $db->getQuery(true)
			->select($db->qn('extension_id'))
			->from($db->qn('#__extensions'))
			->where($db->qn('type') . ' = ' . $db->q($this->extensionType))
			->where($db->qn('element') . ' = ' . $db->q($this->extensionElement));
		$db->setQuery($query);

		$extension_id = $db->loadResult();

		if (empty($extension_id))
		{
			return 0;
		}
		else
		{
			return $extension_id;
		}
	}

	/**
	 * Refreshes the Joomla! update sites for this extension as needed
	 *
	 * @return  void
	 */
	public function refreshUpdateSite()
	{
		// Extra query for Joomla 3.0 onwards
		$extra_query = null;

		if (preg_match('/^([0-9]{1,}:)?[0-9a-f]{32}$/i', $this->downloadid))
		{
			$extra_query = 'dlid=' . $this->downloadid;
		}

		// Setup update site array for storing in database
		$update_site = array(
			'name' => $this->updateStreamName,
			'type' => $this->updateStreamType,
			'location' => $this->updateStreamUrl,
			'enabled'  => 1,
			'last_check_timestamp' => 0,
			'extra_query'          => $extra_query
		);

		// For joomla versions < 3.0
		if (version_compare(JVERSION, '3.1', 'lt'))
		{
			unset($update_site['extra_query']);
		}

		$db = $this->getDbo();

		// Get current extension ID
		$extension_id = $this->getExtensionId();

		if (!$extension_id)
		{
			return;
		}

		// Get the update sites for current extension
		$query = $db->getQuery(true)
			->select($db->qn('update_site_id'))
			->from($db->qn('#__update_sites_extensions'))
			->where($db->qn('extension_id') . ' = ' . $db->q($extension_id));
		$db->setQuery($query);

		$updateSiteIDs = $db->loadColumn(0);

		if (!count($updateSiteIDs))
		{
			// No update sites defined. Create a new one.
			$newSite = (object) $update_site;
			$db->insertObject('#__update_sites', $newSite);

			$id = $db->insertid();

			$updateSiteExtension = (object) array(
				'update_site_id' => $id,
				'extension_id'   => $extension_id,
			);

			$db->insertObject('#__update_sites_extensions', $updateSiteExtension);
		}
		else
		{
			// Loop through all update sites
			foreach ($updateSiteIDs as $id)
			{
				$query = $db->getQuery(true)
					->select('*')
					->from($db->qn('#__update_sites'))
					->where($db->qn('update_site_id') . ' = ' . $db->q($id));
				$db->setQuery($query);
				$aSite = $db->loadObject();

				// Does the name and location match?
				if (($aSite->name == $update_site['name']) && ($aSite->location == $update_site['location']))
				{
					// Do we have the extra_query property (J 3.2+) and does it match?
					if (property_exists($aSite, 'extra_query'))
					{
						if ($aSite->extra_query == $update_site['extra_query'])
						{
							continue;
						}
					}
					else
					{
						// Joomla! 3.1 or earlier. Updates may or may not work.
						continue;
					}
				}

				$update_site['update_site_id'] = $id;
				$newSite = (object) $update_site;
				$db->updateObject('#__update_sites', $newSite, 'update_site_id', true);
			}
		}
	}

	/**
	 * Function getLatestVersion for getting the latest version
	 *
	 * @return  obj extension object
	 */
	public function getLatestVersion()
	{
		// Get current extension ID
		$extension_id = $this->getExtensionId();

		if (!$extension_id)
		{
			return 0;
		}

		$db = $this->getDbo();

		// Get current extension ID
		$query = $db->getQuery(true)
			->select($db->qn(array('version', 'infourl')))
			->from($db->qn('#__updates'))
			->where($db->qn('extension_id') . ' = ' . $db->q($extension_id));
		$db->setQuery($query);

		$latestVersion = $db->loadObject();

		if (empty($latestVersion))
		{
			return 0;
		}
		else
		{
			return $latestVersion;
		}
	}
}
