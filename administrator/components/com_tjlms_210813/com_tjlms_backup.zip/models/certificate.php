<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
	defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
jimport('joomla.filesystem.file');

/**
 * TjlmsModelCertificate class
 *
 * @since  1.6
 */
class TjlmsModelCertificate extends JModelLegacy
{
	/**
	 * Function saves configuration data to a file
	 *
	 * @return	boolean
	 */
	public function save()
	{
		$app = JFactory::getApplication();
		$input = JFactory::getApplication()->input;
		$certificate = JRequest::getVar('data', '', 'post', 'array', JREQUEST_ALLOWHTML);
		$file = JPATH_ADMINISTRATOR . DS . "components" . DS . "com_tjlms" . DS . "certificate.php";
		$msg = '';
		$msg_type = '';

		if ($certificate)
		{
			$template_css = $certificate['template_css'];
			unset($certificate['template_css']);

			$file_contents = "<?php \n\n";
			$file_contents .= "\$certificate = array(\n" . $this->row2text($certificate) . "\n);\n";
			$file_contents .= "\n?>";

			if (JFile::write($file, $file_contents))
			{
				$msg = JText::_('COM_TJLMS_CERTIFICATE_TEMPLATE_SAVED');
			}
			else
			{
				$msg = JText::_('CONFIG_SAVE_PROBLEM');
				$msg_type = 'error';
			}

			$cssfile = JPATH_SITE . DS . "components" . DS . "com_tjlms" . DS . "assets/css" . DS . "certificate.css";
					JFile::write($cssfile, $template_css);
		}

		$app->redirect('index.php?option=com_tjlms&view=certificate', $msg, $msg_type);
	}
	// Store() ends

	/**
	 *This formats the data to be stored in the config file
	 *
	 * @param   integer  $row    The id of the row to check out.
	 * @param   array    $dvars  The id of the row to check out.
	 *
	 * @return	boolean		True on success, false on failure.
	 */
	public function row2text($row, $dvars = array())
	{
		reset($dvars);

		while (list($idx, $var) = each($dvars))
		{
			unset($row[$var]);
		}

		$text = '';
		reset($row);
		$flag = 0;
		$i = 0;

		while (list($var, $val) = each($row))
		{
			if ($flag == 1)
			{
				$text .= ",\n";
			}
			elseif ($flag == 2)
			{
				$text .= ",\n";
			}

			$flag = 1;

			if (is_numeric($var))
			{
				if ($var{0} == '0')
				{
					$text .= "'$var'=>";
				}
				else
				{
					if ($var !== $i)
					{
						$text .= "$var=>";
					}

					$i = $var;
				}
			}
			else
			{
				$text .= "'$var'=>";
			}

			$i++;

			if (is_array($val))
			{
				$text .= "array(" . $this->row2text($val, $dvars) . ")";
				$flag = 2;
			}
			else
			{
				$text .= "\"" . addslashes($val) . "\"";
			}
		}

		return($text);
	}
}
