<?php
/**
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
// No direct access.
defined('_JEXEC') or die;
jimport('joomla.application.component.modellist');

/**
 * Methods to get a list of enrollment users
 *
 * @since  1.0.0
 */
class TjlmsModelEnrolment extends JModelList
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.0.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'u.id',
				'name', 'u.name',
				'status', 'u.block',
				'username', 'u.username',
				'groupfilter'
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
		$app = JFactory::getApplication('administrator');
		$input = JFactory::getApplication()->input;
		$post = $input->post;

		// Load the filter state.
		$search = $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		// Filtering type
		$this->setState('filter.accesslevel', $app->getUserStateFromRequest($this->context . '.filter.accesslevel', 'accesslevel', '', 'STRING'));

		// Filtering group
		$groupfilter = $app->getUserStateFromRequest($this->context . '.filter.groupfilter', 'groupfilter', '', 'INT');
		$this->setState('filter.groupfilter', $groupfilter);

		// Filter for selected courses
		$selectedcourse = $app->getUserStateFromRequest($this->context . '.filter.selectedcourse', 'selectedcourse', '', 'ARRAY');
		$this->setState('filter.selectedcourse', $selectedcourse);

		// Load the parameters.
		$params = JComponentHelper::getParams('com_tjlms');
		$this->setState('params', $params);

		// List state information.
		parent::populateState();
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since	1.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return	JDatabaseQuery
	 *
	 * @since	1.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
				$this->getState(
						'list.select', 'distinct(u.id), u.name, u.username, u.block'
				)
		);

		$query->from('`#__users` AS u');
		$query->where('u.block != 1');
		$query->join('left', '`#__user_usergroup_map` as uum ON u.id = uum.user_id');

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('u.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('(( u.name LIKE ' . $search . ' ) OR ( u.username LIKE ' . $search . ' )OR ( u.id LIKE ' . $search . ' ))');
			}
		}

		$input    = JFactory::getApplication()->input;
		$groupfilter = $input->get('groupfilter', '', 'INT');

		// Get user ID if view called from course list view to view enrolled users.
		if (!$groupfilter)
		{
			$coursefilter = $this->getState('filter.coursefilter');
		}

		// Filtering type
		if ($groupfilter != '')
		{
			$query->where('uum.group_id = ' . $groupfilter);
		}

		// Filtering groups
		$accessLevel = $this->state->get('filter.accesslevel');

		if ($accessLevel != '')
		{
			$query->where('uum.group_id=' . $accessLevel);
		}

		$where = $this->_buildContentWhere();

		if ($where)
		{
			$query->where(' ' . $where);
		}

		// Add the list ordering clause.
		$orderCol = $this->state->get('list.ordering');
		$orderDirn = $this->state->get('list.direction');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * To get where condition for query.
	 *
	 * @return  query
	 *
	 * @since  1.0.0
	 */
	public function _buildContentWhere()
	{
		global $mainframe, $option;
		$mainframe = JFactory::getApplication();
		$input = JFactory::getApplication()->input;
		$db = JFactory::getDBO();
		$c_id = $input->get('course_id', '0', 'INT');

		if ($c_id)
		{
			$enroled_users = $this->getCourseEnrolledUsers($c_id);
		}

		$where = '';

		if (!empty($enroled_users))
		{
			$where[] = "u.id NOT IN(" . implode(',', $enroled_users) . ")";
		}

		$c_al = $input->get('course_al', '', 'STRING');
		$u_groups = '';

		// If course has access level get groups applicable for that access level
		if ($c_al)
		{
			if ($c_al != 1)
			{
				$u_groups = $this->getGroups($c_al);
			}

			$this->setState('filter.groupfilter', "");
		}
		else
		{
			if ($this->getState('filter.groupfilter') > 1)
			{
				// Use value set in filter
				$u_groups = (array) $this->getState('filter.groupfilter');
			}
		}

		if (!empty($u_groups['0']))
		{
			$where[] = "uum.group_id IN(" . implode(',', $u_groups) . ")";
		}

		if (!empty($where))
		{
			$where = (count($where) ?  implode(' AND ', $where) : '');
		}

		return $where;
	}

	/**
	 * To get user already enrolled in the course.
	 *
	 * @param   INT  $c_id  The course ID.
	 *
	 * @return  result
	 *
	 * @since  1.0.0
	 */
	public function getCourseEnrolledUsers($c_id='')
	{
		// Get a db connection.
		$db = JFactory::getDbo();

		// Create a new query object.
		$query = $db->getQuery(true);

		// Select all records from the user profile table where key begins with "custom.".
		// Order it by the ordering field.
		$query->select('eu.user_id');
		$query->from('#__tjlms_enrolled_users as eu');
		$query->where('eu.course_id="' . $c_id . '"');
		$query->where('eu.state=1');

			// Reset the query using our newly populated query object.
		$db->setQuery($query);

		// Load the results
		return $db->loadColumn();
	}

	/**
	 * To get groups for the repected access level.
	 *
	 * @param   INT  $c_al  The access level ID.
	 *
	 * @return  Object
	 *
	 * @since  1.0.0
	 */
	public function getGroups($c_al)
	{
		$al_groups = array();

		$db	= JFactory::getDBO();

		// Create a new query object.
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select('rules');
		$query->from('`#__viewlevels`');

		// If public get all access levels
		if ($c_al == 1)
		{
			$db->setQuery($query);
			$tempLevels = $db->loadObjectlist();

			foreach ($tempLevels as $tempLevel)
			{
				$temp = json_decode($tempLevel->rules);

				$al_groups = array_merge($al_groups, $temp);
				$al_groups = array_unique($al_groups);
			}
		}
		else
		{
				$query->where('id="' . $c_al . '"');
				$db->setQuery($query);
				$temp = json_decode($db->loadResult());

				if (isset($temp))
				{
					$al_groups = array_merge($al_groups, $temp);
				}
		}

		return $al_groups;
	}

	/**
	 * To get the records
	 *
	 * @return  Object
	 *
	 * @since  1.0.0
	 */
	public function getItems()
	{
		$items = parent::getItems();

		// Get a db connection.
		$db	= JFactory::getDBO();

		foreach ($items as $k => $obj)
		{
			$userGroups = JAccess::getGroupsByUser($obj->id);
			$userGroups = array_diff($userGroups, array('1'));
			$group = array();

			// Create a new query object.
			$query = $db->getQuery(true);

			$query->select($db->quoteName('title'));
			$query->from($db->quoteName('#__usergroups'));
			$query->where($db->quoteName('id') . ' IN (' . implode(',', $userGroups) . ' ) ');
			$db->setQuery($query);
			$group = $db->loadColumn();

			$items[$k]->groups = implode('<br />', $group);
		}

		return $items;
	}

	/**
	 * To plublish and unpublish enrolledment.
	 *
	 * @param   JRegistry  $items  The item to update.
	 * @param   JRegistry  $state  The state for the item.
	 *
	 * @return  true or false
	 *
	 * @since  1.0.0
	 */
	public function setItemState($items, $state)
	{
		$db = JFactory::getDBO();

		if (is_array($items))
		{
			foreach ($items as $id)
			{
				$db = JFactory::getDbo();

				$query = $db->getQuery(true);

				// Fields to update.
				$fields = array(
					$db->quoteName('state') . ' = ' . $state
				);

				// Conditions for which records should be updated.
				$conditions = array(
					$db->quoteName('id') . ' = ' . $id
				);

				$query->update($db->quoteName('#__tjlms_enrolled_users'))->set($fields)->where($conditions);

				$db->setQuery($query);

				if (!$db->execute())
				{
					$this->setError($this->_db->getErrorMsg());

					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Function used to get eligible groups
	 *
	 * @return  Object  all groups
	 *
	 * @since  1.0.0
	 */
	public function getGroupsfilter()
	{
		$db	= JFactory::getDBO();
		$input = JFactory::getApplication()->input;
		$c_al = $input->get('course_al', '', 'STRING');
		$options = '';
		$options[] = JHTML::_('select.option', '', JText::_('COM_TJLMS_ENROLLED_USER_ACCESS'));

		// If on course enrolment view
		if ($c_al)
		{
			$al_groups = $this->getGroups($c_al);

			foreach ($al_groups as $group_id)
			{
				// Create a new query object.
				$query = $db->getQuery(true);

				// Select the required fields from the table.
				$query->select('title');
				$query->from('`#__usergroups`');
				$query->where('id="' . $group_id . '"');
				$db->setQuery($query);
				$options[] = JHTML::_('select.option', $group_id, $db->loadResult());
			}
		}
		else
		{
				// Create a new query object.
				$query = $db->getQuery(true);

				// Select the required fields from the table.
				$query->select('id,title');
				$query->from('`#__usergroups`');
				$db->setQuery($query);
				$results = $db->loadObjectlist();

				foreach ($results AS $result)
				{
					$options[] = JHTML::_('select.option', $result->id, $result->title);
				}
		}

		return $options;
	}
}
