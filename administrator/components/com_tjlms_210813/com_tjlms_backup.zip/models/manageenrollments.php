<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;
jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Tjlms records.
 *
 * @since  1.0.0
 */
class TjlmsModelManageenrollments extends JModelList
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.0.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'b.id',
				'state', 'b.state',
				'course_id', 'b.course_id',
				'user_id', 'b.user_id',
				'timestart', 'b.timestart',
				'name', 'uc.name',
				'username', 'uc.username',
				'coursefilter',
				'enroll_starts',
				'enroll_ends'
			);
		}

		$this->ComtjlmsHelper = new ComtjlmsHelper;

		$path = JPATH_SITE . '/components/com_tjlms/helpers/main.php';
		$this->comtjlmsHelper = '';

		if (JFile::exists($path))
		{
			if (!class_exists('comtjlmsHelper'))
			{
				JLoader::register('comtjlmsHelper', $path);
				JLoader::load('comtjlmsHelper');
			}

			$this->comtjlmsHelper = new comtjlmsHelper;
		}

		// Load jlike main helper to call api function for assigndetails and other
		$path = JPATH_SITE . '/components/com_jlike/helpers/main.php';
		$this->ComjlikeMainHelper = "";

		if (JFile::exists($path))
		{
			if (!class_exists('ComjlikeMainHelper'))
			{
				JLoader::register('ComjlikeMainHelper', $path);
				JLoader::load('ComjlikeMainHelper');
			}

			$this->ComjlikeMainHelper = new ComjlikeMainHelper;
		}

		// Load jlike model to call api function for assigndetails and other
		$path = JPATH_SITE . '/components/com_jlike/models/recommendations.php';
		$this->JlikeModelRecommendations = "";

		if (JFile::exists($path))
		{
			if (!class_exists('JlikeModelRecommendations'))
			{
				JLoader::register('JlikeModelRecommendations', $path);
				JLoader::load('JlikeModelRecommendations');
			}

			$this->JlikeModelRecommendations = new JlikeModelRecommendations;
		}

		// Load jlike admin model content form to call api to get content id
		$path = JPATH_SITE . '/administrator/components/com_jlike/models/contentform.php';

		$this->JlikeModelContentForm = "";

		if (JFile::exists($path))
		{
			if (!class_exists('JlikeModelContentForm'))
			{
				JLoader::register('JlikeModelContentForm', $path);
				JLoader::load('JlikeModelContentForm');
			}

			$this->JlikeModelContentForm = new JlikeModelContentForm;
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// Initialise variables.
		$app = JFactory::getApplication('administrator');

		// Load the filter state.
		$search = $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$published = $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_published', '', 'string');
		$this->setState('filter.state', $published);

		// Filtering course
		$coursefilter = $app->getUserStateFromRequest($this->context . '.filter.coursefilter', 'coursefilter', '', 'INT');

		$this->setState('filter.coursefilter', $coursefilter);

		$enroll_starts = $app->getUserStateFromRequest($this->context . '.filter.enroll_starts', 'filter_enroll_starts');
		$this->setState('filter.enroll_starts', $enroll_starts);

		$enroll_ends = $app->getUserStateFromRequest($this->context . '.filter.enroll_ends', 'filter_enroll_ends');
		$this->setState('filter.enroll_ends', $enroll_ends);

		// Load the parameters.
		$params = JComponentHelper::getParams('com_tjlms');
		$this->setState('params', $params);

		// List state information.
		parent::populateState('b.id', 'desc');

		$orderCol = $app->getUserStateFromRequest($this->context . '.filter_order', 'filter_order');

		if (!empty($orderCol))
		{
			$this->setState('list.ordering', $orderCol);
		}

		$listOrder = $app->getUserStateFromRequest($this->context . 'filter_order_Dir', 'filter_order_Dir');

		if (!empty($listOrder))
		{
			$this->setState('list.direction', $listOrder);
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   int  $id  A prefix for the store id.
	 *
	 * @return    string        A store id.
	 *
	 * @since    1.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return    JDatabaseQuery
	 *
	 * @since    1.0
	 */
	protected function getListQuery()
	{
		$user = JFactory::getUser();
		$olUserid = $user->id;
		$isroot = $user->authorise('core.admin');

		// Create a new query object.
		$db    = $this->getDbo();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select($this->getState('list.select', 'b.*, co.title, uc.name, uc.username,a.start_date,a.due_date,a.id as todo_id'));
		$query->from('`#__tjlms_enrolled_users` AS b');
		$query->join('INNER', '`#__tjlms_courses` AS co ON co.id = b.course_id');
		$query->join('INNER', '`#__users` AS uc ON b.user_id = uc.id');
		$query->join('INNER', '#__categories as cat ON cat.id=co.cat_id');
		$query->join('LEFT', '#__jlike_content as c  ON c.element_id=co.id AND c.element="com_tjlms.course"');
		$query->join('LEFT', '`#__jlike_todos` AS a   ON c.id=a.content_id AND a.state=1 AND a.assigned_to=uc.id  ');
		$query->where('co.state=1 AND cat.published=1');

		if (!$isroot)
		{
			$query->where('co.created_by=' . $olUserid);
		}

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('b.state = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(b.state IN (0, 1))');
		}

		$input    = JFactory::getApplication()->input;
		$courseId = $input->get('course_id', '', 'INT');

		if ($courseId)
		{
			$query->where('(b.state=1)');
		}

		// Get user ID if view called from course list view to view enrolled users.
		if (!$courseId)
		{
			$courseId = $this->getState('filter.coursefilter');
		}

		// Filtering type
		if ($courseId != '')
		{
			$query->where('b.course_id = ' . $courseId);
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			$search = $db->Quote('%' . $db->escape($search, true) . '%');
			$query->where('(( uc.name LIKE ' . $search . ' ) OR ( uc.username LIKE ' . $search . ' ))');
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering');
		$orderDirn = $this->state->get('list.direction');

		if ($orderCol == 'c.element_id')
		{
			$orderCol = 'b.course_id';
		}

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

			// Date filters
		$enroll_starts = $this->getState('filter.enroll_starts', '');
		$enroll_starts_date = date("Y-m-d", strtotime($enroll_starts));

		$enroll_ends = $this->getState('filter.enroll_ends', '');
		$enroll_ends_date = date("Y-m-d", strtotime($enroll_ends));

		if ($enroll_starts and !$enroll_ends)
		{
			$query->where('DATE(a.start_date)>=' . $db->quote($enroll_starts_date));
		}

		if ($enroll_ends and !$enroll_starts)
		{
			$query->where('DATE(a.due_date)<=' . $db->quote($enroll_ends_date));
		}

		if ($enroll_starts and $enroll_ends)
		{
			if ($enroll_starts != $enroll_ends)
			{
				$query->where('DATE(a.start_date)>=' . $db->quote($enroll_starts_date));
				$query->where('DATE(a.due_date)<=' . $db->quote($enroll_ends_date));
			}
			else
			{
				$query->where('DATE(a.start_date)=' . $db->quote($enroll_starts_date));
				$query->where('DATE(a.due_date)=' . $db->quote($enroll_ends_date));
			}
		}

		return $query;
	}

	/**
	 * To get the records
	 *
	 * @return  Object
	 *
	 * @since  1.0.0
	 */
	public function getItems()
	{
		$items = parent::getItems();

		foreach ($items as $ind => $courseUser)
		{
			$items[$ind]->groups     = $this->getGroups($courseUser->user_id);

			$data               = array();
			$data['element']    = 'com_tjlms.course';
			$data['element_id'] = $courseUser->course_id;
			$course_url         = 'index.php?option=com_tjlms&view=course&id=' . $courseUser->course_id;

			if ($this->comtjlmsHelper)
			{
				$itemId      = $this->comtjlmsHelper->getitemid($course_url);
				$data['url'] = $course_url . '&Itemid=' . $itemId;
			}
			else
			{
				$data['url'] = $course_url;
			}

			$techjoomlaCommon = new TechjoomlaCommon;

			$items[$ind]->enrolled_on_time = $techjoomlaCommon->getDateInLocal($courseUser->enrolled_on_time);
		}

		return $items;
	}

	/**
	 * To plublish and unpublish enrolledment.
	 *
	 * @param   JRegistry  $items     The item to update.
	 * @param   JRegistry  $state     The state for the item.
	 * @param   int        $courseId  The course ID
	 *
	 * @return  true or false
	 *
	 * @since  1.0.0
	 */
	public function setItemState($items, $state, $courseId)
	{
		$db            = JFactory::getDBO();

		// $todaydatetime = JFactory::getDate()->toFormat('Y-m-d H:i:s');

		if (is_array($items))
		{
			foreach ($items as $id)
			{
				$object                = new stdClass;
				$object->id            = $id;
				$object->state         = $state;

				$date = JFactory::getDate();
				$date = $date->toSql(true);
				$object->modified_time = $date;

				if (!$db->updateObject('#__tjlms_enrolled_users', $object, 'id'))
				{
					$this->setError($this->_db->getErrorMsg());

					return false;
				}

				if ($state == '1')
				{
					$plan_id = $this->getPlanId($id);

					if (!empty($plan_id))
					{
						$tjlmsCoursesHelper = new tjlmsCoursesHelper;
						$endTime            = $tjlmsCoursesHelper->updateEndTimeForCourse($plan_id, $id);
					}
				}

				$dispatcher = JDispatcher::getInstance();
				JPluginHelper::importPlugin('system');
				$dispatcher->trigger('onAfterApprovecourseEnrolement', array(
																				$id,
																				$state,
																				JFactory::getUser()->id
																			)
									);
			}
		}

		return true;
	}

	/**
	 * To get subscription plan ID
	 *
	 * @param   int  $enrollmentId  The enrollment table ID
	 *
	 * @return  true or false
	 *
	 * @since  1.0.0
	 */
	public function getPlanId($enrollmentId)
	{
		$db    = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('course_id,user_id');
		$query->from($db->quoteName('#__tjlms_enrolled_users'));
		$query->where($db->quoteName('id') . ' = ' . $enrollmentId);
		$db->setQuery($query);
		$enrollmentDetails = $db->loadObject();

		$plan_id = '';

		if ($enrollmentDetails->course_id)
		{
			$tjlmsCoursesHelper = new tjlmsCoursesHelper;
			$courseInfo            = $tjlmsCoursesHelper->getCourseColumn($enrollmentDetails->course_id, array('id','type'));

			if ($courseInfo && $courseInfo->id > 0 && $courseInfo->type == 1)
			{
				// Get plan id from order item table
				$query = $db->getQuery(true);
				$query->select('oi.plan_id');
				$query->from($db->quoteName('#__tjlms_order_items') . 'AS oi');
				$query->join('INNER', $db->quoteName('#__tjlms_orders') . 'AS o ON o.id=oi.order_id');
				$query->where('o.course_id = ' . $enrollmentDetails->course_id . ' AND o.user_id = ' . $enrollmentDetails->user_id);
				$db->setQuery($query);
				$plan_id = $db->loadResult();
			}
		}

		return $plan_id;
	}

	/**
	 * To get User Groups
	 *
	 * @param   int  $user_id  The user ID
	 *
	 * @return  string  $groups_str
	 *
	 * @since  1.0.0
	 */
	public function getGroups($user_id)
	{
		$db     = JFactory::getDBO();
		$groups = array();
		$query  = "SELECT ug.title FROM #__usergroups as ug, #__user_usergroup_map as uum where uum.group_id= ug.id and user_id=" . $user_id;
		$db->setQuery($query);
		$groups     = $db->loadColumn();
		$groups_str = '';

		for ($i = 0; $i < count($groups); $i++)
		{
			$groups_str .= $groups[$i] . '<br />';
		}

		return $groups_str;
	}

	/**
	 * To All courses
	 *
	 * @return  obj
	 *
	 * @since  1.0.0
	 */
	public function getAllCourses()
	{
		$db    = JFactory::getDBO();
		$query = " SELECT tc.id as value, tc.title as text FROM #__tjlms_courses as tc";
		$db->setQuery($query);

		return $db->loadObjectList();
	}

	/**
	 * Delet orders
	 *
	 * @param   ARRAY  $cid  array of order id
	 *
	 * @return  true
	 *
	 * @since   1.0.0
	 */
	public function delete($cid)
	{
		$db = JFactory::getDbo();
		$not_allowed_del = array();
		$app = JFactory::getApplication();

		// Add Table Path
		JTable::addIncludePath(JPATH_ROOT . '/administrator/components/com_tjlms/tables');

		foreach ($cid as $key => $eachEnrollment)
		{
			$Enrolledusers = JTable::getInstance('Enrolledusers', 'TjlmsTable', array('dbo', $db));
			$Enrolledusers->load(array('id' => $eachEnrollment));
			$course = JTable::getInstance('course', 'TjlmsTable', array('dbo', $db));
			$course->load(array('id' => $Enrolledusers->course_id));
			$allowed_delete = 1;

			if ($course->type == 1)
			{
				if (($key = array_search($eachEnrollment, $cid)) !== false)
				{
					$allowed_delete = 0;
					$not_allowed_del[] = $eachEnrollment . ' : ' . $Enrolledusers->user_id . ' : ' . $course->title;

					unset($cid[$key]);
				}
			}

			if ($allowed_delete == 1)
			{
				// Get content Id
				$data               = array();
				$data['element']    = 'com_tjlms.course';
				$data['element_id'] = $Enrolledusers->course_id;
				$course_url         = 'index.php?option=com_tjlms&view=course&id=' . $Enrolledusers->course_id;

				if ($this->comtjlmsHelper)
				{
					$itemId      = $this->comtjlmsHelper->getitemid($course_url);
					$data['url'] = $course_url . '&Itemid=' . $itemId;
				}
				else
				{
					$data['url'] = $course_url;
				}

				$content_id         = $this->JlikeModelContentForm->getConentId($data);

				// Get assignment Details
				$this->JlikeModelRecommendations = new JlikeModelRecommendations;

				if ($content_id)
				{
					$this->JlikeModelRecommendations->setState("content_id", $content_id);
				}

				$this->JlikeModelRecommendations->setState("type", "myassign");
				$this->JlikeModelRecommendations->setState("user_id", $Enrolledusers->user_id);

				$assigndetails     = $this->JlikeModelRecommendations->getItems();

				if ($assigndetails[0])
				{
					$this->ComjlikeMainHelper->deleteTodo($assigndetails[0]->id);
				}
			}
		}

		if ($cid != null)
		{
			$enrollmentToDelet = implode(',', $cid);

			$query = $db->getQuery(true);

			// Delete all orders as selected
			$conditions = array(
				$db->quoteName('id') . ' IN ( ' . $enrollmentToDelet . ' )',
			);

			$query->delete($db->quoteName('#__tjlms_enrolled_users'));
			$query->where($conditions);

			$db->setQuery($query);

			if (!$db->execute())
			{
					$this->setError($this->_db->getErrorMsg());

					return false;
			}
		}

		if (count($not_allowed_del))
		{
			$app->enqueueMessage(JText::sprintf(JText::_('COM_TJLMS_CAN_DELETE_ENROLLMENT'), implode('<br>', $not_allowed_del)), 'notice');
		}

		return count($cid);
	}

	/**
	 * Get Enrollment Details
	 *
	 * @param   INT  $enrollmentId  id of enrollment
	 *
	 * @return  true
	 *
	 * @since   1.0.0
	 */
	public function getenrollmentdetails($enrollmentId='')
	{
		if ($enrollmentId)
		{
			$db = JFactory::getDbo();

			// Add Table Path
			JTable::addIncludePath(JPATH_ROOT . '/administrator/components/com_tjlms/tables');

			// First parameter file name and second parameter is prefix
			$table = JTable::getInstance('Enrolledusers', 'TjlmsTable', array('dbo', $db));

			// Check if already Enrolled User
			$table->load(array('id' => (int) $enrollmentId));

			return $table;
		}

		return false;
	}

	/**
	 * Update assignment dates
	 *
	 * @return  true
	 *
	 * @since   1.0.0
	 */
	public function changeDateCourse()
	{
		$input = JFactory::getApplication()->input;
		$post = $input->post;

		// Get data passed by the post from the view
		if ($post->get('start_date', '', 'DATE'))
		{
			$data['start_date']   = $post->get('start_date', '', 'DATE');
		}

		if ($post->get('due_date', '', 'DATE'))
		{
			$data['due_date']     = $post->get('due_date', '', 'DATE');
		}

		$notify_user					= $post->get('notify_user', '', 'INT') ? $post->get('notify_user', '', 'INT') : 0;
		$data['todo_id']				= $post->get('todo_id', '', 'INT');
		$data['recommend_friends']		= $post->get('recommend_friends', '', 'ARRAY');
		$data['type']					= 'assign';

		// Set the plugin details
		$plg_name   = 'jlike_tjlms';
		$plg_type   = 'content';
		$element    = 'com_tjlms.course';
		$element_id = $post->get('element_id', '', 'INT');
		$options = array('element' => $element, 'element_id' => $element_id, 'plg_name' => $plg_name, 'plg_type' => $plg_type);

		if (!empty($data))
		{
			$res       = $this->ComjlikeMainHelper->updateTodos($data, $options, $notify_user);

			return $res;
		}
	}

/**
	* check selected content follows criteria to send reminder
	*
	* @param   INT  $course_id  course ID
	* @param   INT  $user_id    user_id ID
	*
	* @return reminder Array.
	*/
	public function checkIfEnrollmentPublished($course_id, $user_id)
	{
		$conditions = array('eu.course_id =' . (int) $course_id, 'eu.user_id =' . (int) $user_id, 'eu.state=1');

		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('count(*)');
		$query->from($db->quoteName('#__tjlms_enrolled_users') . 'as eu');
		$query->where($conditions);
		$db->setQuery($query);
		$published = $db->loadResult();

		return $published;
	}
}
