<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Tjlms
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Shika is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Tjlms helper.
 *
 * @since  1.0.0
 */
class TjlmsHelper
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   STRING  $vName  View name
	 *
	 * @return  void
	 *
	 * @since  1.0.0
	 */
	public static function addSubmenu($vName = '')
	{
		$canDo = self::getActions();

		// Get component params
		$tjlmsparams = JComponentHelper::getParams('com_tjlms');
		$catTmtUrl = 'index.php?option=com_categories&view=categories&extension=com_tmt.questions';
		$manageEnrollmentUrl = 'index.php?option=com_tjlms&view=manageenrollments';
		$singlecoursereporturl = 'index.php?option=com_tjlms&view=singlecoursereport';
		JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_DASHBOARD'), 'index.php?option=com_tjlms&view=dashboard', $vName == 'dashboard');

		if ($canDo->get('view.coursecategories'))
		{
			$catTjlmsUrl = 'index.php?option=com_categories&extension=com_tjlms';
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_SUBMENU_CATEGORIES'), $catTjlmsUrl, $vName == 'categories');
		}

		if ($canDo->get('view.courses'))
		{
			JHtmlSidebar::addEntry(
			JText::_('COM_TJLMS_TITLE_COURSES'), 'index.php?option=com_tjlms&view=courses&filter[type]=&filter[state]=', $vName == 'courses'
			);
		}

		if ($canDo->get('view.questioncategories'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_SUBMENU_QUIZ_CATEGORIES'), $catTmtUrl, $vName == 'categories.questions');
		}

		if ($canDo->get('view.questionbank'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_SUBMENU_QUIZ_QUESTIONS'), 'index.php?option=com_tmt&view=questions', $vName == 'questions');
		}

		if ($canDo->get('view.manageenrollment'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_MANAGE_ENROLLMENT'), $manageEnrollmentUrl, $vName == 'manageenrollments');
		}

		if ($canDo->get('view.certificatetemplate'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_CERTIFICATE'), 'index.php?option=com_tjlms&view=certificates', $vName == 'certificates');
		}

		if ($canDo->get('view.coupons'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_COUPONS'), 'index.php?option=com_tjlms&view=coupons', $vName == 'coupons');
		}

		if ($canDo->get('view.reminders'))
		{
			// Added to add link for assignment reminders report view
			$reminders = 'index.php?option=com_tjlms&view=reminders';
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_REMINDERS'), $reminders, $vName == 'reminders');
		}

		if ($canDo->get('view.orders'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_ORDERS'), 'index.php?option=com_tjlms&view=orders', $vName == 'orders');
		}

		if ($canDo->get('view.activities'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_ACTIVITIES'), 'index.php?option=com_tjlms&view=activities', $vName == 'activities');
		}

		if ($canDo->get('view.reports'))
		{
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_ATTEMPTS'), 'index.php?option=com_tjlms&view=attemptreport', $vName == 'attemptreport');

			/*JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_STUDENT_LESSON_REPORT'), $singlecoursereporturl, $vName == 'singlecoursereport');*/

			$userReport = 'index.php?option=com_tjlms&view=reports&reportToBuild=userreport';
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_REPORT'), $userReport, $vName == 'reports');
		}

		/* @TODO : remove commenting once ready with tjField integration*/
		if ($canDo->get('view.coursefieldsgroups'))
		{
			$course_fields_group_url = 'index.php?option=com_tjfields&view=groups&client=com_tjlms.course&extension=com_tjlms';
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_COURSE_FIELD_GROUP'), $course_fields_group_url, $vName == 'groups');
		}

		if ($canDo->get('view.coursefields'))
		{
			$course_fields_url = 'index.php?option=com_tjfields&view=fields&client=com_tjlms.course&extension=com_tjlms';
			JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_COURSE_FIELDS'), $course_fields_url, $vName == 'fields');
		}

		JHtmlSidebar::addEntry(JText::_('COM_TJLMS_TITLE_HELP'), 'index.php?option=com_tjlms&view=help', $vName == 'help');
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return  JObject
	 *
	 * @since    1.6
	 */
	public static function getActions()
	{
		$user   = JFactory::getUser();
		$result = new JObject;

		$assetName = 'com_tjlms';

		$actions = array(
			'core.admin',
			'core.manage',
			'core.create',
			'core.edit',
			'core.edit.own',
			'core.edit.state',
			'core.delete',
			'view.reports',
			'view.coursecategories',
			'view.courses',
			'view.questioncategories',
			'view.questionbank',
			'view.manageenrollment',
			'view.certificatetemplate',
			'view.coupons',
			'view.orders',
			'view.activities',
			'view.coursefields',
			'view.coursefieldsgroups',
			'view.singlecoursereport'
		);

		foreach ($actions as $action)
		{
			$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}

	/**
	 * Function to upload files
	 *
	 * @param   ARRAY  $post   Post array
	 * @param   ARRAY  $files  File array
	 *
	 * @return  INT
	 *
	 * @since  1.0.0
	 */
	public function upload_files_store($post, $files)
	{
		$user = JFactory::getUser();
		$db   = JFactory::getDBO();

		if (!JFolder::exists(JPATH_SITE . '/media/com_tjlms' . '/associatefiles'))
		{
			JFolder::create(JPATH_SITE . '/media/com_tjlms' . '/associatefiles', 0777);
		}

		$lessonsFiles  = $files->get('lesson_files', '', 'ARRAY');
		$lessonDetails = $post->get('lesson_files', '', 'ARRAY');

		foreach ($lessonsFiles as $k => $v)
		{
			$filepath    = 'media/com_tjlms' . '/associatefiles/' . $v['file']['name'];
			$uploads_dir = JPATH_SITE . '/' . $filepath;

			if ($v['file']['name'])
			{
				if (!JFile::exists(JPATH_SITE . $uploads_dir))
				{
					$src = $v['file']['tmp_name'];
					JFile::upload($src, $uploads_dir);
				}

				$file_data           = new stdClass;
				$file_data->filename = $lessonDetails[$k]['title'];
				$file_data->path     = $filepath;
				$file_data->user_id  = $user->id;

				if (!empty($file_data->filename) && !empty($file_data->path))
				{
					if (!$db->insertObject('#__tjlms_media', $file_data, 'id'))
					{
						echo $this->_db->stderr();

						return false;
					}
					else
					{
						$file_id[] = $file_data->id;
					}
				}
			}
		}

		return $file_id;
	}

	/**
	 * Get all access levels of joomla
	 *
	 * @return  ARRAY
	 *
	 * @since  1.0.0
	 */
	public function getJoomlaAccessLevels()
	{
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('a.id as value,a.title as text');
		$query->from('`#__viewlevels` AS a');
		$db->setQuery($query);

		return $db->loadObjectList();
	}

	/**
	 * Get all the dates converted to utc
	 *
	 * @param   date  $date  date of lesson
	 *
	 * @return   date in utc format
	 *
	 * @since   1.0
	 */
	public function getDateInUtc($date)
	{
		// Change date in UTC
		$config = JFactory::getConfig();
		$offset = $config->get('offset');

		$lessonDate = JFactory::getDate(strtotime($date), 'UTC', true);
		$date = $lessonDate->toSql(true);

		return $date;
	}

	/**
	 * Get all the dates converted to utc
	 *
	 * @param   date  $date  date of lesson
	 *
	 * @return   date in utc format
	 *
	 * @since   1.0
	 */
	public function getDateInLocal($date)
	{
		// Get some system objects.
		$config = JFactory::getConfig();
		$user   = JFactory::getUser();

		$config = JFactory::getConfig();
		$offset = $config->get('offset');

		$mydate = JFactory::getDate(strtotime($date), $offset);

		return $mydate;
	}

	/**
	 * Get all jtext for javascript
	 *
	 * @return   void
	 *
	 * @since   1.0
	 */
	public static function getLanguageConstant()
	{
		JText::script('COM_TJLMS_NO_OF_ATTEMPT_VALIDATION_MSG');
		JText::script('COM_TJLMS_MAX_ATTEMPT_VALIDATION_MSG1');
		JText::script('COM_TJLMS_MAX_ATTEMPT_VALIDATION_MSG2');
		JText::script('COM_TJLMS_EMPTY_TITLE_ISSUE');
		JText::script('COM_TJLMS_COURSE_DURATION_VALIDATION');
		JText::script('COM_TJLMS_LESSON_UPDATED_SUCCESSFULLY');
		JText::script('COM_TJLMS_MODULE_PUBLISHED_SUCCESSFULLY');
		JText::script('COM_TJLMS_MODULE_UNPUBLISHED_SUCCESSFULLY');
		JText::script('COM_TJLMS_REPORTS_CANNOT_SELECT_NONE');
		JText::script('COM_TJLMS_ENTER_NUMERNIC_MARKS');
		JText::script('COM_TJLMS_NO_NEGATIVE_NUMBER');
		JText::script('COM_TJLMS_UPDATED_MARKS_SUCCESSFULLY');
		JText::script('COM_TJLMS_ENTER_MARKS_GRT_TOTALMARKS');
		JText::script('COM_TJLMS_END_DATE_CANTBE_GRT_TODAY');
		JText::script('COM_TJLMS_SURE_PAID_TO_FREE');
		JText::script('COM_TJLMS_VALID_MODULE_TITLE');

		// For date valiation
		JText::script('COM_TJLMS_SELECT_FILL_DATES');
		JText::script('COM_TJLMS_INVALID_DATE_FORMAT');
		JText::script('COM_TJLMS_DUE_DATE_EMPTY');
		JText::script('COM_TJLMS_START_GT_THAN_DUE_DATE');
		JText::script('COM_TJLMS_START_GT_THAN_TODAY');
		JText::script('COM_TJLMS_DATE_VALIDATION_MONTH_INCORRECT');
		JText::script('COM_TJLMS_DATE_VALIDATION_DATE_INCORRECT');
		JText::script('COM_TJLMS_DATE_VALIDATION');
		JText::script('COM_TJLMS_DATE_VALIDATION_DATE_RANGE');
		JText::script('COM_TJLMS_DATE_RANGE_VALIDATION');
		JText::script('COM_TJLMS_DATE_TIME_VALIDATION');
		JText::script('COM_TJLMS_COUPON_DATE_VALIDATION');
		JText::script('COM_TJLMS_DASHBOARD_DATE_RANGE_VALIDATION');
		JText::script('COM_TJLMS_CLOSE_PREVIEW_LESSON');
		JText::script('COM_TJLMS_SURE_DELETE_MODULE');
		JText::script('COM_TJLMS_REPORTS_VALID_DATE');
		JText::script('COM_TJLMS_INVALID_START_DATE');
		JText::script('COM_TJLMS_INVALID_END_DATE');
		JText::script('COM_TJLMS_SELECT_COURSE_TO_ENROLL');
		JText::script('COM_TJLMS_FORM_INVALID_FIELD');
		JText::script('COM_TJLMS_DATE_RANGE_VALIDATION');
		JText::script('COM_TJLMS_CERTIFICATE_ACCESS_MSG');
		JText::script('COM_TJLMS_ATTEMPTREPORT_DATE_RANGE_VALIDATION');
		JText::script('COM_TJLMS_ATTEMPTREPORT_INVALID_DATE_FORMAT');
		JText::script('COM_TJLMS_MANAGEENROLLMENTS_DATE_RANGE_VALIDATION');
		JText::script('COM_TJLMS_MANAGEENROLLMENTS_INVALID_DATE_FORMAT');
		JText::script('COM_TJLMS_MAX_USER_VALIDATION');

		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXFIXCOURSEALIAS');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXFIXLESSONALIAS');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXFIXCOLUMNINDEXES');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXFIXOTHERDBCHANGES');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXMIGRATECOURSETRACK');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXMIGRATETESTS');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIX_SUCCESS_MSG');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXREMOVEORPHANEDLESSONFILES');
		JText::script('COM_TJLMS_TOOLBAR_DATABASE_FIXUPDATECERTIFICATETAGS');
	}
}
