<?php
/**
 * @version    SVN: <svn_id>
 * @package    Tjlms
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access.
defined('_JEXEC') or die;

$certificate = array(
'message_body' => "
<div style=\"width: 700px; height: 450px; padding: 20px; text-align: center; border: 10px solid #787878;\">
<div style=\"width: 650px; height: 400px; padding: 20px; text-align: center; border: 5px solid #787878;\">
<span style=\"font-size: 50px; font-weight: bold;\">Certificate of Completion</span> <br /><br />
<span style=\"font-size: 25px;\"><i>This is to certify that</i></span> <br /><br />
<span style=\"font-size: 30px;\"><b>[STUDENTNAME]</b></span><br /><br /><span style=\"font-size: 25px;\">
<i> has completed the course</i></span> <br /><br /><span style=\"font-size: 30px;\"><b>[COURSE]</b></span>
<br /><br /><span style=\"font-size: 25px;\"><i> dated </i></span><br /><br />
<span style=\"font-size: 30px;\">[GRANTED_DATE]</span></div>
</div>"
);
