<?php
/**
* @package		PayPlans
* @copyright	Copyright (C) Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* PayPlans is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

jimport('joomla.filesystem.file');

// If Payplans System Plugin disabled then do nothing
$systemPlugin = JPluginHelper::isEnabled('system','payplans');
if (!$systemPlugin){
	return true;
}

$file = JPATH_ADMINISTRATOR . '/components/com_payplans/includes/payplans.php';
if (!JFile::exists($file)) {
	return;
}

require_once($file);

$userId = JFactory::getUser();
$userId = $userId->id;

// Do nothing if user is not logged in
if ($userId == 0) {
	return true;
}

// Initialize payplans
PP::initialize();

// Load up module library
$modules = PP::modules($module);

// Load PayPlans Configuration
$config = PP::config();

// Get view and layout
$view = JFactory::getApplication()->input->get('view', '', 'default');
$layout = JFactory::getApplication()->input->get('layout', '', 'default');

require_once JModuleHelper::getLayoutPath('mod_payplans_navigation', 'default');
