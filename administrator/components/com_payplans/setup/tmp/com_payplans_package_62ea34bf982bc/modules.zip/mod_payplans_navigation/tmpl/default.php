<?php 
/**
* @package		PayPlans
* @copyright	Copyright (C) Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* PayPlans is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');
?>
<script type="text/javascript">
	PayPlans.ready(function($) {
		$('[data-pp-navigation-logout-button]').on('click', function() {
			$('[data-pp-navigation-logout-form]').submit();
		});
	});
</script>
<div id="fd" class="" data-pp-structure>
	<div id="pp" class="mod-pp mod-pp-navigation theme-layer <?php echo $modules->isMobile() ? 'is-mobile' : 'is-desktop';?>"">
		<div class="o-navigation">
			<div class="o-navigation__item has-label <?php echo ($view === 'dashboard' && $layout == '') ? 'is-active' : ''?>">
				<a href="<?php echo PPR::_('index.php?option=com_payplans&view=dashboard');?>" class="o-navigation__link">
					<i class="fdi fa fa-shopping-cart fa-fw mr-xs"></i>
					<?php echo JText::_('MOD_PAYPLANS_NAVIGATION_SUBSCRIPTIONS'); ?>
				</a>
			</div>

			<?php if ($config->get('user_edit_preferences') || $config->get('user_edit_customdetails')) { ?>
				<div class="o-navigation__item has-label <?php echo $layout === 'preferences' ? 'is-active' : ''?>">
					<a href="<?php echo PPR::_('index.php?option=com_payplans&view=dashboard&layout=preferences');?>" class="o-navigation__link">
						<i class="fdi fa fa-user-edit fa-fw mr-xs"></i>
						<?php echo JText::_('MOD_PAYPLANS_NAVIGATION_EDIT_ACCOUNT');?>
					</a>
				</div>
			<?php } ?>

			<?php if ($config->get('users_download')) { ?>
				<div class="o-navigation__item has-label <?php echo $layout === 'download' ? 'is-active' : ''?>">
					<a href="<?php echo PPR::_('index.php?option=com_payplans&view=dashboard&layout=download');?>" class="o-navigation__link">
						<i class="fdi fa fa-user-shield fa-fw mr-xs"></i>
						<?php echo JText::_('MOD_PAYPLANS_NAVIGATION_DOWNLOAD_DATA');?>
					</a>
				</div>
			<?php } ?>

			<div class="o-navigation__item is-divider"></div>

			<div class="o-navigation__item has-label">
				<a href="javascript:void(0);" class="o-navigation__link" data-pp-navigation-logout-button>
					<i class="fdi fas fa-sign-out-alt fa-fw mr-xs"></i>
					<?php echo JText::_('MOD_PAYPLANS_NAVIGATION_SIGN_OUT');?>
				</a>

				<form method="post" action="<?php echo JRoute::_('index.php');?>" data-pp-navigation-logout-form>
					<input type="hidden" value="com_users"  name="option">
					<input type="hidden" value="user.logout" name="task">
					<input type="hidden" name="<?php echo FH::token();?>" value="1" />
				</form>
			</div>
		</div>
	</div>
</div>
