<?php
/**
* @package		PayPlans
* @copyright	Copyright (C) 2010 - 2018 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* PayPlans is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

class PayplansControllerSystem extends PayPlansController
{
	/**
	 * Allows user to upgrade payplans
	 *
	 * @since	4.0.0
	 * @access	public
	 */
	public function upgrade()
	{
		// Check Access the user allowd to upgrade or not
		if (!JFactory::getUser()->authorise('core.manage', 'com_payplans')) {
			return JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
		}

		$model = PP::model('System');
		$state = $model->update();

		if ($state === false) {
			$this->info->set($model->getError(), 'danger');
			return $this->app->redirect('index.php?option=com_payplans');
		}

		$this->info->set('PayPlans updated to the latest version successfully', 'success');
		return $this->app->redirect('index.php?option=com_payplans');
	}

	/**
	 * turn off the override outdated message
	 *
	 * @since	5.0.1
	 * @access	public
	 */
	public function dismissOutdatedOverrideNotice()
	{
		$key = 'show_override_outdated';

		$table = PP::table('Config');
		$exists = $table->load(array('key' => $key));

		if (!$exists) {
			$table->key = $key;
		}

		$table->value = '0';
		$table->store();
	}
}
