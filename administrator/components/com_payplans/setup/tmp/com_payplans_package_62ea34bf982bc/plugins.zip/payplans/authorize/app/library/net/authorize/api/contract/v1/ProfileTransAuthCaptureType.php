<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing ProfileTransAuthCaptureType
 *
 *
 * XSD Type: profileTransAuthCaptureType
 */
class ProfileTransAuthCaptureType extends ProfileTransOrderType
{


}

