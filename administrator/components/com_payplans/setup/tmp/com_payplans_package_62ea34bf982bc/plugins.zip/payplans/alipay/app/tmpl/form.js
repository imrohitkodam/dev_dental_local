
PayPlans.ready(function($) {
	setTimeout(function() {
		$('[data-pp-alipay-form]').submit();

	}, 1000);
});