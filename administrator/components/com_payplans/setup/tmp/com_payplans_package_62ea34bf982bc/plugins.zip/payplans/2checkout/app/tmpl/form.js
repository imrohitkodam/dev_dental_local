
PayPlans.ready(function($) {
	setTimeout(function() {
		
		$('[data-pp-2co-form]').submit();
	}, 1000);
});