<?php echo $contents; ?>
