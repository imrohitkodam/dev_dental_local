<?php
/**
* @package		PayPlans
* @copyright	Copyright (C) Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* PayPlans is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');
?>
<style type="text/css">
html, body {
	background: #fff;
	height: 100%;
	font-size: 13px;
}
</style>
<div id="fd">
	<div id="pp" class="pp-frontend pp-main <?php echo $view . $task . $object . $layout . $suffix; ?> <?php echo $view == ' view-checkout' || $view == ' view-payment' ? 'is-fullscreen' : ''; ?> <?php echo $this->isMobile() ? 'is-mobile' : 'is-desktop';?>" data-pp-structure>

		<?php echo $this->render('module', 'pp-checkout-top'); ?>

		<?php echo $this->render('module', 'pp-general-before-contents'); ?>

		<?php echo $contents; ?>

		<?php echo $this->render('module', 'pp-general-bottom'); ?>

		<div><?php echo $scripts; ?></div>
		<div data-pp-popbox-error style="display:none;"><?php echo JText::_('Unable to load tooltip content.'); ?></div>
	</div>
</div>
<script>
PayPlans.require()
.done(function($) {
	$('body').addClass('com_payplans <?php echo $view . ' ' . $layout . ' ' . $task; ?> is-fullscreen');
});
</script>