<?php
/**
 * @package	Jticketing
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
	
// no direct access
	defined('_JEXEC') or die('Restricted access'); 



class Tablemypayouts	 extends JTable
{

	var $id 			= 0;	
	var $published		=null;
	var $user_id		=null;
	var $payee_name 	=null;
	var $date 			=null;
	var $transction_id	=null;
	var $payee_id		=null;
	var $amount 		=null;
	var $status 		=null;
	var $ip_address  	=null;
	var $type   		=null;
	
	
	
	 	 	 	 	 	 	 	 	 	 		
	 					 					
	
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function Tablemypayouts (& $database) {
		parent::__construct('#__jticketing_ticket_payouts', 'id', $database);
	}
}
?>
