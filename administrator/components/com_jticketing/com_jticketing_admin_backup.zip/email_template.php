<?php 

$emails_config=array(
'message_body'=>"<table class=\"demoTable\" style=\"background-color: #f7f7f7;\" width=\"80%\" cellpadding=\"10\">
<tbody>
<tr>
<td colspan=\"2\"><span style=\"font-size: 20px;\">Live webinar confirmation: [EVENT_NAME]</span><br /> <br /> [EVENT_DESCRIPTION] <br /><br /> <span style=\"color: #999999; font-size: 14px;\">Name: </span> [NAME]</td>
</tr>
<tr>
<td width=\"50%\"><img style=\"max-width: 58px; display: block; height: auto !important;\" src=\"https://cdn0.iconfinder.com/data/icons/business-economics/64/calendar_date_icon_organizer_plan_planning_schedule_approved_event_month-128.png\" alt=\"editors\" /><br /> <span style=\"color: #999999; font-size: 14px;\">Event Start: </span>[ST_DATE]</td>
<td width=\"50%\"><img style=\"max-width: 58px; display: block; height: auto !important;\" src=\"https://cdn0.iconfinder.com/data/icons/business-economics/64/calendar_date_icon_organizer_plan_planning_schedule_approved_event_month-128.png\" alt=\"cleaning\" /><br /> <span style=\"color: #999999; font-size: 14px;\">Event End:</span><br /> [EN_DATE]</td>
</tr>
<tr>
<td colspan=\"2\"><strong>**Don\'t miss the webinar! Open the calendar attachment and save the event in your diary.</strong></td>
</tr>
</tbody>
</table>"
);

?>