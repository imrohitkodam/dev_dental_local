<?php
/**
 * @package		JTicketing
 * @subpackage
 * @author		Tekdi Web Solutions
 * @author		Created on 26-Mar-2012
 */
defined( '_JEXEC' ) or die( ';)' );
jimport('joomla.installer.installer');
jimport('joomla.filesystem.file');
if(!defined('DS'))
{
define('DS',DIRECTORY_SEPARATOR);
}
/**
 * Script file of JTicketing component

 */
class com_jticketingInstallerScript
{
	/** @var array The list of extra modules and plugins to install */
	private $installation_queue = array(
		// modules => { (folder) => { (module) => { (position), (published) } }* }*
		'modules'=>array(
			'admin'=>array(
			),
			'site'=>array(
			'mod_jticketing_buy'=>0,
			'mod_jticketing_event'=>0,
			'mod_jticketing_menu'=>0,
			'mod_jticketing_calendar'=>0

			)
		),
		// plugins => { (folder) => { (element) => (published) }* }*
		'plugins'=>array(
			'system'=>array(
				'jticketing_j3'=>1,
				'plug_sys_jticketing'=>1,
			),
			'community'=>array(
				'addfields'=>0,
			),
			'api'=>array(
				'jticket'=>1,
			),
			'jevents'=>array(
				'addfields'=>0,
			),
			'jticketingtax'=>array(
				'jticketing_tax_default'=>0,
			),

			'tjsms'=>array(
				'smshorizon'=>0,
			),

			'tjlmsdashboard'=>array(
				'eventlist'=>1,
			),
			'payment'=>array(
				'2checkout'=>0,
				'pagseguro_jgive'=>0,
				'alphauserpoints'=>0,
				'authorizenet'=>1,
				'bycheck'=>1,
				'byorder'=>1,
				'ccavenue'=>0,
				'jomsocialpoints'=>0,
				'linkpoint'=>1,
				'paypal'=>1,
				'paypalpro'=>0,
				'payu'=>1,
				'amazon'=>0,
				'ogone'=>0,
				'paypal_adaptive_payment'=>0
			)
			),

			'applications'=>array(
			'easysocial'=>array(
					'jticketMyEvents'=>0,
					'jticket_boughttickets'=>0,
					'jticketingtickettypes'=>1,

				)
		),

		'libraries'=>array(
			'activity'=>1,
			'techjoomla'=>1
		)


	);
	/** @var array Obsolete files and folders to remove*/
	private $removeFilesAndFolders = array(
		'files'	=> array(
			'administrator/components/com_jticketing/views/orders/tmpl/all.php',
			'administrator/components/com_jticketing/views/orders/tmpl/my.php',
			'administrator/components/com_jticketing/views/orders/tmpl/my.xml',
			'administrator/components/com_jticketing/views/events/tmpl/all_list.php',
			'administrator/components/com_jticketing/views/events/tmpl/create.php',
			'administrator/components/com_jticketing/views/events/tmpl/single.php',
			'plugins/payment/authorizenet/authorizenet/com_jticketing_authorizenet.log',
			'plugins/payment/2checkout/2checkout/com_jticketing_2checkout.log',
			'plugins/payment/alphauserpoints/alphauserpoints/com_jticketing_alphauserpoints.log',
			'plugins/payment/ccavenue/ccavenue/com_jticketing_ccavenue.log',
			'plugins/payment/ogone/ogone/com_jticketing_ogone.log',
			'plugins/payment/paypal/paypal/com_jticketing_paypal.log',
			'plugins/payment/amazon/amazon/com_jticketing_amazon.log',
			'plugins/payment/paypalpro/paypalpro/com_jticketing_paypalpro.log',
			'plugins/payment/payu/payu/com_jticketing_payu.log',
			'plugins/payment/transfirst/transfirst/com_jticketing_transfirst.log',
			'components/com_jticketing/views/buy/metadata.xml',
			'components/com_jticketing/views/buy/tmpl/checkout.xml',
			'components/com_jticketing/views/buy/tmpl/checkout.php',
			'components/com_jticketing/views/buy/tmpl/confirmation.php',
			'components/com_jticketing/views/buy/tmpl/order.php',
			'components/com_jticketing/views/buy/tmpl/ticketdetails.php',
			'components/com_jticketing/views/buy/tmpl/pdf_gen.php',
			'components/com_jticketing/views/event/metadata.xml',
			'components/com_jticketing/views/event/tmpl/default.xml',
		),

		'folders' => array(
			'components/com_jticketing/bootstrap',
			'components/com_jticketing/views/createevent',
			'components/com_jticketing/views/checkout',
			'components/com_jticketing/views/eventl',
			'components/com_jticketing/models/createevent',
			'components/com_jticketing/models/eventl',
			'components/com_jticketing/helpers/dompdf/lib/ttf2ufm',
			'administrator/components/com_jticketing/views/settings',
			'administrator/components/com_jticketing/models/settings',
			'administrator/components/com_jticketing/controllers/settings',

		)
	);

	/**
	 * method to install the component
	 *
	 * @return void
	 */
	function install($parent)
	{


	}

	function chk_array($configdata) {

		if(is_array($configdata))
		{
			$str = 'array(';
			$str_arr=array();
			foreach ($configdata as $kk => $vv)
			{
				$str_arr[]= "'{$kk}' => " . chk_array($vv) ;
			}
			$str.= implode(",", $str_arr);;
			$str .= ')';
			return $str;
		}
		else{
			return  "'".addslashes($configdata). "'";
		}

	}


	function row2text($row,$dvars=array())
	{

		reset($dvars);
		while(list($idx,$var)=each($dvars))
		unset($row[$var]);
		$text='';
		reset($row);
		$flag=0;
		$i=0;
		while(list($var,$val)=each($row))
		{
			if($flag==1)
			$text.=",\n";
			elseif($flag==2)
			$text.=",\n";
			$flag=1;

			if(is_numeric($var))
			if($var{0}=='0')
			$text.="'$var'=>";
			else
			{
				if($var!==$i)
				$text.="$var=>";
				$i=$var;
			}
			else
			$text.="'$var'=>";
			$i++;

			if(is_array($val))
			{
				$text.="array(".$this->row2text($val,$dvars).")";
				$flag=2;
			}
			else
			$text.="\"".addslashes($val)."\"";
		}

		return($text);
	}





/**
	 * method to update the component
	 *
	 * @return void
	 */
	function update($parent)
	{
		//Install SQL FIles
		$this->installSqlFiles($parent);
		//Since JTicketing 1.5
		$this->fix_db_on_update();
		// To remove short description
		$this->removeShortDescription($parent);
	}

	/**
	 * method to run before an install/update/uninstall method
	 *
	 * @return void
	 */
	function preflight($type, $parent)
	{

	}

	/**
	 * method to run after an install/update/uninstall method
	 *
	 * @return void
	 */
	function postflight($type, $parent)
	{
		//Install SQL FIles
		$this->installSqlFiles($parent);

		// Install subextensions
		$status = $this->_installSubextensions($parent);

		// Add default permissions
		$this->deFaultPermissionsFix();

		// Remove obsolete files and folders
		$removeFilesAndFolders = $this->removeFilesAndFolders;
		$this->_removeObsoleteFilesAndFolders($removeFilesAndFolders);

		echo '<br/>' . '
<div align="center"> <div class="alert alert-success" style="background-color:#DFF0D8;border-color:#D6E9C6;color: #468847;padding: 8px;"> <div style="font-weight:bold;"></div> <h4><a href="https://techjoomla.com/table/extension-documentation/documentation-for-jticketing/" target="_blank">'.JText::_('COM_JTICKETING_PRODUCT_DOC').'</a> | <a href="https://techjoomla.com/documentation-for-jticketing/jticketing-faqs.html" target="_blank">'.JText::_('COM_JTICKETING_PRODUCT_FAQ').'</a></h4> </div> </div>';

		// Show the post-installation page
		$this->_renderPostInstallation($status, $parent);


		// Add sample field manager data.
		$fieldsManagerDataStatus = $this->_installSampleFieldsManagerData();

		if($fieldsManagerDataStatus)
		{
			echo '<br/><strong style="color:green">' . JText::_('COM_JTICKETING_FIELDS_SAMPLE_DATA_INSTALLED') . '</strong>';
		}
		// Add core fields manager .
		$fieldsManagerDataStatus = $this->_installSampleCoreFieldsJTicketing();

		if($fieldsManagerDataStatus)
		{
			echo '<br/><strong style="color:green">' . JText::_('COM_JTICKETING_FIELDS_SAMPLE_CORE_FIELDS_INSTALLED') . '</strong>';
		}

		// Add Categories for native events
		$basicCategories = $this->_installbasicCategories();

		if($basicCategories)
		{
			echo '<br/><strong style="color:green">' . JText::_('COM_JTICKETING_FIELDS_SAMPLE_CATEGORY_INSTALLED') . '</strong>';
		}

		// Add Categories for native events
		$basicCategoriesforVenues = $this->_installbasicCategoriesforVenues();

		if($basicCategoriesforVenues)
		{
			echo '<br/><strong style="color:green">' . JText::_('COM_JTICKETING_FIELDS_SAMPLE_CATEGORY_INSTALLED') . '</strong>';
		}

		// Write template file for email and pdf template
		$this->_writeTemplate();

		if($type=='install')
		{
			echo '<p><strong style="color:green">' . JText::_('COM_JTICKETING_' . $type . '_TEXT') . '</p></strong>';
		}
		else
		{
			echo '<p><strong style="color:green">' . JText::_('COM_JTICKETING_' . $type . '_TEXT') . '</p></strong>';
		}

	}

	function _writeTemplate()
	{
		// Write default config template for PDF(Which is attached to Ticket email)
		$this->_writeTicketTemplate();

		// Write default config template for Email
		$this->_writeEmailTemplate();
	}

	function _writeTicketTemplate()
	{
		//Code for email template
		$filename=JPATH_ADMINISTRATOR.'/components/com_jticketing/config.php';
		$filename_default = JPATH_ADMINISTRATOR.'/components/com_jticketing/config_default.php';

		if(!JFile::exists($filename))//if config file does not exists
		{
			JFile::move($filename_default,$filename);
			include($filename);

			$emails_config_new=array();
			$emails_config_new['message_body']	        = $emails_config["message_body"];


			$emails_config_file_contents="<?php \n\n";
			$emails_config_file_contents.="\$emails_config=array(\n".$this->row2text($emails_config_new)."\n);\n";
			$emails_config_file_contents.="\n?>";

			JFile::delete($filename);
			JFile::write($filename,$emails_config_file_contents);
		}
		elseif(JFile::exists($filename_default))//if config file exists
		{
			JFile::delete($filename_default);
		}
	}


	function _writeEmailTemplate()
	{

		//Code for email template
		$filename=JPATH_ADMINISTRATOR.'/components/com_jticketing/email_template.php';
		$filename_default = JPATH_ADMINISTRATOR.'/components/com_jticketing/default_email_template.php';

		if(!JFile::exists($filename))//if config file does not exists
		{
			JFile::move($filename_default,$filename);
			include($filename);

			$emails_config_new=array();
			$emails_config_new['message_body']	        = $emails_config["message_body"];
			$emails_config_file_contents="<?php \n\n";
			$emails_config_file_contents.="\$emails_config=array(\n".$this->row2text($emails_config_new)."\n);\n";
			$emails_config_file_contents.="\n?>";

			JFile::delete($filename);
			JFile::write($filename,$emails_config_file_contents);
		}
		elseif(JFile::exists($filename_default))//if config file exists
		{
			JFile::delete($filename_default);
		}
	}

	/**
	 * Add default ACL permissions if already set by administrator
	 *
	 * @return  void
	 */
	public function deFaultPermissionsFix()
	{
		$db = JFactory::getDBO();
		$query = "SELECT id, rules FROM `#__assets` WHERE `name` = 'com_jticketing' ";
		$db->setQuery($query);
		$result = $db->loadobject();

		if(strlen(trim($result->rules))<=3)
		{
			$obj = new Stdclass();
			$obj->id = $result->id;
			$obj->rules = '{"core.admin":[],"core.manage":[],"core.create":{"2":1},"core.delete":{"2":1},"core.edit":{"2":1},"core.edit.state":{"2":1},"core.edit.own":{"2":1}}';

			if (!$db->updateObject('#__assets', $obj, 'id'))
			{
				$app = JFactory::getApplication();
				$app->enqueueMessage($db->stderr(), 'error');
			}
		}
	}

	/**
	 * Installs subextensions (modules, plugins) bundled with the main extension
	 *
	 * @param JInstaller $parent
	 * @return JObject The subextension installation status
	 */
	private function _installSubextensions($parent)
	{
		$src = $parent->getParent()->getPath('source');

		$db = JFactory::getDbo();

		$status = new JObject();
		$status->modules = array();
		$status->plugins = array();

		// Modules installation
		if(count($this->installation_queue['modules'])) {
			foreach($this->installation_queue['modules'] as $folder => $modules) {
				if(count($modules)) foreach($modules as $module => $modulePreferences) {
					// Install the module
					if(empty($folder)) $folder = 'site';
					$path = "$src/modules/$folder/$module";
					if(!is_dir($path)) {
						$path = "$src/modules/$folder/mod_$module";
					}
					if(!is_dir($path)) {
						$path = "$src/modules/$module";
					}
					if(!is_dir($path)) {
						$path = "$src/modules/mod_$module";
					}
					if(!is_dir($path)) continue;
					// Was the module already installed?
					$sql = $db->getQuery(true)
						->select('COUNT(*)')
						->from('#__modules')
						->where($db->qn('module').' = '.$db->q('mod_'.$module));
					$db->setQuery($sql);
					$count = $db->loadResult();
					$installer = new JInstaller;
					$result = $installer->install($path);
					$status->modules[] = array(
						'name'=>'mod_'.$module,
						'client'=>$folder,
						'result'=>$result
					);
					// Modify where it's published and its published state
					if(!$count) {
						// A. Position and state
						list($modulePosition, $modulePublished) = $modulePreferences;
						if($modulePosition == 'cpanel') {
							$modulePosition = 'icon';
						}
						$sql = $db->getQuery(true)
							->update($db->qn('#__modules'))
							->set($db->qn('position').' = '.$db->q($modulePosition))
							->where($db->qn('module').' = '.$db->q('mod_'.$module));
						if($modulePublished) {
							$sql->set($db->qn('published').' = '.$db->q('1'));
						}
						$db->setQuery($sql);
						$db->execute();

						// B. Change the ordering of back-end modules to 1 + max ordering
						if($folder == 'admin') {
							$query = $db->getQuery(true);
							$query->select('MAX('.$db->qn('ordering').')')
								->from($db->qn('#__modules'))
								->where($db->qn('position').'='.$db->q($modulePosition));
							$db->setQuery($query);
							$position = $db->loadResult();
							$position++;

							$query = $db->getQuery(true);
							$query->update($db->qn('#__modules'))
								->set($db->qn('ordering').' = '.$db->q($position))
								->where($db->qn('module').' = '.$db->q('mod_'.$module));
							$db->setQuery($query);
							$db->execute();
						}

						// C. Link to all pages
						$query = $db->getQuery(true);
						$query->select('id')->from($db->qn('#__modules'))
							->where($db->qn('module').' = '.$db->q('mod_'.$module));
						$db->setQuery($query);
						$moduleid = $db->loadResult();

						$query = $db->getQuery(true);
						$query->select('*')->from($db->qn('#__modules_menu'))
							->where($db->qn('moduleid').' = '.$db->q($moduleid));
						$db->setQuery($query);
						$assignments = $db->loadObjectList();
						$isAssigned = !empty($assignments);
						if(!$isAssigned) {
							$o = (object)array(
								'moduleid'	=> $moduleid,
								'menuid'	=> 0
							);
							$db->insertObject('#__modules_menu', $o);
						}
					}
				}
			}
		}

		// Plugins installation
		if(count($this->installation_queue['plugins'])) {
			foreach($this->installation_queue['plugins'] as $folder => $plugins) {
				if(count($plugins)) foreach($plugins as $plugin => $published) {
					$path = "$src/plugins/$folder/$plugin";
					if(!is_dir($path)) {
						$path = "$src/plugins/$folder/plg_$plugin";
					}
					if(!is_dir($path)) {
						$path = "$src/plugins/$plugin";
					}
					if(!is_dir($path)) {
						$path = "$src/plugins/plg_$plugin";
					}
					if(!is_dir($path)) continue;

					// Was the plugin already installed?
					$query = $db->getQuery(true)
						->select('COUNT(*)')
						->from($db->qn('#__extensions'))
						->where($db->qn('element').' = '.$db->q($plugin))
						->where($db->qn('folder').' = '.$db->q($folder));
					$db->setQuery($query);
					$count = $db->loadResult();

					$installer = new JInstaller;
					$result = $installer->install($path);

					$status->plugins[] = array('name'=>'plg_'.$plugin,'group'=>$folder, 'result'=>$result);

					if($published && !$count) {
						$query = $db->getQuery(true)
							->update($db->qn('#__extensions'))
							->set($db->qn('enabled').' = '.$db->q('1'))
							->where($db->qn('element').' = '.$db->q($plugin))
							->where($db->qn('folder').' = '.$db->q($folder));
						$db->setQuery($query);
						$db->execute();
					}
				}
			}
		}

		if(isset($this->installation_queue['libraries']) and count($this->installation_queue['libraries'])) {
			foreach($this->installation_queue['libraries']  as $folder=>$status1) {

					$path = "$src/libraries/$folder";
					if(file_exists($path))
					{
						$query = $db->getQuery(true)
							->select('COUNT(*)')
							->from($db->qn('#__extensions'))
							->where('( '.($db->qn('name').' = '.$db->q($folder)) .' OR '. ($db->qn('element').' = '.$db->q($folder)) .' )')
							->where($db->qn('folder').' = '.$db->q($folder));
						$db->setQuery($query);
						$count = $db->loadResult();

						$installer = new JInstaller;
						$result = $installer->install($path);

						$status->libraries[] = array('name'=>$folder,'group'=>$folder, 'result'=>$result,'status'=>$status1);
						//print"<pre>"; print_r($status->plugins); die;

						if($published && !$count) {
							$query = $db->getQuery(true)
								->update($db->qn('#__extensions'))
								->set($db->qn('enabled').' = '.$db->q('1'))
								->where('( '.($db->qn('name').' = '.$db->q($folder)) .' OR '. ($db->qn('element').' = '.$db->q($folder)) .' )')
								->where($db->qn('folder').' = '.$db->q($folder));
							$db->setQuery($query);
							$db->execute();
						}
					}
			}
		}

		//Application Installations
		if (count($this->installation_queue['applications'])) {
			foreach ($this->installation_queue['applications'] as $folder => $applications) {
				if (count($applications)) {
					foreach ($applications as $app => $published) {
						$path = "$src/applications/$folder/$app";
						if (!is_dir($path)) {
							$path = "$src/applications/$folder/plg_$app";
						}
						if (!is_dir($path)) {
							$path = "$src/applications/$app";
						}
						if (!is_dir($path)) {
							$path = "$src/applications/plg_$app";
						}

						if (!is_dir($path)) continue;


						if (file_exists(JPATH_ADMINISTRATOR . '/components/com_easysocial/includes/foundry.php')) {
							require_once( JPATH_ADMINISTRATOR . '/components/com_easysocial/includes/foundry.php' );

							$installer     = FD::get( 'Installer' );
							// The $path here refers to your application path
							$installer->load( $path );
							$plg_install=$installer->install();
							//$status->app_install[] = array('name'=>'easysocial_camp_plg','group'=>'easysocial_camp_plg', 'result'=>$plg_install,'status'=>'1');
							$status->applications[] = array('name'=>$app,'group'=>$folder, 'result'=>$result,'status'=>$published);
						}
					}
				}
			}
		}


		return $status;
	}


	/**
	 * Removes obsolete files and folders
	 *
	 * @param array $removeFilesAndFolders
	 */
	private function _removeObsoleteFilesAndFolders($removeFilesAndFolders)
	{
		// Remove files
		jimport('joomla.filesystem.file');
		if(!empty($removeFilesAndFolders['files'])) foreach($removeFilesAndFolders['files'] as $file) {
			$f = JPATH_ROOT.DS.$file;
			if(!JFile::exists($f)) continue;
			JFile::delete($f);
		}
		// Remove folders
		jimport('joomla.filesystem.file');
		if(!empty($removeFilesAndFolders['folders'])) foreach($removeFilesAndFolders['folders'] as $folder) {
			$f = JPATH_ROOT.DS.$folder;
			if(!file_exists($f)) continue;
				JFolder::delete($f);
		}
	}

	function installSqlFiles($parent)
	{
		$db = JFactory::getDbo();
		// Obviously you may have to change the path and name if your installation SQL file ;)
		if(method_exists($parent, 'extension_root')) {
			$sqlfile = $parent->getPath('extension_root').DS.'admin'.DS.'sql'.DS.'install.sql';
		} else {
			$sqlfile = $parent->getParent()->getPath('extension_root').DS.'sql'.DS.'install.sql';
		}
		// Don't modify below this line
		$buffer = file_get_contents($sqlfile);
		if ($buffer !== false) {
			jimport('joomla.installer.helper');
			$queries = JInstallerHelper::splitSql($buffer);
			if (count($queries) != 0) {
				foreach ($queries as $query)
				{
					$query = trim($query);
					if ($query != '' && $query{0} != '#') {
						$db->setQuery($query);
						if (!$db->execute()) {
							JError::raiseWarning(1, JText::sprintf('JLIB_INSTALLER_ERROR_SQL_ERROR', $db->stderr(true)));
							return false;
						}
					}
				}
			}
		}
		$config=JFactory::getConfig();
		if(JVERSION>=3.0)
			$configdb=$config->get('db');
		else
			$configdb=$config->getValue('config.db');

		//get dbprefix
		if(JVERSION>=3.0)
			$dbprefix=$config->get('dbprefix');
		else
			$dbprefix=$config->getValue('config.dbprefix');


		// Removed tables from 1.5.3 Version

		//install country table(#__tj_country) if it does not exists
		/*$query="SELECT table_name
		FROM information_schema.tables
		WHERE table_schema='".$configdb."'
		AND table_name='".$dbprefix."tj_country'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check){
			//Lets create the table
			$this->runSQL($parent,'country.sql');
		}*/

		//install region table(#__tj_region) if it does not exists


		/*$query="SELECT table_name
		FROM information_schema.tables
		WHERE table_schema='".$configdb."'
		AND table_name='".$dbprefix."tj_region'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check){
			//Lets create the table
			$this->runSQL($parent,'region.sql');
		}*/
		//since version 1.6
		//install region table(#__tj_city) if it does not exists
		/*$query="SELECT table_name
		FROM information_schema.tables
		WHERE table_schema='".$configdb."'
		AND table_name='".$dbprefix."tj_city'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check){
			//Lets create the table
			$this->runSQL($parent,'city.sql');
		}*/

	}



	function runSQL($parent,$sqlfile)
	{
		$db = JFactory::getDbo();
		// Obviously you may have to change the path and name if your installation SQL file ;)
		if(method_exists($parent, 'extension_root')) {
			$sqlfile = $parent->getPath('extension_root').DS.'admin'.DS.'sql'.DS.$sqlfile;
		} else {
			$sqlfile = $parent->getParent()->getPath('extension_root').DS.'sql'.DS.$sqlfile;
		}
		// Don't modify below this line
		$buffer = file_get_contents($sqlfile);
		if ($buffer !== false) {
			jimport('joomla.installer.helper');
			$queries = JInstallerHelper::splitSql($buffer);
			if (count($queries) != 0) {
				foreach ($queries as $query)
				{
					$query = trim($query);
					if ($query != '' && $query{0} != '#') {
						$db->setQuery($query);
						if (!$db->execute()) {
							JError::raiseWarning(1, JText::sprintf('JLIB_INSTALLER_ERROR_SQL_ERROR', $db->stderr(true)));
							return false;
						}
					}
				}
			}
		}
	}//end run sql

	function _installSampleCoreFieldsJTicketing()
	{

		//Check if file is present.
		$db   = JFactory::getDbo();

		// Check if any core ateende fields  exists.
		$query = $db->getQuery(true);
		$query->select('COUNT(aflds.id) AS count');
		$query->from('`#__jticketing_attendee_fields` AS aflds');
		$query->where('aflds.core=1');
		$db->setQuery($query);
		$attendee_fields = $db->loadResult();
		if(empty($attendee_fields))
		{


			// If no core ateende fields, add a sample one.First name,Last name is required
			$queries[] = "INSERT INTO `#__jticketing_attendee_fields` (`eventid`, `placeholder`, `type`, `label`, `name`,`core`,`state`,`required`) VALUES(0, 'First Name','text','First Name','first_name',1,1,1);";
			$queries[] = "INSERT INTO `#__jticketing_attendee_fields` (`eventid`, `placeholder`, `type`, `label`, `name`,`core`,`state`,`required`) VALUES(0, 'Last Name','text','Last Name','last_name',1,1,1);";
			$queries[] = "INSERT INTO `#__jticketing_attendee_fields` (`eventid`, `placeholder`, `type`, `label`, `name`,`core`,`state`,`required`) VALUES(0, 'Phone','text','Phone','phone',1,1,0);";
			$queries[] = "INSERT INTO `#__jticketing_attendee_fields` (`eventid`, `placeholder`, `type`, `label`, `name`,`core`,`state`,`required`) VALUES(0, 'Email','text','Email','email',1,1,0);";
			// Execute sql queries.
			if (count($queries) != 0)
			{
				foreach ($queries as $query)
				{
					$query = trim($query);

					if ($query != '')
					{
						$db->setQuery($query);

						if (!$db->execute())
						{
							JError::raiseWarning(1, JText::sprintf('JLIB_INSTALLER_ERROR_SQL_ERROR', $db->stderr(true)));
							return false;
						}
					}
				}
			}
		}

		return true;


	}


	function _installbasicCategories()
	{
		jimport( 'joomla.filesystem.file' );
		$db   = JFactory::getDbo();
		$user = JFactory::getUser();


		// Check if any categories present for jticketing.
		$query = $db->getQuery(true);
		$query->select('COUNT(cat.id) AS count');
		$query->from('`#__categories` AS cat');
		$search = $db->Quote('com_jticketing');
		$query->where('cat.extension=' . $search);
		$db->setQuery($query);
		$CategoryCount = $db->loadResult();

		// If no category found, add a sample one.
		if (!$CategoryCount)
		{
				$catobj=new stdClass;
				$catobj->title = 'General';
				$catobj->alias = 'General';;
				$catobj->extension="com_jticketing";
				$catobj->path=" General";
				$catobj->parent_id=1;
				$catobj->level=1;

				$paramdata=array();
				$paramdata['category_layout']='';
				$paramdata['image']='';
				$catobj->params=json_encode($paramdata);

				$catobj->created_user_id=$user->id;
				$catobj->language="*";
				//$catobj->description = $category->description;

				$catobj->published = 1;
				$catobj->access = 1;
				if(!$db->insertObject('#__categories',$catobj,'id'))
				{
					echo $db->stderr();
					return false;
				}
			return true;
		}
	}

	function _installbasicCategoriesforVenues()
	{
		jimport( 'joomla.filesystem.file' );
		$db   = JFactory::getDbo();
		$user = JFactory::getUser();


		// Check if any categories present for jticketing.
		$query = $db->getQuery(true);
		$query->select('COUNT(cat.id) AS count');
		$query->from('`#__categories` AS cat');
		$search = $db->Quote('com_jticketing.venues');
		$query->where('cat.extension=' . $search);
		$db->setQuery($query);
		$CategoryCount = $db->loadResult();

		// If no category found, add a sample one.
		if (!$CategoryCount)
		{
				$catobj=new stdClass;
				$catobj->title = 'General';
				$catobj->alias = 'General';;
				$catobj->extension="com_jticketing.venues";
				$catobj->path=" General";
				$catobj->parent_id=1;
				$catobj->level=1;

				$paramdata=array();
				$paramdata['category_layout']='';
				$paramdata['image']='';
				$catobj->params=json_encode($paramdata);

				$catobj->created_user_id=$user->id;
				$catobj->language="*";
				//$catobj->description = $category->description;

				$catobj->published = 1;
				$catobj->access = 1;
				if(!$db->insertObject('#__categories',$catobj,'id'))
				{
					echo $db->stderr();
					return false;
				}
			return true;
		}
	}

	function _installSampleFieldsManagerData()
	{
		// Check if file is present.
		jimport( 'joomla.filesystem.file' );
		$filePath = JPATH_SITE . DS . 'components' . DS . 'com_tjfields' . DS . 'tjfields.php';

		if(!JFile::exists($filePath))
		{
			return false;
		}

		$db   = JFactory::getDbo();
		$user = JFactory::getUser();

		// Check if any eventform fields groups exists.
		$query = $db->getQuery(true);
		$query->select('COUNT(tfg.id) AS count');
		$query->from('`#__tjfields_groups` AS tfg');
		$search = $db->Quote('com_jticketing.event');
		$query->where('tfg.client=' . $search);
		$db->setQuery($query);
		$eventFieldsGroupsCount = $db->loadResult();

		// Check if any ticket fields groups exists.
		$query = $db->getQuery(true);
		$query->select('COUNT(tfg.id) AS count');
		$query->from('`#__tjfields_groups` AS tfg');
		$search = $db->Quote('com_jticketing.ticket');
		$query->where('tfg.client=' . $search);
		$db->setQuery($query);
		$ticketFieldsGroupsCount = $db->loadResult();

		$queries = array();

		// If no eventform fields groups found, add a sample one.
		if (!$eventFieldsGroupsCount)
		{
			$queries[] = "INSERT INTO `#__tjfields_groups` (`ordering`, `state`, `created_by`, `name`, `client`) VALUES(1, 1, ".$user->id.", 'Event - Additional Details', 'com_jticketing.event');";
		}

		// If no ticketform fields groups found, add a sample one.
		if (!$ticketFieldsGroupsCount)
		{
			$queries[] = "INSERT INTO `#__tjfields_groups` (`ordering`, `state`, `created_by`, `name`, `client`) VALUES(2, 1,".$user->id.", 'Ticket - Additional Details', 'com_jticketing.ticket');";
		}

		// Execute sql queries.
		if (count($queries) != 0)
		{
			foreach ($queries as $query)
			{
				$query = trim($query);

				if ($query != '')
				{
					$db->setQuery($query);

					if (!$db->execute())
					{
						JError::raiseWarning(1, JText::sprintf('JLIB_INSTALLER_ERROR_SQL_ERROR', $db->stderr(true)));
						return false;
					}
				}
			}
		}

		return true;
	}

	function fixCouponTable($db,$dbprefix,$config)
	{
		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'state'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_coupon` ADD  `state` tinyint(1) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_queue WHERE `Field` = 'event_id'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_queue` ADD  `event_id` int(11) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_reminder_types WHERE `Field` = 'replytoemail'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_reminder_types` ADD  `replytoemail` varchar(255) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_reminder_types WHERE `Field` = 'reminder_params'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_reminder_types` ADD  `reminder_params` text";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_queue WHERE `Field` = 'user_id'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_queue` ADD  `user_id` int(11) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'ordering'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_coupon` ADD  `ordering` int(11) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'checked_out'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_coupon` ADD  `checked_out` int(11) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'checked_out_time'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_coupon` ADD  `checked_out_time` datetime NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'created_by'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_coupon` ADD  `created_by` int(11) NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'published'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if ($check)
		{
			// Set each ticket type as public
			$query=" UPDATE   `#__jticketing_coupon` SET  `state` =  `published`";
			$db->setQuery($query);
			$db->execute();

			//Remove published table
			$query=" ALTER TABLE `#__jticketing_coupon`  DROP `published`;";
			$db->setQuery($query);
			$db->execute();

		}

		$query="SHOW COLUMNS FROM #__jticketing_coupon WHERE `Field` = 'params'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if ($check)
		{
			$query=" ALTER TABLE  `#__jticketing_coupon` CHANGE  `params`  `coupon_params` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;";
			$db->setQuery($query);
			$db->execute();
		}

	}

	//Since jticketing version 1.5
	function fix_db_on_update()
	{

		$db = JFactory::getDBO();
		$config = JFactory::getConfig();
		if(JVERSION>=3.0)
		$dbprefix=$config->get( 'dbprefix' );
		else
		$dbprefix=$config->getValue( 'config.dbprefix' );

		$xml=JFactory::getXML(JPATH_ADMINISTRATOR.'/components/com_jticketing/jticketing.xml');
		$version=(string)$xml->version;
		$this->version=(float)($version);

		$this->fixCouponTable($db,$dbprefix,$config);
		// Since version 1.7
		$query="SHOW COLUMNS FROM #__jticketing_order_items WHERE `Field` = 'comment'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_order_items` ADD  `comment` text NOT NULL ";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}


		$query="ALTER TABLE `#__jticketing_users` CHANGE `country_code` `country_code` VARCHAR( 250 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
		CHANGE `city` `city` VARCHAR( 250 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
		CHANGE `state_code` `state_code` VARCHAR( 250 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL";
		$db->setQuery($query);
		if ( !$db->execute() ) {
			JError::raiseError( 500, $db->stderr() );
		}



		//since version 1.5
		//check if column - paypal_email exists
		$query="SHOW COLUMNS FROM #__jticketing_integration_xref WHERE `Field` = 'paypal_email' AND `Type` = 'VARCHAR(100)'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_integration_xref` ADD  `paypal_email` VARCHAR( 100 ) NOT NULL  AFTER  `source`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}


		//since version 1.5
		//check if column - userid exists
		$query="SHOW COLUMNS FROM #__jticketing_integration_xref WHERE `Field` = 'userid' AND `Type` = 'INT(11)'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_integration_xref` ADD  `userid` INT(11) NOT NULL  COMMENT 'This is id of event creator from respective tables community_events,jevents_vevent,jticketing_events' AFTER  `checkin` ";
			$db->setQuery($query);
			//$db->loadResult();
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}



		//since version 1.5
		//check if column - parent_order_id exists
		$query="SHOW COLUMNS FROM #__jticketing_order WHERE `Field` = 'parent_order_id' AND `Type` = 'INT(11)'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_order` ADD  `parent_order_id` INT(11) NOT NULL  AFTER  `order_id`";
			$db->setQuery($query);
			//$db->loadResult();
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_order_items WHERE `Field` = 'attendee_id' AND `Type` = 'INT(11)'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_order_items` ADD  `attendee_id` int(11) NOT NULL COMMENT 'id of #__jticketing_attendees table'";
			$db->setQuery($query);
			//$db->loadResult();
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5
		//check if column - payment_status exists
		$query="SHOW COLUMNS FROM #__jticketing_order_items WHERE `Field` = 'payment_status'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_order_items` ADD  `payment_status` varchar(10) NOT NULL";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5
		//check if column - amount_paid exists
		$query="SHOW COLUMNS FROM #__jticketing_order_items WHERE `Field` = 'amount_paid'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_order_items` ADD  `amount_paid` FLOAT(10,2) NOT NULL AFTER `ticketcount`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5
		//check if column - ticket_price exists
		$query="SHOW COLUMNS FROM #__jticketing_order_items WHERE `Field` = 'ticket_price'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_order_items` ADD  `ticket_price` FLOAT(10,2) NOT NULL  AFTER `amount_paid`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}


		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_types WHERE `Field` = 'deposit_fee' AND `Type` = 'float(10,2)'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_types` ADD  `deposit_fee` float(10,2) AFTER  `price`";
			$db->setQuery($query);
			//$db->loadResult();
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//
			//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_order WHERE `Field` = 'ticket_email_sent'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if (!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_order` ADD  `ticket_email_sent` tinyint(4)	AFTER  `coupon_discount_details`";
			$db->setQuery($query);

			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}

			// Set each ticket type as public
			$query=" UPDATE   `#__jticketing_order` SET  `ticket_email_sent`=1 WHERE status='C'";
			$db->setQuery($query);
			$db->execute();

		}


		//

		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_types WHERE `Field` = 'access'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_types` ADD  `access` tinyint(4)	AFTER  `max_limit_ticket`";
			$db->setQuery($query);

			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}

			// Set each ticket type as public
			$query=" UPDATE   `#__jticketing_types` SET  `access`=1 ";
			$db->setQuery($query);
			$db->execute();

		}

		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_types WHERE `Field` = 'unlimited_seats'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_types` ADD  `unlimited_seats` int(11)	AFTER  `max_limit_ticket`";
			$db->setQuery($query);

			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}

			// Update Unlimited Seats column
			$query=" UPDATE   `#__jticketing_types` SET  `unlimited_seats`=1 WHERE `available`<=1 AND `count`<=1";
			$db->setQuery($query);
			$db->execute();

		}

		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_events WHERE `Field` = 'access'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_events` ADD  `access` int(11)	AFTER  `state`";
			$db->setQuery($query);

			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}

			// Set each ticket type as public
			/*$query=" UPDATE   `#__jticketing_events` SET  `access`=1";
			$db->setQuery($query);
			$db->execute();*/

		}

		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_events WHERE `Field` = 'asset_id'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_events` ADD  `asset_id` int(11)	AFTER  `id`";
			$db->setQuery($query);

			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_types WHERE `Field` = 'state'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_types` ADD  `state` tinyint(4)	AFTER  `access`";
			$db->setQuery($query);

			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}

			// Set each ticket type as public
			$query=" UPDATE   `#__jticketing_types` SET  `state`=1 ";
			$db->setQuery($query);
			$db->execute();

		}
		//Insert userid(event creators id) if JTicketing version is less than 1.5
		if((float)$this->version<1.5)
		{
			$query = "SELECT xref.id,xref.eventid,xref.source,xref.userid FROM #__jticketing_integration_xref AS xref";
			$db->setQuery($query);
			$eventdata = $db->loadObjectList();
			if(!empty($eventdata))
			{
				$jticketing_table_exists=$js_table_exists=$jevents_table_exists=0;
				//check if jomsocial table exists
				$query = "SHOW TABLES LIKE '".$dbprefix."community_events';";
				$db->setQuery($query);
				$js_table_exists=$db->loadResult();

				//check if jevents_vevent table exists
				$query = "SHOW TABLES LIKE '".$dbprefix."jevents_vevent';";
				$db->setQuery($query);
				$jevents_table_exists=$db->loadResult();

				//check if jticketing_events table exists
				$query = "SHOW TABLES LIKE '".$dbprefix."jticketing_events';";
				$db->setQuery($query);
				$jticketing_table_exists=$db->loadResult();

				foreach($eventdata AS $event)
				{
					$eventid=$event->eventid;
					$xrefid=$event->id;
					$query='';
					if($event->source=='com_community' and ($js_table_exists))
					{
						$query="SELECT creator FROM #__community_events WHERE id = {$eventid}";
					}
					else if($event->source=='com_jevents' and ($jevents_table_exists))
					{
						$query = "SELECT created_by as creator FROM #__jevents_vevent WHERE detail_id = {$eventid}";

					}
					else if($event->source=='com_jticketing' and ($jticketing_table_exists))
					{
						$query = "SELECT created_by as creator FROM #__jticketing_events WHERE id = {$eventid}";

					}

					if(!$query)
					continue;

					$db->setQuery($query);
					$creator = $db->loadResult();

					$query="SELECT paypalemail FROM #__jticketing_events_xref WHERE eventid = {$xrefid} AND paypalemail<>''";
					$db->setQuery($query);
					$paypalemail = $db->loadResult();


					if($creator)
					{
						$integration = new stdClass;
						$integration->id = $event->id;

						$integration->userid = $creator;

						if($paypalemail)
						{
							$integration->paypal_email = $paypalemail;
						}


						if (!$db->updateObject('#__jticketing_integration_xref', $integration, 'id'))
						{
							//return false;
						}
					}

				}
			}

		}

		//since version 1.5
		//Delete events xref table
		$query = "SHOW TABLES LIKE '".$dbprefix."jticketing_events_xref';";
		$db->setQuery($query);
		$fields = $db->loadResult();
		if($fields)
		{
			$query="DROP TABLE `#__jticketing_events_xref`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5.2
		//Delete events xref table
		$query="SHOW COLUMNS FROM #__jticketing_types WHERE `Field` = 'max_limit_ticket'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{

			$query="ALTER TABLE  `#__jticketing_types` ADD  `max_limit_ticket` INT(11) NOT NULL  AFTER  `eventid`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}


		//since version 1.5.3
		$query="SHOW COLUMNS FROM #__jticketing_ticket_payouts WHERE `Field` = 'transction_id'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if($check)
		{

			$query="ALTER TABLE #__jticketing_ticket_payouts MODIFY transction_id TEXT NOT NULL;";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.5.3

		$query="Select * From #__jticketing_users";
		$db->setQuery($query);
		$billing_datas=$db->loadObjectlist();

		if ($billing_datas)
		{
			$query="SHOW COLUMNS FROM #__tj_country WHERE `Field` = 'country_jtext'";
			$db->setQuery($query);
			$check=$db->loadResult();
			if(!$check)
			{
				echo "<span id='NewVersion' style='padding-top: 5px; color: red; font-weight: bold; padding-left: 5px;'>". JText::_("Please Install TJField Component First and then JTicketing"). $latestversion ."</span>";
				return;

			}




			//***********Back up old tables of jticketing users

			$query = "SHOW TABLES LIKE '".$dbprefix."jticketing_users_backup';";
			$db->setQuery($query);
			$backup_exists=$db->loadResult();

			if(!$backup_exists)
			{



			$db = JFactory::getDBO();
			$query = "CREATE TABLE IF NOT EXISTS  #__jticketing_users_backup LIKE #__jticketing_users;";
			$db->setQuery($query);
			if ($db->execute())
			{


				$query = "INSERT INTO  #__jticketing_users_backup SELECT * FROM #__jticketing_users";
				$db->setQuery($query);
				if ($db->execute())
				{

				}



			//********* End Back up old tables of jticketing users


				foreach($billing_datas as $data )
				{
						if($data->country_code)
						{
							$query="Select id From #__tj_country WHERE country LIKE '".$data->country_code."'";
							$db->setQuery($query);
							$country_code=$db->loadResult();
							if($country_code)
							{
								$country_object = new stdClass;
								$country_object->id = $data->id;
								$country_object->country_code = $country_code;
								if (!$db->updateObject('#__jticketing_users', $country_object, 'id'))
								{
									return false;
								}
							}
						}

						if($data->state_code)
						{
							$query="Select id From #__tj_region WHERE region LIKE '".$data->state_code."'";
							$db->setQuery($query);
							$region_code=$db->loadResult();

							if($region_code)
							{
								$region_object = new stdClass;
								$region_object->id = $data->id;
								$region_object->state_code = $region_code;
								if (!$db->updateObject('#__jticketing_users', $region_object, 'id'))
								{
									return false;
								}
							}
						}
					}
				}
			}
		}

		//since version 1.7.2
		//check if column - attendee_id exists
		$query="SHOW COLUMNS FROM #__jticketing_users WHERE `Field` = 'country_mobile_code'";
		$db->setQuery($query);
		$check=$db->loadResult();

		if(!$check)
		{
			$query=" ALTER TABLE  `#__jticketing_users` ADD  `country_mobile_code` int(11) NOT NULL AFTER  `zipcode`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.8
		//check if column - paypal_email exists
		$query="SHOW COLUMNS FROM #__jticketing_integration_xref WHERE `Field` = 'cron_status'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_integration_xref` ADD  `cron_status` INT( 11 ) NOT NULL  AFTER  `userid`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.8
		//check if column - paypal_email exists
		$query="SHOW COLUMNS FROM #__jticketing_integration_xref WHERE `Field` = 'cron_date'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_integration_xref` ADD  `cron_date` datetime NOT NULL  AFTER  `cron_status`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.8
		//check if column - venue exists
		$query="SHOW COLUMNS FROM #__jticketing_events WHERE `Field` = 'venue'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_events` ADD  `venue` INT(11) NOT NULL  AFTER  `catid`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		//since version 1.8
		//check if column - venue exists
		$query="SHOW COLUMNS FROM #__jticketing_venues WHERE `Field` = 'address'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_venues` ADD  `address` VARCHAR(255) NOT NULL  AFTER  `zipcode`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		// Since version 1.8
		$query="SHOW COLUMNS FROM #__jticketing_events WHERE `Field` = 'online_events'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_events` ADD  `online_events` TINYINT(4) NOT NULL  AFTER  `featured`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}

		// Since version 1.8
		$query="SHOW COLUMNS FROM #__jticketing_events WHERE `Field` = 'jt_params'";
		$db->setQuery($query);
		$check=$db->loadResult();
		if(!$check)
		{
			$query="ALTER TABLE  `#__jticketing_events` ADD  `jt_params` TEXT NOT NULL  AFTER  `checked_out_time`";
			$db->setQuery($query);
			if ( !$db->execute() ) {
				JError::raiseError( 500, $db->stderr() );
			}
		}


	}



	function renameTable($table, $newTable)
	{
		$db = JFactory::getDBO();
		$query = "RENAME TABLE `" . $table . "` TO `" . $newTable  . "`";
		$db->setQuery($query);
		if ($db->execute())
		{
			return true;
		}
		return false;
	}
	/**
	 * Renders the post-installation message
	 */
	private function _renderPostInstallation($status, $parent, $msgBox=array())
	{
		$document = JFactory::getDocument();

		?>

		<?php $rows = 1;?>

		<link rel="stylesheet" type="text/css" href=""/>
		<div class="techjoomla-bootstrap" >
		<table class="table-condensed table">
			<thead>
				<tr>
					<th class="title" colspan="2">Extension</th>
					<th width="30%">Status</th>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan="3"></td>
				</tr>
			</tfoot>
			<tbody>
				<tr class="row0">
					<td class="key" colspan="2">JTicketing component</td>
					<td><strong style="color: green">Installed</strong></td>
				</tr>




				<?php if (count($status->modules)) : ?>
				<tr>
					<th>Module</th>
					<th>Client</th>
					<th></th>
				</tr>
				<?php foreach ($status->modules as $module) : ?>
				<tr class="row<?php echo ($rows++ % 2); ?>">
					<td class="key"><?php echo $module['name']; ?></td>
					<td class="key"><?php echo ucfirst($module['client']); ?></td>
					<td><strong style="color: <?php echo ($module['result'])? "green" : "red"?>"><?php echo ($module['result'])?'Installed':'Not installed'; ?></strong></td>
				</tr>
				<?php endforeach;?>
				<?php endif;?>
				<?php if (count($status->plugins)) : ?>
				<tr>
					<th>Plugin</th>
					<th>Group</th>
					<th></th>
				</tr>
				<?php foreach ($status->plugins as $plugin) : ?>
				<tr class="row<?php echo ($rows++ % 2); ?>">
					<td class="key"><?php echo ucfirst($plugin['name']); ?></td>
					<td class="key"><?php echo ucfirst($plugin['group']); ?></td>
					<td><strong style="color: <?php echo ($plugin['result'])? "green" : "red"?>"><?php echo ($plugin['result'])?'Installed':'Not installed'; ?></strong></td>
				</tr>
				<?php endforeach; ?>
				<?php endif; ?>
				<?php if (!empty($status->libraries) and count($status->libraries)) : ?>
				<tr class="row1">
					<th>Library</th>
					<th></th>
					<th></th>
					</tr>
				<?php foreach ($status->libraries as $libraries) : ?>
				<tr class="row2 <?php //echo ($rows++ % 2); ?>">
					<td class="key"><?php echo ucfirst($libraries['name']); ?></td>
					<td class="key"></td>
					<td><strong style="color: <?php echo ($libraries['result'])? "green" : "red"?>"><?php echo ($libraries['result'])?'Installed':'Not installed'; ?></strong>
					<?php
						if(!empty($libraries['result'])) // if installed then only show msg
						{
						echo $mstat=($libraries['status']? "<span class=\"label label-success\">Enabled</span>" : "<span class=\"label label-important\">Disabled</span>");

						}
					?>

					</td>
				</tr>
				<?php endforeach;?>
				<?php endif;?>

				<?php if (!empty($status->applications) and count($status->applications)) :
				 ?>
				<tr class="row1">
					<th>EasySocial App</th>
					<th></th>
					<th></th>
					</tr>
				<?php foreach ($status->applications as $app_install) : ?>
				<tr class="row2 <?php  ?>">
					<td class="key"><?php echo ucfirst($app_install['name']); ?></td>
					<td class="key"></td>
					<td><strong style="color: <?php echo ($app_install['result'])? "green" : "red"?>"><?php echo ($app_install['result'])?'Installed':'Not installed'; ?></strong>
					<?php
						if(!empty($app_install['result'])) // if installed then only show msg
						{
							echo $mstat=($app_install['status']? "<span class=\"label label-success\">Enabled</span>" : "<span class=\"label label-important\">Disabled</span>");

						}
					?>

					</td>
				</tr>
				<?php endforeach;?>
				<?php endif;?>

			</tbody>
		</table>
	</div>
		<?php
	}

	function removeShortDescription()
	{
		// Short description removed from current version
		$db    = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select($db->quoteName(array('id', 'short_description', 'long_description')));
		$query->from($db->quoteName('#__jticketing_events'));

		$db->setQuery($query);
		$short_description = $db->loadObjectList();

		if (!empty($short_description))
		{
			foreach ($short_description as $desc)
			{
				$obj = new stdclass;
				$obj->id = $desc->id;
				$obj->long_description = $desc->short_description . ' ' . $desc->long_description;
				$obj->short_description = '';

				if (!$db->updateObject('#__jticketing_events', $obj, 'id'))
				{
					return false;
				}
			}
		}
	}
}
