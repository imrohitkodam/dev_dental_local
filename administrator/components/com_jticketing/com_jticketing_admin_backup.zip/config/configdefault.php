<?php
/**
 * @package	Jticketing
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
	
// no direct access
	defined('_JEXEC') or die('Restricted access'); 
	
$jticketing_config=array(
'integration' => '1',
'show_js_toolbar' => '1',
'show_paid_option' => '1',
'gateways' => array('0' => 'paypal'),
'siteadmin_comm_per' => '10',
'currency' => 'USD',
'private_key_cronjob' => 'az197',
'min_val_masspay' => '100',
'mail_to' => array('0' => '0','1' => '1','2' => '2'),
'eventowner_buy' => '1',
'affect_js_native_seats'=>'1',
'apiuser' => '',
'apipass' => '',
'apisign' => '87',
'sandbox' => '0',
'apiv' => '',		
'article' => '0',
'tnc' => '100',
'integration'=>2
); 


