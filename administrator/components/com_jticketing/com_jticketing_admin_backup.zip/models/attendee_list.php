<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die(';)');
jimport('joomla.application.component.model');
jimport('joomla.database.table.user');

/**
 * Class for Jticketing Attendee List Model
 *
 * @package  JTicketing
 * @since    1.5
 */
class JticketingModelattendee_List extends JModelLegacy
{
	/**
	 * Constructor
	 *
	 * @since   1.0
	 */
	public function __construct()
	{
		parent::__construct();
		global $mainframe, $option;
		$mainframe = JFactory::getApplication();
		$input     = JFactory::getApplication()->input;
		$option    = $input->get('option');

		// Get pagination request variables
		$limit      = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $input->get('limitstart', '0', 'INT');

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
	}

	/**
	 * Method to get data
	 *
	 * @param   array  $uselimit  use limit or not
	 *
	 * @return  void
	 *
	 * @since   3.1.2
	 */
	public function getData($uselimit = 1)
	{
		if (empty($this->_data))
		{
			$query       = $this->_buildQuery();

			if ($uselimit == 1)
			{
				$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
			else
			{
				$this->_data = $this->_getList($query);
			}
		}

		return $this->_data;
	}

	/**
	 * Method to build query
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function _buildQuery()
	{
		$where                = $this->_buildContentWhere();
		$jticketingmainhelper = new jticketingmainhelper;
		$query                = $jticketingmainhelper->getAttendeesData();

		if ($where)
		{
			$query .= $where;
		}

		$query .= " GROUP BY order_items_id";

		// FOR ORDER
		global $mainframe, $option;
		$mainframe        = JFactory::getApplication();
		$db               = JFactory::getDBO();
		$filter_order     = '';
		$filter_order_Dir = '';
		$qry1             = '';
		$filter_order     = $mainframe->getUserStateFromRequest($option . 'filter_order', 'filter_order', 'title', 'cmd');
		$filter_order_Dir = $mainframe->getUserStateFromRequest($option . 'filter_order_Dir', 'filter_order_Dir', 'desc', 'word');

		if ($filter_order)
		{
			$qry1 = "SHOW COLUMNS FROM #__jticketing_order";

			if ($qry1)
			{
				$db->setQuery($qry1);
				$exists1 = $db->loadobjectlist();

				foreach ($exists1 as $key1 => $value1)
				{
					$allowed_fields[] = $value1->Field;
				}

				if (in_array($filter_order, $allowed_fields))
				{
					$query .= " ORDER BY ordertbl.$filter_order $filter_order_Dir";
				}
			}
		}

		return $query;
	}

	/**
	 * Checkin/undo checkin for event
	 *
	 * @param   ARRAY  $items      array of items
	 * @param   int    $state      publish/unpublish
	 * @param   ARRAY  $trackData  array of online event tracking data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function setItemState_checkin($items, $state, $trackData = '')
	{
		$db = JFactory::getDBO();

		if (is_array($items))
		{
			foreach ($items as $id)
			{
				$query = "SELECT ticketid,checkin FROM #__jticketing_checkindetails  WHERE  ticketid=" . $id;
				$db->setQuery($query);
				$checkin_data = $db->loadObject();
				$ticketid     = $checkin_data->ticketid;
				$query        = "SELECT a.status,a.id,a.name,a.email,a.event_details_id,b.attendee_id,
								a.user_id,b.attendee_id FROM #__jticketing_order AS a,#__jticketing_order_items AS b
								WHERE a.id=b.order_id AND  b.id=$id";
				$db->setQuery($query);
				$result = $db->loadObject();

				if ($result->status != 'C')
				{
					continue;
				}

				$restype                 = new StdClass;
				$restype->ticketid       = $id;
				$restype->checkintime    = date('Y-m-d H:i:s');
				$restype->checkin        = $state;
				$restype->eventid        = $result->event_details_id;
				$restype->attendee_id    = $result->user_id;
				$restype->attendee_name  = $result->name;
				$restype->attendee_email = $result->email;

				if (!empty($checkin_data))
				{
					if (!$db->updateObject('#__jticketing_checkindetails', $restype, 'ticketid'))
					{
					}
				}
				else
				{
					if (!$db->insertObject('#__jticketing_checkindetails', $restype, 'ticketid'))
					{
					}
				}

				// Now UPDATE INTEGRATIONXREF TABLE FOR CHECKIN COUNT
				if ($result->event_details_id)
				{
					if ($state == 1)
					{
						$query = "UPDATE #__jticketing_integration_xref SET checkin=checkin+1 WHERE  id=" . $result->event_details_id;
					}
					else
					{
						$query = "UPDATE #__jticketing_integration_xref SET checkin=checkin-1 WHERE checkin>0 AND id=" . $result->event_details_id;
					}

					$db->setQuery($query);
					$db->execute();
				}

				if ($state == 1)
				{
					$com_params          = JComponentHelper::getParams('com_jticketing');
					$socialintegration   = $com_params->get('integrate_with', 'none');
					$streamCheckinTicket = $com_params->get('streamCheckinTicket', 0);

					if (isset($result->user_id))
					{
						$actor_id = $result->user_id;
					}
					else
					{
						$actor_id = $user->id;
					}

					$jticketingmainhelper = new jticketingmainhelper;
					$jteventHelper        = new jteventHelper;

					if ($socialintegration != 'none' and !empty($result->user_id))
					{
						// Add in activity.
						if ($streamCheckinTicket == 1)
						{
							$libclass              = $jteventHelper->getJticketSocialLibObj();
							$action                = 'streamCheckinTicket';
							$orderinfo             = $jticketingmainhelper->getorderinfo($result->id);
							$eventLink             = '<a class="" href="' . $orderinfo['eventinfo']->event_url . '">' . $orderinfo['eventinfo']->summary . '</a>';
							$collect_attendee_info = $com_params->get('collect_attendee_info_checkout', '0');

							if ($result->attendee_id and $collect_attendee_info)
							{
								$field_array = array(
									'first_name',
									'last_name'
								);

								// Get Attendee Details
								$attendee_details = $jticketingmainhelper->getAttendees_details($result->attendee_id, $field_array);

								if (isset($attendee_details['first_name']))
								{
									$buyername = implode(" ", $attendee_details);
								}
								else
								{
									$db = JFactory::getDBO();

									// If collect attendee info is set  to no in backend then take first and last name from billing info.
									if ($result->id)
									{
										$query = "SELECT firstname,lastname FROM #__jticketing_users WHERE order_id=" . $result->id;
										$db->setQuery($query);
										$attname   = $db->loadObject();
										$buyername = $attname->firstname . ' ' . $attname->lastname;
									}
								}

								$originalMsg = JText::sprintf('COM_JTICKETING_CHECKIN_SUCCESS_ACT_NAME', $buyername, $eventLink);
							}
							else
							{
								$originalMsg = JText::sprintf('COM_JTICKETING_CHECKIN_SUCCESS_ACT', $eventLink);
							}

							$libclass->pushActivity($actor_id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
						}
					}
				}

				$this->onAfterEventAttendance($result, $state, $trackData);
			}
		}

		return 1;
	}

	/**
	 * Method to build where content
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function _buildContentWhere()
	{
		global $mainframe, $option;
		$jticketingmainhelper     = new jticketingmainhelper;
		$integration              = $jticketingmainhelper->getIntegration();
		$input                    = JFactory::getApplication()->input;
		$eventid                  = '';
		$mainframe                = JFactory::getApplication();
		$option                   = $input->get('option');
		$event_id                 = $input->get('eventid', '', 'INT');
		$search = $mainframe->getUserStateFromRequest($option . 'filter.search', 'filter_search');
		$search_event_list = $mainframe->getUserStateFromRequest($option . 'search_event_list', 'search_event_list', $event_id, 'string');
		$search_event             = $search_event_list;
		$search_paymentStatuslist = $mainframe->getUserStateFromRequest($option . 'search_paymentStatuslist', 'search_paymentStatuslist', '', 'string');

		if (!empty($search_event))
		{
			$eventid = JString::strtolower($search_event);
		}

		$where = "";

		if ($eventid)
		{
			$intxrefidevid = $jticketingmainhelper->getEventrefid($eventid);

			if ($intxrefidevid)
			{
				$where .= "  AND ordertbl.event_details_id = {$intxrefidevid}  ";
			}
		}

		if ($search_paymentStatuslist)
		{
			$where .= "  AND ordertbl.status LIKE '" . $search_paymentStatuslist . "'";
		}

		$search = trim($search);

		if ($search)
		{
			$where .= "  AND (ordertbl.name LIKE '%" . $search . "%' OR ordertbl.email LIKE '%" . $search . "%')";
		}

		if ($where)
		{
			return $where;
		}
		else
		{
			return '';
		}
	}

	/**
	 * Method to get total records
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTotal()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_total))
		{
			$query        = $this->_buildQuery();
			$this->_total = $this->_getListCount($query);
		}

		return $this->_total;
	}

	/**
	 * Method to get pagination
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getPagination()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_pagination;
	}

	/**
	 * Method to get eventname
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventName()
	{
		$input                = JFactory::getApplication()->input;
		$mainframe            = JFactory::getApplication();
		$option               = $input->get('option');
		$event_id             = $input->get('event_list', '', 'INT');
		$jticketingmainhelper = new jticketingmainhelper;
		$query                = $jticketingmainhelper->getEventName($eventid);
		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Method to get
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventid()
	{
		$jticketingmainhelper = new jticketingmainhelper;
		$query                = $jticketingmainhelper->getSalesDataAdmin('', '', $where);
	}

	/**
	 * Method to get
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function Eventdetails()
	{
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');
		$eventid   = $input->get('event', '', 'INT');
		$query     = "SELECT title FROM #__community_events
			  WHERE id = {$eventid}";
		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Get customer note for CSV and other
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getCustomerNote()
	{
		$input       = JFactory::getApplication()->input;
		$attendee_id = $input->get('attendee_id', '', 'INT');

		if (!$attendee_id)
		{
			return false;
		}

		$query = "SELECT o.customer_note
		FROM #__jticketing_order as o
		LEFT JOIN #__jticketing_order_items as oi ON oi.order_id = o.id
		WHERE oi.attendee_id=" . $attendee_id;
		$this->_db->setQuery($query);

		return $this->_db->loadResult();
	}

	/**
	 * Email to selected attendees or Adds antries to jticketing queue which will be used later
	 *
	 * @param   ARRAY   $cid             array of emails
	 * @param   string  $subject         subject of email
	 * @param   string  $message         message of email
	 * @param   string  $attachmentPath  Attachment path
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function emailtoSelected($cid, $subject, $message, $attachmentPath = '')
	{
		$db = JFactory::getDBO();
		$jticketingmainhelper = new jticketingmainhelper;
		$path                 = JPATH_ROOT . '/components/com_jticketing/models/orders.php';
		$com_params           = JComponentHelper::getParams('com_jticketing');
		$replytoemail         = $com_params->get('reply_to');
		$where       = '';
		$app       	= JFactory::getApplication();
		$mailfrom  	= $app->getCfg('mailfrom');
		$fromname  	= $app->getCfg('fromname');
		$sitename  	= $app->getCfg('sitename');
		$mainframe 	= JFactory::getApplication();

		if (isset($replytoemail))
		{
			$replytoemail = explode(",", $replytoemail);
		}

		if (!class_exists('JticketingModelorders'))
		{
			JLoader::register('JticketingModelorders', $path);
			JLoader::load('JticketingModelorders');
		}

		$JticketingModelorders = new JticketingModelorders;

		if (is_array($cid))
		{
			foreach ($cid AS $email)
			{
				// If order is deleted dont send reminder
				if (!$email)
				{
					continue;
				}

				/*
				$obj = new StdClass;
				$obj->sent = 0;
				$obj->reminder_type = 'manual_email';
				$obj->date_to_sent = date("Y-m-d H:i:s");
				$obj->subject = $subject;
				$obj->content = $message;
				$obj->email = $email;
				$obj->order_id = $order_id;
				$JticketingModelorders->addtoQueue($obj);
				$result = $jticketingmainhelper->jtsendmail($email, $subject,
				$message, $bcc_string = '', $singlemail = 1, $attachmentPath, "", "", $mode = 1);
				*/

				$result = $jticketingmainhelper->jtsendMail($mailfrom, $fromname, $email, $subject, $message, $html = 1, '', '', '', $replytoemail);
			}
		}
	}

	/**
	 * Email to selected attendees or Adds antries to jticketing queue which will be used later
	 *
	 * @param   ARRAY  $order_items  order_items
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getAttendeeEmail($order_items)
	{
		$db                       = JFactory::getDBO();
		$email_array = array();

		foreach ($order_items AS $order_item_id)
		{
			$query = "SELECT order_id from #__jticketing_order_items where id=" . $order_item_id;
			$db->setQuery($query);
			$order_id = $db->loadResult($query);

			if (!$order_id)
			{
				continue;
			}

			$query = "SELECT email from #__jticketing_order where  id=" . $order_id;
			$db->setQuery($query);
			$email = $db->loadResult($query);

			if ($email)
			{
				$email_array[] = $email;
			}
		}

		return array_unique($email_array);
	}

	/**
	 * Method to getEvents forpurchase
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventsforpurchase()
	{
		$path = JPATH_ROOT . '/components/com_jticketing/helpers/main.php';

		if (!class_exists('jticketingmainhelper'))
		{
			JLoader::register('jticketingmainhelper', $path);
			JLoader::load('jticketingmainhelper');
		}

		$jticketingmainhelper = new jticketingmainhelper;
		$jinput        = JFactory::getApplication()->input;
		$catId         = $jinput->get('category_id', '', 'integer');
		$location      = $jinput->post->get('location', '', 'string');
		$buyer_id      = $jinput->post->get('buyer_id', '', 'INT');

		if (!empty($catId))
		{
			$select_options = "";
			$db                       = JFactory::getDBO();
			$query = $db->getQuery(true);
			$query->select('te.id AS eventId, te.title , te.startdate');
			$query->from('`#__jticketing_events` AS te');
			$query->where('te.catid = ' . $db->Quote($catId));
			$query->where('te.state = 1');

			if ($location)
			{
				$location = $db->Quote('%' . $db->escape($location, true) . '%');
				$query->where('( te.location LIKE ' . $location . ' )');
			}

			$query->group('te.id');
			$db->setQuery($query);
			$eventList = $db->loadObjectList();
			$listv = '';
			$date_format = JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_AMPM');
			$i = 0;
			$result = array();

			foreach ($eventList as $value)
			{
				if ($value)
				{
					$sel = '';
					$showEvent = 0;
					$showEvent = $jticketingmainhelper->showbuybutton($value->eventId);

					if ($showEvent)
					{
							$result[$i]['eventid'] = $value->eventId;
							$result[$i]['title'] = $value->title . ' (' . JHtml::date($value->startdate, $date_format, false) . ') ';
							$i++;
					}
				}
			}

			if (!empty($result))
			{
				return $result;
			}
		}
	}

	/**
	 * Method to change ticket assignment
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function changeTicketAssignment()
	{
		$jinput        = JFactory::getApplication()->input;
		$search_event_assignee         = $jinput->get('search_event_assignee', '', 'integer');
		$search_ticket_assignee         = $jinput->get('search_ticket_assignee', '', 'integer');
		$order_items_id   = $jinput->get('order_items_id', '', 'integer');
		$order_id         = $jinput->get('order_id', '', 'integer');

		if (!empty($search_event_assignee) and !empty($search_ticket_assignee) and !empty($order_items_id))
		{
			if (!empty($order_id))
			{
				$this->changeOrderticket($search_event_assignee, $search_ticket_assignee, $order_items_id, $order_id);
			}
		}
	}

	/**
	 * Method to change ticket assignment
	 *
	 * @param   array  $search_event_assignee   event id
	 * @param   array  $search_ticket_assignee  search_ticket_assignee
	 * @param   array  $order_items_id          order_items_id
	 * @param   array  $order_id                order_id
	 *
	 * @return  void
	 *
	 * @since   3.1.2
	 */
	public function changeOrderticket($search_event_assignee,$search_ticket_assignee, $order_items_id, $order_id)
	{
		$jticketingmainhelper = new jticketingmainhelper;
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Get integration xref id from eventid
		$intxrefidevid = $jticketingmainhelper->getEventrefid($search_event_assignee);
		$query = "SELECT o.evento.fee,o.amount,o.customer_note,o.processor,o.order_id
				FROM #__jticketing_order  as o
				where o.id=" . $order_id;
		$db->setQuery($query);
		$orderdata = $db->loadObject($query);

		// Change Integration xref in main order
		$order               = $db->loadObjectlist();
		$res                 = new stdClass;
		$res->id             = $order_id;
		$res->mdate          = date("Y-m-d H:i:s");
		$res->extra          = $orderdata->extra;

		if (!$db->updateObject('#__jticketing_order', $res, 'id'))
		{
			return false;
		}
	}

	/**
	 * Method to get ticket types
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTicketTypes()
	{
		$jticketingmainhelper = new jticketingmainhelper;
		$jinput        = JFactory::getApplication()->input;
		$eventid         = $jinput->get('eventid', '', 'integer');
		jimport('joomla.utilities.arrayhelper');
		$result_arr = array();

		if ($eventid)
		{
			$results = $jticketingmainhelper->getTicketTypes($eventid);

			foreach ($results AS $result)
			{
				$result_arr[] = JArrayHelper::fromObject($result, true);
			}
		}

		return $result_arr;
	}

	/**
	 * Method to import CSV.
	 *
	 * @param   array  $data  event id
	 *
	 * @return  void
	 *
	 * @since   3.1.2
	 */
	public function csvImport($data)
	{
		require_once JPATH_SITE . '/components/com_jticketing/controllers/orders.php';
		$JticketingControllerorders = new JticketingControllerorders;

		if (!empty($data['ticket_types']))
		{
			$orders  = $JticketingControllerorders->bookTicket("", $data['userid'], $data['eventid'], $data['ticket_types']);
		}
		else
		{
			$orders  = $JticketingControllerorders->bookTicket("", $data['userid'], $data['eventid']);
		}

		return 1;

		/*if (! $eventid)
		{
			$JticketingControllerorders = new JticketingControllerorders;
			$orders  = $JticketingControllerorders->bookTicket($data['userid'], "", $data['eventid']);

			return 1;
		}
		else
		{
			return 0;
		}*/
	}

	/**
	 * Method to cancel ticket
	 *
	 * @param   INT  $order_id  order ID for event
	 *
	 * @return  void
	 *
	 * @since   3.1.2
	 */
	public function cancelTicket($order_id='')
	{
		$jinput = JFactory::getApplication()->input;

		if (!$order_id)
		{
			$order_id = $jinput->post->get('order_id', 'null', 'INT');
		}

		$db = JFactory::getDbo();

		if ($order_id)
		{
			$query = "DELETE FROM #__jticketing_queue WHERE order_id={$order_id}";
			$db->setQuery($query);
			$db->query();

			$query = "SELECT id from #__jticketing_order_items WHERE order_id={$order_id}";
			$db->setQuery($query);
			$order_items    = $db->loadObjectlist();

			if ($order_items)
			{
				foreach ($order_items AS $oitems)
				{
					// Delete From Checkin Details Table
					$query = "DELETE FROM #__jticketing_checkindetails	WHERE ticketid=" . $oitems->id;
					$db->setQuery($query);
					$db->execute();
				}
			}
		}

		if ($order_id && $status)
		{
			require_once JPATH_ADMINISTRATOR . '/components/com_jticketing/controllers/orders.php';
			$JticketingControllerorders = new JticketingControllerorders;
			$JticketingControllerorders->save();
		}
	}

	/**
	 * This function used to return formated event data
	 *
	 * @param   ARRAY  $result     array of user order details
	 * @param   int    $state      attendee stata
	 * @param   ARRAY  $trackData  online event tracking data
	 *
	 * @return  on success, return event tracking data
	 *
	 * @since   1.0
	 */
	public function onAfterEventAttendance($result, $state, $trackData = '')
	{
		if (empty($trackData))
		{
			$trackData = array();
			require_once JPATH_SITE . '/components/com_jticketing/helpers/main.php';
			$jticketingMainHelper = new Jticketingmainhelper;
			$eventDetails = $jticketingMainHelper->getAllEventDetails($result->event_details_id);
			$trackData['user_id'] = $result->user_id;
			$trackData['event_id'] = $result->event_details_id;
			$trackData['completed'] = $result->status == 'C' ? 1 : 0;
			$trackData['state'] = $state;
			$trackData['spent_time'] = strtotime($eventDetails->enddate) - strtotime($eventDetails->startdate);
		}

		JPluginHelper::importPlugin('tjevent');
		$dispatcher = JDispatcher::getInstance();
		$result = $dispatcher->trigger('on_AttendanceEvent', array($trackData));

		return $trackData;
	}
}
