<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');
jimport('joomla.database.table.user');

/**
 * Model for buy for order
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingModelorders extends JModelLegacy
{
	/**
	 * Constructor
	 *
	 * @since   1.0
	 */
	public function __construct()
	{
		parent::__construct();
		global $mainframe, $option;
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');

		// Load the filter state.
		$search = $mainframe->getUserStateFromRequest($this->option . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		// Get pagination request variables
		$limit      = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $input->get('limitstart', '0', 'INT');

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->jticketingmainhelper = new jticketingmainhelper;
	}

	/**
	 * Method to get data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getData()
	{
		if (empty($this->_data))
		{
			$query       = $this->_buildQuery();
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_data;
	}

	/**
	 * Method to build query
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function _buildQuery()
	{
		$where = $this->_buildContentWhere();
		$query = $this->jticketingmainhelper->getOrderData($where);

		// For ordering
		global $mainframe, $option;
		$mainframe        = JFactory::getApplication();
		$db               = JFactory::getDBO();
		$filter_order     = '';
		$filter_order_Dir = '';
		$qry1             = '';

		// Filter by search in id
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'o.id:') === 0)
			{
				$query .= 'AND o.order_id = ' . (int) substr($search, 4);
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query .= 'AND ( o.order_id LIKE ' . $search . ' )';
			}
		}

		$filter_order     = $mainframe->getUserStateFromRequest($option . 'filter_order', 'filter_order', 'title', 'cmd');
		$filter_order_Dir = $mainframe->getUserStateFromRequest($option . 'filter_order_Dir', 'filter_order_Dir', 'desc', 'word');

		if ($filter_order)
		{
			$qry1 = "SHOW COLUMNS FROM #__jticketing_order";

			if ($qry1)
			{
				$db->setQuery($qry1);
				$exists1 = $db->loadobjectlist();

				foreach ($exists1 as $key1 => $value1)
				{
					$allowed_fields[] = $value1->Field;
				}

				if (in_array($filter_order, $allowed_fields))
				{
					$query .= " ORDER BY o.$filter_order $filter_order_Dir";
				}
			}
		}

		return $query;
	}

	/**
	 * Method to build where content
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function _buildContentWhere()
	{
		global $mainframe, $option;
		$mainframe    = JFactory::getApplication();
		$input        = JFactory::getApplication()->input;
		$mainframe    = JFactory::getApplication();
		$option       = $input->get('option');
		$eventid      = $input->get('event', '', 'INT');
		$search_event = $mainframe->getUserStateFromRequest($option . 'search_event', 'search_event', '', 'string');

		if (empty($search_event))
		{
			$search_event = $eventid;
		}

		$search_paymentStatus = $mainframe->getUserStateFromRequest($option . 'search_paymentStatus', 'search_paymentStatus', '', 'string');
		$where                = "";

		if ($search_event != 0)
		{
			$eventid       = JString::strtolower($search_event);
			$intxrefidevid = $this->jticketingmainhelper->getEventrefid($eventid);

			if ($intxrefidevid)
			{
				$where[] = "  	event_details_id={$intxrefidevid}";
			}
		}

		if ($search_paymentStatus)
		{
			$paymentStatus = JString::strtoupper($search_paymentStatus);
			$where[]       = "	 	status LIKE '{$paymentStatus}'";
		}

		$integration = $this->jticketingmainhelper->getIntegration();

		if ($integration == 1)
		{
			$source = 'com_community';
		}
		elseif ($integration == 2)
		{
			$source = 'com_jticketing';
		}
		elseif ($integration == 3)
		{
			$source = 'com_jevents';
		}
		elseif ($integration == 4)
		{
			$source = 'com_easysocial';
		}

		$where[] = "  i.source='" . $source . "'";

		if (!empty($where))
		{
			return $where1 = (count($where) ? ' WHERE ' . implode(' AND ', $where) : '');
		}
		else
		{
			return '';
		}
	}

	/**
	 * Method to get total records
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTotal()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_total))
		{
			$query        = $this->_buildQuery();
			$this->_total = $this->_getListCount($query);
		}

		return $this->_total;
	}

	/**
	 * Method to get pagination
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getPagination()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_pagination;
	}

	/**
	 * Method to get eventname
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventName()
	{
		$input = JFactory::getApplication()->input;

		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');
		$eventid   = $input->get('event', '', 'INT');

		$query = $this->jticketingmainhelper->getEventName($eventid);

		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Method to get event Details
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function Eventdetails()
	{
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');

		$eventid = $input->get('event', '', 'INT');

		$query = "SELECT title FROM #__community_events
			  WHERE id = {$eventid}";
		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Change order status
	 *
	 * @param   object  $post  post data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function store($post)
	{
		$integration = $this->jticketingmainhelper->getIntegration();

		$db                  = JFactory::getDBO();
		$res                 = new stdClass;
		$res->id             = $post->get('order_id');
		$res->mdate          = date("Y-m-d H:i:s");
		$res->transaction_id = md5($post->get('order_id'));
		$res->payee_id       = $post->get('buyer_email');
		$res->status         = trim($post->get('pstatus'));
		$res->processor      = $post->get('processor');

		if (!$db->updateObject('#__jticketing_order', $res, 'id'))
		{
			return false;
		}

		if ($post->get('pstatus') == 'C')
		{
			if ($integration == 1)
			{
				$eventidquery = "SELECT i.id, i.eventid
				FROM #__jticketing_integration_xref AS i
				LEFT JOIN  #__jticketing_order AS o ON o.event_details_id = i.id
				WHERE o.id =" . $post->get('order_id');
				$db->setQuery($eventidquery);
				$eventid = $db->loadObjectlist();
			}

			if ($integration == 1)
			{
				$query = "SELECT type_id,count(ticketcount) as ticketcounts
					FROM #__jticketing_order_items where order_id=" . $post->get('order_id') . " GROUP BY type_id";
			}
			elseif ($integration = 2)
			{
				$query = "SELECT type_id,count(ticketcount) as ticketcounts
					FROM #__jticketing_order_items where order_id=" . $post->get('order_id') . " GROUP BY type_id";
			}

			$db->setQuery($query);
			$orderdetails = $db->loadObjectlist();

			foreach ($orderdetails as $orderdetail)
			{
				$typedata = '';
				$restype  = new stdClass;

				if ($integration == 1)
				{
					$query = "SELECT count
					FROM #__jticketing_types where id=" . $orderdetail->type_id;
				}
				elseif ($integration == 2)
				{
					$query = "SELECT count
					FROM #__jticketing_types where id=" . $orderdetail->type_id;
				}

				$db->setQuery($query);
				$typedata       = $db->loadResult();
				$restype->id    = $orderdetail->type_id;
				$restype->count = $typedata - $orderdetail->ticketcounts;

				if ($integration == 1)
				{
					$db->updateObject('#__community_events', $restype, 'id');
				}
				elseif ($integration == 2)
				{
					$db->updateObject('#__jticketing_types', $restype, 'id');
				}
			}
		}
	}

	/**
	 * Method to delete order
	 *
	 * @param   integer  $orderid  country id
	 *
	 * @return  array state list
	 *
	 * @since   1.0
	 */
	public function delete_order($orderid)
	{
		$db = JFactory::getDBO();
		$id = implode(',', $orderid);

		$integration = $this->jticketingmainhelper->getIntegration();

		for ($i = 0; $i < 2; $i++)
		{
			$data = $this->jticketingmainhelper->getOrder_ticketcount($id, $i);
			$db->setQuery($data);
			$result  = $db->loadobjectlist();
			$confrim = 0;

			foreach ($result as $temp_result)
			{
				// Update the Type ticeket count. When Deleting Confirmed order increase count in types table
				if ($i == 0)
				{
					$query = " Update #__jticketing_types SET count = count+$temp_result->cnt where id=" . $temp_result->type_id;
					$db->setQuery($query);
					$confrim = $db->execute();
				}
			}

			// When Deleting Confirmed order decresing the confromcount in community_events table & deleting the community_events_members confirmed users
			if ($i == 0 && (!empty($result)) && $integration == 1)
			{
				$confrim = $this->jticketingmainhelper->unJoinMembers($id);
			}
		}

		// Delete the order from order table
		$delete_order = "delete from #__jticketing_order where id IN ( $id )";
		$db->setQuery($delete_order);
		$confrim = $db->execute();

		// Delete the order from order table
		$delete_order = "delete from #__jticketing_queue where order_id IN ($id)";
		$db->setQuery($delete_order);
		$confrim = $db->execute();
		$query = "SELECT id from #__jticketing_order_items WHERE order_id IN ( $id )";
		$db->setQuery($query);
		$order_items    = $db->loadObjectlist();

		if ($order_items)
		{
			foreach ($order_items AS $oitems)
			{
				// Delete From Checkin Details Table
				$query = "DELETE FROM #__jticketing_checkindetails	WHERE ticketid=" . $oitems->id;
				$db->setQuery($query);
				$db->execute();
			}
		}

		// Delete the order item
		$delete_order_item = "delete from #__jticketing_order_items where order_id IN ( $id )";
		$db->setQuery($delete_order_item);
		$confrim = $db->execute();

		if ($confrim)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Method to increase ticket count
	 *
	 * @param   integer  $order_id  order_id
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function events_types_count_decrease($order_id)
	{
		$db   = JFactory::getDBO();
		$data = $this->jticketingmainhelper->getOrder_ticketcount($order_id, 0);
		$db->setQuery($data);
		$result  = $db->loadobjectlist();
		$confrim = 0;

		foreach ($result as $temp_result)
		{
			// Update the Type ticeket count
			$query = " Update #__jticketing_types SET count = count-$temp_result->cnt where id=" . $temp_result->type_id;
			$db->setQuery($query);
			$confrim = $db->execute();
		}
	}

	/**
	 * Method to increase ticket count
	 *
	 * @param   integer  $order_id  order_id
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function events_types_count_increase($order_id)
	{
		$db          = JFactory::getDBO();
		$integration = $this->jticketingmainhelper->getIntegration();
		$data        = $this->jticketingmainhelper->getOrder_ticketcount($order_id, 0);
		$db->setQuery($data);
		$result  = $db->loadobjectlist();
		$confrim = 0;

		foreach ($result as $temp_result)
		{
			// Update the Type ticeket count
			$query = " Update #__jticketing_types SET count = count+$temp_result->cnt where id=" . $temp_result->type_id;
			$db->setQuery($query);
			$confrim = $db->execute();
		}

		// If jomsocial unjoin member from jomsocial
		if ($integration == 1)
		{
			$confrim = $this->jticketingmainhelper->unJoinMembers($order_id);
		}
	}

	/**
	 * Method to get order status
	 *
	 * @param   integer  $order_id  order_id
	 *
	 * @return  string  $result  order status
	 *
	 * @since   1.0
	 */
	public function get_order_status($order_id)
	{
		$db    = JFactory::getDBO();
		$query = "SELECT status from #__jticketing_order where id=$order_id";
		$db->setQuery($query);

		return $result = $db->loadResult($query);
	}

	/**
	 * Update order status
	 *
	 * @param   integer  $order_id   order_id for successed
	 * @param   string   $status     step no
	 * @param   string   $sendemail  step no
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function update_order_status($order_id, $status,$sendemail =null)
	{
		$db    = JFactory::getDBO();
		$query = "UPDATE #__jticketing_order SET status='$status' where id=$order_id";
		$db->setQuery($query);
		$db->execute();
		$input   = JFactory::getApplication()->input;
		$post    = $input->post;
		$comment = $post->get('comment', '', 'STRING');

		if ($post->get('order_items_id') and isset($comment))
		{
			$query = "UPDATE #__jticketing_order_items SET comment='$comment' where id=" . $post->get('order_items_id');
			$db->setQuery($query);
			$db->execute();
		}

		// Change sent column ub backend queue
		if ($status != 'C')
		{
			$query = "UPDATE #__jticketing_queue SET sent=4 WHERE order_id=$order_id AND sent IN('0','3')";
			$db->setQuery($query);
			$db->execute();

			$query = "SELECT id from #__jticketing_order_items WHERE order_id={$order_id}";
			$db->setQuery($query);
			$order_items    = $db->loadObjectlist();

			if ($order_items)
			{
				foreach ($order_items AS $oitems)
				{
					// Delete From Checkin Details Table
					$query = "DELETE FROM #__jticketing_checkindetails	WHERE ticketid=" . $oitems->id;
					$db->setQuery($query);
					$db->execute();
				}
			}
		}
		else
		{
			$query = "UPDATE #__jticketing_queue SET sent=0 WHERE order_id=$order_id AND sent=4";
			$db->setQuery($query);
			$db->execute();
		}

		$com_params           = JComponentHelper::getParams('com_jticketing');
		$email_options              = $com_params->get('email_options');

		// Send order status change Email
		if ($email_options)
		{
			if (in_array('order_status_change_email', $email_options))
			{
					$this->sendOrderStatusEmail($order_id, $status);
			}
		}
	}

	/**
	 * Order status Email change
	 *
	 * @param   integer  $order_id  order_id for successed
	 * @param   string   $status    step no
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendOrderStatusEmail($order_id, $status)
	{
		$input                = JFactory::getApplication()->input;
		$post                 = $input->post;
		$ticketid             = $post->get('ticketid', '', 'STRING');
		$jticketingmainhelper = new jticketingmainhelper;
		$statusdet = $jticketingmainhelper->getPaymentStatus($status);
		$com_params           = JComponentHelper::getParams('com_jticketing');
		$mail_to              = $com_params->get('mail_to');
		$orderinfo            = $jticketingmainhelper->getorderinfo($order_id);
		$buyer                = JFactory::getUser();
		$app                  = JFactory::getApplication();
		$mailfrom             = $app->getCfg('mailfrom');
		$fromname             = $app->getCfg('fromname');
		$sitename             = $app->getCfg('sitename');

		// Chk whom to send email
		if (in_array('site_admin', $mail_to))
		{
			$toemail[] = trim($mailfrom);
		}

		if (in_array('event_creator', $mail_to))
		{
			if (!empty($orderinfo['eventinfo']->email))
			{
				$toemail[] = trim($orderinfo['eventinfo']->email);
			}
			elseif (!empty($orderinfo['eventinfo']->creator))
			{
				$toemail[] = trim($orderinfo['eventinfo']->creator);
			}
		}

		if (in_array('event_buyer', $mail_to))
		{
			if (!empty($orderinfo['order_info']['0']->user_email))
			{
				$toemail[] = trim($orderinfo['order_info']['0']->user_email);
			}
		}

		$toemail_bcc = '';
		$dispatcher  = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$resp = $dispatcher->trigger('jt_OnBeforeOrderStatusChangeEmail', array($orderinfo));

		if (!empty($resp['0']))
		{
			$toemail_bcc = $resp['0'];
		}

		$subject = JText::sprintf('COM_JTICKETING_CANCEL_ORDER_STATUS_CHANGE_SUBJECT', $sitename, ucfirst($orderinfo['eventinfo']->title));
		$body    = JText::sprintf('COM_JTICKETING_CANCEL_ORDER_STATUS_CHANGE_MESSAGE', $ticketid, $sitename, ucfirst($orderinfo['eventinfo']->title));
		$body = str_replace("[STATUS]", $statusdet, $body);
		$mailer  = JFactory::getMailer();

		$result  = $mailer->sendMail($mailfrom, $fromname, $toemail, $subject, $body, $mode = 1, $toemail_bcc);
	}
}
