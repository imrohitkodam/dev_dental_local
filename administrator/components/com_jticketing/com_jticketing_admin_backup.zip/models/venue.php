<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Jticketing
 * @author     Techjoomla <kiran_l@techjoomla.com>
 * @copyright  2016 techjoomla
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.modelitem');
jimport('joomla.event.dispatcher');

use Joomla\Utilities\ArrayHelper;
/**
 * Jticketing model.
 *
 * @since  1.6
 */
class JticketingModelVenue extends JModelAdmin
{
	/**
	 * Method to get an object.
	 *
	 * @param   integer  $id  The id of the object to get.
	 *
	 * @return  mixed    Object on success, false on failure.
	 */
	public function getItem($id = null)
	{
		$this->item = parent::getItem($id);

		if (isset($this->item->created_by) )
		{
			$this->item->created_by_name = JFactory::getUser($this->item->created_by)->name;
		}

		if (isset($this->item->modified_by) )
		{
			$this->item->modified_by_name = JFactory::getUser($this->item->modified_by)->name;
		}

		return $this->item;
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   string  $data      An optional array of data for the form to interogate.
	 * @param   string  $loadData  True if the form is to load its own data (default case), false if not.
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Initialise variables.
		$app = JFactory::getApplication();

		// Get the form.
		$form = $this->loadForm('com_jticketing.venue', 'venue', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return    mixed    The data for the form.
	 *
	 * @since    1.6
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jticketing.edit.venue.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	/**
	 * Get an instance of JTable class
	 *
	 * @param   string  $type    Name of the JTable class to get an instance of.
	 * @param   string  $prefix  Prefix for the table class name. Optional.
	 * @param   array   $config  Array of configuration values for the JTable object. Optional.
	 *
	 * @return  JTable|bool JTable if success, false on failure.
	 */
	public function getTable($type = 'Venue', $prefix = 'JticketingTable', $config = array())
	{
		$this->addTablePath(JPATH_ADMINISTRATOR . '/components/com_jticketing/tables');

		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Get the id of an item by alias
	 *
	 * @param   string  $alias  Item alias
	 *
	 * @return  mixed
	 */
	public function getItemIdByAlias($alias)
	{
		$table = $this->getTable();

		$table->load(array('alias' => $alias));

		return $table->id;
	}

	/**
	 * Method to check out an item for editing.
	 *
	 * @param   integer  $id  The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since    1.6
	 */
	public function checkout($id = null)
	{
		// Get the user id.
		$id = (!empty($id)) ? $id : (int) $this->getState('venue.id');

		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Get the current user object.
			$user = JFactory::getUser();

			// Attempt to check the row out.
			if (method_exists($table, 'checkout'))
			{
				if (!$table->checkout($user->get('id'), $id))
				{
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Get the name of a category by id
	 *
	 * @param   int  $id  Category id
	 *
	 * @return  Object|null	Object if success, null in case of failure
	 */
	public function getCategoryName($id)
	{
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query
			->select('title')
			->from('#__categories')
			->where('id = ' . $id);
		$db->setQuery($query);

		return $db->loadObject();
	}

	/**
	 * Publish the element
	 *
	 * @param   int  &$id    Item id
	 * @param   int  $state  Publish state
	 *
	 * @return  boolean
	 */
	public function publish(&$id, $state=1)
	{
		$table = $this->getTable();
		$table->load($id);
		$table->state = $state;

		return $table->store();
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @param   JTable  $plugin_name  TO  ADD
	 *
	 * @return void
	 *
	 * @since    1.6
	 */
	public function get_default_plugin_params($plugin_name)
	{
		$query = "select params from #__extensions where element='" . $plugin_name . "' && folder='tjevents'";

		$this->_db->setQuery($query);
		$plug_params = $this->_db->loadResult();

		if (!$plug_params)
		{
			return false;
		}

		if (preg_match_all('/\[(.*?)\]/', $plug_params, $match))
		{
			foreach ($match[1] as $mat)
			{
				$match       = str_replace(',', '|', $mat);
				$plug_params = str_replace($mat, $match, $plug_params);
			}
		}

		$newlin = explode(",", $plug_params);

		foreach ($newlin as $v)
		{
			$entry = "";

			if (!empty($v))
			{
				$v                            = str_replace('{', '', $v);
				$v                            = str_replace(':', '=', $v);
				$v                            = str_replace('"', '', $v);
				$v                            = str_replace('}', '', $v);
				$v                            = str_replace('[', '', $v);
				$v                            = str_replace(']', '', $v);
				$v                            = str_replace('|', ',', $v);
				$v                            = explode("=", $v);
				$default_plugin_params[$v[0]] = $v[1];
			}
		}

		return $default_plugin_params;
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @param   data  $data  TO  ADD
	 *
	 * @return void
	 *
	 * @since    1.6
	 */
	public function save($data)
	{
		$db    = JFactory::getDBO();
		$plgname = $this->get_default_plugin_params($data['online_provider']);
		$input = JFactory::getApplication()->input;
		$post = $input->post;
		$plgdetails = array();
		$formData = new JRegistry($input->get('jform', '', 'array'));

		foreach ($plgname as $key => $value)
		{
			$plgdetails[$key] = $post->get($key, "", "STRING");
		}

		$data["params"] = json_encode($plgdetails);
		parent::save($data);

		return true;
	}

	/**
	 * Method to Get User Current Location.
	 *
	 * @param   Array  $post  Array of data
	 *
	 * @return Array
	 *
	 * @since   1.0
	 */
	public function getCurrentLocation($post)
	{
		$longitude = $post->get('longitude');
		$latitude  = $post->get('latitude');

		$url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($latitude) . ',' .
		trim($longitude) . '&sensor=false';

		$json = @file_get_contents($url);
		$data = json_decode($json);
		$status = $data->status;

		$location = array();
		$location_log_lat = array();
		$location_log_lat = $data->results[0]->geometry;
		$longitude = $location_log_lat->location->lng;
		$latitude = $location_log_lat->location->lat;

		if ($status == "OK")
		{
			// Get address from json data
			$location['location'] = $data->results[0]->formatted_address;
			$location['latitude'] = $latitude;
			$location['longitude'] = $longitude;
		}
		else
		{
			$location['location'] = '';
			$location['latitude'] = '';
			$location['longitude'] = '';
		}

		return $location;
	}

	/**
	 * To return a Used Venues
	 *
	 * @param   integer  $venueCodes  Venue Codes
	 *
	 * @return  integer on success
	 *
	 * @since  1.6
	 */
	public function usedVenues($venueCodes)
	{
		$venue_code = implode(", ", $venueCodes);

		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select('venue');
		$query->from('`#__jticketing_events`');
		$query->where('`venue` IN (' . $venue_code . ')');

		$db->setQuery($query);
		$used = $db->loadColumn();

		if ($used)
		{
			return $used;
		}
		else
		{
			return false;
		}
	}
}
