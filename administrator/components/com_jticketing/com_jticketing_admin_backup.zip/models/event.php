<?php
/**
 * @version    SVN: <svn_id>
 * @package    JGive
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die;
jimport('joomla.application.component.modeladmin');

require_once JPATH_SITE . "/components/com_tjfields/filterFields.php";
/**
 * jticketingfrontendhelper
 *
 * @since  1.0
 */
class JticketingModelEvent extends JModelAdmin
{
	use TjfieldsFilterField;

	protected $text_prefix = 'COM_JTICKETING';

	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param   string  $type    The table type to instantiate
	 * @param   string  $prefix  A prefix for the table class name. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTable($type = 'Event', $prefix = 'JticketingTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   string  $data      An optional array of data for the form to interogate.
	 * @param   string  $loadData  True if the form is to load its own data (default case), false if not.
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jticketing.event', 'event', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return	mixed	The data for the form.
	 *
	 * @since	1.6
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_jticketing.edit.event.data', array());

		if (empty($data))
		{
			$data = $this->getItem();
		}

		return $data;
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @param   integer  $table  The id of the primary key.
	 *
	 * @return	mixed  object on success, false on failure.
	 *
	 * @since	1.6
	 */
	protected function prepareTable($table)
	{
		jimport('joomla.filter.output');

		if (empty($table->id))
		{
			// Set ordering to the last item if not set
			if (@$table->ordering === '')
			{
				$db = JFactory::getDbo();
				$db->setQuery('SELECT MAX(ordering) FROM #__jticketing_events');
				$max             = $db->loadResult();
				$table->ordering = $max + 1;
			}
		}
	}

	/**
	 * Method to save form
	 *
	 * @param   string  $data              An optional array of data for the form to interogate.
	 * @param   string  $extra_jform_data  True if the form is to load its own data (default case), false if not.
	 * @param   string  $post              post data
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function save($data, $extra_jform_data='', $post='')
	{
		$input = JFactory::getApplication()->input;

		// TRIGGER Before Event Create
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('jt_OnBeforeEventCreate', array($data));
		$jteventHelper = new jteventHelper;
		$com_params    = JComponentHelper::getParams('com_jticketing');
		$id            = (!empty($data['id'])) ? $data['id'] : (int) $this->getState('event.id');
		$state         = (!empty($data['state'])) ? 1 : 0;
		$user          = JFactory::getUser();
		$app           = JFactory::getApplication();
		$created_by    = $data['created_by'];
		$jticketingmainhelper = new jticketingmainhelper;

		// Add booking time as end of the day
		$tempEndDate        = new DateTime($data['booking_end_date']);
		$tempEndDate->setTime(23, 59, 59);
		$data['booking_end_date']       = $tempEndDate->format('Y-m-d H:i:s');

		if ($id)
		{
			// Check the user can edit this item.
			$authorised = $user->authorise('core.edit', 'com_jticketing') || $authorised = $user->authorise('core.edit.own', 'com_jticketing');

			// The user cannot edit the state of the item.
			if ($user->authorise('core.edit.state', 'com_jticketing') !== true && $state == 1)
			{
				$data['state'] = 0;
			}
		}
		else
		{
			// Check the user can create new items in this section.
			$authorised = $user->authorise('core.create', 'com_jticketing');

			// The user cannot edit the state of the item.
			if ($user->authorise('core.edit.state', 'com_jticketing') !== true && $state == 1)
			{
				$data['state'] = 0;
			}

			// For new record, Add created time.
			$data['created'] = date('Y-m-d H:i:s');
		}

		if ($authorised !== true)
		{
			JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		// Store uploaded file path in a temp variable.
		$tempImage = $data['image'];

		// Unset image file index from data array.
		// Added by komal for csv import
		if (!isset($data['isImportCsv']))
		{
			unset($data['image']);
			$data['jt_params']['event_url'] = $post->get('event_url', '', 'STRING');
			$data['jt_params']['event_sco_id'] = $post->get('event_sco_id', '', 'INT');
			$data['jt_params'] = json_encode($data['jt_params']);
		}

		// End by komal

		// Clean Data like date fields convert to database format
		$data = $this->CleanEventData($data);
		$table = $this->getTable();

		// Added by komal for csv import
		if (isset($data['isImportCsv']))
		{
			$paypal_emailx = $post['paypal_email'];
		}
		else
		{
			$paypal_emailx = $post->get('paypal_email', '', 'STRING');
		}

		// End by komal

		if ($table->save($data) === true)
		{
			unset($data['jt_params']);

			// Save event id into integration xref table.
			$obj                      = new stdclass;
			$obj->eventid             = $table->id;
			$obj->source              = 'com_jticketing';
			$obj->userid              = $created_by;
			$obj->paypal_email        = $paypal_emailx;
			$jticketingfrontendhelper = new jticketingfrontendhelper;
			$XrefId                   = $jticketingfrontendhelper->getXreftableID($obj->source, $obj->eventid);
			$db                       = JFactory::getDBO();

			if (!$id)
			{
				if (!$db->insertObject('#__jticketing_integration_xref', $obj, 'id'))
				{
					echo $db->stderr();

					return false;
				}
			}
			else
			{
				$obj->id = $XrefId;

				if (!$db->updateObject('#__jticketing_integration_xref', $obj, 'id'))
				{
					echo $db->stderr();

					return false;
				}
			}

			$XrefId = $obj->id;

			$content_id = $data['id'];

			$extra_field_data = array();
			$extra_field_data['content_id'] = $content_id;
			$extra_field_data['client'] = 'com_jticketing.event';
			$extra_field_data['fieldsvalue'] = $extra_jform_data;

			// Save extra fields data.
			$this->saveExtraFields($extra_field_data, $table->id, $created_by);

			// Save ticket types.
			// $data     added by komal for csv import
			$this->saveTicketTypes($post, $table->id, $data);

			// Save Custom Fields Save Custom Attendee Fields
			$this->collect_attendee_info_checkout = $com_params->get('collect_attendee_info_checkout');

			if ($this->collect_attendee_info_checkout)
			{
				// Added by komal for csv import

				if (isset($data['isImportCsv']))
				{
					$ticket_fields = array('');
				}
				else
				{
					$ticket_fields = $post->get('ticket_field', '', 'ARRAY');
				}

				// End by Komal
				$ticket_obj    = $jteventHelper->saveCustomAttendee_fields($ticket_fields, $table->id, $created_by);
			}

			// Restore the unsetted image file index from data array.
			$data['image'] = $tempImage;

			// Save uploaded image.
			$jticketingMediaHelper = new jticketingMediaHelper;
			$uploadSuccess         = $jticketingMediaHelper->uploadEventImage($table->id);

			if (!$uploadSuccess)
			{
				$app->setUserState('com_jticketing.edit.event.id', $table->id);

				return false;
			}

			// Find event xref id and add entries to reminder queues
			$ev_xref_id               = $jticketingmainhelper->getEventrefid($table->id);

			// Add to activity stream of easysocial jomsocial
			$socialintegration = $com_params->get('integrate_with', 'none');
			$streamAddEvent    = $com_params->get('streamAddEvent', 0);

			if ($socialintegration != 'none')
			{
				$user     = JFactory::getUser();
				$libclass = $jteventHelper->getJticketSocialLibObj();

				// Add in activity.
				if ($streamAddEvent and  $table->id)
				{
					$action      = 'addevent';
					$url = JUri::root() . substr(JRoute::_('index.php?option=com_jticketing&view=event&id=' . $table->id), strlen(JUri::base(true)) + 1);
					$eventLink = '<a class="" href="' . $url . '">' . $data['title'] . '</a>';
					$originalMsg = JText::sprintf('COM_JTICKETING_ACTIVITY_ADD_EVENT', $eventLink);
					$libclass->pushActivity($user->id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
				}
			}

			// TRIGGER After Process Payment
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('system');
			$result = $dispatcher->trigger('jt_OnAfterEventCreate', array($data));
			$task  = $input->get('task');

			if (empty($id) and $task == 'apply')
			{
				return $table->id;
			}
			else
			{
				return $id;
			}
		}
		else
		{
			return false;
		}
	}

	/**
	 * Method to save form
	 *
	 * @param   string  $post     post values
	 * @param   int     $eventid  id of event
	 * @param   array   $data     added by komal for csv import
	 *
	 * @return	void
	 *
	 * @since   1.0
	 */
	public function saveTicketTypes($post, $eventid = '', $data = array())
	{
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$integrationID = $jticketingfrontendhelper->getIntegrationID($eventid, $client = 'com_jticketing');

		if ($eventid)
		{
			$tickettype = $jticketingfrontendhelper->getTicketTypes($integrationID);
			$tickettypesIds     = array();
			$ticket_type_count1 = array();

			foreach ($tickettype as $key => $value)
			{
				$tickettypesIds[$key] = $tickettype[$key]->id;
			}

			// Added by komal for csv import

			if (isset($data['isImportCsv']))
			{
				$ids        = $post['ticket_type_id'];
			}
			else
			{
				$ids        = $post->get('ticket_type_id', '', 'ARRAY');
			}

			// End by komal
			$delete_ids = array_diff($tickettypesIds, $ids);
			$obj         = $jticketingfrontendhelper->deleteTicket($delete_ids);
			$tickettype1 = $jticketingfrontendhelper->getTicketTypes($integrationID);

			foreach ($tickettype1 as $key => $value)
			{
				$ticket_type_count1[] = (int) ($tickettype1[$key]->available - $tickettype1[$key]->count);
			}

			// Added by komal for csv import

			if (isset($data['isImportCsv']))
			{
				$post['ticket_type_count'] = $ticket_type_count1;
			}
			else
			{
				$post->set('ticket_type_count', $ticket_type_count1);
			}

			// End by komal
		}

		$user   = JFactory::getUser();
		$userid = $user->id;

		if ($eventid)
		{
			$editflag = 1;
		}

		if (!$userid)
		{
			$userid = 0;

			return false;
		}

		// Prepare object for insert
		$objtopass = new stdClass;

		if ($eventid)
		{
			// 3rd parameter added by komal for csv import
			$ticket_obj = $jticketingfrontendhelper->createTicketTypeObj($post, $integrationID, $data);
		}
	}

	/**
	 * Method to save attendee fields
	 *
	 * @param   string  $ticket_fields  post values
	 * @param   int     $eventid        id of event
	 * @param   int     $userid         user id
	 *
	 * @return	void
	 *
	 * @since   1.0
	 */
	public function saveCustomAttendee_fields($ticket_fields, $eventid, $userid)
	{
		$this->jticketingfrontendhelper = new jticketingfrontendhelper;
		$fields_selected                = $fields_in_DB = '';
		$attendee_fields                = $this->jticketingfrontendhelper->getAllfields($eventid);

		// Firstly Delete Attendee Fields That are Removed
		foreach ($attendee_fields['attendee_fields'] as $atkey => $atvalue)
		{
			if ($atvalue->id)
			{
				$fields_in_DB[] = $atvalue->id;
			}
		}

		$fields_selected = '';

		foreach ($ticket_fields AS $key => $value)
		{
			if ($value['id'])
			{
				$fields_selected[] = $value['id'];
			}
		}

		if ($fields_in_DB)
		{
			$diff_ids = array_diff($fields_in_DB, $fields_selected);

			if (!empty($diff_ids))
			{
				$this->delete_Ateendee_fields($diff_ids);
			}
		}

		// Get xref id for this event
		$jticketingmainhelper = new jticketingmainhelper;
		$XrefID               = $jticketingmainhelper->getEventrefid($eventid);

		// Now Insert or Update New Fields

		foreach ($ticket_fields AS $tkey => $tvalue)
		{
			$ticket_field_to_insert = new StdClass;

			foreach ($tvalue AS $ntkey => $nvalue)
			{
				$ticket_field_to_insert->$ntkey = $nvalue;
			}

			$ticket_field_to_insert->eventid = $XrefID;
			$ticket_field_to_insert->state   = 1;

			if (!$ticket_field_to_insert->id)
			{
				// Create Unique Name
				$ticket_field_to_insert->name = $this->CreateField_Name($ticket_field_to_insert->label);

				if ($ticket_field_to_insert->label)
				{
					if (!$this->_db->insertObject('#__jticketing_attendee_fields', $ticket_field_to_insert, 'id'))
					{
						echo $this->_db->stderr();

						return false;
					}

					$tickettypeid = $this->_db->insertid();
				}
			}
			else
			{
				$this->_db->updateObject('#__jticketing_attendee_fields', $ticket_field_to_insert, 'id');
			}
		}
	}

	/**
	 * Method to save attendee fields
	 *
	 * @param   string  $string  string name
	 *
	 * @return	void
	 *
	 * @since   1.0
	 */
	public function CreateField_Name($string)
	{
		$string = strtolower($string);

		// Replaces all spaces with hyphens.
		$string = str_replace(' ', '_', $string);

		// Removes special chars.
		return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
	}

	/**
	 * Method to clean event data
	 *
	 * @param   array  $data  The data to validate.
	 *
	 * @return  mixed  Array of filtered data if valid, false otherwise.
	 *
	 * @see     JFormRule
	 * @see     JFilterInput
	 * @since   12.2
	 */
	public function CleanEventData($data)
	{
		$startdate_timestamp = strtotime($data['startdate']);
		$data['startdate']   = date('Y-m-d H:i:s', $startdate_timestamp);
		$enddate_timestamp = strtotime($data['enddate']);
		$data['enddate']   = date('Y-m-d H:i:s', $enddate_timestamp);
		$booking_start_date_timtestamp = strtotime($data['booking_start_date']);
		$data['booking_start_date']    = date('Y-m-d H:i:s', $booking_start_date_timtestamp);
		$booking_end_date_timtestamp = strtotime($data['booking_end_date']);
		$data['booking_end_date']    = date('Y-m-d H:i:s', $booking_end_date_timtestamp);

		return $data;
	}

	/**
	 * Method to get book venue
	 *
	 * @param   array  $array_venue  An array to get the booked values
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getAvailableVenue($array_venue)
	{
		$db = JFactory::getDbo();
		$eventInfo = $this->getItem($array_venue['eventid']);
		$venue_id = $eventInfo->venue;
		$venue = $array_venue['venue'];
		$array_venue['start_dt_timestamp'];
		$array_venue['end_dt_timestamp'];
		$array_venue['event_online'] = (int) $array_venue['event_online'];
		$created_by = $array_venue['created_by'];
		$query = $db->getQuery(true);

		if (!empty($array_venue['eventid']))
		{
			$query = "SELECT  v.id,v.name,v.created_by,v.privacy,v.state FROM   #__jticketing_venues AS v
				WHERE NOT EXISTS(SELECT NULL FROM #__jticketing_events AS ed WHERE ed.venue = v.id AND(('"
			. $array_venue["start_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
			. $array_venue["end_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
			. $array_venue["start_dt_timestamp"] . "' <= UNIX_TIMESTAMP(ed.startdate) AND '"
			. $array_venue["end_dt_timestamp"] . "' >= UNIX_TIMESTAMP(ed.enddate))
			 )) AND v.online = "
			. $array_venue['event_online'] . " AND v.state = 1 AND (v.created_by ='"
			. $created_by . "' OR v.privacy = 1) ";
			$db->setQuery($query);
			$eventsCreate = $db->loadObjectList();

			$query1 = "SELECT  v.id,v.name,v.created_by,v.privacy,v.state FROM   #__jticketing_venues AS v WHERE v.id =  '" . $venue_id . "'";
			$db->setQuery($query1);
			$eventsEdit = $db->loadObjectList();

			$eventsFinal = array_merge($eventsCreate, $eventsEdit);
			$events = array_map("unserialize", array_unique(array_map("serialize", $eventsFinal)));

			return $events;
		}
		else
		{
			$query = "SELECT  v.id,v.name,v.created_by,v.privacy,v.state FROM   #__jticketing_venues AS v
			WHERE NOT EXISTS(SELECT NULL FROM #__jticketing_events AS ed WHERE ed.venue = v.id AND(('"
			. $array_venue["start_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
			. $array_venue["end_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
			. $array_venue["start_dt_timestamp"] . "' <= UNIX_TIMESTAMP(ed.startdate) AND '"
			. $array_venue["end_dt_timestamp"] . "' >= UNIX_TIMESTAMP(ed.enddate))
			 )) AND v.online = " . $array_venue['event_online'] . " AND v.state = 1 AND (v.created_by ='" . $created_by . "' OR v.privacy = 1)";

			$db->setQuery($query);
			$events = $db->loadObjectList();

			return $events;
		}
	}

	/**
	 * Method to get book venue
	 *
	 * @param   array  $event  An array to get the item values
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getvenuehtml($event)
	{
		$array_venue = array();
		$db = JFactory::getDbo();
		$selectedvenue = $event->venue;
		$jinput = JFactory::getApplication()->input;
		$eventid = $jinput->get('id', '', 'STRING');
		$array_venue['venue'] = $selectedvenue;
		$array_venue['eventid'] = $eventid;
		$array_venue['start_dt_timestamp'] = $event->startdate;
		$array_venue['end_dt_timestamp'] = $event->enddate;
		$array_venue['event_online'] = $event->online_events;
		$array_venue['created_by'] = $event->created_by;

		$getvenue = $this->getAvailableVenue($array_venue);
		$options = array();
		$u = array();
		/*$u->id = '';*/
		$u['id'] = '';
		/*$u->name = '';*/
		$u['name'] = '';

		foreach ($getvenue as $u)
		{
			$options[] = JHtml::_('select.option', $u->id, $u->name);
		}

		return JHtml::_('select.genericlist', $options, $u->name, 'class="inputbox"  size="5"', 'value', 'text', $selectedvenue);
	}

	/**
	 * Method to get book venue
	 *
	 * @param   array  $itemId  An array to get the item values
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getEditVenue($itemId)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$query = "SELECT venue FROM #__jticketing_events WHERE id = " . $itemId;

		$db->setQuery($query);
		$events = $db->loadResult();

		if ($events)
		{
			$db = JFactory::getDbo();
			$subQuery = $db->getQuery(true);
			$subQuery = "SELECT id,name FROM #__jticketing_venues WHERE id = " . $events;

			$db->setQuery($subQuery);
			$venueName = $db->loadObject();

			return $venueName;
		}
	}

	/**
	 * Method to Check Venue Exist Or Not
	 *
	 * @return	void
	 *
	 * @since	1.8
	 */
	public function checkVenueExistOrNot()
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query = "SELECT * FROM #__jticketing_venues";
		$db->setQuery($query);
		$venue_exist = $db->loadResult();

		if (empty($venue_exist))
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
}
