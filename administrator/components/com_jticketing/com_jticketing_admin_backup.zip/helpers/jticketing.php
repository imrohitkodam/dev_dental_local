<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access.
defined('_JEXEC') or die;

/**
 * Class for showing toolbar in backend jticketing toolbar
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingHelper
{
	/**
	 * function for showing toolbar in backend jticketing toolbar
	 *
	 * @param   integer  $vName  name of view for which to add menu
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public static function addSubmenu($vName = '')
	{
		$params               = JComponentHelper::getParams('com_jticketing');
		$integration          = $params->get('integration', '', 'INT');
		$input                = JFactory::getapplication()->input;
		$vName                = $input->get('view', '', 'STRING');
		$client               = $input->get('client', '', 'STRING');
		$extension			  = $input->get('extension', '', 'STRING');
		$client_ticket_fields = $client_event_fields = $client_ticket_groups = $client_event_groups = 0;

		if ($client == 'com_jticketing.ticket' && $vName == 'fields')
		{
			$client_ticket_fields = 1;
		}
		elseif ($client == 'com_jticketing.event' && $vName == 'fields')
		{
			$client_event_fields = 1;
		}
		elseif ($client == 'com_jticketing.ticket' && $vName == 'groups')
		{
			$client_ticket_groups = 1;
		}
		elseif ($client == 'com_jticketing.event' && $vName == 'groups')
		{
			$client_event_groups = 1;
		}

		// Define view paths
		$events_view = 'index.php?option=com_jticketing&view=events';
		$categories_view = 'index.php?option=com_categories&view=categories&extension=com_jticketing';
		$sales_view = 'index.php?option=com_jticketing&view=allticketsales';
		$orders_view = 'index.php?option=com_jticketing&view=orders';
		$attendee_list_view = 'index.php?option=com_jticketing&view=attendee_list';
		$payout_list_view = 'index.php?option=com_jticketing&view=mypayouts';
		$email_config_view = 'index.php?option=com_jticketing&view=email_config';
		$email_template_view = 'index.php?option=com_jticketing&view=email_template';
		$catimpexp = 'index.php?option=com_jticketing&view=catimpexp';
		$reminder_view = 'index.php?option=com_jticketing&view=reminders';
		$coupon_view = 'index.php?option=com_jticketing&view=coupons';
		$event_field_view = 'index.php?option=com_tjfields&view=fields&client=com_jticketing.event';
		$event_field_group_view = 'index.php?option=com_tjfields&view=groups&client=com_jticketing.event';
		$ticket_field_view = 'index.php?option=com_tjfields&view=fields&client=com_jticketing.ticket';
		$ticket_field_group_view = 'index.php?option=com_tjfields&view=groups&client=com_jticketing.ticket';
		$venues = 'index.php?option=com_jticketing&view=venues';
		$venues_categories = 'index.php?option=com_categories&view=categories&extension=com_jticketing.venues';
		$ticket_vendor_view = 'index.php?option=com_tjvendors&view=vendors&client=com_jticketing';

		if (JVERSION >= '3.0')
		{
			JHtmlSidebar::addEntry(JText::_('JT_CP'), 'index.php?option=com_jticketing&view=cp', $vName == 'cp');

			JHtmlSidebar::addEntry(
					JText::_('COM_JTICKETING_TITLE_VENUES_CATS'),
					$venues_categories,
					$vName == 'categories' && $extension == 'com_jticketing.venues');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_TITLE_VENUES'), $venues, $vName == 'venues');

			// Showing Native event and event category menus
			if ($integration == 2)
			{
				JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_TITLE_EVENTS'), $events_view, $vName == 'events');
				JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_SUBMENU_CATEGORIES'), $categories_view, $vName == 'categories' && $extension == 'com_jticketing');
				JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_TITLE_CATIMPORTEXPORT'), $catimpexp, $vName == 'catimpexp');
			}

			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_TICKET_SALES_REPORT'), $sales_view, $vName == 'allticketsales');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_ORDERS'), $orders_view, $vName == 'orders');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_ATTENDEE_LIST'), $attendee_list_view, $vName == 'attendee_list');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_PAYOUT_REPORTS'), $payout_list_view, $vName == 'mypayouts');

			if ($vName == 'categories')
			{
				JToolBarHelper::title('Jticketing: Categories (Events)');
			}

			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_EMAIL_CONFIG'), $email_config_view, $vName == 'email_config');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_EMAIL_TEMPLATE'), $email_template_view, $vName == 'email_template');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_REMINDER_TYPES'), $reminder_view, $vName == 'reminders');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_COUPONS'), $coupon_view, $vName == 'coupons');
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_EVENT_FIELD_MENU'), $event_field_view, $client_event_fields == 1);
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_EVENT_GROUP_MENU'), $event_field_group_view, $client_event_groups == 1);
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_TICKET_FIELD_MENU'), $ticket_field_view, $client_ticket_fields == 1);
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_TICKET_GROUP_MENU'), $ticket_field_group_view, $client_ticket_groups == 1);
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_VENDORS'), $ticket_vendor_view, $vName == "vendors");
		}
		else
		{
			JSubMenuHelper::addEntry(JText::_('JT_CP'), 'index.php?option=com_jticketing&view=cp', $vName == 'cp');

			// Showing Native event and event category menus
			if ($integration == 2)
			{
				JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_TITLE_EVENTS'), $events_view, $vName == 'events');
				JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_SUBMENU_CATEGORIES'), $categories_view, $vName == 'categories');
				JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_TITLE_CATIMPORTEXPORT'), $catimpexp, $vName == 'catimpexp');
			}

			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_TICKET_SALES_REPORT'), $sales_view, $vName == 'allticketsales');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_ORDERS'), $orders_view, $vName == 'orders');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_ATTENDEE_LIST'), $attendee_list_view, $vName == 'attendee_list');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_PAYOUT_REPORTS'), $payout_list_view, $vName == 'mypayouts');

			if ($vName == 'categories.events.category_id')
			{
				JToolBarHelper::title('Jticketing: Categories (Events)');
			}

			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_EMAIL_CONFIG'), $email_config_view, $vName == 'email_config');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_EMAIL_TEMPLATE'), $email_template_view, $vName == 'email_template');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_REMINDER_TYPES'), $reminder_view, $vName == 'reminders');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_COUPONS'), $coupon_view, $vName == 'coupons');
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_EVENT_FIELD_MENU'), $event_field_view, $client_event_fields == 1);
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_EVENT_GROUP_MENU'), $event_field_group_view, $client_event_groups == 1);
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_TICKET_FIELD_MENU'), $ticket_field_view, $client_ticket_fields == 1);
			JSubMenuHelper::addEntry(JText::_('COM_JTICKETING_TICKET_GROUP_MENU'), $ticket_field_group_view, $client_ticket_groups == 1);
			JHtmlSidebar::addEntry(JText::_('COM_JTICKETING_VENDORS'), $ticket_vendor_view, $vName == "vendors");
		}
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return	JObject
	 *
	 * @since	1.6
	 */
	public static function getActions()
	{
		$user      = JFactory::getUser();
		$result    = new JObject;
		$assetName = 'com_jticketing';
		$actions   = array(
						'core.admin',
						'core.manage',
						'core.create',
						'core.edit',
						'core.edit.own',
						'core.edit.state',
						'core.delete'
		);

		foreach ($actions as $action)
		{
						$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}
}
