<?php
/**
 * @version    SVN: <svn_id>
 * @package    Com_Jticketing
 * @copyright  Copyright (C) 2005 - 2014. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * Jticketing is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');
require_once JPATH_ADMINISTRATOR . '/components/com_jticketing/models/venue.php';

/**
 * Event controller class.
 *
 * @since  1.0.0
 */
class JticketingControllerEvent extends JControllerForm
{
	/**
	 * Constructor.
	 *
	 * @see     JControllerLegacy
	 * @since   1.0.0
	 * @throws  Exception
	 */
	public function __construct()
	{
		$this->view_list = 'events';
		parent::__construct();
	}

	/**
	 * Method to save a user's profile data.
	 *
	 * @param   string  $key     TO ADD
	 * @param   string  $urlVar  TO ADD
	 *
	 * @return    void
	 *
	 * @since    1.6
	 */
	public function save($key = null, $urlVar = null)
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Initialise variables.
		$app   = JFactory::getApplication();
		$model = $this->getModel('Event', 'JticketingModel');

		// Get the user data.
		$data = JFactory::getApplication()->input->get('jform', array(), 'array');

		// Jform tweaing starts.
		// JForm tweak - Save all jform array data in a new array for later reference.
		$all_jform_data = $data;

		// Jform tweak - Get all posted data.
		$post = JFactory::getApplication()->input->post;

		// Get formatted start time & end time for event.
		$formattedTime = $this->getFormattedTime($post);

		// Append formatted start time & end time for event to startdate & enddate.
		$data['startdate']  = $data['startdate'] . " " . $formattedTime['event_start_time'];
		$data['enddate']    = $data['enddate'] . " " . $formattedTime['event_end_time'];
		$start_dt_timestamp = strtotime($data['startdate']);
		$end_dt_timestamp   = strtotime($data['enddate']);

		// Validate if start-date-time <= end-date-time.
		if ($start_dt_timestamp > $end_dt_timestamp)
		{
			// Save the data in the session.
			// Tweak.
			$app->setUserState('com_jticketing.edit.event.data', $all_jform_data);

			// Tweak *important
			$app->setUserState('com_jticketing.edit.event.id', $all_jform_data['id']);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setMessage(JText::_('COM_JTICKETING_EVENT_START_DATE_LESS_EVENT_END_DATE_ERROR'), 'warning');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		$booking_start_date = strtotime($data['booking_start_date']);
		$booking_end_date   = strtotime($data['booking_end_date']);

		// Validate if booking-start-date <= booking-end-date.
		if ($booking_start_date > $booking_end_date)
		{
			// Save the data in the session.
			// Tweak.
			$app->setUserState('com_jticketing.edit.event.data', $all_jform_data);

			// Tweak *important
			$app->setUserState('com_jticketing.edit.event.id', $all_jform_data['id']);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setMessage(JText::_('COM_JTICKETING_EVENT_BOOKING_START_DATE_LESS_BOOKING_END_DATE_ERROR'), 'warning');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		// Validate the posted data.
		$form = $model->getForm();

		if (!$form)
		{
			JError::raiseError(500, $model->getError());

			return false;
		}

		// Validate the posted data.
		if (!empty($form))
		{
			$data = $model->validate($form, $data);
		}

		// Check for errors.
		if ($data === false)
		{
			// Get the validation messages.
			$errors = $model->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++)
			{
				if ($errors[$i] instanceof Exception)
				{
					$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				}
				else
				{
					$app->enqueueMessage($errors[$i], 'warning');
				}
			}

			// Save the data in the session.
			// Tweak.
			$app->setUserState('com_jticketing.edit.event.data', $all_jform_data);

			// Tweak *important
			$app->setUserState('com_jticketing.edit.event.id', $all_jform_data['id']);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		// Jform tweaking - get data for extra fields jform.
		$extra_jform_data = array_diff_key($all_jform_data, $data);

		// Check if form file is present.
		jimport('joomla.filesystem.file');
		$filePath = JPATH_SITE . '/components/com_jticketing/models/forms/eventform_extra.xml';

		if (JFile::exists($filePath))
		{
			// Validate the posted data.
			$formExtra = $model->getFormExtra(
						array("category" => $data['catid'],
							"clientComponent" => 'com_jticketing',
							"client" => 'com_jticketing.event',
							"view" => 'event',
							"layout" => 'edit')
							);

			if (!$formExtra)
			{
				JError::raiseWarning(500, $model->getError());

				return false;
			}

			$formExtra = array_filter($formExtra);

			if (!empty($formExtra))
			{
				if (!empty($formExtra[0]))
				{
					// Validate the posted extra data.
					$extra_jform_data = $model->validateExtra($formExtra[0], $extra_jform_data);
				}
				else
				{
					// Validate the posted extra data.
					$extra_jform_data = $model->validateExtra($formExtra[1], $extra_jform_data);
				}
			}

			// Check for errors.
			if ($extra_jform_data === false)
			{
				// Get the validation messages.
				$errors = $model->getErrors();

				// Push up to three validation messages out to the user.
				for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++)
				{
					if ($errors[$i] instanceof Exception)
					{
						$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
					}
					else
					{
						$app->enqueueMessage($errors[$i], 'warning');
					}
				}

				// Save the data in the session.
				// Tweak.
				$app->setUserState('com_jticketing.edit.event.data', $all_jform_data);

				// Tweak *important
				$app->setUserState('com_jticketing.edit.event.id', $all_jform_data['id']);

				// Redirect back to the edit screen.
				$id = (int) $app->getUserState('com_jticketing.edit.event.id');
				$app->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

				return false;
			}
		}

		/* Attempt to save the data.
		$return = $model->save($data);
		Tweaked. */
		$return = $model->save($data, $extra_jform_data, $post);

		// Check for errors.
		if ($return === false)
		{
			/* Save the data in the session.
			$app->setUserState('com_jticketing.edit.event.data', $data);
			Tweak.*/
			$app->setUserState('com_jticketing.edit.event.data', $all_jform_data);

			/* Tweak *important.
			$app->setUserState('com_jticketing.edit.event.id', $all_jform_data['id']);*/

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setMessage(JText::sprintf('COM_JTICKETING_MSG_ERROR_SAVE_EVENT', $model->getError()), 'warning');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		$msg      = JText::_('COM_JTICKETING_MSG_SUCCESS_SAVE_EVENT');
		$input = JFactory::getApplication()->input;
		$id  = $input->get('id');

		if (empty($id))
		{
			$id = $return;
		}

		$task  = $input->get('task');

		if ($task == 'apply')
		{
			$redirect = JRoute::_('index.php?option=com_jticketing&&view=event&layout=edit&id=' . $id, false);
			$app->redirect($redirect, $msg);
		}

		if ($task == 'save2new')
		{
			$redirect = JRoute::_('index.php?option=com_jticketing&&view=event&layout=edit', false);
			$app->redirect($redirect, $msg);
		}

		// Clear the profile id from the session.
		$app->setUserState('com_jticketing.edit.event.id', null);

		// Check in the profile.
		if ($return)
		{
			$model->checkin($return);
		}

		// Redirect to the list screen.
		$redirect = JRoute::_('index.php?option=com_jticketing&view=events', false);
		$app->redirect($redirect, $msg);

		// Flush the data from the session.
		$app->setUserState('com_jticketing.edit.event.data', null);
	}

	/**
	 * Function used to get the formaated time
	 *
	 * @param   ARRAY  $post  Post data
	 *
	 * @return  string  $formattedTime  Final formatted time
	 *
	 * @since  1.0.0
	 */
	private function getFormattedTime($post)
	{
		// Get all non-jform data for event start time fields.
		$event_start_time_ampm = strtolower($post->get('event_start_time_ampm', '', 'string'));
		$event_start_time_hour = $post->get('event_start_time_hour', '', 'int');
		$event_start_time_min  = $post->get('event_start_time_min', '', 'int');
		$event_start_time      = $event_start_time_hour;

		// Convert hours into 24 hour format.
		if (($event_start_time_ampm == 'pm') && ($event_start_time_hour != '12'))
		{
			$event_start_time = $event_start_time_hour + 12;
		}
		elseif (($event_start_time_ampm == 'am') && ($event_start_time_hour == '12'))
		{
			$event_start_time = $event_start_time_hour - 12;
		}

		// Get minutes and attach seconds.
		$event_start_time .= ":" . $event_start_time_min;
		$event_start_time .= ":" . '00';

		// Get all non-jform data for event start time fields.
		$event_end_time_ampm = strtolower($post->get('event_end_time_ampm', '', 'string'));
		$event_end_time_hour = $post->get('event_end_time_hour', '', 'int');
		$event_end_time_min  = $post->get('event_end_time_min', '', 'int');
		$event_end_time      = $event_end_time_hour;

		// Convert hours into 24 hour format.
		if (($event_end_time_ampm == 'pm') && ($event_end_time_hour != '12'))
		{
			$event_end_time = $event_end_time_hour + 12;
		}

		// Checking time 12am is it then convert to 24 hour time
		elseif (($event_end_time_ampm == 'am') && ($event_end_time_hour == '12'))
		{
			$event_end_time = $event_end_time_hour - 12;
		}

		// Get minutes and attach seconds.
		$event_end_time .= ":" . $event_end_time_min;
		$event_end_time .= ":" . '00';

		$formattedTime = array();

		// Set return values.
		$formattedTime['event_start_time'] = $event_start_time;
		$formattedTime['event_end_time']   = $event_end_time;

		return $formattedTime;
	}

	/**
	 * Function used to get the formaated time
	 *
	 * @param   ARRAY  $post  Post data
	 *
	 * @return  string  $formattedTime  Final formatted time
	 *
	 * @since  1.0.0
	 */
	private function getEventDetails($post)
	{
		// Get all non-jform data for event start time fields.
		$event_start_time_ampm = strtolower($post->get('event_start_time_ampm', '', 'string'));
		$event_start_time_hour = $post->get('event_start_time_hour', '', 'int');
		$event_start_time_min  = $post->get('event_start_time_min', '', 'int');
		$event_start_time      = $event_start_time_hour;

		return $formattedTime;
	}

	/**
	 * Internal use functions
	 *
	 * @return  file
	 *
	 * @since 1.0.0
	 */
	public function getEventsDetails()
	{
		$db = JFactory::getDBO();
		$input = JFactory::getApplication()->input;
		$event_id  = $input->get('event_id');

		$query = $db->getQuery(true);

		$query->select('e.id')
			->from('#__jticketing_events as e');
		$query->select('t.eventid as eventid , t.id as ticketid, t.price, t.title');
		$query->join('LEFT', '#__jticketing_types AS t ON t.eventid = e.id');
		$query->where($db->qn('e.id') . ' = ' . $db->quote($event_id));

		$db->setQuery($query);
		$var = $db->loadObjectlist();
		print_r(json_encode($var));
		jexit();
	}

	/**
	 * Method to get book venue
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getAvailableVenue()
	{
		$array_venue = array();
		$post = JFactory::getApplication()->input->post;
		$array_venue['venue']		= $post->get('venue', '', 'INT');
		$startdate					= $post->get('startdate', '', 'STRING');
		$enddate					= $post->get('enddate', '', 'STRING');

		// Get formatted start time & end time for event.
		$formattedTime = $this->getFormattedTime($post);

		// Append formatted start time & end time for event to startdate & enddate.
		$startdate = $startdate . " " . $formattedTime['event_start_time'];
		$enddate = $enddate . " " . $formattedTime['event_end_time'];
		$array_venue['start_dt_timestamp'] = strtotime($startdate);
		$array_venue['end_dt_timestamp']   = strtotime($enddate);
		$array_venue['created_by']   = $post->get('created_by', '', 'INT');
		$array_venue['event_online']   = $post->get('event_online', '', 'INT');
		$array_venue['eventid']   = $post->get('eventid', '0', 'INT');
		require_once JPATH_COMPONENT . '/models/event.php';
		$JticketingModelEvent = new JticketingModelEvent;
		$result = $JticketingModelEvent->getAvailableVenue($array_venue);
		echo json_encode($result);

		/*if ($result)
		{
			echo "success";
		}
		else
		{
			echo "failure";
		}*/

		jexit();
	}

	/**
	 * Method to get edit venue
	 *
	 * Method to create online event
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getEditVenue()
	{
		$post = JFactory::getApplication()->input->post;
		$itemId		= $post->get('itemId', '', 'INT');
		require_once JPATH_COMPONENT . '/models/event.php';
		$JticketingModelEvent = new JticketingModelEvent;
		$result = $JticketingModelEvent->getEditVenue($itemId);
	}

	/**
	 * Method to get edit venue
	 *
	 * Method to create online event
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function createSeminar()
	{
		$post = JFactory::getApplication()->input->post;
		$formData = new JRegistry($post->get('jform', '', 'array'));
		$unlimitedCount = $post->get('ticket_type_unlimited_seats', '', 'array');

		if ($unlimitedCount['0'] == 1)
		{
			$ticketCount = 'unlimited';
		}
		else
		{
			$ticketCount = array_sum($post->get('ticket_type_available', '', 'array'));
		}

		$venueId = $formData->get('venue');
		$Name = $formData->get('title');
		$startTime = $post->get('event_start_time_hour') . ':' . $post->get('event_start_time_min') . ' ' . $post->get('event_start_time_ampm');

		if ($post->get('event_start_time_min') != '00')
		{
			$startTimeFormated = date("H:i", strtotime($startTime));
		}
		else
		{
			$startTimeFormated = date("H:i", strtotime($post->get('event_start_time_hour') . ' ' . $post->get('event_start_time_ampm')));
		}

		$endTime = $post->get('event_end_time_hour') . ':' . $post->get('event_end_time_min') . ' ' . $post->get('event_end_time_ampm');

		if ($post->get('event_end_time_min') != '00')
		{
			$endTimeFormated = date("H:i", strtotime($endTime));
		}
		else
		{
			$endTimeFormated = date("H:i", strtotime($post->get('event_end_time_hour') . ' ' . $post->get('event_end_time_ampm')));
		}

		$beginDate = $formData->get('startdate') . 'T' . $startTimeFormated;
		$endDate = $formData->get('enddate') . 'T' . $endTimeFormated;
		$jticketingfrontendhelper = new jticketingfrontendhelper;

		// Load AnnotationForm Model
		$model = JModelLegacy::getInstance('Venue', 'JticketingModel');
		$licenceContent = $model->getItem($venueId);
		$licence = (object) $licenceContent->params;
		$jticketingmainhelper = new jticketingmainhelper;
		$password = $jticketingmainhelper->rand_str(8);
		$userid = $post->get('jform_created_by');

		if ($userid == 0)
		{
			$userDetail = JFactory::getUser();
		}
		elseif ($userid == -1)
		{
			$userDetail->id = 0;
		}
		else
		{
			$userDetail = JFactory::getUser($userid);
		}

		// TRIGGER After create event
		if (!empty($licence))
		{
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('tjevents');

			if ($licence->event_type == 'meeting')
			{
				$result = $dispatcher->trigger('createMeeting', array($licence, $Name, $userDetail, $beginDate, $endDate, $ticketCount, $password));
			}
			elseif ($licence->event_type == 'seminar')
			{
				$result = $dispatcher->trigger('createSeminar', array($licence, $Name, $userDetail, $beginDate, $endDate, $ticketCount, $password));
			}
		}

		echo json_encode($result['0']);

		jexit();
	}

	/**
	 * Method to get all existing events
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getAllMeetings()
	{
		$post = JFactory::getApplication()->input->post;
		$venueId = $post->get('venueId');

		// Load AnnotationForm Model
		$model = JModelLegacy::getInstance('Venue', 'JticketingModel');
		$licenceContent = $model->getItem($venueId);
		$licence = (object) $licenceContent->params;

		if (!empty($venueId))
		{
			// TRIGGER After create event
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('tjevents');
			$result = $dispatcher->trigger('getAllMeetings', array($licence));
			echo json_encode($result);
		}

		jexit();
	}

	/**
	 * Method to chk if free event or not
	 *
	 * @return  int  id of event
	 */
	public function isFreeEvent()
	{
		require_once JPATH_SITE . "/components/com_jticketing/helpers/main.php";
		$input = JFactory::getApplication()->input;
		$eventid = $input->get('event_id');

		$jticketingmainhelper = new jticketingmainhelper;
		$freeEvent = $jticketingmainhelper->isFreeEvent($eventid);

		if (empty($freeEvent))
		{
			print_r($freeEvent);
		}
		else
		{
			print_r(0);
		}

		jexit();
	}

	/**
	 * Method to get event sco_id from meeting URL
	 *
	 * @return  int  id of event
	 */
	public function getScoID()
	{
		$post = JFactory::getApplication()->input->post;
		$venueurl = $post->get('venueurl');
		$venueId = $post->get('venueId');

	// Load AnnotationForm Model
		$model = JModelLegacy::getInstance('Venue', 'JticketingModel');
		$licenceContent = $model->getItem($venueId);
		$licence = (object) $licenceContent->params;

		if (!empty($venueurl))
		{
			// TRIGGER After create event
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('tjevents');
			$result = $dispatcher->trigger('getScoID', array($licence, $venueurl));
			echo json_encode($result);
		}

		jexit();
	}
}
