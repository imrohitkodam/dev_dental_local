<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Jticketing
 * @author     Techjoomla <kiran_l@techjoomla.com>
 * @copyright  2016 techjoomla
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Venue controller class.
 *
 * @since  1.6
 */
class JticketingControllerVenue extends JControllerForm
{
	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'venues';
		parent::__construct();
	}

	/**
	 * Constructor
	 *
	 * @throws Exception
	 *
	 * @return tag      in function	 *
	 */
	public function getelementparams()
	{
		$db = JFactory::getDBO();
		$params = "";

		$input = JFactory::getApplication()->input;
		$element  = $input->get('element');
		$venue_id  = $input->get('venue_id');

		if ($venue_id)
		{
			JTable::addIncludePath(JPATH_ROOT . '/administrator/components/com_jticketing/tables');
			$db = JFactory::getDbo();
			$table = JTable::getInstance('venue', 'JticketingTable', array('dbo', $db));
			$table->load(array('id' => $venue_id));
			$params = json_decode($table->params);
		}

		$plug_res = $this->buildForm($params, $element);
		echo $plug_res;
		jexit();
	}

	/**
	 * Constructor
	 *
	 * @param   string  $params   TO ADD
	 * @param   string  $element  TO ADD
	 *
	 * @throws  Exception
	 *
	 * @return tag      in function	 *
	 */
	public function buildForm($params, $element)
	{
		$form = null;
		$form_path = JPATH_SITE . DS . 'plugins' . DS . 'tjevents' . DS . $element . DS . $element . DS . 'form' . DS . $element . '.xml';
		$test = $element . '_' . 'plugin';

		$lang = JFactory::getLanguage();
		$lang->load('plg_tjevents_' . $element, JPATH_ADMINISTRATOR);

		$form = JForm::getInstance($test, $form_path);
		$form->bind($params);

		$fieldSet = $form->getFieldset('basic');
		$html = array();

		foreach ($fieldSet as $field)
		{
			$html[] = $field->renderField();
		}

		return implode('', $html);
	}

	/**
	 * Method to Publish the element.
	 *
	 * @return   void
	 *
	 * @since    1.6
	 *
	 */
	public function publish()
	{
		// Initialise variables.
		$app = JFactory::getApplication();

		// Checking if the user can remove object
		$user = JFactory::getUser();

		if ($user->authorise('core.edit', 'com_jticketing') || $user->authorise('core.edit.state', 'com_jticketing'))
		{
			$model = $this->getModel('venue', 'JticketingModel');

			// Get the user data.
			$id = $app->input->getInt('id');
			$state = $app->input->getInt('state');

			// Attempt to save the data.
			$return = $model->publish($id, $state);

			// Check for errors.
			if ($return === false)
			{
				$this->setMessage(JText::sprintf('Save failed: %s', $model->getError()), 'warning');
			}

			// Clear the profile id from the session.
			$app->setUserState('com_jticketing.edit.venue.id', null);

			// Flush the data from the session.
			$app->setUserState('com_jticketing.edit.venue.data', null);

			// Redirect to the list screen.
			if ($state == '0')
			{
				$this->setMessage(JText::_('COM_JTICKETING_VENUE_UNPUBLISHED'));
			}
			else
			{
				$this->setMessage(JText::_('COM_JTICKETING_VENUE_PUBLISHED'));
			}

			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=venues', false));
		}
		else
		{
			throw new Exception(500);
		}
	}

	/**
	 * To Fetch state list from Db
	 *
	 * @return  list of state
	 *
	 * @since  1.0.0
	 */
	public function getRegionListFromCountryID()
	{
		$TjGeoHelper = JPATH_ROOT . '/components/com_tjfields/helpers/geo.php';

		if (!class_exists('TjGeoHelper'))
		{
			JLoader::register('TjGeoHelper', $TjGeoHelper);
			JLoader::load('TjGeoHelper');
		}

		$tjGeoHelper = new TjGeoHelper;

		$jinput = JFactory::getApplication()->input;
		$country = $jinput->get('country', '', 'STRING');
		echo json_encode($tjGeoHelper->getRegionListFromCountryID($country));

		jexit();
	}

	/**
	 * Method to Get Location.
	 *
	 * @return json
	 *
	 * @since   1.0
	 */
	public function getLocation()
	{
		$post = JFactory::getApplication()->input->post;

		$model = $this->getModel('venue');
		$result = $model->getCurrentLocation($post);

		echo json_encode($result);

		jexit();
	}
}
