<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die('Restricted access');
require_once JPATH_COMPONENT . DS . 'controller.php';
jimport('joomla.application.component.controller');

/**
 * controller for showing order
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingControllerorders extends JControllerLegacy
{
	/**
	 * Changes order status for example pending to completed
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function save()
	{
		$com_params           = JComponentHelper::getParams('com_jticketing');
		$model         = $this->getModel('orders');
		$mainframe     = JFactory::getApplication();
		$input         = JFactory::getApplication()->input;
		$post          = $input->post;
		$paymentHelper = JPATH_SITE . '/components/com_jticketing/models/payment.php';
		$socialintegration    = $com_params->get('integrate_with', 'none');
		$streamBuyTicket      = $com_params->get('streamBuyTicket', 0);

		if (!class_exists('jticketingModelpayment'))
		{
			JLoader::register('jticketingModelpayment', $paymentHelper);
			JLoader::load('jticketingModelpayment');
		}

		$paymentHelperObj = new jticketingModelpayment;
		$orderobj = new jticketingModelorders;

		if ($post->get('payment_status') == 'C')
		{
			$order_id  = $post->get('order_id');
			$obj       = new jticketingModelpayment;
			$member_id = $obj->getEventMemberid($order_id, 'P');
			$orderobj->update_order_status($order_id, $post->get('payment_status'));
			$eventupdate          = $obj->eventupdate($order_id, $member_id);
			$jticketingmainhelper = new jticketingmainhelper;
			$jticketingfrontendhelper = new jticketingfrontendhelper;
			$email                = $jticketingmainhelper->sendmailnotify($order_id, 'afterordermail');
			$invoice_email = $paymentHelperObj->sendInvoiceEmail($order_id);
			$orderobj->events_types_count_decrease($order_id);
			$order = $jticketingmainhelper->getorderinfo($order_id);
			$jteventHelper        = new jteventHelper;

			if ($socialintegration != 'none')
			{
				// Add in activity.
				if ($streamBuyTicket == 1 and !empty($member_id))
				{
					$libclass    = $jteventHelper->getJticketSocialLibObj();
					$action      = 'streamBuyTicket';
					$eventLink   = '<a class="" href="' . $order['eventinfo']->event_url . '">' . $order['eventinfo']->summary . '</a>';
					$originalMsg = JText::sprintf('COM_JTICKETING_PURCHASED_TICKET', $eventLink);
					$libclass->pushActivity($member_id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
				}
			}

			// Add entries to reminder queue to send reminder for Event
			$reminder_data              = $jticketingmainhelper->getticketDetails($order['eventinfo']->id, $order['items']['0']->order_items_id);
			$eventType = $reminder_data->online_events;
			$meeting_url = json_decode($reminder_data->jt_params);
			$reminder_data->ticketprice = $order['order_info']['0']->amount;
			$reminder_data->nofotickets = 1;
			$reminder_data->totalprice  = $order['order_info']['0']->amount;
			$reminder_data->eid         = $order['eventinfo']->id;
			$eventupdate                = $obj->addtoReminderQueue($reminder_data, $order);
			$integration = $com_params->get('integration');
			$orderDetails               = $jticketingmainhelper->getOrderDetail($order_id);
			$randomPassword               = $jticketingmainhelper->rand_str(8);

			if ($integration == 2)
			{
				$venueDetails               = $jticketingfrontendhelper->getvenue($order['eventinfo']->venue);
				$venueParams                = json_decode($venueDetails->params);
				$venueParams->user_id  = $orderDetails->user_id;
				$venueParams->name     = $orderDetails->name;
				$venueParams->email    = $orderDetails->email;
				$venueParams->password = $randomPassword;
				$venueParams->meeting_url = $meeting_url->event_url;
				$venueParams->sco_id = $meeting_url->event_sco_id;

				if (($eventType == '1') && (!empty($venueParams->meeting_url)))
				{
					// TRIGGER After create event
					$dispatcher = JDispatcher::getInstance();
					JPluginHelper::importPlugin('tjevents');
					$result = $dispatcher->trigger('tj_inviteUsers', array($venueParams));
				}
			}
		}
		else
		{
			$order_id  = $post->get('order_id');
			$status    = $orderobj->get_order_status($order_id);
			$obj       = new jticketingModelpayment;
			$member_id = $obj->getEventMemberid($order_id, 'C');
			$orderobj->events_types_count_increase($order_id);
			$orderobj->update_order_status($order_id, $post->get('payment_status'));
		}

		if ($post->get('redirectview', '', 'STRING'))
		{
				$link = $post->get('redirectview', '', 'STRING');
		}
		else
		{
			$link = 'index.php?option=com_jticketing&view=orders';
		}

		$mainframe->redirect($link);
	}

	/**
	 * Changes order status for example pending to completed
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function remove()
	{
		$model = $this->getModel('orders');
		$post = JRequest::get('post');
		$orderid = $post['cid'];

		if ($model->delete_order($orderid))
		{
						$msg = JText::_('C_ORDER_DELETED_SCUSS');
		}
		else
		{
						$msg = JText::_('C_ORDER_DELETED_ERROR');
		}

		if (JVERSION >= '1.6.0')
		{
			$this->setRedirect(JUri::base() . "index.php?option=com_jticketing&view=orders", $msg);
		}
		else
		{
			$this->setRedirect(JUri::base() . "index2.php?option=com_jticketing&view=orders", $msg);
		}
	}

	/**
	 * cancel to redirect to control panel
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function cancel()
	{
		$this->setRedirect('index.php?option=com_jticketing');
	}

	/**
	 * function to csv export data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function csvexport()
	{
		$com_params    = JComponentHelper::getParams('com_jticketing');
		$currency      = $com_params->get('currency');
		$model         = $this->getModel('attendees');
		$model_results = $model->getData();
		$db            = JFactory::getDBO();
		$query         = "SELECT d.ad_id, d.ad_title, d.ad_payment_type, d.ad_creator,d.ad_startdate, d.ad_enddate,
							i.processor, i.ad_credits_qty, i.cdate, i.ad_amount,i.status,i.id
							FROM #__ad_data AS d RIGHT JOIN #__ad_payment_info AS i ON d.ad_id = i.ad_id";
		$db->setQuery($query);
		$results = $db->loadObjectList();
		$csvData = null;
		$csvData .= "Attender_Name,Bought_On,Ticket_Type,Ticket_Rate,Number_of_tickets_bought,Total_Amount_(A-B)";
		$csvData .= "\n";
		$filename = "Jt_attendees_" . date("Y-m-d_H-i", time());
		header("Content-type: application/vnd.ms-excel");
		header("Content-disposition: csv" . date("Y-m") . ".csv");
		header("Content-disposition: filename=" . $filename . ".csv");
		$totalnooftickets = $totalprice = $totalcommission = $totalearn = 0;

		foreach ($model_results as $result)
		{
			$totalnooftickets = $totalnooftickets + $result->ticketcount;
			$totalprice       = $totalprice + $result->amount;
			$totalearn        = $totalearn + $result->totalamount;
			$csvData .= '"' . $result->name . '"' . ',';
			$csvData .= '"' . (JVERSION < "1.6.0" ? JHtml::_('date', $result->cdate, '%Y/%m/%d')
			:JHtml::_('date', $result->cdate, "Y-m-d")) . '"' . ',';
			$csvData .= '"' . $result->ticket_type_title . '"' . ',';
			$csvData .= '"' . $result->amount . ' ' . $currency . '"' . ',';
			$csvData .= '"' . $result->ticketcount . '"' . ',';
			$csvData .= '"' . $result->totalamount . $currency . '"';
			$csvData .= "\n";
		}

		$csvData .= '" "," ","' . JText::_('TOTAL') . '","';
		$csvData .= number_format($totalnooftickets, 2, '.', '') . '","';
		$csvData .= number_format($totalprice, 2, '.', '') . $currency . '","';
		$csvData .= number_format($totalearn, 2, '.', '') . $currency . '"';
		$csvData .= "\n";
		print $csvData;
		exit();
	}
}
