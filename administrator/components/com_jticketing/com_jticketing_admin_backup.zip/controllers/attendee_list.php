<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die('Restricted access');
require_once JPATH_COMPONENT . '/controller.php';
jimport('joomla.application.component.controller');
/**
 * Model for buy for attendee list
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingControllerattendee_List extends JControllerLegacy
{
	/**
	 * Method to redirect to contact us view
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function cancelEmail()
	{
		$mainframe = JFactory::getApplication();
		$contact_ink = JRoute::_(JUri::base() . 'index.php?option=com_jticketing&view=attendee_list&layout=attendee_list');
		$mainframe->redirect($contact_ink);
	}

	/**
	 * Method to redirect to contact us view
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function redirectforEmail()
	{
		$mainframe = JFactory::getApplication();
		$input = JFactory::getApplication()->input;
		$post = $input->post;
		$cids	= $input->get('cid', '', 'POST', 'ARRAY');
		$session =& JFactory::getSession();
		$session->set('selected_order_item_ids', $cids);
		$selected_order_item_ids = $session->get('selected_order_item_ids');
		$contact_ink = JRoute::_(JUri::base() . 'index.php?option=com_jticketing&view=attendee_list&layout=contactus');
		$mainframe->redirect($contact_ink, $msg);
	}

	/**
	 * Method to checkin for ticket
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function emailtoSelected()
	{
		$mainframe = JFactory::getApplication();
		$input = JFactory::getApplication()->input;
		$selected_ids	= $input->get('selected_emails', '', 'POST', 'STRING');
		$subject	= $input->get('jt-message-subject', '', 'POST', 'STRING');
		$body = JRequest::getVar('jt-message-body', '', 'post', 'string', JREQUEST_ALLOWHTML);
		$img_path = 'img src="' . JUri::root();
		$res->content = str_replace('img src="' . JUri::root(), 'img src="', $body);
		$res->content = str_replace('img src="', $img_path, $res->content);
		$res->content = str_replace("background: url('" . JUri::root(), "background: url('", $res->content);
		$res->content = str_replace("background: url('", "background: url('" . JUri::root(), $res->content);
		$cid = explode(",", $selected_ids);
		$cid = array_unique($cid);
		$model = $this->getModel('attendee_list');
		$msg = JText::_('COM_JTICKETING_EMAIL_SUCCESSFUL');

		if ($model->emailtoSelected($cid, $subject, $body, $attachmentPath))
		{
			$msg = JText::_('COM_JTICKETING_EMAIL_SUCCESSFUL');
		}
		else
		{
			$msg = $model->getError();
		}

		$contact_ink = JRoute::_(JUri::base() . 'index.php?option=com_jticketing&view=attendee_list');
		$mainframe->redirect($contact_ink, $msg);
	}

	/**
	 * Method to checkin for ticket
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function cancel()
	{
		$this->setRedirect('index.php?option=com_jticketing');
	}

	/**
	 * Method to checkin for ticket
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function checkin()
	{
		$input = JFactory::getApplication()->input;
		$post  = $input->post;

		// Get some variables from the request
		$cid = $input->get('cid', array(), 'post', 'array');
		JArrayHelper::toInteger($cid);
		$mainframe = JFactory::getApplication();
		$sitename  = $mainframe->getCfg('sitename');
		$model     = $this->getModel('attendee_list');

		if ($model->setItemState_checkin($cid, 1))
		{
			$msg = JText::_('COM_JTICKETING_CHECKIN_SUCCESS_MSG');
		}
		else
		{
			$msg = $model->getError();
		}

		$this->setRedirect('index.php?option=com_jticketing&view=attendee_list', $msg);
	}

	/**
	 * Method to undo checkin for ticket
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function undochekin()
	{
		$input = JFactory::getApplication()->input;
		$post  = $input->post;

		// Get some variables from the request
		$cid = $input->get('cid', array(), 'post', 'array');
		JArrayHelper::toInteger($cid);
		$mainframe = JFactory::getApplication();
		$sitename  = $mainframe->getCfg('sitename');
		$model     = $this->getModel('attendee_list');

		if ($model->setItemState_checkin($cid, 0))
		{
			$msg = JText::_('COM_JTICKETING_CHECKIN_FAIL_MSG');
		}
		else
		{
			$msg = $model->getError();
		}

		$this->setRedirect('index.php?option=com_jticketing&view=attendee_list', $msg);
	}

	/**
	 * Method to csv Import
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function csvImport()
	{
		jimport('joomla.html.html');
		jimport('joomla.filesystem.file');
		header('Content-Type: text/html; charset=UTF-8');

		$mainframe = JFactory::getApplication();
		$rs1 = @mkdir(JFactory::getApplication()->getCfg('tmp_path') . '/', 0777);

		// Start file heandling functionality *
		$fname       = $_FILES['csvfile']['name'];
		$uploads_dir = JFactory::getApplication()->getCfg('tmp_path') . '/' . $fname;
		move_uploaded_file($_FILES['csvfile']['tmp_name'], $uploads_dir);

		if ($file = fopen($uploads_dir, "r"))
		{
			$info = pathinfo($uploads_dir);

			if ($info['extension'] != 'csv')
			{
				$msg = JText::_('NOT_CSV_MSG');
				$mainframe->redirect(JRoute::_('index.php?option=com_jticketing&view=catimpexp', false), "<b>" . $msg . "</b>");

				return;
			}

			while (($data = fgetcsv($file)) !== false)
			{
				if ($rowNum == 0)
				{
					// Parsing the CSV header
					$headers = array();

					foreach ($data as $d)
					{
						$headers[] = $d;
					}
				}
				else
				{
					// Parsing the data rows
					$rowData = array();

					foreach ($data as $d)
					{
						$rowData[] = $d;
					}

					$eventData[] = array_combine($headers, $rowData);
				}

				$rowNum++;
			}

			fclose($file);
		}
		else
		{
			// $msg = JText::_('File not open');
			$application = JFactory::getApplication();
			$application->enqueueMessage(JText::_('COM_JTICKETING_SOME_ERROR_OCCURRED'), 'error');
			$mainframe->redirect(JRoute::_('index.php?option=com_jticketing&view=events', false));

			return;
		}

		if (!empty($eventData))
		{
			$location = 0;
			$booking_end_date = 0;
			$booking_start_date = 0;
			$enddate = 0;
			$startdate = 0;
			$catidx = 0;
			$titlex = 0;
			$idnotfound = 0;
			$catidnotfound = 0;
			$sucess = 0;
			$totalEvents = count($eventData);
			$useridnotfound = 0;
			$eventidnotfound = 0;
			$useralreadypresent = array();

			foreach ($eventData as $eachEvent)
			{
				foreach ($eachEvent as $key => $value)
				{
					$value = trim($value);

					switch ($key)
					{
						case 'UserID' :
							if (!empty ($value))
							{
								$data['userid'] = $value;
							}

						break;

						case 'EventID' :
							$data['eventid'] = $value;
						break;

						case 'TicketTypes' :
							$data['tickettypes'] = $value;
						break;

						default :
						break;
					}
				}

				if (!empty($data['tickettypes']))
				{
					$tickettypes_arr = array();
					$tickettypes_arr = explode(",",$data['tickettypes']);

					foreach ($tickettypes_arr AS $ticket_types)
					{
						$ticket_types_arr_new = array();
						$ticket_types_arr_new = explode("|",$ticket_types);
						$data['ticket_types']['type_ticketcount'][$ticket_types_arr_new['0']] = $ticket_types_arr_new['1'];
					}
				}

				$checkUserid = $this->getValidateUser($data['userid']);

				if (empty($checkUserid))
				{
					$useridnotfound ++;
				}
				else
				{
					$data['userid'] = $checkUserid;
				}

				$checkEventid = $this->getValidateEvent($data['eventid']);

				if (empty($checkUserid))
				{
					$eventidnotfound ++;
				}

				$obj                  = new stdClass;

				if ($data['userid'])
				{
					$model = $this->getModel('attendee_list');
					$imported_data = $model->csvImport($data);

					if (!$imported_data)
					{
						$useralreadypresent_email = JFactory::getUser($data['userid'])->email;
						$useralreadypresent[] = "<br>Already present userid==" . $useralreadypresent_email . " For eventid==" . $data['eventid'];
					}
				}
			}
		}

		$msg = JText::sprintf('COMJTICKETING_EVENT_IMPORT_SUCCESS_MSG', $totalEvents, $eventidnotfound, $useridnotfound);

		if (!empty($useralreadypresent))
		{
			$msg .= implode("", $useralreadypresent);
		}

		$mainframe->redirect(JRoute::_('index.php?option=com_jticketing&view=attendee_list', false), "<b>" . $msg . "</b>");

		return;
	}

	/**
	 * Method to csv export
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function csvexport()
	{
		$input      = Jfactory::getApplication()->input;
		$post       = $input->post;
		$com_params = JComponentHelper::getParams('com_jticketing');
		$currency   = $com_params->get('currency');
		$model                          = $this->getModel('attendee_list');
		$DATA                           = $model->getData($uselimit = 0);
		$this->jticketingmainhelper     = new jticketingmainhelper;
		$collect_attendee_info_checkout = $com_params->get('collect_attendee_info_checkout');
		$db         = JFactory::getDBO();
		$com_params = JComponentHelper::getParams('com_jticketing');
		$yes = JText::_('COM_JTICKETING_YES');
		$no = JText::_('COM_JTICKETING_NO');

		// Create CSV headers
		$csvData       = null;
		$csvData_arr[] = JText::_('TICKET_ID');
		$csvData_arr[] = JText::_('EVENT_NAME');
		$csvData_arr[] = JText::_('ATTENDER_NAME');
		$csvData_arr[] = JText::_('JT_ATTENDEE_EMAIL');
		$csvData_arr[] = JText::_('BOUGHTON');
		$csvData_arr[] = JText::_('TICKET_TYPE_TITLE');
		$csvData_arr[] = JText::_('TICKET_TYPE_RATE');
		$csvData_arr[] = JText::_('NUMBEROFTICKETS_BOUGHT');
		$csvData_arr[] = JText::_('ORIGINAL_AMOUNT');
		$csvData_arr[] = JText::_('PAYMENT_STATUS');
		$csvData_arr[] = JText::_('COM_JTICKETING_CHECKIN');

		// If collect attendee info is set  to no in backend then take first and last name from billing info.
		if ($collect_attendee_info_checkout)
		{
			// Get xref primary key id for this event
			$evxref_id        = $this->jticketingmainhelper->getEventrefid($post->get('search_event_list', '', 'STRING'));
			$extraFieldslabel = $this->jticketingmainhelper->extraFieldslabel($evxref_id);

			// Add extra fields label as column head.
			if (!empty($extraFieldslabel))
			{
				foreach ($extraFieldslabel as $efl)
				{
					$csvData_arr[] = $efl->label;
				}
			}
		}
		else
		{
			$csvData_arr[] = JText::_('COM_JTICKETING_BILLIN_FNAM');
			$csvData_arr[] = JText::_('COM_JTICKETING_BILLIN_LNAM');
			$csvData_arr[] = JText::_('COM_JTICKETING_BILLIN_EMAIL');
			$csvData_arr[] = JText::_('COM_JTICKETING_BILLIN_PHON');
		}

		// Add customer note
		$csvData_arr[] = JText::_('COM_JTICKETING_USER_COMMENT');

		// Trigger After csv header add extra fields
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$extra_labels = $dispatcher->trigger('jt_OnAfterCSVHeaderAttendee');

		if (!empty($extra_labels))
		{
			foreach ($extra_labels['0'] as $labelkey => $labelval)
			{
				$csvData_arr[] = $labelval;
			}
		}

		$csvData .= implode(',', $csvData_arr);
		$csvData .= "\n";
		echo $csvData;
		$payment_statuses = array(
			'P' => JText::_('JT_PSTATUS_PENDING'),
			'C' => JText::_('JT_PSTATUS_COMPLETED'),
			'D' => JText::_('JT_PSTATUS_DECLINED'),
			'E' => JText::_('JT_PSTATUS_FAILED'),
			'UR' => JText::_('JT_PSTATUS_UNDERREVIW'),
			'RF' => JText::_('JT_PSTATUS_REFUNDED'),
			'CRV' => JText::_('JT_PSTATUS_CANCEL_REVERSED'),
			'RV' => JText::_('JT_PSTATUS_REVERSED')
		);

		$csvData = '';
		$filename = "Jt_attendees_" . date("Y-m-d_H-i", time());

		// Set CSV headers
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename=" . $filename . ".csv");
		header("Pragma: no-cache");
		header("Expires: 0");
		$totalnooftickets = $totalprice = $totalcommission = $totalearn = 0;

		foreach ($DATA as $data)
		{
			$csvData      = '';
			$csvData_arr1 = array();

			if ($data->status == 'C')
			{
				$ticketid = JText::_("TICKET_PREFIX") . $data->id . '-' . $data->order_items_id;
			}
			else
			{
				$ticketid = '';
			}

			$totalnooftickets = $totalnooftickets + $data->ticketcount;
			$totalprice       = $totalprice + $data->amount;
			$totalearn        = $totalearn + $data->totalamount;

			if (!$ticketid)
			{
				$csvData_arr1['ticketid'] = '-';
			}
			else
			{
				$csvData_arr1['ticketid'] = $ticketid;
			}

			$eventinfo      = $this->jticketingmainhelper->getEventInfo($data->evid);
			$csvData_arr1[] = ucfirst($eventinfo[0]->title);
			$csvData_arr1[] = ucfirst($data->name);

			if (isset($data->buyeremail))
			{
				$csvData_arr1[] = $data->buyeremail;
			}
			else
			{
				$csvData_arr1[] = '';
			}

			$jdate = new JDate($data->cdate);

			if (JVERSION < 3.0)
			{
				$csvData_arr1[] = str_replace('00:00:00', '', $jdate->toFormat('%d-%m-%Y'));
			}
			else
			{
				$csvData_arr1[] = str_replace('00:00:00', '', $jdate->Format('d-m-Y'));
			}

			$csvData_arr1[] = $data->ticket_type_title;
			$csvData_arr1[] = $data->amount . ' ' . $currency;

			$csvData_arr1[] = $data->ticketcount;
			$csvData_arr1[] = $data->totalamount . ' ' . $currency;
			$csvData_arr1[] = $payment_statuses[$data->status];
			$csvData_arr1[] = ($data->checkin) ? $yes : $no;

			// Add extra fields value
			if ($collect_attendee_info_checkout)
			{
				if (!empty($extraFieldslabel))
				{
					$i = 0;

					foreach ($extraFieldslabel as $efl)
					{
						foreach ($efl->attendee_value as $key_attendee => $eflav)
						{
							if ($data->attendee_id == $key_attendee)
							{
								$csvData_arr1[] = $eflav->field_value;
								$i              = 1;
								break;
							}
						}

						if ($i == 0)
						{
							$csvData_arr1[] = '';
						}
					}
				}
			}
			else
			{
				$query = "SELECT firstname,lastname,user_email,phone FROM #__jticketing_users WHERE order_id=" . $data->id;
				$db->setQuery($query);
				$attname = $db->loadObject();

				if ($attname)
				{
					foreach ($attname as $attnval)
					{
						if ($attnval)
						{
							$csvData_arr1[] = $attnval;
						}
						else
						{
							$csvData_arr1[] = $attnval;
						}
					}
				}
				else
				{
					$csvData_arr1[] = '';
					$csvData_arr1[] = '';
					$csvData_arr1[] = '';
					$csvData_arr1[] = '';
				}
			}

			// Add customer note
			$csvData_arr1[] = $data->customer_note;

			// Trigger After csv body add extra fields
			if (!empty($extra_labels))
			{
				// Call the plugin and get the result
				$dispatcher = JDispatcher::getInstance();
				JPluginHelper::importPlugin('system');
				$extra_labels_value = $dispatcher->trigger('jt_OnAfterCSVBodyAttendee', array($data->id, $data->order_items_id));

				if (!empty($extra_labels_value['0']))
				{
					foreach ($extra_labels_value['0'] as $extra_value)
					{
						if ($extra_value)
						{
							$csvData_arr1[] = $extra_value;
						}
						else
						{
							$csvData_arr1[] = 0;
						}
					}
				}
				else
				{
					foreach ($extra_labels as $exlabel)
					{
						$csvData_arr1[] = '';
					}
				}
			}

			// TRIGGER After csv body add extra fields
			$csvData = implode(',', $csvData_arr1);
			echo $csvData . "\n";
		}

		jexit();
	}

	/**
	 * Method to get events for purchase
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventsforpurchase()
	{
		$model     = $this->getModel('attendee_list');
		$result = $model->getEventsforpurchase();
		echo json_encode($result);
		jexit();
	}

	/**
	 * Method to get events for purchase
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function cancelTicket()
	{
		$model     = $this->getModel('attendee_list');
		$result = $model->cancelTicket();
		echo json_encode($result);
		jexit();
	}

	/**
	 * Method to get events for purchase
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function masscancelTicket()
	{
		$model     = $this->getModel('attendee_list');

		if ($order_id)
		{
			$result = $model->cancelTicket($order_id);
		}
	}

	/**
	 * getValidateId.
	 *
	 * @param   integer  $id  event id
	 *
	 * @return  void
	 *
	 * @since   3.1.2
	 */
	public function getValidateEvent($id)
	{
		$eventId = '';

		if ($id)
		{
			$db    = JFactory::getDBO();
			$query = "SELECT id FROM #__jticketing_events WHERE id ='{$id}'";
			$db->setQuery($query);

			return $eventId = $db->loadResult();
		}

		return $eventId;
	}

	/**
	 * getValidateId.
	 *
	 * @param   integer  $id  event id
	 *
	 * @return  void
	 *
	 * @since   3.1.2
	 */
	public function getValidateUser($id)
	{
		$eventId = '';

		if ($id)
		{
			$db    = JFactory::getDBO();
			$query = "SELECT id FROM #__users WHERE id ='{$id}' OR email LIKE '{$id}'";
			$db->setQuery($query);

			return $eventId = $db->loadResult();
		}

		return $eventId;
	}

	/**
	 * Method to assign ticket to another ticket type
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function changeTicketAssignment()
	{
		$model     = $this->getModel('attendee_list');
		$result = $model->changeTicketAssignment();
	}

	/**
	 * Method to get ticket types
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTicketTypes()
	{
		$model     = $this->getModel('attendee_list');
		$result = $model->getTicketTypes();
		echo json_encode($result);
		jexit();
	}
}
