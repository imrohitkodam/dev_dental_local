<?php
/**
 * @package	Jticketing
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once( JPATH_COMPONENT.DS.'controller.php' );

class jticketingControllercp extends jticketingController
{
	function __construct()
	{
		parent::__construct();
	}

	function getVersion()
	{
		//echo $recdata = file_get_contents('http://techjoomla.com/vc/index.php?key=abcd1234&product=jticketing');
		$url = "https://techjoomla.com/vc/index.php?key=abcd1234&product=jticketing";
		$ch = curl_init();
		$timeout = 5;
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$data = curl_exec($ch);
		curl_close($ch);
		echo $data;
		jexit();
	}


	function save()
	{
		$input=JFactory::getApplication()->input;
		switch ($input->get('task'))
		{
			case 'cancel':
				$this->setRedirect( 'index.php?option=com_broadcast');
			break;
			case 'save':
				if($this->getModel('cp')->store(JRequest::get('post')))
					$msg = JText::_('QUEUE_SAVED');
				else
					$msg = JText::_('QUEUE_SAVE_PROBLEM');
				$this->setRedirect( "index.php?option=com_broadcast&view=cp&layout=queue", $msg );
			break;
		}
	}
	function cancel()
	{
		$this->setRedirect( 'index.php?option=com_broadcast');
	}

	function SetsessionForGraph()
	{
		$periodicorderscount='';
	 	$fromDate =  $_GET['fromDate'];
	 	$toDate =  $_GET['toDate'];
		$periodicorderscount=0;

		$session = JFactory::getSession();
		$session->set('jticketing_from_date', $fromDate);
		$session->set('jticketing_end_date', $toDate);

		$model = $this->getModel('cp');
		$statsforpie=$model->statsforpie();
		$periodicorderscount=$model->getperiodicorderscount();
		$session->set('statsforpie', $statsforpie);
		$session->set('periodicorderscount', $periodicorderscount);

		header('Content-type: application/json');
		echo (json_encode(array("statsforpie"=>$statsforpie)));

		jexit();
	}

	function makechart()
	{
		$month_array_name = array(JText::_('SA_JAN'),JText::_('SA_FEB'),JText::_('SA_MAR'),JText::_('SA_APR'),JText::_('SA_MAY'),JText::_('SA_JUN'),JText::_('SA_JUL'),JText::_('SA_AUG'),JText::_('SA_SEP'),JText::_('SA_OCT'),JText::_('SA_NOV'),JText::_('SA_DEC')) ;
		$session = JFactory::getSession();
		$jticketing_from_date='';
		$jticketing_end_date='';
		$statsforbar='';
		$jticketing_from_date= $session->get('jticketing_from_date', '');
		$jticketing_end_date=$session->get('jticketing_end_date', '');
		$total_days = (strtotime($jticketing_end_date) - strtotime($jticketing_from_date)) / (60 * 60 * 24);
		$total_days=$total_days+1;
		$statsforbar = $session->get('statsforbar','');
		$statsforpie = $session->get('statsforpie','');
		$periodicorderscount=$session->get('periodicorderscount');
		$imprs=0;
		$clicks=0;


		$emptylinechart=0;
		$barchart='';
		$fromDate= $session->get('jticketing_from_date', '');
		$toDate=$session->get('jticketing_end_date', '');

		$dateMonthYearArr = array();
		$fromDateSTR = strtotime($fromDate);
		$toDateSTR = strtotime($toDate);
		$pending_orders=$confirmed_orders=$refund_orders=0;
			if(empty($statsforpie))
			{
				$barchart=JText::_('NO_STATS');
				$emptylinechart=1;
			}
			else
			{
			  	if(!empty($statsforpie['P']))
				{

						$pending_orders= $statsforpie['P'];
				}

				if(!empty($statsforpie['C']))
				{

						$confirmed_orders= $statsforpie['C'];
				}
				if(!empty($statsforpie['D']))
				{

						$denied_orders= $statsforpie['D'];
				}
				if(!empty($statsforpie['RF']))
				{

						$refund_orders= $statsforpie['RF'];
				}
			}

		header('Content-type: application/json');
		  	echo (json_encode(array("pending_orders"=>$pending_orders,
		  						"confirmed_orders"=>$confirmed_orders,
		  						"refund_orders"=>$refund_orders,
		  						"periodicorderscount"=>$periodicorderscount,
		  						"emptylinechart"=>$emptylinechart
		  						)));

		  	jexit();
	}

	/**
	 * Manual Setup related chages: For now - 1. for overring the bs-2 view
	 *
	 * @param   string  $name    The name of the model.
	 * @param   string  $prefix  The prefix for the PHP class name.
	 * @param   array   $config  The array of config values.
	 *
	 * @return  JModel
	 *
	 * @since   1.6
	 */
	public function setup()
	{
		jimport('joomla.filesystem.file');
		jimport('joomla.filesystem.folder');
		$jinput = JFactory::getApplication()->input;
		$takeBackUp = $jinput->get("takeBackUp", 1);

		$jticketingmainhelper     = new jticketingmainhelper;
		$defTemplate = $jticketingmainhelper->getSiteDefaultTemplate(0);
		$templatePath = JPATH_SITE . '/templates/' . $defTemplate . '/html/';

		$statusMsg = array();
		$statusMsg["component"] = array();

		// 1. Override component view
		$siteBs2views = JPATH_ROOT . "/components/com_jticketing/views_bs2/site";

		// Check for com_jticketing folder in template override location
		$compOverrideFolder  = $templatePath . "com_jticketing";

		if (JFolder::exists($compOverrideFolder))
		{
			if ($takeBackUp)
			{
				// Rename
				$backupPath = $compOverrideFolder . '_' . date("Ymd_H_i_s");
				$status = JFolder::move($compOverrideFolder, $backupPath);
				$statusMsg["component"][] = JText::_('COM_JTICKETING_TAKEN_BACKUP_OF_OVERRIDE_FOLDER') . $backupPath;
			}
			else
			{
				$delStatus = JFolder::delete($compOverrideFolder);
			}
		}

		// Copy
		$status = JFolder::copy($siteBs2views, $compOverrideFolder);
		$statusMsg["component"][] = JText::_('COM_JTICKETING_OVERRIDE_DONE') . $compOverrideFolder;


		// 2. Create Override plugins folder if not exist
		$pluginsPath = JPATH_ROOT . "/components/com_jticketing/views_bs2/plugins/";

		// Check for com_jticketing folder in template override location
		$pluginsOverrideFolder  = $templatePath . "plugins";
		$createFolderStatus = JFolder::create($pluginsOverrideFolder);

		if ($createFolderStatus)
		{


			/*if (JFolder::exists($tjshippingOverrideFolder))
			{
			* $statusMsg["plugins"][] = JText::_('COM_JTICKETING_CREATE_PLUGINS_FOLDER_STATUS');

			// Check for override tjshipping plugin
			$newtjshipping = $pluginsPath . "/tjshipping";
			$tjshippingOverrideFolder = $pluginsOverrideFolder . "/tjshipping";
				if ($takeBackUp)
				{
					// Rename
					$backupPath = $tjshippingOverrideFolder . '_' . date("Ymd_H_i_s");
					$status = JFolder::move($tjshippingOverrideFolder, $backupPath);

					$statusMsg["plugins"][] = JText::sprintf('COM_JTICKETING_TAKEN_OF_PLUGIN_ND_BACKUP_PATH','tjshipping', $backupPath);
				}
				else
				{
					$delStatus = JFolder::delete($tjshippingOverrideFolder);
				}
			}

			$status = JFolder::copy($newtjshipping, $tjshippingOverrideFolder);
			$statusMsg["plugins"][] = JText::sprintf('COM_JTICKETING_COMPLETED_PLUGINS_OVERRIDE', "<b> tjshipping</b>");*/
		}
		else
		{
			$statusMsg["plugins"][] = JText::_('COM_JTICKETING_CREATE_PLUGINS_FOLDER_FAILED');
		}

		// 3. Modules override
		$modules = JFolder::folders(JPATH_ROOT . "/components/com_jticketing/views_bs2/modules/");
		$statusMsg["modules"] = array();

		foreach($modules as $modName)
		{
			$this->overrideModule($templatePath, $modName, $statusMsg, $takeBackUp);
		}

		$this->displaySetup($statusMsg);
				exit;
	}

	/**
	 * Override the Modules
	 *
	 * @param   string  $templatePath    templatePath eg JPATH_SITE . '/templates/protostar/html/'
	 * @param   string  $modName  Module name
	 * @param   array   $status  The array of config values.
	 *
	 * @return  JModel
	 *
	 * @since   1.6
	 */
	public function overrideModule($templatePath, $modName, &$statusMsg, $takeBackUp)
	{
		jimport('joomla.filesystem.file');
		jimport('joomla.filesystem.folder');

		$bs2ModulePath = JPATH_ROOT . "/components/com_jticketing/views_bs2/modules/" . $modName;
		$overrideBs2ModulePath = $templatePath . $modName;

		$statusMsg["modules"][] = JText::sprintf('COM_JTICKETING_OVERRIDING_THE_MODULE', $modName);

		if (JFolder::exists($overrideBs2ModulePath))
		{
			if ($takeBackUp)
			{
				// Rename
				$backupPath = $overrideBs2ModulePath . '_' . date("Ymd_H_i_s");
				$status = JFolder::move($overrideBs2ModulePath, $backupPath);

				$statusMsg["modules"][] = JText::sprintf('COM_JTICKETING_TAKEN_OF_MODULE_ND_BACKUP_PATH',  $modName, $backupPath);
			}
			else
			{
				$delStatus = JFolder::delete($overrideBs2ModulePath);
			}
		}

		// Copy
		$status = JFolder::copy($bs2ModulePath, $overrideBs2ModulePath);
		$statusMsg["modules"][] = JText::sprintf('COM_JTICKETING_COMPLETED_MODULE_OVERRIDE', "<b>" . $modName . "</b>");
	}

	/**
	 * Override the Modules
	 *
	 * @param   array   $statusMsg  The array of config values.
	 *
	 * @return  JModel
	 *
	 * @since   1.6
	 */
	public function displaySetup($statusMsg)
	{
		echo "<br/> =================================================================================";
		echo "<br/> " . JText::_("COM_JTICKETING_BS2_OVERRIDE_PROCESS_START");
		echo "<br/> =================================================================================";

		foreach ($statusMsg as $key => $extStatus)
		{
			echo "<br/> <br/><br/>*****************  " . JText::_("COM_JTICKETING_BS2_OVERRIDING_FOR") . " <strong>" . $key . "</strong> ****************<br/>";

			foreach($extStatus as $k => $status)
			{
				$index = $k+1;
				echo $index . ") " . $status . "<br/> ";
			}
		}

		echo "<br/> " . JText::_("COM_JTICKETING_BS2_OVERRIDING_DONE");
	}
}
