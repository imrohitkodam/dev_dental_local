<?php
/**
 *  @package    Quick2Cart
 *  @copyright  Copyright (c) 2009-2013 TechJoomla. All rights reserved.
 *  @license    GNU General Public License version 2, or later
 */
defined( '_JEXEC' ) or die( ';)' );

/*if user is on payment layout and log out at that time undefined order is is found
in such condition send to home page or provide error msg
*/

$params = JComponentHelper::getParams( 'com_jticketing' );
$this->gateways = $params->get('gateways');
$integration = $params->get('integration','','INT');
$jinput = JFactory::getApplication()->input;
$orderid = $jinput->get('orderid','','STRING');
$processor = $jinput->get('processor','','STRING');

$helperobj=new jticketingmainhelper();
$user=JFactory::getUser();
$jinput=JFactory::getApplication()->input;
$logedin_user = $user->id;
$session =JFactory::getSession();
$is_zero_amountOrder=$session->get('JT_is_zero_amountOrder');
$JT_coupon_code=$session->get('JT_coupon_code');

$paymentStatus['P']=JText::_('JT_PSTATUS_PENDING');$paymentStatus['C']=JText::_('JT_PSTATUS_COMPLETED');
$paymentStatus['D']=JText::_('JT_PSTATUS_DECLINED');$paymentStatus['E']=JText::_('JT_PSTATUS_FAILED');
$paymentStatus['UR']=JText::_('JT_PSTATUS_UNDERREVIW');$paymentStatus['RF']=JText::_('JT_PSTATUS_REFUNDED');
$paymentStatus['CRV']=JText::_('JT_PSTATUS_CANCEL_REVERSED');$paymentStatus['RV']=JText::_('JT_PSTATUS_REVERSED');
$billinfo = '';

$retryPayment_show= (isset($this->retryPayment_show)) ? $this->retryPayment_show : 1;
// Url for retry donation
$url = JUri::root() . "index.php?option=com_jticketing&tmpl=component&task=orders.retryPayment&order=" . $orderid . "&gateway_name="	;


if(isset($this->orderinfo))
{
	$coupon_code=$this->orderinfo[0]->coupon_code;
	if(isset($this->orderinfo[0]->address_type) && $this->orderinfo[0]->address_type == 'BT')
	{
		$billinfo = $this->orderinfo[0];
	}
	else if(isset($this->orderinfo[1]->address_type) && $this->orderinfo[1]->address_type == 'BT')
	{
			$billinfo = $this->orderinfo[1];
	}
}
if(isset($this->orderinfo))
{
	$where="  AND a.id=".$this->orderinfo['0']->order_id;
	if($this->orderinfo['0']->order_id)
	{
		$orderdetails = $helperobj->getallEventDetailsByOrder($where);
	}

	$this->orderinfo = $this->orderinfo[0];
}
$orders_email=( isset($this->orders_email) )?$this->orders_email:0;
$emailstyle="style='background-color: #cccccc'";

$order_currency =$params->get('currency');

//show login to guest if the option 'allow_buy_guest' is disable
if(!$user->id && !$params->get( 'allow_buy_guest' ) )
{
?>
<div class="well" >
	<div class="alert alert-error">
		<span ><?php echo JText::_('COM_JTICKETING_LOGIN'); ?> </span>
	</div>
</div>
<?php
	return false;
}

if(!isset($this->order_authorized))
{
?>
<div class="well" >
	<div class="alert alert-error">
		<span ><?php echo JText::_('COM_JTICKETING_ORDER_UNAUTHORISED'); ?> </span>
	</div>
</div>
<?php
	return false;
}

if(isset($this->orderview))
{
	$link=$session->get('backlink', '');
	if(!empty($orderdetails))
	{
		$link=$session->get('backlink', '');
		$freeticket=JText::_('ETICKET_PRINT_DETAILS_FREE');
		$freeticket=str_replace('[EVENTNAME]',$orderdetails[0]->title,$freeticket);
		if (!empty($billinfo))
			$freeticket=str_replace('[EMAIL]',$billinfo->user_email,$freeticket);
	}

?>
	<?php
	if(!empty($billinfo))
	{
		?>
		<div class="techjoomla-bootstrap">
			<h3 class=""><?php echo JText::_('JT_ORDERS_REPORT'); ?></h3>
				<div class="row-fluid">
					<?php
					$eventid=$session->get('JT_eventid',0);
							if($this->orderinfo->amount<=0)
							{
								echo '<div class="alert alert-info span12">'.$freeticket;
							}
					?>
				</div>
		</div>
	<?php
	}
}	?>


	<div class="techjoomla-bootstrap">
		<?php if(isset($this->orderview))
			{
				?>
				<div class="row-fluid">
					<div class="span12 ">

						<div class="pull-right">
							<input type="button" class="btn btn-success no-print" onclick="javascript:window.print()" value="<?php echo JText::_('COM_JTICKEING_PRINT');?>">
						</div>
					</div>
				</div>
		<?php
			}	?>

		<div class="row-fluid">
				<hr class="hr hr-condensed"/>
			<!--SHOW COMAPNY DETAILS ON LEFT SIDE-->
				<?php
						$company_name = $params->get('company_name','','STRING');
						$company_address = $params->get('company_address','','STRING');
						$company_vat_no = $params->get('company_vat_no','','STRING');

					?>

				<div class="">

					<div class="span8">
						<div class="span4">
								<?php
								if(isset($orderdetails[0]->image))
								{

									if($integration == 2)
									{
										$imagePath = 'media/com_jticketing/images/';
									}
									else
									{
										$imagePath = '';
									}

									$imagePath = JRoute::_(JUri::root() . $imagePath . $orderdetails[0]->image, false);
									?>
									<img class="jt_img-thumbnail img-polaroid" src="<?php echo $imagePath;?>" height="150px" width="150px">
							<?php	}	?>
						</div>
						<div class="span4">
								<h1><?php echo $orderdetails[0]->title; ?></h1>
						</div>
					</div>

					<div style="text-align:right">
							<div class="pull-right " >
									<div>
										<?php 	echo $company_name;	?>
									</div>
									<div>
										<?php 	echo $company_address;	?>
									</div>
									<div>
										<?php 	echo $company_vat_no;	?>
									</div>
							</div>
							<div style="clear:both"></div>
							<div class="pull-right " >
								<div>
									<strong><?php echo JText::_('COM_JTICKETING_ORDER_ID'); ?></strong>  <?php echo $this->orderinfo->orderid_with_prefix ; ?>
								</div>
								<!--SHOW ORDER STATUS-->
								<div class="row-fluid">
									<strong><?php echo JText::_('COM_JTICKETING_ORDER_PAYMENT_STATUS'); ?></strong>  <?php echo $paymentStatus[$this->orderinfo->status]; ?>
								</div>
								<!--SHOW ORDER STATUS-->
								<div>
									<strong><?php echo JText::_('COM_JTICKETING_ORDER_DATE'); ?></strong>  <?php
									echo $bookdate = JHtml::_('date', $this->orderinfo->cdate, 'Y-m-d h:i');


									 ; ?>

								</div>
							</div>
					</div>
				</div>
			<!--COMPANY DETAILS ENDS-->

			<!--USER INFO STRAT-->
		<?php	if(!empty($billinfo))
		{
			?>
			<div class="span12">
				<hr class="hr hr-condensed"/>
					<div class="pull-left " >
							<div>
								<?php echo $billinfo->firstname.' '.$billinfo->lastname;?>
							</div>
								<?php
								if(!empty($billinfo->vat_number))
									{
										?>
										<div>
											<?php echo $billinfo->vat_number;?>
										</div>
							<?php 	}	?>

							<div>
								<?php echo $billinfo->phone;?>
							</div>
							<div>
								<?php echo $billinfo->user_email;?>
							</div>
							<div>
								<?php echo $billinfo->address.' '.$billinfo->city;?>
							</div>
							<div>
								<?php echo $billinfo->zipcode.' '.$billinfo->state_code.' '.$billinfo->country_code;?>
							</div>

					</div>
			</div>
			<!--USER INFO ENDS-->
		<?php
		}	?>
		</div><!--ROW FLUID ENDS-->



		<!--TICKET INFO START-->
			<div class="row-fluid">
				<hr class="hr hr-condensed"/>
				<div class="span12 well"> <!-- cart detail start -->

					<h3><?php echo JText::_('COM_JTICKETING_TICKET_INFO'); ?></h3>
						<?php
								$price_col_style = "style=\"".(!empty($orders_email)?'text-align: right;' :'')."\"";
								$showoptioncol=0;
						?>
						<table width="100%" class="table">
							<tr>
								<th class="jtitem_num" width="5%" align="right" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo JText::_('COM_JTICKETING_NO'); ?></th>
								<th class="jtitem_name" align="left" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo  JText::_('COM_JTICKETING_PRODUCT_NAM'); ?></th>
								<th class="jtitem_qty" align="left" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo JText::_('COM_JTICKETING_PRODUCT_QTY'); ?></th>
								<th class="jtitem_price" align="left" <?php echo $price_col_style;  ?> ><?php echo JText::_('COM_JTICKETING_PRODUCT_PRICE'); ?></th>
								<th class="jtitem_tprice" align="left" <?php echo $price_col_style;  ?> ><?php echo JText::_('COM_JTICKETING_PRODUCT_TPRICE'); ?></th>
							</tr>


							<?php
								$tprice = 0;
								$i=1;

								foreach ($this->orderitems as $order)
								{
									$totalprice=0;
									if(!isset($order->price))
									$order->price=0;
							?>
								<tr class="row0">
									<td class="jtitem_num" ><?php echo $i++;?></td>
									<td class="jtitem_name" ><?php echo $order->order_item_name;?></td>

					<td class="jtitem_qty" ><?php echo $order->ticketcount;?></td>


									<td class="jtitem_price" <?php echo $price_col_style;  ?>><span><?php echo $helperobj->getFromattedPrice( number_format(($order->price),2),$order_currency);?></span></td>

									<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span><?php $totalprice=$order->price*$order->ticketcount;echo $helperobj->getFromattedPrice(number_format($totalprice,2),$order_currency); ?></span></td>
									<?php
										$tprice = $totalprice+$tprice;
									?>

								</tr>
						<?php
								}
						?>

							<tr>
								<td colspan="5">&nbsp;</td>
							</tr>
							<tr>
								<?php	$col=3;
									if($showoptioncol==1)
								{	 $col=3; }?>
								<td colspan="<?php echo $col;?>" > </td>
								<td class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_PRODUCT_TOTAL'); ?></strong></td>
								<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "cop_discount" ><?php echo $helperobj->getFromattedPrice( number_format($tprice,2),$order_currency); ?></span></td>
							</tr>
							<!--discount price -->

							<?php
								$coupon_code=trim($coupon_code);
								$total_amount_after_disc=$this->orderinfo->original_amount;
								if($this->orderinfo->coupon_discount>0)
								{
									$total_amount_after_disc=$total_amount_after_disc-$this->orderinfo->coupon_discount;
							?>
									<tr>
										<td colspan="<?php echo $col;?>" > </td>
										<td class="jtitem_tprice_label" align="left"><strong><?php echo sprintf(JText::_('COM_JTICKETING_PRODUCT_DISCOUNT'),$this->orderinfo->coupon_code); ?></strong></td>
										<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "coupon_discount" >
										<?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->coupon_discount,2),$order_currency);
										?>
										</span></td>
									</tr>
									<!-- total amt after Discount row-->
									<tr class="dis_tr" 		<?php
									// echo $cop_style;  ?>>
										<td colspan = "<?php echo $col;?>"></td>
										<td  class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_NET_AMT_PAY');?></strong></td>
										<td class="jtitem_tprice" <?php echo $price_col_style; ?> ><span id= "total_dis_cop" >
										<?php
											echo $helperobj->getFromattedPrice(number_format($total_amount_after_disc,2),$order_currency);
										?></span></td>
									</tr>

						<?php
								}

								if(isset($this->orderinfo->order_tax) and $this->orderinfo->order_tax>0)
								{
									$tax_json=$this->orderinfo->order_tax_details;
									$tax_arr=json_decode($tax_json,true);
								?>
									<tr>
										<td colspan="<?php echo $col;?>" > </td>
										<td class="jtitem_tprice_label" align="left"><strong><?php echo JText::sprintf('TAX_AMOOUNT',$tax_arr['percent']).""; ; ?></strong></td>
										<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "tax_amt" ><?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->order_tax,2),$order_currency); ?></span></td>
									</tr>
						<?php 	} 	?>

									<tr>
										<td colspan="<?php echo $col;?>" > </td>
										<td class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_ORDER_TOTAL'); ?></strong></td>
										<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><strong><span id="final_amt_pay"	name="final_amt_pay"><?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->amount,2),$order_currency); ?></span></td>
									</tr>

						</table>
						</div>

						<div id="gatewaysContent" style="display:none;">
							<div class="form-group">
								<label for="" class="col-lg-8 col-md-8 col-sm-8 col-xs-12 control-label">
									<?php echo JText::_('COM_JTICKETING_PAY_METHODS');?>
								</label>
										<?php

									if (empty($this->gateways))
										{
											echo JText::_('NO_PAYMENT_GATEWAY');
										}
									else
									{
										foreach($this->gateways as $gateway)
										{
											$plg_html .=
											'<div class="radio">
												<label>
													<input type="radio" name="gateways" id="'.$gateway.'" value="'.$gateway.'" aria-label="..." autocomplete="off">
														'.$gateway.'
												</label>
											</div>';
										}
										echo $plg_html;
									}
										 ?>
							</div>
						</div>


				</div><!--SAPN!2 ENDS-->
			</div><!--ROW FLUID ENDS-->
			</div><!--PRINT ENDS-->
		<!--TICKET INFO ENDS-->
	</div><!--bootstrap ends-->

<div style="clear:both;"></div>
<!--PAYMENT HIDDEN DATA WILL COME HERE -->
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"id="html-container" name=""></div>


<script type="text/javascript">

	techjoomla.jQuery(document).ready(function()
	{
		techjoomla.jQuery("input[name='gateways']").change(function()
		{
			var url1 = '<?php echo $url; ?>'+techjoomla.jQuery("input[name='gateways']:checked").val();

			techjoomla.jQuery('#html-container').empty().html('Loading...');
			techjoomla.jQuery.ajax({
				url: url1,
				type: 'GET',
				dataType: 'json',
				success: function(response)
				{
					techjoomla.jQuery('#html-container').removeClass('ajax-loading').html( response );
				}
				});
		});
	});

	function showpaymentgetways()
	{
		if (document.getElementById('gatewaysContent').style.display=='none')
		{
			document.getElementById('gatewaysContent').style.display='block';
		}

		return false;
	}

	function printDiv()
	{
		var printContents = document.getElementById('printDiv').innerHTML;
		var originalContents = document.body.innerHTML;

		document.body.innerHTML = printContents;

		window.print();

		document.body.innerHTML = originalContents;
	}
</script>
