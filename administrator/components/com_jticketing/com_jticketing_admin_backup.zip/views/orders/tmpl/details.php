<?php 
/**
 *  @package    Quick2Cart
 *  @copyright  Copyright (c) 2009-2013 TechJoomla. All rights reserved.
 *  @license    GNU General Public License version 2, or later
 */
defined( '_JEXEC' ) or die( ';)' );

/*if user is on payment layout and log out at that time undefined order is is found 
in such condition send to home page or provide error msg
*/

$params = JComponentHelper::getParams( 'com_jticketing' );
$helperobj = new jticketingmainhelper();
$user=JFactory::getUser();
$jinput=JFactory::getApplication()->input;
$logedin_user = $user->id;
$session =JFactory::getSession();

$is_zero_amountOrder=$session->get('JT_is_zero_amountOrder');
$JT_coupon_code=$session->get('JT_coupon_code');

$paymentStatus=$helperobj->getPaymentStatusArray();
$coupon_code=$this->orderinfo[0]->coupon_code ;
if(isset($this->orderinfo[0]->address_type))
{
if($this->orderinfo[0]->address_type == 'BT')
	$billinfo = $this->orderinfo[0];
else if($this->orderinfo[1]->address_type == 'BT')
	$billinfo = $this->orderinfo[1];
}
$where="  AND a.id=".$this->orderinfo['0']->id;

if($this->orderinfo['0']->id)
$orderdetails=$helperobj->getallEventDetailsByOrder($where);

$this->orderinfo = $this->orderinfo[0];
$orders_email=( isset($this->orders_email) )?$this->orders_email:0;
$emailstyle="style='background-color: #cccccc'";
			
$order_currency =$params->get('currency');	

if(!$user->id && !$params->get( 'allow_buy_guest' ) )
{
?>
<div class="well" >
	<div class="alert alert-error">
		<span ><?php echo JText::_('COM_JTICKETING_LOGIN'); ?> </span>
	</div>
</div>
<?php
	return false;
}


	if(isset($this->orderview)){
		
		$link=$session->get('backlink', '');
		if(!empty($orderdetails))
		{
			$link=$session->get('backlink', '');
			$freeticket=JText::_('ETICKET_PRINT_DETAILS_FREE');
			$freeticket=str_replace('[EVENTNAME]',$orderdetails[0]->title,$freeticket);
			if(isset($billinfo))
			$freeticket=str_replace('[EMAIL]',$billinfo->user_email,$freeticket);
		}


			$eventtitle=$helperobj->getEventTitle($this->orderinfo->id);
					
					
			?>
			<?php
				if(JVERSION>=3.0):	 
					if(!empty( $this->sidebar)): ?>
					<div id="sidebar" >
						<div id="j-sidebar-container" class="span2">
							<?php echo $this->sidebar; ?>
						</div>
						
					</div>	
					
				<div id="j-main-container" class="span10">	
			<?php else : ?>
				<div id="j-main-container">
			<?php endif;
		endif;	
		?>	
			<div class="techjoomla-bootstrap">
				<h3 class=""><?php echo JText::_('JT_ORDERS_REPORT'); ?></h3>
			
			</div>
			
		<?php
		}
	?>

<?php


if(isset($this->order_blocks)){
$order_blocks = $this->order_blocks;
}
else{
$order_blocks  = array ('1'=>'billing','2'=>'cart','3'=>'order');
}

if(isset($order_blocks))
{



?>

	<div class="techjoomla-bootstrap">
		<div class="row-fluid">

	
<?php if (in_array('order', $order_blocks)) { 

	?>
	<div class="span6 well">		
		<h3><?php echo JText::_('COM_JTICKETING_ORDER_INFO'); ?></h3>

			<table class="table" >
				<tr>
					<td><?php echo JText::_('COM_JTICKETING_ORDER_ID');?></td>	
					<td><?php echo $this->orderinfo->orderid_with_prefix;?></td>
				</tr>

				<tr>
					<td><?php echo JText::_('COM_JTICKETING_ORDER_DATE');?></td>	
					<td><?php echo $this->orderinfo->cdate;?></td>
				</tr>
				<tr>
					<td><?php echo JText::_('COM_JTICKETING_AMOUNT');?></td>	
					<td><span><?php echo $this->orderinfo->amount.' '.$params->get('currency');?></span></td>
				</tr>

				<tr>
					<td><?php echo JText::_('COM_JTICKETING_ORDER_USER');?></td>	
					<td>
					<?php 
					$table   = JUser::getTable();
					$user_id = intval( $this->orderinfo->user_id );
					if($user_id){
						$creaternm = '';
						if($table->load( $user_id ))
						{			
							$creaternm = JFactory::getUser($this->orderinfo->user_id);
						}
						echo (!$creaternm)?JText::_('COM_JTICKETING_NO_USER'): $creaternm->username; 
					 }
					 else{
						 echo $billinfo->user_email;
					 }
						 ?>
					</td>
				</tr>
				<tr>
					<td><?php echo JText::_('COM_JTICKETING_ORDER_IP');?></td>	
					<td><?php echo $this->orderinfo->ip_address;?></td>
				</tr>
				<?php if($this->orderinfo->processor){ ?>
				<tr>
					<td><?php echo JText::_('COM_JTICKETING_ORDER_PAYMENT');?></td>	
					<td>
					<?php 
						if(isset($this->orderinfo->processor)){
						$plugin = JPluginHelper::getPlugin('payment',  $this->orderinfo->processor);
						if(isset($plugin->params)){

						$pluginParams = new JRegistry();
						$pluginParams->loadString($plugin->params);
						$param = $pluginParams->get('plugin_name',  $this->orderinfo->processor); 
						echo $param;}
						else
						echo $this->orderinfo->processor;
						}
						
					?>
					</td>
				</tr>
				<?php } ?>
				
				<?php if($this->orderinfo->status){
					
					?>
				<tr>
					<td><?php echo JText::_('COM_JTICKETING_ORDER_PAYMENT_STATUS');?></td>	
					<td><?php echo $paymentStatus[$this->orderinfo->status];?></td>
				</tr>
				<?php } ?>
				
			</table>
		</div>
<?php } ?>	
<?php if(!empty($billinfo)){?>
<div id="jt_wholeCustInfoDiv" class="span6 well" >
<h3><?php echo JText::_('COM_JTICKETING_BILLIN_INFO'); ?></h3>
		
	<table class="table" >
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_FNAM');?></td>	
			<td><?php echo $billinfo->firstname;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_LNAM');?></td>	
			<td><?php echo $billinfo->lastname;?></td>
		</tr>
		<?php 
			if(!empty($billinfo->vat_number)){
		?>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_VAT_NUM');?></td>	
			<td><?php echo $billinfo->vat_number;?></td>
		</tr>
		
		<?php
		}
		?>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_ADDR');?></td>	
			<td><?php echo $billinfo->address;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_ZIP');?></td>	
			<td><?php echo $billinfo->zipcode;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_COUNTRY');?></td>	
			<td><?php echo $billinfo->country_code;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_STATE');?></td>	
			<td><?php echo $billinfo->state_code;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_CITY');?></td>	
			<td><?php echo $billinfo->city;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_PHON');?></td>	
			<td><?php echo $billinfo->phone;?></td>
		</tr>
		<tr>
			<td><?php echo JText::_('COM_JTICKETING_BILLIN_EMAIL');?></td>	
			<td><?php echo $billinfo->user_email;?></td>
		</tr>	
			
	</table>	


</div>  <!-- customer info end  id=qtc_wholeCustInfoDiv-->
<?php 
}
?>

</div>





<div class="row-fluid"> 

	<div class="span12 well"> <!-- cart detail start -->
<h3><?php echo JText::_('COM_JTICKETING_TICKET_INFO'); ?></h3>

	<?php
	$price_col_style = "style=\"".(!empty($orders_email)?'text-align: right;' :'')."\"";


	$showoptioncol=0;


	?>	
		<table width="100%" class="table">
			<tr>
				<th colspan="2"><?php echo JText::_('COM_JTICKETING_EVENT_NAME'); ?></th>	
				<th colspan="3"><?php echo $eventtitle; ?></th>			
			</tr>
			<tr>
				<th class="jtitem_num" width="5%" align="right" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo JText::_('COM_JTICKETING_NO'); ?></th>		
				<th class="jtitem_name" align="left" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo  JText::_('COM_JTICKETING_PRODUCT_NAM'); ?></th>
				<th class="jtitem_qty" align="left" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo JText::_('COM_JTICKETING_PRODUCT_QTY'); ?></th>
				<th class="jtitem_price" align="left" <?php echo $price_col_style;  ?> ><?php echo JText::_('COM_JTICKETING_PRODUCT_PRICE'); ?></th>
				<th class="jtitem_tprice" align="left" <?php echo $price_col_style;  ?> ><?php echo JText::_('COM_JTICKETING_PRODUCT_TPRICE'); ?></th>			
			</tr>
			
		<?php
			$tprice = 0;
			$i=1;
			
			foreach ($this->orderitems as $order){
				$totalprice=0;
				if(!isset($order->price))
				$order->price=0;
		?>
		<tr class="row0">
				<td class="jtitem_num" ><?php echo $i++;?></td>	
				<td class="jtitem_name" ><?php echo $order->order_item_name;?></td>
						
				<td class="jtitem_qty" ><?php echo $order->ticketcount;?></td>
			
				<td class="jtitem_price" <?php echo $price_col_style;  ?>><span><?php echo $helperobj->getFromattedPrice( number_format(($order->price),2),$order_currency);?></span></td>
				
				<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span><?php $totalprice=$order->price*$order->ticketcount;echo $helperobj->getFromattedPrice(number_format($totalprice,2),$order_currency); ?></span></td>
			<?php 
				$tprice = $totalprice+$tprice;
				?>
			
			</tr>		
		<?php
			}
		?>
			<tr >
				<td colspan="6">&nbsp;</td>
			</tr>	
			<tr>
				<?php	$col=3;
					if($showoptioncol==1)
				{	 $col=4; }?>
				<td colspan="<?php echo $col;?>" > </td>
				<td class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_PRODUCT_TOTAL'); ?></strong></td>
				<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "cop_discount" ><?php echo $helperobj->getFromattedPrice( number_format($tprice,2),$order_currency); ?></span></td>
			</tr>
			<!--discount price -->
			
			<?php 
				$coupon_code=trim($coupon_code);
				$total_amount_after_disc=$this->orderinfo->original_amount;
				if($this->orderinfo->coupon_discount>0)
				{
					
				
						
						$total_amount_after_disc=$total_amount_after_disc-$this->orderinfo->coupon_discount;			
					?>
						<tr>
							<td colspan="<?php echo $col;?>" > </td>
							<td class="jtitem_tprice_label" align="left"><strong><?php echo sprintf(JText::_('COM_JTICKETING_PRODUCT_DISCOUNT'),$this->orderinfo->coupon_code); ?></strong></td>
							<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "coupon_discount" >
							<?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->coupon_discount,2),$order_currency); 
							?>
							</span></td>
						</tr>
						<!-- total amt after Discount row-->
						<tr class="dis_tr" 		<?php 
						// echo $cop_style;  ?>>
							<td colspan = "<?php echo $col;?>"></td>
							<td  class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_NET_AMT_PAY');?></strong></td>
							<td class="jtitem_tprice" <?php echo $price_col_style; ?> ><span id= "total_dis_cop" >
							<?php 				
								echo $helperobj->getFromattedPrice(number_format($total_amount_after_disc,2),$order_currency); 
							?></span></td>
						</tr>
						
			<?php 
						
						
					}
			if(isset($this->orderinfo->order_tax) and $this->orderinfo->order_tax>0){
				$tax_json=$this->orderinfo->order_tax_details;
				$tax_arr=json_decode($tax_json,true);
			?>						
			<tr>
				<td colspan="<?php echo $col;?>" > </td>
				<td class="jtitem_tprice_label" align="left"><strong><?php echo JText::sprintf('TAX_AMOOUNT',$tax_arr['percent']).""; ; ?></strong></td>
				<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "tax_amt" ><?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->order_tax,2),$order_currency); ?></span></td>
			</tr>
			<?php } ?>
				
			<tr>
				<td colspan="<?php echo $col;?>" > </td>
				<td class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_ORDER_TOTAL'); ?></strong></td>
				<td class="jtitem_tprice" <?php echo $price_col_style;  ?>><strong><span id="final_amt_pay"	name="final_amt_pay"><?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->amount,2),$order_currency); ?></span></td>
			</tr>
			<?php
			if($this->orderinfo->amount<=0 and empty($this->orderview)){
			?>
			
			<tr>
				
				<td colspan="5">
		 		<?php
		 		$vars=new Stdclass();
		 		$user=JFactory::getUser();
		 		if(!$user->id)
		 		{
					$guest_email = "&email=".md5($billinfo->user_email);
				}
				$vars->url=JUri::root().substr(JRoute::_("index.php?option=com_jticketing&view=orders&layout=order".$guest_email."&orderid=".($this->orderinfo->orderid_with_prefix)."&processor={$pg_plugin}&Itemid=".$orderItemid,false),strlen(JUri::base(true))+1);
		
		 		?>
		 		
				<form action="<?php echo $vars->url; ?>" method="post">			
					<div class="jtspacercnf">
					<input type="submit" name="submit" class="button btn btn-primary" value="<?php echo JText::_('COM_JTICKETING_CONFIRM_ORDER');?>" />
					</div>
				</form>					
				</td>
			</tr>
			<?php
		}
	}
		?>
		</table>
		</div> 
	</div>	
	
	</div>	</div>
	
	


