<?php
/**
* @package	Jticketing
* @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
* @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
* @link http://www.techjoomla.com
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
global $mainframe;

$document =JFactory::getDocument();
jimport('joomla.filter.output');
jimport( 'joomla.utilities.date');
JHtml::_('behavior.modal', 'a.modal');
$input=JFactory::getApplication()->input;
$user=JFactory::getUser();
$jticketingmainhelper = new jticketingmainhelper();
$com_params=JComponentHelper::getParams('com_jticketing');
$integration = $com_params->get('integration');
$currency = $com_params->get('currency');
if(empty($user->id))
{

	echo '<b>'.JText::_('USER_LOGOUT').'</b>';
	return;

}

$user=JFactory::getUser();
$document =JFactory::getDocument();
?>



<?php
$payment_statuses=array('P'=>JText::_('JT_PSTATUS_PENDING'),
'C'=>JText::_('JT_PSTATUS_COMPLETED'),
		'D'=>JText::_('JT_PSTATUS_DECLINED'),
		'E'=>JText::_('JT_PSTATUS_FAILED'),
		'UR'=>JText::_('JT_PSTATUS_UNDERREVIW'),
		'RF'=>JText::_('JT_PSTATUS_REFUNDED'),
		'CRV'=>JText::_('JT_PSTATUS_CANCEL_REVERSED'),
		'RV'=>JText::_('JT_PSTATUS_REVERSED'),
);
$delmsg=JText::_('C_ORDER_DELETE_CONF');
$pstatus1=array();


$pstatus1=array('P'=>JText::_('JT_PSTATUS_PENDING'),
'C'=>JText::_('JT_PSTATUS_COMPLETED'),
		'D'=>JText::_('JT_PSTATUS_DECLINED'),
		'E'=>JText::_('JT_PSTATUS_FAILED'),
		'UR'=>JText::_('JT_PSTATUS_UNDERREVIW'),
		'RF'=>JText::_('JT_PSTATUS_REFUNDED'),
		'CRV'=>JText::_('JT_PSTATUS_CANCEL_REVERSED'),
		'RV'=>JText::_('JT_PSTATUS_REVERSED'),
);


if(JVERSION >= '1.6.0')
	$js_key="Joomla.submitbutton = function(task){ ";
else
	$js_key="function submitbutton( task ){";

	$js_key.="document.adminForm.action.value=task;


		if (task =='orders.remove')
		{
		var r=confirm('".$delmsg."');
			if (r!=true)
				return false;
		}";

	        if(JVERSION >= '1.6.0')
				$js_key.="	Joomla.submitform(task);";
			else
				$js_key.="document.adminForm.submit();";

	$js_key.="
	}
";

$js_key.="
function selectstatusorder(appid,processor,ele)
{
	document.getElementById('order_id').value = appid;
	document.getElementById('payment_status').value = ele.value;
	document.getElementById('processor').value = processor;
	document.adminForm.task.value='orders.save';
	task='orders.save';";
	if(JVERSION >='1.6.0')
	{
		$js_key.="
		Joomla.submitform(task);";
	}

	$js_key.="
	}";
	$document->addScriptDeclaration($js_key);

	$document->addScriptDeclaration($js_key);

	if(empty($this->lists['search_event']))
	{
		$this->lists['search_event']=$input->get('event','','INT');
	}

	$eventid=$input->get('event','','INT');
	$linkbackbutton='';

?>
<form action="" method="post" name="adminForm" id="adminForm">

	<div class="techjoomla-bootstrap">
		<div class="js-stools clearfix" id="well">
			<?php
				if(JVERSION>=3.0):
					if(!empty( $this->sidebar)): ?>
					<div id="sidebar" >
						<div id="j-sidebar-container" class="span2">
							<?php echo $this->sidebar; ?>
						</div>

					</div>
					<?php if(JVERSION>'3.0') {?>

					<?php } ?>
				<div id="j-main-container" class="span10">
			<?php else : ?>
				<div id="j-main-container">
			<?php endif;
		endif;
		?>
		<div id="filter-bar" class="btn-toolbar">

			<!--Filter by Search in id-->
			<div class="filter-search btn-group pull-left">
					<label for="filter_search" class="element-invisible"><?php echo JText::_('JSEARCH_FILTER');?></label>
					<input type="text" name="filter_search" id="filter_search" placeholder="<?php echo JText::_('JSEARCH_FILTER'); ?>" value="" title="<?php echo JText::_('JSEARCH_FILTER'); ?>" />
				</div>
				<div class="btn-group pull-left">
					<button class="btn hasTooltip" type="submit" title="<?php echo JText::_('JSEARCH_FILTER_SUBMIT'); ?>"><i class="icon-search"></i></button>
					<button class="btn hasTooltip" type="button" title="<?php echo JText::_('JSEARCH_FILTER_CLEAR'); ?>" onclick="document.id('filter_search').value='';this.form.submit();"><i class="icon-remove"></i></button>
				</div>


			<div class="btn-group pull-right hidden-phone">
				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php
				echo $this->pagination->getLimitBox();
				?>
			</div>
		</div>
		<?php if(JVERSION<3.0): ?>

		<div align="right">
			<table>
				<tr>
					<td></td>
					<td><?php
						$search_event = $mainframe->getUserStateFromRequest( 'com_jticketingsearch_event', 'search_event','', 'string' );
							echo JHtml::_('select.genericlist', $this->status_event, "search_event", 'class="ad-status" size="1" onchange="document.adminForm.submit();" name="search_event"',"value", "text", $search_event);
							echo JHtml::_('select.genericlist', $this->paymentStatus, "search_paymentStatus", 'class="ad-status" size="1" onchange="document.adminForm.submit();" name="search_paymentStatus"',"value", "text", strtoupper($this->lists['search_paymentStatus']));
						?>
					</td>
				</tr>
			</table>
		</div>
		<?php endif;?>

		<?php
		if(empty($this->Data) or $this->noeventsfound==1)
		{
			?>
			<div class="alert alert-info "><?php echo JText::_('NODATA');?></div>
			<?php
			return;
		}
		?>

			<table border="0" width="100%"	class="table table-striped table-hover ">
				<tr>
					<th width="1%" class="nowrap center">
								<input type="checkbox" name="checkall-toggle" value="" title="<?php echo JText::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
					</th>
					<th width="5%" align="center">
						<?php echo JHtml::_( 'grid.sort','ORDER_ID','id', $this->lists['order_Dir'], $this->lists['order']); ?>
					</th>
					<th width="5%" align="center">
						<?php  echo JText::_( 'COM_JTICKETING_BUYER_NAME' ); ?>
					</th>
					<th width="5%" align="center">
						<?php echo JText::_( 'TRANSACTION_ID' );?>
					</th>
					<th  align="center">
						<?php echo JHtml::_( 'grid.sort','PAY_METHOD','processor', $this->lists['order_Dir'], $this->lists['order']); ?>
					</th>
					<th align="center">
						<?php echo JText::_( 'NUMBEROFTICKETS_SOLD' );?>
					</th>
					<th align="center">
						<?php echo  JText::_( 'ORIGINAL_AMOUNT' ); ?>
					</th>
					<th align="center">
						<?php echo  JText::_( 'DISCOUNT_AMOUNT' ); ?>
					</th>
					<?php
				if($this->jticketingparams->get('allow_taxation')){
					?>
					<th align="center">
						<?php echo  JText::_( 'TAX_AMOUNT' ); ?>
					</th>
				<?php }?>
					<th align="center">
						<?php echo  JText::_( 'PAID_AMOUNT' ); ?>
					</th>
					<th align="center">
						<?php echo  JText::_( 'COM_JTICKETING_FEE' ); ?>
					</th>

					<th align="center">
						<?php echo  JText::_( 'COUPON_CODE_DIS' ); ?>
					</th>

					<th  align="center">
						<?php echo JHtml::_( 'grid.sort','PAYMENT_STATUS','status', $this->lists['order_Dir'], $this->lists['order']); ?>
					</th>
				</tr>
				<?php
				$i = $subfee = $totaltax = 0;
				$totalpaidamt = $totalnooftickets = $totalprice = $totalcommission = $totalearn = 0;
				$subdisc = 0;
				$subpaid = 0;
				foreach($this->Data as $data)
				{
					if($data->ticketscount<0)
					{
						$data->ticketscount=0;
					}

					if($data->original_amount<0)
					{
						$data->original_amount=0;
					}

					if($data->fee<0)
					{
						$data->fee=0;
					}

					$totalnooftickets=$totalnooftickets+$data->ticketscount;

					if($data->status=='C')
					{
						$totalpaidamt=$totalpaidamt+$data->original_amount;
					}

					$totalprice=$totalprice+$data->original_amount;
					$totalcommission=$totalcommission+$data->fee;
					$totaltax+=$data->order_tax;
					if($data->order_id)
					{
						$passorderid=$data->order_id;
					}
					else
					{
						$passorderid=$data->id;
					}

					$link_for_attendees = JRoute::_('index.php?option=com_jticketing&view=attendees&event='.$data->evid ."&order_id=".$passorderid."&Itemid=".$this->Itemid);
					$link_for_orders = JRoute::_('index.php?option=com_jticketing&view=orders&layout=order&event='.$data->evid .'&orderid='.$passorderid.'&Itemid='.$this->Itemid.'&tmpl=component');

					?>
					<tr class="">
						<td class="center">
							<?php echo JHtml::_('grid.id', $i, $data->id); ?>
						</td>
						<td  align="center">
							<a rel="{handler: 'iframe', size: {x: 600, y: 600}}" class="modal" href="<?php echo $link_for_orders;?>"><?php if($data->order_id) echo $data->order_id; else echo $data->id;?></a>
						</td>
						<td><?php
							if(!empty($data->id)){ echo $data->firstname . ' ' . $data->lastname ;} else echo '-';
							?>
						</td>
						<td><?php
							if(!empty($data->transaction_id)){ echo $data->transaction_id. ' ';} else echo '-';?>
						</td>


						<td align="center"><?php
							echo $data->processor;	?>
						</td>

						<td align="center">
							<?php echo $data->ticketscount ?>
						</td>

						<td align="center">
							<?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($data->original_amount),2),$currency);?>
						</td>

						<td align="center">
							<?php $subdisc += $discount = $data->coupon_discount;
									echo $jticketingmainhelper->getFromattedPrice( number_format(($discount),2),$currency);?>
						</td>

				<?php
					if($this->jticketingparams->get('allow_taxation'))
					{
				?>
						<td align="center">
							<?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($data->order_tax),2),$currency);?>
						</td>
				<?php
					}
				?>
						<td align="center">
							<?php $subpaid += $data->paid_amount;
								echo $jticketingmainhelper->getFromattedPrice( number_format(($data->paid_amount),2),$currency);?>
						</td>

						<td align="center">
							<?php $subfee+=$data->fee;
								echo $jticketingmainhelper->getFromattedPrice( number_format(($data->fee),2),$currency);?>
						</td>

						<td align="center">
							<?php if(!empty($data->coupon_code)){ echo $data->coupon_code. ' ';} else echo '-';?>
						</td>

						<td align="center">
							<?php if ( ($data->status) AND (!empty($data->processor)) )
									{
										$processor="'".$data->processor."'";
										echo JHtml::_('select.genericlist',$pstatus1,"pstatus".$i,'onChange="selectstatusorder('.$data->id.','.$processor.',this);"',"value","text",$data->status);
									}
									else
									{
										echo $payment_statuses[$data->status];
									}
									?>
						</td>
					</tr>
					<?php $i++;
				}
			?>


			<tr>
				<td colspan="5" align="right">
					<div class="jtright">
						<b><?php echo JText::_('TOTAL');?></b>
					</div>
				</td>
				<td align="center">
					<b><?php echo number_format($totalnooftickets, 0, '', '');?></b>
				</td>
				<td align="center">
					<b><?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($totalprice),2),$currency);?></b>
				</td>
				<td align="center">
					<b><?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($subdisc),2),$currency);?></b>
				</td>
				<?php
				if($this->jticketingparams->get('allow_taxation')){
				?>
				<td align="center">
					<b><?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($totaltax),2),$currency);?></b>
				</td>
				<?php
				}?>
				<td align="center">
					<b><?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($subpaid),2),$currency);?></b>
				</td>

				<td align="center">
					<b><?php  echo $jticketingmainhelper->getFromattedPrice( number_format(($subfee),2),$currency);?></b>
				</td>
				<td align="center" colspan="3"></td>
			</tr>

			<tfoot>
				<tr>
					<td colspan="10" align="center">
						<?php echo $this->pagination->getListFooter();  ?>
					</td>
				</tr>
			</tfoot>
		</table>


			<input type="hidden" name="option" value="com_jticketing" />
			<input type="hidden" id='order_id' name="order_id" value="" />
			<input type="hidden" id='payment_status' name="payment_status" value="" />
			<input type="hidden" id='processor' name="processor" value="" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
			<input type="hidden" name="controller" value="orders" />
			<input type="hidden" name="view" value="orders" />
			<input type="hidden" name="jversion" value="<?php echo JText::_( 'JVERSION'); ?>" />
			<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
			<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
		</div><!--row-fluid-->


	</div>
</form>



