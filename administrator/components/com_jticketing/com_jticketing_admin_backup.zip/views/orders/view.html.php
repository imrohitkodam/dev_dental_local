<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

/**
 * View for order
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingVieworders extends JViewLegacy
{
	/**
	 * Method to display calendar
	 *
	 * @param   object  $tpl  tpl
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function display($tpl = null)
	{
		$params = JComponentHelper::getParams('com_jticketing');
		$integration = $params->get('integration');
		$this->state      = $this->get('State');

		// Native Event Manager.
		if ($integration < 1)
		{
			$this->sidebar = JHtmlSidebar::render();

			JToolBarHelper::preferences('com_jticketing');

		?>
			<div class="alert alert-info alert-help-inline">
		<?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
		?>
			</div>
		<?php
			return false;
		}

		if (JVERSION >= 3.0)
		{
			JHtml::_('bootstrap.tooltip');
			JHtml::_('behavior.multiselect');
			JHtml::_('formbehavior.chosen', 'select');
		}

		$this->jticketingmainhelper = new jticketingmainhelper;
		$this->jticketingparams     = JComponentHelper::getParams('com_jticketing');
		$input = JFactory::getApplication()->input;
		$input->set('view', 'orders');
		$layout = JFactory::getApplication()->input->get('layout', 'default');
		$this->setLayout($layout);
		global $mainframe, $option;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');
		$user      = JFactory::getUser();
		$search_event = $mainframe->getUserStateFromRequest($option . 'search_event', 'search_event', '', 'string');
		$search_event = JString::strtolower($search_event);
		$search_paymentStatus = $mainframe->getUserStateFromRequest($option . 'search_paymentStatus', 'search_paymentStatus', '', 'string');
		$status_event = array();
		$eventlist           = $this->jticketingmainhelper->geteventnamesByCreator();
		$this->noeventsfound = 0;

		if (JVERSION < 3.0)
		{
			$status_event[] = JHtml::_('select.option', '0', JText::_('SELONE_EVENT'));
		}

		if (!empty($eventlist))
		{
			foreach ($eventlist as $key => $event)
			{
				$event_id       = $event->id;
				$event_nm       = $event->title;
				$status_event[] = JHtml::_('select.option', $event_id, $event_nm);
			}
		}
		elseif ($layout == 'my' or $layout == 'default')
		{
			$this->noeventsfound = 1;
		}

		$eventid = JRequest::getInt('event');
		$paymentStatus   = array();
		$paymentStatus[] = JHtml::_('select.option', 'P', JText::_('JT_PSTATUS_PENDING'));
		$paymentStatus[] = JHtml::_('select.option', 'C', JText::_('JT_PSTATUS_COMPLETED'));
		$paymentStatus[] = JHtml::_('select.option', 'D', JText::_('JT_PSTATUS_DECLINED'));
		$paymentStatus[] = JHtml::_('select.option', 'E', JText::_('JT_PSTATUS_FAILED'));
		$paymentStatus[] = JHtml::_('select.option', 'UR', JText::_('JT_PSTATUS_UNDERREVIW'));
		$paymentStatus[] = JHtml::_('select.option', 'RF', JText::_('JT_PSTATUS_REFUNDED'));
		$paymentStatus[] = JHtml::_('select.option', 'CRV', JText::_('JT_PSTATUS_CANCEL_REVERSED'));
		$paymentStatus[] = JHtml::_('select.option', 'RV', JText::_('JT_PSTATUS_REVERSED'));
		$lists['search_event']         = $search_event;
		$lists['search_paymentStatus'] = $search_paymentStatus;
		$Orders = $this->get('Orders');
		$Itemid = $input->get('Itemid', '', 'GET');

		if (empty($Itemid))
		{
			$Session = JFactory::getSession();
			$Itemid  = $Session->get("JT_Menu_Itemid");
		}

		$this->paymentStatus = $paymentStatus;
		$this->status_event  = $status_event;
		$this->Itemid        = $Itemid;
		$order_id            = $input->get('orderid', '', 'STRING');
		$oid                 = $this->jticketingmainhelper->getIDFromOrderID($order_id);
		$order               = $this->jticketingmainhelper->getOrderInfo($oid);
		JLoader::import('buy', JPATH_SITE . DS . 'components' . DS . 'com_jticketing' . DS . 'models');
		$jticketingModelbuy = new jticketingModelbuy;
		$this->billinfo     = $jticketingModelbuy->getuserdata($oid);
		$this->user         = JFactory::getUser();

		if ($this->user->id)
		{
			if (!empty($order))
			{
				$this->order_authorized = $this->jticketingmainhelper->getorderAuthorization($order["order_info"][0]->user_id);
				$this->orderinfo        = $order['order_info'];
				$this->orderitems       = $order['items'];
				$this->orderview        = 1;
				$this->order_authorized = 1;
			}
			else
			{
				$this->noOrderDetails = 1;
			}
		}
		else
		{
			$email = $input->get('email', '', 'STRING');

			if (md5($this->billinfo['BT']->user_email) != $email)
			{
				$this->noOrderDetails = 1;
			}
			else
			{
				$this->order_authorized = 1;
				$this->orderinfo        = $order['order_info'];
				$this->orderitems       = $order['items'];
				$this->orderview        = 1;
			}
		}

		jimport('joomla.html.pagination');

		// Get data from the model
		$data       = $this->get('Data');
		$pagination = $this->get('Pagination');

		// Push data into the template
		$this->Data       = $data;
		$this->pagination = $pagination;

		// FOR ORDARING
		$filter_order_Dir = $mainframe->getUserStateFromRequest('com_jticketing.filter_order_Dir', 'filter_order_Dir', 'desc', 'word');
		$filter_type      = $mainframe->getUserStateFromRequest('com_jticketing.filter_order', 'filter_order', 'id', 'string');
		$title              = '';
		$lists['order_Dir'] = '';
		$lists['order']     = '';
		$title = $mainframe->getUserStateFromRequest('com_jticketing' . 'title', '', 'string');

		if ($title == null)
		{
			$title = '-1';
		}

		$lists['title']     = $title;
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order']     = $filter_type;
		$this->lists = $lists;
		$JticketingHelper = new JticketingHelper;
		$JticketingHelper->addSubmenu('orders');

		if (JVERSION >= '3.0')
		{
			JHtmlBehavior::framework();
		}
		else
		{
			JHtml::_('behavior.mootools');
		}

		$this->setToolBar();

		if (JVERSION >= '3.0')
		{
			$this->sidebar = JHtmlSidebar::render();
		}

		$this->setLayout($layout);
		parent::display($tpl);
	}

	/**
	 * Method to set toolbar
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function setToolBar()
	{
		$document = JFactory::getDocument();
		$document->addStyleSheet(JUri::base() . 'components/com_jticketing/assets/css/jticketing.css');
		$bar = JToolBar::getInstance('toolbar');

		if (JVERSION >= '3.0')
		{
			JToolBarHelper::title(JText::_('COM_JTICKETING_COMPONENT') . JText::_('ORDER_VIEW'), 'folder');
		}
		else
		{
			JToolBarHelper::title(JText::_('COM_JTICKETING_COMPONENT') . JText::_('ORDER_VIEW'), 'icon-48-jticketing.png');
		}

		$layout = JFactory::getApplication()->input->get('layout', 'default');
		JToolbarHelper::deleteList('', 'orders.remove', 'JTOOLBAR_DELETE');

		if (JVERSION >= 3.0 and $layout == 'default')
		{
			JHtmlSidebar::setAction('index.php?option=com_jticketing');
			$sel_event = JText::_('SELONE_EVENT');
			$sel_pay = JText::_('SEL_PAY_STATUS');
			$status_event = $this->status_event;
			$paymentStatus = $this->paymentStatus;
			$option = JHtml::_('select.options', $status_event, 'value', 'text', $this->lists['search_event'], true);
			$option_pay = JHtml::_('select.options', $paymentStatus, 'value', 'text', $this->lists['search_paymentStatus'], true);
			JHtmlSidebar::addFilter($sel_event, 'search_event', $option);
			JHtmlSidebar::addFilter($sel_pay, 'search_paymentStatus', $option_pay);
		}

		JToolBarHelper::preferences('com_jticketing');
	}
}
