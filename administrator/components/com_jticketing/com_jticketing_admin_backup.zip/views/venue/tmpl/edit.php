<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Jticketing
 * @author     Techjoomla <kiran_l@techjoomla.com>
 * @copyright  2016 techjoomla
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

$path = JPATH_SITE . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'main.php';

if (!class_exists('Jticketingmainhelper'))
{
	JLoader::register('Jticketingmainhelper', $path);
	JLoader::load('Jticketingmainhelper');
}

$jticketingmainhelper  = new jticketingmainhelper;
$language_const = $jticketingmainhelper->getLanguageConstant();

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet(JUri::root() . 'media/com_jticketing/css/form.css');

// Add JS for getting Longitude nad latitude
$document->addScript(JUri::root() . 'components/com_jticketing/assets/js/venue.js');

$editId = $this->item->id;
$com_params          = JComponentHelper::getParams('com_jticketing');
$googlemap_apikey = $com_params->get('google_map_api_key');

?>
<script src="https://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places&key=<?php echo $googlemap_apikey;?>" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(document).ready(function() {

	Joomla.submitbutton = function (task)
	{
		if(task == 'venue.apply' || task == 'venue.save' || task == 'venue.save2new')
		{
			var venue_name = techjoomla.jQuery('input[name="jform[jform_name]"]:checked').val();
			var api_username = techjoomla.jQuery('input[name="jform[api_username]"]:checked').val();
			var api_password = techjoomla.jQuery('input[name="jform[api_password]"]:checked').val();
			var host_url = techjoomla.jQuery('input[name="jform[host_url]"]:checked').val();
			var source_sco_id = techjoomla.jQuery('input[name="jform[source_sco_id]"]:checked').val();
			var meeting_permission = techjoomla.jQuery('input[name="jform[meeting_permission]"]:checked').val();

			var onlines = techjoomla.jQuery('input[name="jform[online]"]:checked').val();
			var editId = "<?php echo $editId; ?>";

			if(editId && onlines == "0")
			{
				techjoomla.jQuery('#api_username').val('');
				techjoomla.jQuery('#api_password').val('');
				techjoomla.jQuery('#host_url').val('');
				techjoomla.jQuery('#source_sco_id').val('');
				techjoomla.jQuery('#meeting_permission').val('');
			}

			if (jQuery('input[name="jform[online]"]:checked').val() == 1)
			{
				if (!jQuery('#jformonline_provider').val())
				{
					error_html = "<?php echo jText::_("COM_JTICKETING_INVALID_FIELD")?> " + "<?php echo jText::_("COM_JTICKETING_ONLINE_EVENTS_PROVIDER")?>"

					jQuery("#system-message-container").html("<div class='alert alert-warning'>" + error_html + "</div>");

					return false;
				}

				if (!document.formvalidator.isValid('#provider_html'))
				{
					return false;
				}

				jsonObj = [];
				jQuery('#provider_html input').each(function() {
				var id = jQuery(this).attr("id");
				var output = jQuery(this).val();

				item = {}
				item ["id"] = id;
				item ["output"] = output;

				var source = jsonObj.push(item);
				jsonString = JSON.stringify(item);
				techjoomla.jQuery("#venue_params").val(jsonString);
				});
			}
			else
			{
				if (!jQuery("#country").val() || !jQuery("#state_id").val() || !jQuery("#jform_city").val() || !jQuery("#jform_zipcode").val() || !jQuery("#jform_address").val())
				{
					var error_html = '';
					if (!jQuery("#country").val())
					{
						error_html += "<?php echo jText::_("COM_JTICKETING_INVALID_FIELD")?> " + "<?php echo jText::_("COM_JTICKETING_FORM_LBL_VENUE_COUNTRY")?>"
					}
					if (!jQuery("#state_id").val())
					{
						error_html += "<br /> <?php echo jText::_("COM_JTICKETING_INVALID_FIELD")?> " + "<?php echo jText::_("COM_JTICKETING_FORM_LBL_VENUE_STATE")?>"
					}
					if (!jQuery("#jform_city").val())
					{
						error_html += "<br /> <?php echo jText::_("COM_JTICKETING_INVALID_FIELD")?> " + "<?php echo jText::_("COM_JTICKETING_FORM_LBL_VENUE_CITY")?>"
					}
					if (!jQuery("#jform_zipcode").val())
					{
						error_html += "<br /> <?php echo jText::_("COM_JTICKETING_INVALID_FIELD")?> " + "<?php echo jText::_("COM_JTICKETING_FORM_LBL_VENUE_ZIPCODE")?>"
					}
					if (!jQuery("#jform_address").val())
					{
						error_html += "<br /> <?php echo jText::_("COM_JTICKETING_INVALID_FIELD")?> " + "<?php echo jText::_("COM_JTICKETING_FORM_LBL_VENUE_ADDRESS")?>"
					}
					jQuery("#system-message-container").html("<div class='alert alert-warning'>" + error_html + "</div>");
					return false;
				}
			}
		}

		jQuery("#system-message-container").html("");
		Joomla.submitform(task, document.getElementById('venue-form'));
	}

	jQuery('#jformonline_provider').change(function()
	{
		var element = jQuery(this).val();

		jQuery.ajax({
		type:'POST',
		url:'index.php?option=com_jticketing&task=venue.getelementparams',
		data: {element:element,venue_id:jQuery("#venue_id").val()},
		datatype:"HTML",
		async: 'false',
		success:function(response){
			jQuery('#provider_html').html(response);
			var online = jQuery('input[name="jform[online]"]:checked').val();

			jQuery('#provider_html').css('display', 'none');
			if(online == 1)
			{
				jQuery('#provider_html').css('display', 'block');
			}
			},
			error: function() {
				jQuery('#provider_html').hide();
				return true;
				},
			});
		});
	});

	jQuery(window).load(function()
	{
		jQuery('input[name="jform[online]').click(function()
		{
			showOnlineOffline(jQuery('input[name="jform[online]"]:checked').val())
		});

		showOnlineOffline(jQuery('input[name="jform[online]"]:checked').val());

		<?php if($this->form->getValue('online_provider')){ ?>
				jQuery('#jformonline_provider').trigger('change');
		<?php } ?>
	})

	function showOnlineOffline(ifonline)
	{
		if (ifonline == 1)
		{
			jQuery("#jformonline_provider").closest(".control-group").show();
			jQuery("#provider_html").show();
			jQuery("#jformoffline_provider").hide();
		}
		else
		{
			jQuery("#jformonline_provider").closest(".control-group").hide();
			jQuery("#provider_html").hide();
			jQuery("#jformoffline_provider").show();
		}

	}
	// Google Map autosuggest  for location
	function initialize()
	{
		input = document.getElementById('jform_address');
		var autocomplete = new google.maps.places.Autocomplete(input);
	}

	google.maps.event.addDomListener(window, 'load', initialize);

</script>

<form
	action="<?php echo JRoute::_('index.php?option=com_jticketing&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="venue-form" class="form-validate">

	<div class="form-horizontal">
		<div class="row-fluid">
			<?php if ($googlemap_apikey == null)
			{?>
			<div class="span12 alert alert-warning">
				<?php echo JText::_('COM_JTICKETING_CONFIGURE_API_KEY');?>
			</div>
			<?php
			}?>
			<div class="span10 form-horizontal">
				<fieldset class="adminform">
				<input type="hidden" name="jform[id]" id="venue_id" value="<?php echo $this->item->id; ?>" />
				<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
				<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
				<input type="hidden" id="venue_params" name="params" value=""/>
				<?php if (empty($existingSco)){ ?>
					<input type="hidden" id="jform_seminar_room" name="jform[seminar_room]" value=""/>
					<input type="hidden" id="jform_seminar_room_id" name="jform[seminar_room_id]" value=""/>
				<?php }
				else{ ?>
					<input type="hidden" id="jform_seminar_room" name="jform[existingScoUrl]" value="<?php echo $existingSco; ?>"/>
					<input type="hidden" id="jform_seminar_room" name="jform[seminar_room]" value="<?php echo $existingScoUrl; ?>"/>

				<?php } ?>
				<?php if(empty($this->item->created_by)){ ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo JFactory::getUser()->id; ?>" />

				<?php }
				else{ ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo $this->item->created_by; ?>" />

				<?php } ?>
				<?php if(empty($this->item->modified_by)){ ?>
					<input type="hidden" name="jform[modified_by]" value="<?php echo JFactory::getUser()->id; ?>" />

				<?php }
				else{ ?>
					<input type="hidden" name="jform[modified_by]" value="<?php echo $this->item->modified_by; ?>" />
				<?php } ?>
				<?php echo $this->form->renderField('name'); ?>
				<?php echo $this->form->renderField('state'); ?>
				<?php echo $this->form->renderField('venue_category'); ?>

				<?php
					$componentParams = JComponentHelper::getParams('com_jticketing');
					$com_params = $componentParams->get('enable_online_events');


					if ($com_params == 1)
					{	 echo $this->form->renderField('online');
						 echo $this->form->renderField('online_provider');
					}
					?>
				<div id="provider_html">

				</div>
				<div id="jformoffline_provider">
					<?php echo $this->form->renderField('address'); ?>
					<?php echo $this->form->renderField('country'); ?>
					<?php echo $this->form->renderField('state_id'); ?>
					<?php echo $this->form->renderField('city'); ?>
					<?php echo $this->form->renderField('zipcode'); ?>
					<?php echo $this->form->renderField('longitude'); ?>
					<?php echo $this->form->renderField('latitude'); ?>
				</div>

				<?php echo $this->form->renderField('privacy'); ?>

				</fieldset>
			</div>
		</div>

		<input type="hidden" name="task" value=""/>
		<?php echo JHtml::_('form.token'); ?>

	</div>
</form>
