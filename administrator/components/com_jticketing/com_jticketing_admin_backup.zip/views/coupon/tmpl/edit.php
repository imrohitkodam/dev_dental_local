<?php
/**
 * @version     3.2
 * @package     com_jticketing
 * @copyright   Copyright (c) 2009-2015 TechJoomla. All rights reserved
 * @license     GNU General Public License version 2, or later
 * @author      Techjoomla <extensions@techjoomla.com> - http://www.techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
if (JVERSION > '3.0')
{
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');
}
// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_jticketing/assets/css/jticketing.css');
$input=JFactory::getApplication()->input;
$cid = $input->get( 'id','','INT' );

?>
<script type="text/javascript">
	js = jQuery.noConflict();
	js(document).ready(function()
	{
			techjoomla.jQuery("#jform_value").change(function()
				{
					checkforZeroAndalpha(this,'46','<?php echo JText::_('COM_JTICKETING_ENTER_NUMERICS'); ?>');
				});
	});

	Joomla.submitbutton = function(task)
	{
		if (task == 'coupon.apply')
		{
			var checkdate = checkdates();

			if(checkdate === 0)
			{
				return false;
			}

			var check = coupounduplicatecheck();

			if(check === 0)
			{
				return false;
			}
		}

		if (task == 'coupon.save')
		{
			var checkdate = checkdates();

			if(checkdate === 0)
			{
				return false;
			}

			var check = coupounduplicatecheck();

			if(check === 0)
			{
				return false;
			}
		}

		if (task == 'coupon.save2new')
		{
			var checkdate = checkdates();

			if(checkdate === 0)
			{
				return false;
			}

			var check = coupounduplicatecheck();

			if(check === 0)
			{
				return false;
			}
		}

		if (task == 'coupon.cancel')
		{
			Joomla.submitform(task, document.getElementById('coupon-form'));
		}
		else {

			if (task != 'coupon.cancel' && document.formvalidator.isValid(document.id('coupon-form')))
			{
				Joomla.submitform(task, document.getElementById('coupon-form'));
			}
			else
			{
				alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
			}
		}

		document.adminForm.submit();
	}


	function checkforZeroAndalpha(ele,allowedChar,msg)
	{
		if(ele.value <= 0)
		{
			alert("<?php echo JText::_('COM_JTICKETING_MIN_AMT_SHOULD_GREATER_MSG'); ?>");
			ele.value='';
		}
	}



	function coupounduplicatecheck()
	{
		var coupon_code=document.getElementById('jform_code').value;
		var cid=<?php if($cid) echo $cid;else echo "0"; ?>;
		var duplicatecode = 0;

		if(parseInt(cid)==0)
		{
			var url = "index.php?option=com_jticketing&tmpl=component&task=coupon.getcode&selectedcode="+coupon_code;
		}
		else
		{
			var url = "index.php?option=com_jticketing&task=coupon.getselectcode&tmpl=component&couponid="+cid+"&selectedcode="+coupon_code;
		}

		jQuery.ajax({
		url:url,
		type: 'GET',
		async:false,
		success: function(response) {
				if(parseInt(response)==1)
				{
					alert("<?php echo JText::_('COM_JTICKETING_DUPLICATE_COUPON');?>");
					duplicatecode = 1;
				}
				else
				{
					return 1;
				}
			}
		});

		if(duplicatecode === 1)
		{
			return 0;
		}
	}

	/* Function to check coupon valid from and valid to date*/
	function checkdates()
	{
		var selectedFromDate = document.getElementById('jform_from_date').value;
		var selectedToDate = document.getElementById('jform_from_date').value;
		startDate = new Date(selectedFromDate);
		startDate.setHours(0, 0, 0, 0);
		endDate = new Date(selectedToDate);
		endDate.setHours(0, 0, 0, 0);

		var today = new Date();
		today.setHours(0, 0, 0, 0);

		/* Coupon start date should not be less than todays date*/
		if(startDate < today)
		{
			alert("<?php	echo JText::_('COM_JTICKETING_DATE_START_ERROR_MSG');?>");
			return 0;
		}

		/* Coupon expiry date should not be less than todays date*/
		if(endDate < today)
		{
			alert("<?php	echo JText::_('COM_JTICKETING_DATE_END_ERROR_MSG');?>");
			return 0;
		}

		/* Coupon expiry date should not be less than from date*/
		if(document.getElementById('jform_exp_date').value !='')
		{
			if (document.getElementById('jform_from_date').value > document.getElementById('jform_exp_date').value)
			{
				alert("<?php echo JText::_("COM_JTICKETING_DATE_ERROR_MSG");?>");
				return 0;
			}
			else
			{
				return 1;
			}
		}
	}



</script>
<div class="sa-coupon"> <!--Remove this because it gives wraning<?php //echo SA_WRAPPER_CLASS;?>-->
<form action="<?php echo JRoute::_('index.php?option=com_jticketing&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="coupon-form" class="form-validate">

	<div class="form-horizontal">
		<?php //echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

		<?php //echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_JTICKETING_TITLE_COUPON', true)); ?>
		<div class="row-fluid">
			<div class="span10 form-horizontal">
			<fieldset class="adminform">

                <input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
				<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
				<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
				<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
				<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

				<?php if(empty($this->item->created_by)){ ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo JFactory::getUser()->id; ?>" />

				<?php }
				else{ ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo $this->item->created_by; ?>" />

				<?php } ?>
				<input type="hidden" name="jform[published]" value="<?php echo !empty($this->item->published) ? $this->item->published : '' ;?>" />
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('name'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('name'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('code'); ?></div>
				<div class="controls" id = "code"><?php echo $this->form->getInput('code'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('value'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('value'); ?></div>
				<div class="controls"><?php echo JText::_('COM_JTICKETING_FORM_VALUE_NOTE');?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('val_type'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('val_type'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('max_use'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('max_use'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('max_per_user'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('max_per_user'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('from_date'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('from_date'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('exp_date'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('exp_date'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('description'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('description'); ?></div>
			</div>
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('coupon_params'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('coupon_params'); ?></div>
			</div>
	</fieldset>
	</div>
		</div>
		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>
</div>
