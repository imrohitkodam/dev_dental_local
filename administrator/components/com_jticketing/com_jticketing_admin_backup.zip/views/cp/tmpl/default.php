<?php
   /**
    * @package		JTicketing
    * @version		$versionID$
    * @author		TechJoomla
    * @author mail	extensions@techjoomla.com
    * @website		http://techjoomla.com
    * @copyright	Copyright © 2009-2013 TechJoomla. All rights reserved.
    * @license		GNU General Public License version 2, or later
   */
   //no direct access
   defined( '_JEXEC' ) or die( 'Restricted access' );

   JHtml::_('behavior.tooltip');
   JHtml::_('behavior.framework');
   JHtml::_('behavior.modal');
   //load style sheet
   $document=JFactory::getDocument();
   $model=$this->getModel('cp');
   $mntnm_cnt=1;
   $i=0;
   ////////////////////
   $session =JFactory::getSession();
   $session->set('jticketing_from_date','');
   $session->set('jticketing_end_date', '');
   $session->set('statsforbar', '');
   $session->set('statsforpie', '');
   $session->set('statsfor_line_day_str_final', '');
   $session->set('statsfor_line_imprs', '');
   $session->set('statsfor_line_clicks', '');
   $session->set('periodicorderscount', '');
   $backdate = date('Y-m-d', strtotime(date('Y-m-d').' - 30 days'));

   $kk=0;


   ///////////////////////////////////

   $curdate='';
   foreach($this->AllMonthName as $AllMonthName)
   {
   	$AllMonthName_final[$i]=$AllMonthName['month'];
   	$curr_MON=$AllMonthName['month'];
   	$month_amt_val[$curr_MON]=0;
   		$i++;

   }

   $emptybarchart=1;
   foreach($this->MonthIncome as $MonthIncome)
   {
   $month_year='';
    $month_year=$MonthIncome->YEARNM;
   $month_name=$MonthIncome->MONTHSNAME;

   $month_int = (int)$month_name;
   $timestamp = mktime(0, 0, 0, $month_int);
   $curr_month=date("F", $timestamp);

   foreach($this->AllMonthName as $AllMonthName)
   {
   if(($curr_month==$AllMonthName['month']) and ($MonthIncome->amount) and ($month_year==$AllMonthName['year']))
   $month_amt_val[$curr_month]=str_replace(",",'',$MonthIncome->amount);

   if($MonthIncome->amount)
   $emptybarchart=0;
   else
   $emptybarchart=1;


   }

   }
    $month_amt_str=implode(",",$month_amt_val);
    $month_name_str=implode("','",$AllMonthName_final);
    $month_name_str="'".$month_name_str."'";
    $month_array_name=array();

     $js = "

     var linechart_imprs;
   	var linechart_clicks;
   	var linechart_day_str=new Array();

     function refreshViews()
   	{
   	jQuery.noConflict();
   		fromDate = document.getElementById('from').value;
   		toDate = document.getElementById('to').value;
   		fromDate1 = new Date(fromDate.toString());
   		toDate1 = new Date(toDate.toString());
   		difference = toDate1 - fromDate1;
   		days = Math.round(difference/(1000*60*60*24));
   		if(parseInt(days)<=0)
   		{
   			alert('".JText::_('COM_JTICKETING_START_DATE_LESS_EVENT_END_DATE_ERROR')."');
   			return;

   		}
   		//Set Session Variables
   		jQuery(document).ready(function(){
   		var info = {};
   		jQuery.ajax({
   			type: 'GET',
   			url: '?option=com_jticketing&task=cp.SetsessionForGraph&fromDate='+fromDate+'&toDate='+toDate,
   			dataType: 'json',
   			async:false,
   			success: function(data) {


   			}
   		});
    setTimeout(function(){},3000);
    //Make Chart and Get Data
   		jQuery.ajax({
   			type: 'GET',
   			url: '?option=com_jticketing&task=cp.makechart',
   			async:false,
   			dataType: 'json',
   			success: function(data) {
   			jQuery('#bar_chart_graph').html(''+data.barchart);

   				document.getElementById('pending_orders').value=data.pending_orders;
   				document.getElementById('confirmed_orders').value=data.confirmed_orders;
   				document.getElementById('refund_orders').value=data.refund_orders;
   				document.getElementById('periodic_orders').innerHTML = data.periodicorderscount;




   			google.setOnLoadCallback(drawPieChart);
   			drawPieChart();

   			}
   		});

   		});
   	}
   	";
     $document->addScriptDeclaration($js);


   ?>
<!--load google chart js-api-->
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<?php
   if(JVERSION>=3.0):

   	if(!empty( $this->sidebar)): ?>
<div id="sidebar">
   <div id="j-sidebar-container" class="span2">
      <?php echo $this->sidebar; ?>
   </div>
</div>
<div id="j-main-container" class="span10">
<?php else : ?>
<div id="j-main-container">
<?php endif;
   endif;
   ?>
<?php
   if(JVERSION<3.0)
   {
   ?>
<div class="techjoomla-bootstrap">
<!--START techjoomla-bootstrap-->
<?php
   }

   		$params = JComponentHelper::getParams('com_jticketing');
   		$integration = $params->get('integration');

   		// Native Event Manager.
   		if($integration<1)
   		{
   		?>
<div class="alert alert-info alert-help-inline">
   <?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
      ?>
</div>
<?php
   }
   ?>
<div class="row-fluid">
<div class="span8">
   <div class="row-fluid">
      <div class="span12">
         <div class="well">
            <?php
               echo "<div class='center'><h3>".JText::_('COM_JTICKETING_TOTAL_SALES').'&nbsp;'.$this->currency."";
               //TOtal Sales
               if($this->SalesArray)
               {
               	echo "&nbsp;".$this->SalesArray."</h3>";
               }
               else{

               	echo '<div style="font-size:15px">'.JText::_('COM_JTICKETING_NO_DATA_FOUND').'</div>';
               }
               echo "</div><hr>";
               if(isset($this->CommisionsArray))
               {
               	echo "<div><strong>".JText::_('COM_JTICKETING_TOTAL_COMMISION').$this->currency."</strong>";
               	//TOtal Sales
               	if($this->CommisionsArray)
               	{
               		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>".$this->CommisionsArray."</b>";


               	}
               	else{

               		echo '<div class="alert alert-warning">'.JText::_('COM_JTICKETING_NO_DATA_FOUND').'</div>';
               	}
               	echo "</div>";
               }

               ?>
            <?php
				$this->OrdersArray = array_filter($this->OrdersArray, "trim");
               //draw chart
               if(!empty($this->OrdersArray))
               {
               	?>
            <script type="text/javascript">
               google.load("visualization", "1", {packages:["corechart"]});
               google.setOnLoadCallback(drawChart);
               function drawChart() {
               	var data = google.visualization.arrayToDataTable([
               		['<?php echo JText::_("COM_JTICKETING_ORDERSDATA");?>', '<?php echo JText::_("COM_JTICKETING_ORDERSDATA");?>'],
               		['<?php echo JText::_("JT_PSTATUS_PENDING");?>',<?php echo !empty ($this->OrdersArray['P']) ? $this->OrdersArray['P']: 0;?>],
               		['<?php echo JText::_("JT_PSTATUS_COMPLETED");?>',<?php echo !empty($this->OrdersArray['C']) ? $this->OrdersArray['C'] : 0;?>],
               		['<?php echo JText::_("JT_PSTATUS_DECLINED");?>',<?php echo !empty($this->OrdersArray['D']) ? $this->OrdersArray['D'] : 0;?>],
               		['<?php echo JText::_("JT_PSTATUS_REFUNDED");?>', <?php echo !empty($this->OrdersArray['RF']) ? $this->OrdersArray['RF'] : 0;?>],
               		['<?php echo JText::_("JT_PSTATUS_FAILED");?>',<?php echo !empty($this->OrdersArray['F']) ? $this->OrdersArray['F'] : 0;?>],
               		['<?php echo JText::_("JT_PSTATUS_REVERSED");?>', <?php echo !empty($this->OrdersArray['RV']) ? $this->OrdersArray['RV'] : 0;?>],
               		['<?php echo JText::_("JT_PSTATUS_CANCEL_REVERSED");?>',<?php echo !empty($this->OrdersArray['CRV']) ? $this->OrdersArray['CRV'] : 0;?>],

               	]);
               	var options = {
               		title:'<?php echo JText::_("COM_JTICKETING_ORDERSDATA")?>',
               		slices: {

               			0: {color:'#E8B110'},
               			1: {color:'#9ABC32'},

               		},
               		backgroundColor:'transparent'
               	};
               	var chart = new google.visualization.PieChart(document.getElementById('chart_div2'));
               	chart.draw(data, options);
               }
            </script>
            <div id="chart_div2" style="width:100%;height:350px;"></div>
            <?php
               }
               else{
               	echo '<div><strong>'.JText::_('COM_JTICKETING_ORDERSDATA').'</strong></div>';
               	echo '<div class="alert alert-warning">'.JText::_('COM_JTICKETING_NO_DATA_FOUND').'</div>';
               }
               ?>
         </div>
         <!--well-->
      </div>
      <!--span12-->
   </div>
   <!--rowfluid-->
   <div class="row-fluid">
      <div class="span12" >
         <div class="well">
            <?php
               //draw chart
               if($this->ticketSalesLastweek)
               {
               ?>
            <script type="text/javascript">
               google.load("visualization", "1", {packages:["corechart"]});
               google.setOnLoadCallback(drawChart);
               function drawChart() {
               	var data = google.visualization.arrayToDataTable([
               		['<?php echo JText::_("COM_JTICKETING_DATE");?>', '<?php echo JText::_("COM_JTICKETING_TICKET_SALESLASTWEEK_PER_DAY_CNT");?>'],
               		<?php
                  foreach($this->ticketSalesLastweek as $mpd){
                  	echo "['".$mpd->date."',".$mpd->count."],";
                  }
                  ?>
               	]);
               	var options = {
               		title: '<?php echo JText::_("COM_JTICKETING_TICKET_SALESLASTWEEK_PER_DAY");?>',
               		vAxis: {title:'<?php echo JText::_("COM_JTICKETING_TICKET_SALESLASTWEEK_PER_DAY_CNT");?>'},
               		hAxis: {title:'<?php echo JText::_("COM_JTICKETING_DATE");?>'},
               		backgroundColor:'transparent',
               		color:'#3A87AD'

               	};
               	var chart = new google.visualization.LineChart(document.getElementById('chart_div4'));
               	chart.draw(data, options);
               }
            </script>
            <div id="chart_div4" style="width:auto;height:350px;"></div>
            <?php
               }
               else{
               	echo '<div><strong>'.JText::_('COM_JTICKETING_CHAT_MSGS_EXCHANGED').'</strong></div>';
               	echo '<div class="alert alert-warning">'.JText::_('COM_JTICKETING_NO_DATA_FOUND').'</div>';
               }
               ?>
         </div>
         <!--well-->
      </div>
      <!--span12-->
   </div>
   <!--rowfluid-->
   <div class="row-fluid">
      <div class="span12">
         <div class="well">
            <?php
               echo $title = "<p><strong>".JText::_('MONTHLY_ORDERS_INCOME')."&nbsp;".JHtml::tooltip(JText::_('MONTHLY_ORDERS_INCOME_DESC') . '.', JText::_('MONTHLY_ORDERS_INCOME'))."</strong></p>" ;
               echo $data = "<p>".$this->allincome."&nbsp;".$this->currency."</p>";
               echo $text = "<div id=\"monthin\" style=\"text-align: center; font-size: 16px; font-weight: bold;\"> </div>";
               ?>
            <script type="text/javascript" src="http://www.google.com/jsapi"></script>
            <script type="text/javascript">
               // Load the Visualization API and the piechart package.
               google.load('visualization', '1', {'packages':['corechart']});

               // Set a callback to run when the Google Visualization API is loaded.
               google.setOnLoadCallback(drawChart);
               // Create and populate the data table.
               function drawChart() {

               <?php if(!$this->allincome) {?>

               document.getElementById("monthin").innerHTML='<?php  echo '<h5>'.JText::_("NO_STATS").'<h5>'; ?>';
               return;
               <?php } ?>
               var data = new google.visualization.DataTable();

               var raw_dt1=[<?php echo $month_amt_str;?>];
               var raw_data = [raw_dt1];
               var Months = [<?php echo $month_name_str;?>];
               data.addColumn("string", "<?php echo JText::_('BAR_CHART_HAXIS_TITLE');?>");
               data.addColumn("number","<?php echo JText::_('BAR_CHART_VAXIS_TITLE').' ('.$this->currency.')';?>");
               data.addRows(Months.length);

               for (var j = 0; j < Months.length; ++j) {
                 data.setValue(j, 0, Months[j].toString());
               }
               for (var i = 0; i  < raw_data.length; ++i) {
                 for (var j = 1; j  <=(raw_data[i].length); ++j) {
               	data.setValue(j-1, i+1, raw_data[i][j-1]);

                 }
               }


               // Create and draw the visualization.
               new google.visualization.ColumnChart(document.getElementById("monthin")).
               	draw(data,
               		 {title:'<?php echo JText::_("MONTHLY_INCOME_MONTH");?>',
               		  width:'48%', height:300,
               		  fontSize:'13px',
               		  hAxis: {title: "<?php echo JText::_('BAR_CHART_HAXIS_TITLE');?>"},
               		  vAxis: {title: "<?php echo JText::_('BAR_CHART_VAXIS_TITLE').' ('.$this->currency.')';?>"}

               		  }
               	);
               }
            </script>
         </div>
         <!--well-->
      </div>
      <!--span6-->
   </div>
   <!--rowfluid-->
</div>
<!--span8-->
<div class="span4">
   <div class="well well-small">
      <div class="row-striped">
         <div class="panel-heading">
            <div class="row-fluid">
               <div class="newVersionNotice" id='newVersionNotice'>
                  <span>
                  <?php
                     $versionHTML = '<span class="label label-info">' .
                     				JText::_('COM_JTICKETING_HAVE_INSTALLED_VER') . ': ' . $this->version .
                     			'</span>';

                     	if ($this->latestVersion)
                     	{
                     		if ($this->latestVersion->version > $this->version)
                     			{
                     				$versionHTML = '<div class="alert alert-error">' .
                     									'<i class="icon-puzzle install"></i>' .
                     									JText::_('COM_JTICKETING_HAVE_INSTALLED_VER') . ': ' . $this->version .
                     									'<br/>' .
                     									'<i class="icon icon-info"></i>' .
                     									JText::_("COM_JTICKETING_NEW_VER_AVAIL") . ': ' .
                     									'<span class="jticketing_latest_version_number">' .
                     										$this->latestVersion->version .
                     									'</span>
                     									<br/>' .
                     									'<i class="icon icon-warning"></i>' .
                     									'<span class="small">' .
                     										JText::_("COM_JTICKETING_LIVE_UPDATE_BACKUP_WARNING") . '
                     									</span>' . '
                     								</div>
                     								<div class="left">
                     									<a href="index.php?option=com_installer&view=update" class="btn btn-small btn-primary">' .
                     										JText::sprintf('COM_JTICKETING_LIVE_UPDATE_TEXT', $this->latestVersion->version) . '
                     									</a>
                     									<a href="' . $this->latestVersion->infourl . '/?utm_source=clientinstallation&utm_medium=dashboard&utm_term=invitex&utm_content=updatedetailslink&utm_campaign=jticketing_ci' . '" target="_blank" class="btn btn-small btn-info">' .
                     										JText::_('COM_JTICKETING_LIVE_UPDATE_KNOW_MORE') . '
                     									</a>
                     								</div>';
                     			}
                     		}
                     		?>
                  </span>
               </div>
               <div>
                  <?php if (!$this->downloadid): ?>
                  <div class="">
                     <div class="clearfix pull-right">
                        <div class="alert alert-warning center">
                           <?php echo JText::sprintf('COM_JTICKETING_LIVE_UPDATE_DOWNLOAD_ID_MSG', '<a href="https://techjoomla.com/add-on-download-ids/" target="_blank">' . JText::_('COM_JTICKETING_LIVE_UPDATE_DOWNLOAD_ID_MSG2') . '</a>'); ?>
                        </div>
                     </div>
                  </div>
                  <?php endif; ?>
                  <div class="">
                     <div class="clearfix pull-right">
                        <?php echo $versionHTML; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="row-fluid">
            <div class="span12 alert alert-success"><?php echo JText::_('COM_JTICKETING_INTRO'); ?>
            </div>
         </div>
         <div class="row-fluid">
            <div class="span12">
               <p class="pull-right"><span class="label label-info"><?php echo JText::_('COM_JTICKETING_LINKS'); ?></span></p>
            </div>
         </div>
         <div class="row-striped">
            <div class="row-fluid">
               <div class="span12">
                  <a href="https://techjoomla.com/table/extension-documentation/documentation-for-jticketing/" target="_blank"><i class="icon-file"></i> <?php echo JText::_('COM_JTICKETING_DOCS');?></a>
               </div>
            </div>
            <div class="row-fluid">
               <div class="span12">
                  <a href="https://techjoomla.com/documentation-for-jticketing/jticketing-faqs.html" target="_blank">
                  <?php
                     if(JVERSION >= '3.0')
                     	echo '<i class="icon-help"></i>';
                     else
                     	echo '<i class="icon-question-sign"></i>';
                     ?>
                  <?php echo JText::_('COM_JTICKETING_FAQS');?>
                  </a>
               </div>
            </div>
            <div class="row-fluid">
               <div class="span12">
                  <a href="http://techjoomla.com/support/support-tickets" target="_blank">
                  <?php
                     if(JVERSION >= '3.0')
                     	echo '<i class="icon-support"></i>';
                     else
                     	echo '<i class="icon-user"></i>';
                     ?> <?php echo JText::_('COM_JTICKETING_TECHJOOMLA_SUPPORT_CENTER'); ?></a>
               </div>
            </div>
            <div class="row-fluid">
               <div class="span12">
                  <a href="http://extensions.joomla.org/extensions/extension-specific/jomsocial-extensions/21064" target="_blank">
                  <?php
                     if(JVERSION >= '3.0')
                     	echo '<i class="icon-quote"></i>';
                     else
                     	echo '<i class="icon-bullhorn"></i>';
                     ?> <?php echo JText::_('COM_JTICKETING_LEAVE_JED_FEEDBACK'); ?></a>
               </div>
            </div>
         </div>
         <br/>
         <!--
            <div class="row-fluid">
            	<div class="span12">
            		<p class="pull-right">
            			<span class="label label-warning"><?php echo JText::_('COM_JTICKETING_CHECK_LATEST_VERSION'); ?></span>
            		</p>
            	</div>
            </div>
            -->
         <br/>
         <div class="row-fluid">
            <div class="span12">
               <p class="pull-right">
                  <span class="label label-info"><?php echo JText::_('COM_JTICKETING_STAY_TUNNED'); ?></span>
               </p>
            </div>
         </div>
         <div class="row-striped">
            <div class="row-fluid">
               <div class="span4"><?php echo JText::_('COM_JTICKETING_FACEBOOK'); ?></div>
               <div class="span8">
                  <!-- facebook button code -->
                  <div id="fb-root"></div>
                  <script>(function(d, s, id) {
                     var js, fjs = d.getElementsByTagName(s)[0];
                     if (d.getElementById(id)) return;
                     js = d.createElement(s); js.id = id;
                     js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
                     fjs.parentNode.insertBefore(js, fjs);
                     }(document, 'script', 'facebook-jssdk'));
                  </script>
                  <div class="fb-like" data-href="https://www.facebook.com/techjoomla" data-send="true" data-layout="button_count" data-width="250" data-show-faces="false" data-font="verdana"></div>
               </div>
            </div>
            <div class="row-fluid">
               <div class="span4"><?php echo JText::_('COM_JTICKETING_TWITTER'); ?></div>
               <div class="span8">
                  <!-- twitter button code -->
                  <a href="https://twitter.com/techjoomla" class="twitter-follow-button" data-show-count="false">Follow @techjoomla</a>
                  <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
               </div>
            </div>
            <div class="row-fluid">
               <div class="span4"><?php echo JText::_('COM_JTICKETING_GPLUS'); ?></div>
               <div class="span8">
                  <!-- Place this tag where you want the +1 button to render. -->
                  <div class="g-plusone" data-annotation="inline" data-width="300" data-href="https://plus.google.com/102908017252609853905"></div>
                  <!-- Place this tag after the last +1 button tag. -->
                  <script type="text/javascript">
                     (function() {
                     var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                     po.src = 'https://apis.google.com/js/plusone.js';
                     var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                     })();
                  </script>
               </div>
            </div>
         </div>
         <br/>
         <div class="row-fluid">
            <div class="span12 center">
               <?php
                  $logo_path='<img src="'.JUri::base().'components/com_jticketing/assets/images/techjoomla.png" alt="TechJoomla" class="jbolo_vertical_align_top"/>';
                  ?>
               <a href='http://techjoomla.com/' taget='_blank'>
               <?php echo $logo_path;?>
               </a>
               <p><?php echo JText::_('COM_JTICKETING_COPYRIGHT'); ?></p>
            </div>
         </div>
      </div>
   </div>
   <!--END span4 -->
</div>
<!--END outermost row-fluid -->
<div class="row-fluid">
   <div class="span8">
      <div class="row-fluid">
         <div class="span12">
            <div class="well">
               <div class="container-fluid">
                  <div class="form-inline">
                     <div class="pull-left">
                        <label for="from">
                        <?php
                           echo JText::_('FROM_DATE');
                           ?></label>
                        <?php
                           echo JHtml::_('calendar', $backdate, 'from', 'from', '%Y-%m-%d', array('class'=>'input input-small'));
                           ?>
                     </div>
                     <div>
                        <label for="to"><?php
                           echo JText::_("TO_DATE");
                           ?></label>
                        <?php
                           echo JHtml::_('calendar', date('Y-m-d'), 'to', 'to', '%Y-%m-%d', array('class'=>'input input-small'));
                           ?>
                        <input id="btnRefresh" type="button" value=">>" class="btn btn-small btn-primary" onclick="refreshViews();"/>
                     </div>
                     <br><br>
                  </div>
               </div>
               <?php
                  if(!$this->tot_periodicorderscount)
                  $this->tot_periodicorderscount=0;
                  echo $title = "<p><strong>".JText::_('PERIODIC_INCOME')."&nbsp;".JHtml::tooltip(JText::_('PERIODIC_INCOME_DESC') . '.', JText::_('PERIODIC_INCOME'))."<span id='periodic_orders'>&nbsp;&nbsp;".$this->tot_periodicorderscount."&nbsp;&nbsp;&nbsp;"."</span></strong></p>" ;
                  echo $text = "<div id=\"chart_div\" style=\"text-align: center; font-size: 16px; font-weight: bold;\"></div>";
                  echo $text = "<div id=\"monthin\" style=\"text-align: center; font-size: 16px; font-weight: bold;\"> </div>";
                  ?>
               <?php
                  if($session->get('statsforpie', ''))
                  $statsforpie = $session->get('statsforpie', '');
                  else
                  $statsforpie = $this->statsforpie;
                  $currentmonth='';
                  $pending_orders=$confirmed_orders=$refund_orders=0;


                  if(empty($statsforpie))
                  {
                  $barchart=JText::_('NO_STATS');
                  $emptylinechart=1;
                  }
                  else
                  {
                  if(!empty($statsforpie['P']))
                  {

                  	 $pending_orders= $statsforpie['P'];


                  }

                  if(!empty($statsforpie['C']))
                  {

                  	 $confirmed_orders = $statsforpie['C'];


                  }

                  if(!empty($statsforpie['RF']))
                  {

                  	 $refund_orders = $statsforpie['RF'];


                  }



                  }

                  $emptylinechart=0;
                  if(!$pending_orders and !$confirmed_orders and !$refund_orders)
                  $emptylinechart=1;


                  ?>
               <script type="text/javascript" src="http://www.google.com/jsapi"></script>
               <script type="text/javascript">
                  // Load the Visualization API and the piechart package.
                  //google.load('visualization', '1', {'packages':['piechart']});

                  // Set a callback to run when the Google Visualization API is loaded.
                  google.setOnLoadCallback(drawPieChart);

                  // Callback that creates and populates a data table,
                  // instantiates the pie chart, passes in the data and
                  // draws it.
                  function drawPieChart() {
                  	var pending_orders=0;
                  	var confirmed_orders=0;
                  	var refund_orders=0;
                  	pending_orders=parseInt(document.getElementById("pending_orders").value);
                  	confirmed_orders=parseInt(document.getElementById("confirmed_orders").value);
                  	refund_orders=parseInt(document.getElementById("refund_orders").value);
                  	<?php if($emptylinechart) {?>
                  			document.getElementById("chart_div").innerHTML='<?php  echo '<h5>'.JText::_("NO_STATS").'<h5>'; ?>';
                  			return;
                  	<?php } ?>
                  	if(parseInt(pending_orders)==0 && parseInt(confirmed_orders)==0 && parseInt(refund_orders)==0)
                  	{
                  	document.getElementById("chart_div").innerHTML='<?php  echo '<h5>'.JText::_("NO_STATS").'<h5>'; ?>';
                  	return;
                  	}
                  // Create our data table.
                  	var data = new google.visualization.DataTable();
                  	data.addColumn('string', 'Event');
                  	data.addColumn('number', 'Amount');
                  	data.addRows([

                  		['<?php echo JText::_("JT_PSTATUS_PENDING");?>',pending_orders],
                  		['<?php echo JText::_("JT_PSTATUS_COMPLETED");?>',confirmed_orders],
                  		['<?php echo JText::_("JT_PSTATUS_REFUNDED");?>',refund_orders]
                  	]);

                  	var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
                  	chart.draw(data, { width: '48%', height: 300,is3D:true,fontSize:'10px',colors: ['#E8B110','#9ABC32','#0174DF'],  title: '<?php echo JText::_("PERIODIC_ORDERS").' '.$currentmonth;?> '});
                  }
               </script>
               <!-- Extra code for zone -->
               <input type="hidden" name="pending_orders" id="pending_orders" value="<?php if($pending_orders) echo $pending_orders; else echo '0'; ?>">
               <input type="hidden" name="confirmed_orders" id="confirmed_orders" value="<?php if($confirmed_orders) echo $confirmed_orders; else echo '0';  ?>">
               <input type="hidden" name="refund_orders" id="refund_orders" value="<?php if($refund_orders) echo $refund_orders; else echo '0'; ?>">
               <input type="hidden" name="confirmed_orders" id="confirmed_orders" value="<?php if($confirmed_orders) echo $confirmed_orders; else echo '0';  ?>">
               <!-- Extra code for zone -->
               <script type="text/javascript">
                  jQuery(document).ready(function(){
                  	document.getElementById("pending_orders").value=<?php if($pending_orders) echo $pending_orders; else echo '0'; ?>;
                  	document.getElementById("confirmed_orders").value=<?php if($confirmed_orders) echo $confirmed_orders; else echo '0'; ?>;
                  	document.getElementById("refund_orders").value=<?php  if($refund_orders) echo $refund_orders; else echo '0'; ?>;

                  });
               </script>
            </div>
            <!--well-->
         </div>
         <!--span10-->
      </div>
      <!--row-fluid-->
   </div>
   <?php
      if(JVERSION<3.0)
      {
      ?>
</div>
<?php
   }
   ?>
