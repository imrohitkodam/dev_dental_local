<?php

// no direct access
defined( '_JEXEC' ) or die( ';)' );

jimport( 'joomla.application.component.view');


class jticketingViewDashboard extends JViewLegacy
{

	function display($tpl = null)
	{
		$params = JComponentHelper::getParams('com_jticketing');
		$integration = $params->get('integration');

		// Native Event Manager.
		if($integration<1)
		{
		?>
			<div class="alert alert-info alert-help-inline">
		<?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
		?>
			</div>
		<?php
			return false;
		}

		$mainframe = JFactory::getApplication();
		$JticketingHelper=new JticketingHelperadmin();
		$JticketingHelper->addSubmenu('dashboard');
		if(JVERSION>='3.0')
		$this->sidebar = JHtmlSidebar::render();


		$this->_setToolBar();
		$com_params=JComponentHelper::getParams('com_jticketing');
		$this->currency = $com_params->get('currency');

		// Get data from the model
		$allincome =  $this->get( 'AllOrderIncome');
		$MonthIncome =  $this->get( 'MonthIncome');
		$AllMonthName = $this->get( 'Allmonths');
		$orderscount = $this->get( 'orderscount');

		$tot_periodicorderscount =$this->get( 'periodicorderscount');
		$this->tot_periodicorderscount=$tot_periodicorderscount ;
		$model=$this->getModel();
	    $statsforbar= $model->statsforbar();
		$this->statsforbar=$statsforbar;

		//calling line-graph function
	    $statsforpie= $model->statsforpie();
		$this->statsforpie=$statsforpie;


		// Get data from the model
		$this->allincome=$allincome;

		$this->MonthIncome=$MonthIncome;
		$this->AllMonthName=$AllMonthName;
		parent::display($tpl);

	}//function display ends here

	function _setToolBar()
	{
		$document =JFactory::getDocument();
		$document->addStyleSheet(JUri::base().'components/com_jticketing/css/jticketing.css');
		$bar =JToolBar::getInstance('toolbar');
		JToolBarHelper::title( JText::_( 'JT_SOCIAL' ), 'icon-48-jticketing.png' );
			JToolBarHelper::preferences('com_jticketing');

	}

}// class
