<?php
/**
 * @version    SVN: <svn_id>
 * @package    JGive
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

/**
 * View to edit
 *
 * @since  1.0
 */
class JticketingViewEvent extends JViewLegacy
{
	protected $state;

	protected $item;

	protected $form;

	protected $form_extra;

	/**
	 * Display the view
	 *
	 * @param   integer  $tpl  default
	 *
	 * @return  bollean
	 */
	public function display($tpl = null)
	{
		$this->app       = JFactory::getApplication();

		require_once JPATH_COMPONENT . '/models/event.php';
		$JticketingModelEvent = new JticketingModelEvent;
		$venue_exist = $JticketingModelEvent->checkVenueExistOrNot();
		$this->params = JComponentHelper::getParams('com_jticketing');
		$integration = $this->params->get('integration');
		$this->onlineEvents = $this->params->get('enable_online_events');

		// Native Event Manager.
		if ($integration < 1)
		{
			$this->sidebar = JHtmlSidebar::render();
			JToolBarHelper::preferences('com_jticketing');
		?>
			<div class="alert alert-info alert-help-inline">
		<?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
		?>
			</div>
		<?php
			return false;
		}

		$this->state = $this->get('State');
		$this->item  = $this->get('Item');
		$this->form  = $this->get('Form');

		if (!empty($this->item))
		{
			$input  = JFactory::getApplication()->input;
			$input->set("content_id", $this->item->id);

			$this->form_extra = array();
			$JticketingModelEvent = $this->getModel('event');

			// The function getFormExtra is defined in Tj-fields filterFields trait.
			$this->form_extra = $JticketingModelEvent->getFormExtra(
						array("category" => $this->item->catid,
							"clientComponent" => 'com_jticketing',
							"client" => 'com_jticketing.event',
							"view" => 'event',
							"layout" => 'edit')
							);

			$this->form_extra = array_filter($this->form_extra);
		}

		$selectedvenue = $this->item->venue;

		if (!empty($this->item->id))
		{
		$model = $this->getModel('event');
		$this->datas = $model->getvenuehtml($this->item);
		}

		// Get integration set
		$this->integration = $this->params->get('integration', '', 'INT');
		$this->collect_attendee_info_checkout = $this->params->get('collect_attendee_info_checkout');

		// Get form for extra fields.
		// $this->form_extra = $this->get('FormExtra');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		// Added by Sagar.
		$user  = JFactory::getUser();
		$input = JFactory::getApplication()->input;
		$eventid = $input->get('id', '', 'INT');
		$this->jticketingfrontendhelper = new jticketingfrontendhelper;
		$this->custom_fields = $this->jticketingfrontendhelper->getAllfields($eventid);

		$this->addToolbar();

		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 */
	protected function addToolbar()
	{
		// Some buttons are commented by manoj
		JFactory::getApplication()->input->set('hidemainmenu', true);

		$user  = JFactory::getUser();
		$isNew = ($this->item->id == 0);

		if (isset($this->item->checked_out))
		{
			$checkedOut	= !($this->item->checked_out == 0 || $this->item->checked_out == $user->get('id'));
		}
		else
		{
			$checkedOut = false;
		}

		$canDo = JticketingHelper::getActions();

		if (JVERSION >= '3.0')
		{
			if ($isNew)
			{
				JToolBarHelper::title(JText::_('COM_JTICKETING_COMPONENT') . JText::_('COM_JTICKETING_FORM_EVENT_HEADING_CREATE'), 'pencil-2');
			}
			else
			{
				JToolBarHelper::title(JText::_('COM_JTICKETING_COMPONENT') . JText::_('COM_JTICKETING_FORM_EVENT_HEADING_EDIT'), 'edit');
			}
		}
		else
		{
			if ($isNew)
			{
				JToolBarHelper::title(JText::_('COM_JTICKETING_COMPONENT') . JText::_('COM_JTICKETING_FORM_EVENT_HEADING_CREATE'), 'event.png');
			}
			else
			{
				JToolBarHelper::title(JText::_('COM_JTICKETING_COMPONENT') . JText::_('COM_JTICKETING_FORM_EVENT_HEADING_EDIT'), 'edit');
			}
		}

		// If not checked out, can save the item.
		if (!$checkedOut && ($canDo->get('core.edit')||($canDo->get('core.create'))))
		{
			JToolBarHelper::apply('event.apply', 'JTOOLBAR_APPLY');
			JToolBarHelper::save('event.save', 'JTOOLBAR_SAVE');
		}

		if (!$checkedOut && ($canDo->get('core.create')))
		{
			JToolBarHelper::custom('event.save2new', 'save-new.png', 'save-new_f2.png', 'JTOOLBAR_SAVE_AND_NEW', false);
		}

		/*
		If an existing item, can save to a copy.
		if (!$isNew && $canDo->get('core.create'))
		{
			JToolBarHelper::custom('event.save2copy', 'save-copy.png', 'save-copy_f2.png', 'JTOOLBAR_SAVE_AS_COPY', false);
		}
		*/

		if (empty($this->item->id))
		{
			JToolBarHelper::cancel('event.cancel', 'JTOOLBAR_CANCEL');
		}
		else
		{
			JToolBarHelper::cancel('event.cancel', 'JTOOLBAR_CLOSE');
		}
	}
}
