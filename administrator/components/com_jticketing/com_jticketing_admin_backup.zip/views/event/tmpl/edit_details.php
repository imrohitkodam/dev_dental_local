<?php
/**
 * @version     1.5
 * @package     com_jticketing
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Techjoomla <extensions@techjoomla.com> - http://techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

$jsondata = json_decode($this->item->jt_params,true);
?>
<script>
	jQuery(document).ready(function(){
		eventprovider = jQuery("input[name='jform[online_events]']:checked").val();
			if(eventprovider == '0')
			{
				jQuery("#ol_provider").hide();
			}
			if(eventprovider == '0')
			{
				jQuery("#meeting_url").hide();
			}
        jQuery('#adminForm').change(function(){
            selected_value = jQuery("input[name='jform[online_events]']:checked").val();
            if(selected_value)
            {
				jQuery("#ol_provider").show();
			}
			if(selected_value == '0')
			{
				jQuery("#ol_provider").hide();
			}
			if(selected_value)
            {
				jQuery("#meeting_url").show();
			}
			if(selected_value == '0')
			{
				jQuery("#meeting_url").hide();
			}
        });
    });
</script>
<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('title'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('title'); ?></div>
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('created_by'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('created_by'); ?></div>
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('catid'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('catid'); ?></div>
</div>

<div class="control-group">
	<?php $canState = false; ?>
	<?php $canState = $canState = JFactory::getUser()->authorise('core.edit.state','com_jticketing'); ?>

	<?php if(!$canState): ?>
		<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
		<?php
			$state_string = JText::_('COM_JTICKETING_UNPUBLISH');
			$state_value = 0;
			if($this->item->state == 1):
				$state_string = JText::_('COM_JTICKETING_PUBLISH');
				$state_value = 1;
			endif;
		?>
		<div class="controls"><?php echo $state_string; ?></div>
		<input type="hidden" name="jform[state]" value="<?php echo $state_value; ?>" />
	<?php else: ?>
		<div class="control-label"><?php echo $this->form->getLabel('state'); ?></div>
		<div class="controls"><?php echo $this->form->getInput('state'); ?></div>
	<?php endif; ?>

</div>


<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('access'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('access'); ?></div>
</div>

<div id="test">
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('image'); ?></div>
	<div class="controls">
		<?php echo $this->form->getInput('image'); ?>

		<div class="alert alert-warning">
			<?php
			//echo JText::_("COM_JTICKETING_FILE_UPLOAD_FILESIZE_WARNING");
			//echo "<br/>";
			//echo sprintf(JText::_("COM_JTICKETING_FILE_UPLOAD_FILESIZE_LIMIT"), $this->params->get('maxSizeLimit'));
			//echo "<br/>";
			//echo sprintf(JText::_("COM_JTICKETING_FILE_UPLOAD_ALLOWED_EXTENSIONS"), $this->params->get('allowedFileExtensions'));
			echo sprintf(JText::_("COM_JTICKETING_FILE_UPLOAD_ALLOWED_EXTENSIONS"), 'jpg, jpeg, png');
			?>
		</div>

		<?php if (!empty($this->item->image)) : ?>
			<?php
			$imagePath = 'media/com_jticketing/images/';
			$imagePath = JRoute::_(JUri::root() . $imagePath . $this->item->image, false);
			?>

			<div class="text-warning">
				<?php echo JText::_('COM_JTICKETING_EXISTING_IMAGE_MSG');?>
			</div>
			<div class="text-info">
				<?php echo JText::_('COM_JTICKETING_EXISTING_IMAGE');?>
			</div>
			<img class='img-polaroid com_jticketing_image_w98pc' src='<?php echo $imagePath;?>' alt="<?php echo $this->item->title; ?>" />

		<?php endif; ?>
	</div>
</div>

<input type="hidden" name="jform[image]" id="jform_image_hidden" value="<?php echo $this->item->image ?>" />

<!--
<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('short_description'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('short_description'); ?></div>
</div>
-->

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('long_description'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('long_description'); ?></div>
</div>

<script>
jQuery('#jformonline_provider').change(function() {
	var online_provider = jQuery(this).val();
	jQuery.ajax({
		type:'POST',
		url:'index.php?option=com_jticketing&task=getplugindata',
		data: {plug_name:online_provider,plug_type:'tjevents',plug_task:'renderplughtml'},
		datatype:"HTML",
		success:function(response){
			console.log(response);
				jQuery('#test').html(response);
			}
	});
});
</script>
