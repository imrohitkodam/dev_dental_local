<?php
/**
* @version     1.5
* @package     com_jticketing
* @copyright   Copyright (C) 2014. All rights reserved.
* @license     GNU General Public License version 2 or later; see LICENSE.txt
* @author      Techjoomla <extensions@techjoomla.com> - http://techjoomla.com
*/
// no direct access
defined('_JEXEC') or die;

$existingParams = json_decode($this->item->jt_params);
$eventId = '';
$existingUrl = '';
if (!empty($existingParams))
$existingUrl = $existingParams->event_url;
$jinput = JFactory::getApplication()->input;
if (!empty($jinput))
$eventId = $jinput->get('id', '', 'INT');
$com_params          = JComponentHelper::getParams('com_jticketing');
$googlemap_apikey = $com_params->get('google_map_api_key');
?>
<script>
	var onlineEvents = "<?php echo $this->onlineEvents;?>";
	var event_id =  "<?php echo $eventId; ?>";
	jQuery(document).ready(function(){

		if(!event_id)
		{
			validateVenue(this);
		}

		slectExistingEvent();
		var venuestatus = jQuery('input[type=radio][name="jform[online_events]"]:checked').val();
		if (venuestatus == '0' || onlineEvents == 0)
		{
			jQuery("#existingEvent").hide();
			jQuery("#venuechoice_id").hide();
		}
		else
		{
			jQuery("#existingEvent").show();
			jQuery("#venuechoice_id").show();
		}
		jQuery(".venueCheck").change(function()
		{
			slectExistingEvent();
		});

		var venue = document.getElementById("jform_venue").value;
		if(venue != '0')
		{
			jQuery("#event-location").hide();
			techjoomla.jQuery('#jform_location').removeAttr("required");
			techjoomla.jQuery('#jform_location').removeClass("required");

		}

		jQuery('input[type=radio][name="jform[online_events]"]').on('click', function(){
			var venuestatus = jQuery(this).val();
			if(venuestatus == '0')
			{
				jQuery("#existingEvent").hide();
				jQuery("#venuechoice_id").hide();
			}
		});
		jQuery('#venue_id').change(function() {

			var venuestatus = jQuery("label[for='jform_online_events0']").hasClass('active');
			var eventVal = jQuery("#jform_venue").val();

			if(venuestatus == true && eventVal != 0)
			{
				jQuery("#venuechoice_id").show();
				jQuery("#existingEvent").show();
			}

			if (eventVal == 0)
			{
				jQuery("#venuechoice_id, #existingEvent").hide();
			}

		});

		jQuery('input[type=radio][name="jform[venuechoice]"]').on('click', function(){
		var venuechoicestatus = jQuery('input[type=radio][name="jform[venuechoice]"]:checked').val();
			if(venuechoicestatus == 'existing')
			{
				jQuery("#existingEvent").show();
			}
			else
			{
				jQuery("#existingEvent").hide();
			}
		});

		jQuery('#jform_startdate').blur(function() {
				validateVenue(this);
		});

		jQuery('#event_start_time_hour').change(function() {
				validateVenue(this);
		});

		jQuery('#event_start_time_min').change(function() {
				validateVenue(this);
		});

		jQuery('#event_start_time_ampm').change(function() {
				validateVenue(this);
		});

		jQuery('#event_end_time_hour').change(function() {
				validateVenue(this);
		});

		jQuery('#event_end_time_min').change(function() {
				validateVenue(this);
		});

		jQuery('#event_end_time_ampm').change(function() {
				validateVenue(this);
		});
	});

	function existingEventSelection()
	{
		var venueId = document.getElementById("jform_venue").value;
		var venueurl = techjoomla.jQuery('#jform_existing_event :selected').val();
		techjoomla.jQuery("#event_url").val(venueurl);
		techjoomla.jQuery.ajax({
			type: 'POST',
			async: false,
			data:
			{
				'venueId':venueId,
				'venueurl':venueurl
			},
			dataType: 'json',
			url: 'index.php?option=com_jticketing&task=event.getScoID',
			success: function(data)
			{
				techjoomla.jQuery("#event_sco_id").val(data);
			},
			error: function(response)
			{
				// show ckout error msg
				console.log(' ERROR!!' );
				return;
			}
		});
	}

	function decideLocation()
	{
		jQuery("#event-location").hide();
		var venuevalue = jQuery('#jform_venue').val();

		if (venuevalue == '0')
		{
			jQuery("#event-location").show();
		}
		else
		{
			jQuery("#event-location").hide();
			techjoomla.jQuery('#jform_location').removeAttr("required");
			techjoomla.jQuery('#jform_location').removeClass("required");
		}
	}

	function eventCreate()
	{
		techjoomla.jQuery("#task").val("event.createSeminar");
		var values = techjoomla.jQuery('#adminForm').serialize();
		var flag = true;
		var base_url = "<?php echo JUri::base(); ?>";
		var url = base_url + "index.php?option=com_jticketing&task=event.createSeminar&tmpl=component";
		techjoomla.jQuery.ajax({
			type: 'POST',
			async: false,
			data: values,
			dataType: 'json',
			url: url,
			success: function(data)
			{
				console.log("success");

				if (data['status']['@attributes']['code'] == 'ok')
				{
					var venueurl = data['meeting_url'];
					var event_id = data['sco_id'];
					techjoomla.jQuery("#event_url").val(venueurl);
					techjoomla.jQuery("#event_sco_id").val(event_id);
					console.log("url" +venueurl);
					console.log("sco id" +event_id);
				}
				else
				{
					alert(data['error_message']);
					console.log(data);
					flag = false;
				}

			},
			error: function(response)
			{
				// show ckout error msg
				console.log(' ERROR!!' );
				return;
			}
		});

		if (flag == false)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	function slectExistingEvent()
	{
		var venueId = document.getElementById("jform_venue").value;
		var venuestatus = jQuery('input[type=radio][name="jform[online_events]"]:checked').val();
		var existingUrl = '';
		<?php if(!empty($existingUrl)) { ?>
		existingUrl="<?php echo $existingUrl;?>";
		<?php } ?>
		if(venueId != '0' && venuestatus == '1')
		{
			techjoomla.jQuery.ajax({
				type: 'POST',
				async: false,
				data:{
				'venueId':venueId
				},
				dataType: 'json',
				url: 'index.php?option=com_jticketing&task=event.getAllMeetings',
				success: function(data)
				{
					techjoomla.jQuery('#jform_existing_event option').remove();
					var option, index;
					var eventList = data['0']['my-meetings']['meeting'];
					if (eventList !== undefined && eventList !== null)
					{
						var op = "<option value='abcde' selected='selected'> <?php echo JText::_('COM_JTICKETING_FORM_SELECT_EXISTING_EVENT_OPTION'); ?> </option>";
						techjoomla.jQuery("#jform_existing_event").append(op);
						for(index = 0; index < eventList.length; ++index)
						{
							var eventvalue = eventList[index]['url-path'] .replace(/^\s+|\s+$/g, "");

							if(existingUrl==eventvalue)
							{
								var op="<option value='"+eventvalue+"' selected='selected'>"  +eventList[index]['name']+ " (" + eventList[index]['date-modified'] + ")"+ "</option>" ;
							}
							else
							{
								var op="<option value='"+eventvalue+"' >"  +eventList[index]['name']+ " (" + eventList[index]['date-begin'] + ")"+ "</option>" ;
							}

							techjoomla.jQuery('#jform_existing_event').append(op);
						}

						jQuery("#jform_existing_event").trigger("liszt:updated");
					}
				},
				error: function(response)
				{
					//techjoomla.jQuery('').show('slow');
					// show ckout error msg
					console.log(' ERROR!!' );
					return;
				}
			});
		}
	}
</script>
<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('startdate'); ?></div>
	<div class="controls">
		<?php
			//echo $this->form->getInput('startdate');

			for($i = 1; $i <= 12; $i++)
			{

				$hours[] = JHtml::_('select.option', $i, $i);
			}

			$minutes   = array();
			$minutes[] = JHtml::_('select.option', '00', '00');
			$minutes[] = JHtml::_('select.option', 15, '15');
			$minutes[] = JHtml::_('select.option', 30, '30');
			$minutes[] = JHtml::_('select.option', 45, '45');

			$amPmSelect   = array();
			$amPmSelect[] = JHtml::_('select.option', 'AM', 'am' );
			$amPmSelect[] = JHtml::_('select.option', 'PM', 'pm' );

			if(!isset($this->item->startdate) or $this->item->startdate=='0000-00-00 00:00:00')
			{
				$selectedmin = JFactory::getDate()->Format('i');
				$startAmPm   = JFactory::getDate()->Format('H') >= 12 ? 'PM' : 'AM';
				$final_start_event_date = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$selectedStartHour = JFactory::getDate()->Format('H');

			}
			else
			{
				$startAmPm   = JFactory::getDate($this->item->startdate)->Format('H');
				$startAmPm   = JHtml::date($this->item->startdate,JText::_('H'), true);
				$startAmPm  = $startAmPm >= 12 ? 'PM' : 'AM';
				$selectedmin = JFactory::getDate($this->item->startdate)->Format('i');
				$selectedmin = JHtml::date($this->item->startdate,JText::_('i'), true);
				$selectedStartHour = JFactory::getDate($this->item->startdate)->Format('H');
				$selectedStartHour = JHtml::date($this->item->startdate,JText::_('H'), true);

				if($selectedStartHour > 12)
				{
					$selectedStartHour = $selectedStartHour - 12;
				}

				$final_start_event_date = JFactory::getDate($this->item->startdate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$final_start_event_date = JHtml::date($this->item->startdate,JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'), true);
			}

			if($selectedStartHour=='00' or $selectedStartHour=='0')
			{
				$selectedStartHour = 12;
			}

			//static calendar($value, $name, $id, $format= '%Y-%m-%d', $attribs=null)
			echo $calender = JHtml::_('calendar', $final_start_event_date, 'jform[startdate]', 'jform_startdate', JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER'));

			echo "&nbsp;&nbsp;";

			echo $startHourSelect = JHtml::_('select.genericlist', $hours, 'event_start_time_hour', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $selectedStartHour, false );

			echo $startMinSelect = JHtml::_('select.genericlist', $minutes, 'event_start_time_min', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $selectedmin, false );

			echo $startAmPmSelect = JHtml::_('select.genericlist', $amPmSelect, 'event_start_time_ampm', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $startAmPm, false);

			echo "<br/>";

			echo "<i>" . JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER_DESC') . "</i>";
		?>
	</div>
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('enddate'); ?></div>
	<div class="controls">
		<?php
			//echo $this->form->getInput('enddate');

			$selectedStartHour = $selectedmin = $startAmPm = $end_date_event = '';

			// Set date to current date.
			$end_date_event = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));

			if(!isset($this->item->enddate))
			{
				$selectedmin = JFactory::getDate()->Format('i');
				$startAmPm   = JFactory::getDate()->Format('H') >= 12 ? 'PM' : 'AM';
				$final_end_event_date = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$selectedStartHour = JFactory::getDate()->Format('H');
			}
			else
			{
				$startAmPm   = JFactory::getDate($this->item->enddate)->Format('H');
				$startAmPm   = JHtml::date($this->item->enddate,JText::_('H'), true);
				$startAmPm  = $startAmPm >= 12 ? 'PM' : 'AM';
				$selectedmin = JFactory::getDate($this->item->enddate)->Format('i');
				$selectedmin = JHtml::date($this->item->enddate,JText::_('i'), true);
				$selectedStartHour = JFactory::getDate($this->item->enddate)->Format('H');
				$selectedStartHour = JHtml::date($this->item->enddate,JText::_('H'), true);

				if($selectedStartHour > 12)
				{
					$selectedStartHour = $selectedStartHour - 12;
				}

				$final_end_event_date = JFactory::getDate($this->item->enddate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$final_end_event_date = JHtml::date($this->item->enddate,JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'), true);
			}

			if($selectedStartHour=='00' OR $selectedStartHour=='0')
			{
				$selectedStartHour = 12;
			}

			echo $calendar = JHtml::_('calendar', $final_end_event_date, 'jform[enddate]', 'jform_enddate', JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER'));

			echo "&nbsp;&nbsp;";

			echo $endHourSelect = JHtml::_('select.genericlist', $hours, 'event_end_time_hour', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $selectedStartHour, false );

			echo $endMinSelect = JHtml::_('select.genericlist',  $minutes , 'event_end_time_min', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text',$selectedmin , false );

			echo $endAmPmSelect = JHtml::_('select.genericlist', $amPmSelect, 'event_end_time_ampm', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $startAmPm, false );

			echo "<br/>";

			echo "<i>" . JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER_DESC') . "</i>";
		?>
	</div>
</div>

<!--
<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('venueType'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('venueType'); ?></div>
</div>
-->

<?php
	$componentParams = JComponentHelper::getParams('com_jticketing');
	$com_params = $componentParams->get('enable_online_events');

	if ($com_params == 1)
	{	?>
		<div class="control-group">
			<div class="control-label"><?php echo $this->form->getLabel('online_events'); ?></div>
			<div class="controls"><?php echo $this->form->getInput('online_events'); ?></div>
		</div>
<!--
		<div class="control-group online_provider" id="" >
			<div class="control-label"><?php echo $this->form->getLabel('online_provider'); ?></div>
			<div class="controls"><?php echo $this->form->getInput('online_provider'); ?></div>
		</div>
-->
	<?php
	}
?>

<div class="control-group" id="venue_id">
	<div class="control-label"><?php echo $this->form->getLabel('venue'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('venue'); ?></div>
</div>
<div class="control-group" id="venuechoice_id">
	<div class="control-label"><?php echo $this->form->getLabel('venuechoice'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('venuechoice'); ?></div>
	<input type="hidden" name="event_url" class="event_url" id="event_url" value=""/>
	<input type="hidden" name="event_sco_id" class="event_sco_id" id="event_sco_id" value=""/>
</div>
<div class="control-group" id="existingEvent">
	<div class="control-label"><?php echo $this->form->getLabel('existing_event'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('existing_event'); ?></div>
</div>

<div class="control-group" id="event-location">
	<div class="control-label"><?php echo $this->form->getLabel('location'); ?></div>
	<div class="controls"><?php echo $this->form->getInput('location'); ?></div>
</div>
<script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places&key=<?php echo $googlemap_apikey;?>" type="text/javascript"></script>
<script type="text/javascript">

	// Google Map autosuggest  for location
	function initialize()
	{
		input = document.getElementById('jform_location');
		var autocomplete = new google.maps.places.Autocomplete(input);
	}

	google.maps.event.addDomListener(window, 'load', initialize);
</script>
