<?php
/**
 * @version    SVN: <svn_id>
 * @package    Jticketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access.
defined('_JEXEC') or die('Restricted access');

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_jticketing'))
{
	throw new Exception(JText::_('JERROR_ALERTNOAUTHOR'));
}

if (!defined('DS'))
{
	define('DS', DIRECTORY_SEPARATOR);
}

define('JTICKETING_WRAPPER_CLASS', 'jticketing-wrapper');

if (file_exists(JPATH_ROOT . '/media/techjoomla_strapper/tjstrapper.php'))
{
	require_once JPATH_ROOT . '/media/techjoomla_strapper/tjstrapper.php';
	TjStrapper::loadTjAssets('com_jticketing');
}

// Require_once( JPATH_COMPONENT.DS.'controller.php' );
require_once JPATH_SITE . DS . "components" . DS . "com_jticketing" . DS . "helpers" . DS . "main.php";
require_once JPATH_SITE . DS . "components" . DS . "com_jticketing" . DS . "helpers" . DS . "frontendhelper.php";

// Get bootstrap
if (JVERSION >= 3.0)
{
	jimport('joomla.html.html.bootstrap');
}

$doc = JFactory::getDocument();
$doc->addStyleSheet(JUri::base() . 'components' . DS . 'com_jticketing' . DS . 'assets' . DS . 'css' . DS . 'jticketing.css');

$JticketingHelperadmin = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'jticketing.php';

if (!class_exists('JticketingHelperadmin'))
{
	JLoader::register('JticketingHelperadmin', $JticketingHelperadmin);
	JLoader::load('JticketingHelperadmin');
}

$jticketingfrontendhelper = JPATH_ROOT . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'frontendhelper.php';

if (!class_exists('jticketingfrontendhelper'))
{
	JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
	JLoader::load('jticketingfrontendhelper');
}

$jteventHelper = JPATH_ROOT . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'event.php';

if (!class_exists('jteventHelper'))
{
	JLoader::register('jteventHelper', $jteventHelper);
	JLoader::load('jteventHelper');
}

$mediaHelperPath = JPATH_SITE . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'media.php';

if (!class_exists('jticketingMediaHelper'))
{
	JLoader::register('jticketingMediaHelper', $mediaHelperPath);
	JLoader::load('jticketingMediaHelper');
}

$JticketingmainHelper = JPATH_SITE . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'main.php';

if (!class_exists('jticketingmainhelper'))
{
	// Require_once $path;
	JLoader::register('jticketingmainhelper', $JticketingmainHelper);
	JLoader::load('jticketingmainhelper');
}

// Define constants
if (JVERSION < '3.0')
{
	// Icon constants.
	define('COM_JTICKETING_ICON_CHECKMARK', " icon-ok-sign");
	define('COM_JTICKETING_ICON_MINUS', " icon-minus");
	define('COM_JTICKETING_ICON_PLUS', " icon-plus-sign");
	define('COM_JTICKETING_ICON_EDIT', " icon-apply ");
	define('COM_JTICKETING_ICON_CART', " icon-shopping-cart");
	define('COM_JTICKETING_ICON_BACK', " icon-arrow-left");
	define('COM_JTICKETING_ICON_REMOVE', " icon-remove");

	// Define wrapper class
	define('Q2C_WRAPPER_CLASS', "q2c-wrapper techjoomla-bootstrap");

	// Other
	JHtml::_('behavior.tooltip');
}
else
{
	// Icon constants.
	define('COM_JTICKETING_ICON_CHECKMARK', " icon-checkmark");
	define('COM_JTICKETING_ICON_MINUS', " icon-minus-2");
	define('COM_JTICKETING_ICON_PLUS', " icon-plus-2");
	define('COM_JTICKETING_ICON_EDIT', " icon-pencil-2");
	define('COM_JTICKETING_ICON_CART', " icon-cart");
	define('COM_JTICKETING_ICON_BACK', " icon-arrow-left-2");
	define('COM_JTICKETING_ICON_REMOVE', " icon-cancel-2");

	// Define wrapper class
	define('COM_JTICKETING_WRAPPER_CLASS', "jticketing-wrapper");

	// Tabstate
	JHtml::_('behavior.tabstate');

	// Other
	JHtml::_('behavior.tooltip');

	// Bootstrap tooltip and chosen js
	JHtml::_('bootstrap.tooltip');
	JHtml::_('behavior.multiselect');
	JHtml::_('formbehavior.chosen', 'select');
}

$input = JFactory::getApplication()->input;
$get   = $input->get;

$com_params         = JComponentHelper::getParams('com_jticketing');
$siteadmin_comm_per = $com_params->get('siteadmin_comm_per');

// Include dependancies.
jimport('joomla.application.component.controller');

$controller = JControllerLegacy::getInstance('Jticketing');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
