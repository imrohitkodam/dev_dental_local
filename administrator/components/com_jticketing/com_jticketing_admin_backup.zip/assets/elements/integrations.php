<?php
/**
* @package		Broadcast
* @copyright	Copyright © 2012 - All rights reserved.
* @license		GNU/GPL
* @author		TechJoomla
* @author mail	extensions@techjoomla.com
* @website		http://techjoomla.com
*/

defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.pane');
jimport('joomla.application.component.helper');
jimport('joomla.filesystem.folder');
jimport('joomla.form.formfield');

class JFormFieldIntegrations extends JFormField
{
	function getInput()
	{
		return $this->fetchElement($this->name,$this->value,$this->element,$this->options['controls']);
	}

	function fetchElement($name,$value,&$node,$control_name)
	{
		$communityfolder = JPATH_SITE . '/components/com_community';
		$cbfolder = JPATH_SITE . '/components/com_comprofiler';
		$esfolder = JPATH_SITE . '/components/com_easysocial';
		$jevrents = JPATH_SITE . '/components/com_jevents';

		if($name == 'jform[integration]')
		{
			$options=array();
			$options[] = JHTML::_('select.option', '2', JText::_('COM_JTICKETING_NATIVE') );
			if(JFolder::exists($communityfolder))
				$options[] =	JHTML::_('select.option', '1', JText::_('COM_JTICKETING_JOMSOCIAL') );
			if(JFolder::exists($esfolder))
				$options[] = JHTML::_('select.option', '4', JText::_('COM_JTICKETING_EASYSOCIAL') );
			if(JFolder::exists($jevrents))
				$options[] = JHTML::_('select.option', '3', JText::_('COM_JTICKETING_JEVENT') );

			$fieldName = $name;
		}

		if($name == 'jform[socail_integration]')
		{
			$options=array();
			$options[] = JHTML::_('select.option', 'joomla', JText::_('COM_JTICKETING_INTERATION_JOOMLA') );
			if(JFolder::exists($communityfolder))
				$options[] =	JHTML::_('select.option', 'jomsocial', JText::_('COM_JTICKETING_INTERATION_JOMSOCIAL') );
			if(JFolder::exists($esfolder))
				$options[] = JHTML::_('select.option', 'EasySocial', JText::_('COM_JTICKETING_EASYSOCIAL') );
			if(JFolder::exists($cbfolder))
				$options[] = JHTML::_('select.option', 'cb', JText::_('COM_JTICKETING_INTERATION_CB') );

			$fieldName = $name;
		}

		$html = JHtml::_('select.genericlist',  $options, $fieldName, 'class="inputbox"  ', 'value', 'text', $value, $control_name.$name );

		return $html;
	}
}
