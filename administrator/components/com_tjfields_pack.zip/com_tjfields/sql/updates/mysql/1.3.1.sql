ALTER TABLE  `#__tjfields_fields` ADD  `showonlist` INT( 11 ) NOT NULL, `params` varchar(500);
