function sync_data(limitstart, app_id)
{
	jQuery('#sync_button').attr('disabled', 'disabled').html(" Loading...");
	jQuery.ajax(
	{
		type: "POST",
		url: "index.php?option=com_ajax&plugin=syncData&format=json",
		data: { limit: limitstart, app_id: app_id},
		dataType: 'json',
		success: function(results)
		{
			var totalCount = results.data[0].appData.length;
			jQuery.each( results.data[0].appData, function( key, value ) {
				createOrderAjax(value, key, totalCount);			
			});
		},
		error: function (){
			console("Something went wrong");
			jQuery('#sync_button').removeAttr('disabled').html(" Synchronize");
		}
	});
}

function ajax_stream(progressFile)
{
	if (!window.XMLHttpRequest)
	{
		document.getElementById("progressor1").innerHTML = "Your browser does not support the native XMLHttpRequest object.";
		document.getElementById("progressor1").className = document.getElementById("progressor1").className.replace(/\bbar\b/,'')
		return;
	}

	try
	{
		document.getElementById("progress_wrapper1").className += ' active';

		var xhr = new XMLHttpRequest();
		xhr.previous_text = '';

		xhr.onerror = function()
		{
			alert("Fatal Error.");
		};

		xhr.onreadystatechange = function() {
			try
			{
				if (xhr.readyState == 4)
				{
					// alert('[XHR] Done')
				}
				else if (xhr.readyState > 2)
				{
					var new_response = xhr.responseText.substring(xhr.previous_text.length);
					var result = JSON.parse( new_response );

					document.getElementById("progressor1").innerHTML = result.message;
					document.getElementById('progressor1').style.width = result.progress + "%";

					xhr.previous_text = xhr.responseText;
				}
			}
			catch (e)
			{
				alert("[XHR STATECHANGE] Exception: " + e);
			}

			if (result.progress == 100)
			{
				document.getElementById("progress_wrapper1").className = document.getElementById("progress_wrapper1").className.replace(/\bactive\b/,'')
			}
		};

		xhr.open("GET", progressFile, true);
		xhr.send();
	}
	catch (e)
	{
		alert("[XHR REQUEST] Exception: " + e);
	}
}
function createOrderAjax(result, key, totalCount)
{
	var postData = JSON.stringify(result);
	jQuery.ajax(
	{
		type: "POST",
		url: "index.php?option=com_ajax&plugin=createOrder&format=json",
		data: {data: postData},
		dataType: 'json',
		success: function(data)
		{
			console.log("RESULT");
			console.log(totalCount);
			console.log(key);
			if (totalCount == key + 1) {
				jQuery('#sync_button').removeAttr('disabled').html(" Synchronize");	
				console.log("success");
			}
		},
		error: function(error)
		{
			console.log(error);
		}
	});
}
