<?php
defined('_JEXEC') or die('Restricted access');
if(!defined('DS')){
define('DS',DIRECTORY_SEPARATOR);
}


class plgSystemjticketing_j3 extends JPlugin
{



	function jt_OnAfterEventCreate($order){

	}

	function jt_OnBeforeEventCreate($order){
	}

	function jt_OnAfterDeleteEvent($data,$eventid){

	}

	function jt_OnBeforeTicketEmail($toemail, $subject,$message){
	}

	function jt_OnBeforeProcessPayment($post,$order_id,$pg_plugin){
	}

	function jt_OnAfterProcessPayment($post,$order_id,$pg_plugin){
	}

	function jt_OnBeforeInvoiceEmail($billemail,$subject,$invoicehtml){

	}

	/*$order_id */

	function jt_OnAfterBillingsaveData($billingarr,$postdata,$order_id,$userid){



	}

	function jt_OnAfterCSVHeaderAttendee()
	{

	}

	function jt_OnAfterCSVBodyAttendee($order_id,$order_items_id)
	{

	}

}

