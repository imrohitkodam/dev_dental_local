<div class="row-fluid">
    <div id="footer" class="span12">
        <div>
            <a href="https://www.alledia.com">
                <img src="../media/<?php echo $this->option; ?>/images/alledia_logo_150x43.png" />
            </a>
        </div>
        <br />
        <div>
            Powered by&nbsp;
            <a href="https://www.alledia.com">Alledia</a>
        </div>
    </div>
</div>
