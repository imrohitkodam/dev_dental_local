<?php

/**
* @copyright	Copyright (C) 2009 - 2012 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package 		Rb_Ecommerce
* @contact		team@readybytes.in
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

// include 
include_once dirname(__FILE__).'/includes.php';