<?php

/**
 * @copyright	Copyright (C) 2009 - 2012 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @package 	Rb_Ecommerce
 * @subpackage	Front-end
 * @contact		team@readybytes.in
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/** 
 * Base Table
 * @author Gaurav Jain
 */
class Rb_EcommerceTable extends Rb_Table
{
	public $_component = RB_ECOMMERCE_COMPONENT_NAME;
}
