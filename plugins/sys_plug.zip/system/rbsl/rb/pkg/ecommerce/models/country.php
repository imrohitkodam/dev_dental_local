<?php

/**
* @copyright	Copyright (C) 2009 - 2012 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* @package 		Rb_Ecommerce
* @subpackage	Front-end
* @contact		team@readybytes.in
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/** 
 * Country Model
 * @author Gaurav Jain
 */
class Rb_EcommerceModelCountry extends Rb_EcommerceModel
{
}

class Rb_EcommerceModelformCountry extends Rb_EcommerceModelform { }