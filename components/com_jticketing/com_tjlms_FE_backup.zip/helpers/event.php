<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2016 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

// Component Helper
jimport('joomla.application.component.helper');

/**
 * JteventHelper
 *
 * @since  1.0
 */
class JteventHelper
{
	/**
	 * Constructor
	 *
	 * @since   1.0
	 */
	public function __construct()
	{
		// Add social library according to the social integration
		$Params = JComponentHelper::getParams('com_jticketing');
		$socialintegration = $Params->get('integrate_with', 'none');

		// Load main file
		jimport('techjoomla.jsocial.jsocial');
		jimport('techjoomla.jsocial.joomla');

		if ($socialintegration != 'none')
		{
			if ($socialintegration == 'JomSocial')
			{
				jimport('techjoomla.jsocial.jomsocial');
			}
			elseif ($socialintegration == 'EasySocial')
			{
				jimport('techjoomla.jsocial.easysocial');
			}
		}
	}

	/**
	 * cancal ordered ticket
	 *
	 * @param   integer  $order_id  order_id
	 *
	 * @return  object void
	 *
	 * @since   1.0
	 */
	public static function cancelTicket($order_id)
	{
		$path                     = JPATH_ROOT . '/components/com_jticketing/helpers/main.php';
		$jticketingfrontendhelper = JPATH_ROOT . '/components/com_jticketing/helpers/frontendhelper.php';

		if (!class_exists('jticketingmainhelper'))
		{
		JLoader::register('jticketingmainhelper', $path);
		JLoader::load('jticketingmainhelper');
		}

		if (!class_exists('jticketingfrontendhelper'))
		{
		JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
		JLoader::load('jticketingfrontendhelper');
		}

		require_once JPATH_ADMINISTRATOR . '/components/com_jticketing/controllers/attendee_list.php';
		require_once JPATH_ADMINISTRATOR . '/components/com_jticketing/models/attendee_list.php';
		require_once JPATH_ADMINISTRATOR . '/components/com_jticketing/models/orders.php';

		$JticketingModelattendee_List = new JticketingModelattendee_List;
		$JticketingModelattendee_List->cancelTicket($order_id);

		$paymentHelper = JPATH_SITE . '/components/com_jticketing/models/payment.php';

		if (!class_exists('jticketingModelpayment'))
		{
			JLoader::register('jticketingModelpayment', $paymentHelper);
			JLoader::load('jticketingModelpayment');
		}

		$orderobj = new jticketingModelorders;
		$status    = $orderobj->get_order_status($order_id);

		$obj       = new jticketingModelpayment;
		$orderobj->events_types_count_increase($order_id);
		$orderobj->update_order_status($order_id, 'D', 1);
	}

	/**
	 * Get Social library object
	 *
	 * @param   integer  $integration_option  this may be joomla,jomsocial,Easysocial
	 *
	 * @return  object social library
	 *
	 * @since   1.0
	 */
	public function getJticketSocialLibObj($integration_option = '')
	{
		$jtParams = JComponentHelper::getParams('com_jticketing');
		$integration_option = $jtParams->get('integrate_with', 'none');

		if ($integration_option == 'Community Builder')
		{
			$SocialLibraryObject = new JSocialCB;
		}
		elseif ($integration_option == 'JomSocial')
		{
			$SocialLibraryObject = new JSocialJomsocial;
		}
		elseif ($integration_option == 'Jomwall')
		{
			$SocialLibraryObject = new JSocialJomwall;
		}
		elseif ($integration_option == 'EasySocial')
		{
			$SocialLibraryObject = new JSocialEasysocial;
		}
		elseif ($integration_option == 'none')
		{
			$SocialLibraryObject = new JSocialJoomla;
		}

		return $SocialLibraryObject;
	}

	/**
	 * This will add pending entries to reminder queue
	 *
	 * @param   INT  $xrefid  xrefid
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function updateReminderQueue($xrefid ='')
	{
		$db = JFactory::getDBO();

		// Delete entries which are present for that reminder and still not sent
		$query = 'SELECT id FROM #__jticketing_queue
			WHERE sent=0';

		if ($xrefid)
		{
			$query .= " and event_id = " . $xrefid;
		}

		$db->setQuery($query);
		$reminder_queue_ids = $db->loadObjectList();

		if (!empty($reminder_queue_ids))
		{
			foreach ($reminder_queue_ids AS $qid)
			{
				// Update entries for existing reminder
				$this->addPendingEntriestoQueue($xrefid, $qid->id);
			}
		}
		else
		{
			$this->addPendingEntriestoQueue($xrefid);
		}
	}

	/**
	 * This will add pending entries to reminder queue
	 *
	 * @param   INT  $xrefid             xrefid
	 * @param   INT  $reminder_queue_id  reminder_queue_id
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function addPendingEntriestoQueue($xrefid = '', $reminder_queue_id = '')
	{
		$db = JFactory::getDBO();
		$input = JFactory::getApplication()->input;
		$jticketingmainhelper = new Jticketingmainhelper;
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$integration              = $jticketingmainhelper->getIntegration();
		$client                   = $jticketingfrontendhelper->getClientName($integration);

		/*$events = $jticketingmainhelper->getEvents();

		$query                = "select max(remtypes.days)
		from #__jticketing_reminder_types AS remtypes
		WHERE state=1";

		$db->setQuery($query);
		$days = $db->loadResult();
		$today        = date('Y-m-d');
		$date_expires = strtotime($today. ' +'.$days.'day');
		$date_expires = date('Y-m-d', $date_expires);

		$date_expires_old = strtotime($today. ' -2day');
		$date_expires_old = date('Y-m-d', $date_expires_old);

		$newevent = array();
		$i =0;

		foreach ($events AS $event)
		{

			$evstartdate = $event['startdate'];

			if ($evstartdate >= $date_expires_old and $evstartdate <= $date_expires)
			{
				$newevent[$i] =new stdclass;
				$newevent[$i]->startdate = $evstartdate;
				$newevent[$i]->eventid =  $event['id'];
				$i++;
			}
		}*/

		$paymenthelper = JPATH_ROOT . '/components/com_jticketing/models/payment.php';

		if (!class_exists('jticketingModelpayment'))
		{
			JLoader::register('jticketingModelpayment', $paymenthelper);
			JLoader::load('jticketingModelpayment');
		}

		$JticketingModelbuypath = JPATH_ROOT . '/components/com_jticketing/models/buy.php';

		if (!class_exists('JticketingModelbuy'))
		{
			JLoader::register('JticketingModelbuy', $JticketingModelbuypath);
			JLoader::load('JticketingModelbuy');
		}

		$JticketingModelbuy       = new JticketingModelbuy;
		$jticketingModelpayment   = new jticketingModelpayment;
		$Jticketingfrontendhelper = new Jticketingfrontendhelper;
		$Jticketingfrontendhelper->loadHelperClasses();
		$jticketingmainhelper = new jticketingmainhelper;
		$query                = "SELECT orderd.*,xref.eventid AS eventid
		FROM  #__jticketing_order AS orderd,  #__jticketing_integration_xref AS xref
		WHERE STATUS =  'C'
		AND orderd.event_details_id = xref.id";

		if ($xrefid)
		{
			$query .= " AND xref.id=" . $xrefid;
		}

		if (!empty($eventdt->eventid))
		{
			$query .= " AND xref.eventid=" . $eventdt->eventid;
		}

		$query .= " AND xref.source LIKE '" . $client . "'";

		$db->setQuery($query);
		$orders = $db->loadObjectList();

		if (!empty($orders))
		{
			foreach ($orders AS $orderdata)
			{
				$order = $jticketingmainhelper->getorderinfo($orderdata->id);
				$reminder_data              = '';
				$reminder_data              = $jticketingmainhelper->getticketDetails($orderdata->eventid, $order['items']['0']->order_items_id);
				$reminder_data->nofotickets = $orderdata->ticketscount;
				$reminder_data->totalprice  = $orderdata->amount;
				$reminder_data->eid         = $orderdata->eventid;

				if ($reminder_queue_id)
				{
					$reminder_data->reminder_queue_id         = $reminder_queue_id;
				}

				$eventupdate = $jticketingModelpayment->addtoReminderQueue($reminder_data, $order);
			}
		}
	}

	/**
	 * Function to idetify passed field hidden or not from component config.
	 *
	 * @param   String  $field_name  Description
	 *
	 * @return void
	 */
	public function filedToShowOrHide($field_name)
	{
		$params       = JComponentHelper::getParams('com_jticketing');
		$creatorfield = array();
		$creatorfield = $params->get('creatorfield');

		$show_selected_fields = $params->get('show_selected_fields');

		if ($show_selected_fields AND (!empty($creatorfield)))
		{
			// If field is hidden & not to show on form
			if (in_array($field_name, $creatorfield))
			{
				return false;
			}
		}

		// If field is to show on form
		return true;
	}

	/**
	 * Get Event Categories description
	 *
	 * @param   String  $firstOption  Description
	 *
	 * @return  Option
	 */
	public function getEventCategories($firstOption = '')
	{
		$db = JFactory::getDBO();
		$app     = JFactory::getApplication();
		$com_params = JComponentHelper::getParams('com_jticketing');
		$integration = $com_params->get('integration');

		if ($integration == 1)
		{
			$source = 'com_community';
		}
		elseif ($integration == 2)
		{
			$source = 'com_jticketing';
		}
		elseif ($integration == 3)
		{
			$source = 'com_jevents';
		}
		elseif ($integration == 4)
		{
			$source = 'com_easysocial';
		}

		if ($source == 'com_jticketing' or  $source == 'com_jevents')
		{
			$categories  = JHtml::_('category.options', $source, array('filter.published' => array(1)));
			$cat_options = array();

			if ($app->isSite() OR JVERSION < 3.0)
			{
				$cat_options[] = JHtml::_('select.option', '0', JText::_('COM_JTICKETING_EVNT_CATEGORIES'));
			}

			if (!empty($categories))
			{
				foreach ($categories as $category)
				{
					if (!empty($category))
					{
						if (JVERSION >= 3.0)
						{
							$cat_options[] = JHtml::_('select.option', $category->value, $category->text);
						}
						else
						{
							$cat_options[] = JHtml::_('select.option', $category->get('value'), $category->get('text'));
						}
					}
				}
			}
		}
		else
		{
			if ($source == 'com_easysocial')
			{
				$query = "Select id,title FROM #__social_clusters_categories WHERE type LIKE 'event'";
			}

			if ($source == 'com_community')
			{
				$query = "Select id,name AS title FROM #__community_events_category";
			}

			$db->setQuery($query);
			$categories = $db->loadObjectlist();

			if (!empty($categories))
			{
				$cat_options[] = JHtml::_('select.option', "0", "All Category");

				foreach ($categories as $category)
				{
					$cat_options[] = JHtml::_('select.option', $category->id, $category->title);
				}
			}
		}

		return $cat_options;
	}

	/**
	 * EventsToShowOptions description
	 *
	 * @return  Array  Options
	 */
	public function eventsToShowOptions()
	{
		$options = array();
		$app     = JFactory::getApplication();

		if ($app->isSite() OR JVERSION < 3.0)
		{
			$options[] = JHtml::_('select.option', '', JText::_('COM_JTK_EVNT_TO_SHOW'));
		}

		$options[] = JHtml::_('select.option', '', JText::_('COM_JTICKETING_RESET_FILTER_TO_ALL'));
		$options[] = JHtml::_('select.option', 'featured', JText::_('COM_JTK_FEATURED_CAMP'));
		$options[] = JHtml::_('select.option', '0', JText::_('COM_JTK_FILTER_ONGOING'));
		$options[] = JHtml::_('select.option', '-1', JText::_('COM_JTK_FILTER_PAST_EVNTS'));

		return $options;
	}

	/**
	 * SaveCustom Attendee fields description
	 *
	 * @param   Array  $ticket_fields  Tickets fiedls
	 * @param   INT    $eventid        Event Id
	 * @param   INT    $userid         User Id
	 *
	 * @return void
	 */
	public function saveCustomAttendee_fields($ticket_fields, $eventid, $userid)
	{
		// Get xref id for this event
		$jticketingmainhelper = new jticketingmainhelper;
		$XrefID               = $jticketingmainhelper->getEventrefid($eventid);

		$db                       = JFactory::getDBO();
		$jticketingfrontendhelper = JPATH_ROOT . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'frontendhelper.php';

		if (!class_exists('jticketingfrontendhelper'))
		{
			JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
			JLoader::load('jticketingfrontendhelper');
		}

		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$fields_selected          = $fields_in_DB = '';
		$attendee_fields          = $jticketingfrontendhelper->getAllfields($eventid);

		// Firstly Delete Attendee Fields That are Removed
		foreach ($attendee_fields['attendee_fields'] as $atkey => $atvalue)
		{
			if ($atvalue->id)
			{
				$fields_in_DB[] = $atvalue->id;
			}
		}

		$fields_selected[] = '';

		foreach ($ticket_fields AS $key => $value)
		{
			if ($value['id'])
			{
				$fields_selected[] = $value['id'];
			}
		}

		if ($fields_in_DB)
		{
			$diff_ids = array_diff($fields_in_DB, $fields_selected);

			if (!empty($diff_ids))
			{
				$this->delete_Ateendee_fields($diff_ids);
			}
		}

		// Now Insert or Update New Fields
		foreach ($ticket_fields AS $tkey => $tvalue)
		{
			$ticket_field_to_insert = new StdClass;

			foreach ($tvalue AS $ntkey => $nvalue)
			{
				$ticket_field_to_insert->$ntkey = $nvalue;
			}

			$ticket_field_to_insert->eventid = $XrefID;
			$ticket_field_to_insert->state   = 1;

			if (!$ticket_field_to_insert->id)
			{
				// Create Unique Name
				$ticket_field_to_insert->name = $this->CreateField_Name($ticket_field_to_insert->label);

				if ($ticket_field_to_insert->label)
				{
					if (!$db->insertObject('#__jticketing_attendee_fields', $ticket_field_to_insert, 'id'))
					{
						echo $db->stderr();

						return false;
					}

					$tickettypeid = $db->insertid();
				}
			}
			else
			{
				$db->updateObject('#__jticketing_attendee_fields', $ticket_field_to_insert, 'id');
			}
		}
	}

	/**
	 * CreateField_Name description
	 *
	 * @param   String  $string  Description
	 *
	 * @return string
	 *
	 * @since  1.0
	 */
	public function CreateField_Name($string)
	{
		$string = strtolower($string);

		// Replaces all spaces with hyphens.
		$string = str_replace(' ', '_', $string);

		// Removes special chars.
		return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
	}

	/**
	 * Delete_Ateendee_fields description
	 *
	 * @param   Array  $delete_ids  Delete attendees ids
	 *
	 * @return void
	 */
	public function delete_Ateendee_fields($delete_ids)
	{
		$db = JFactory::getDBO();

		foreach ($delete_ids as $key => $value)
		{
			$query = 'DELETE FROM #__jticketing_attendee_fields
				WHERE id = "' . $value . '"';
			$db->setQuery($query);

			if (!$db->execute())
			{
				echo $db->stderr();

				return false;
			}
		}
	}

	/**
	 * Function that allows child controller access to model data
	 *
	 * @param   array  	$integration_ids  array of id of integration xref table
	 *
	 * @return   1 or 0
	 *
	 * @since   1.5.1
	 */
	public function delete_Event($integration_ids)
	{
		$db = JFactory::getDBO();

		// Delete From universal field values which are saved against that event
		$TjfieldsHelperPath = JPATH_ROOT . DS . 'components' . DS . 'com_tjfields' . DS . 'helpers' . DS . 'tjfields.php';

		if (!class_exists('TjfieldsHelper'))
		{
			JLoader::register('TjfieldsHelper', $TjfieldsHelperPath);
			JLoader::load('TjfieldsHelper');
		}

		$content_id_array = $integration_ids;
		$TjfieldsHelper   = new TjfieldsHelper;
		$JteventHelper   = new JteventHelper;

		$this->deleteFieldValues($content_id_array, 'com_jticketing.event');

		foreach ($integration_ids AS $xrefid)
		{
			// Find main order
			$query = "SELECT id FROM #__jticketing_order WHERE event_details_id=" . $xrefid;
			$db->setQuery($query);
			$order_ids = $db->loadColumn();

			if (!empty($order_ids))
			{
				foreach ($order_ids AS $oid)
				{
					$query = "SELECT attendee_id FROM #__jticketing_order_items WHERE attendee_id<>0 AND attendee_id<>'' AND order_id=" . $oid;
					$db->setQuery($query);
					$attendee_ids     = $db->loadColumn();
					$attendee_ids_str = implode("','", $attendee_ids);

					if (!empty($attendee_ids))
					{
						// Delete From attendee field values
						$query = "DELETE FROM #__jticketing_attendee_field_values	WHERE attendee_id IN ('" . $attendee_ids_str . "') ";
						$db->setQuery($query);
						$db->execute();

						// Delete From attendees
						$query = "DELETE FROM #__jticketing_attendees	WHERE id IN ('" . $attendee_ids_str . "') ";
						$db->setQuery($query);
						$db->execute();
					}

					// Delete From order items
					$query = "SELECT id FROM #__jticketing_order_items WHERE order_id=" . $oid;
					$db->setQuery($query);
					$order_items_id     = $db->loadColumn();
					$order_items_id_str = implode("','", $order_items_id);

					$query = "DELETE FROM #__jticketing_order_items	WHERE id IN ('" . $order_items_id_str . "') ";
					$db->setQuery($query);
					$db->execute();
				}
			}

			// Delete From attendee fields per event
			$query = "DELETE FROM #__jticketing_attendee_fields	WHERE  eventid=" . $xrefid;
			$db->setQuery($query);
			$db->execute();

			// Delete Ticket Types
			$query = "DELETE FROM #__jticketing_types	WHERE  eventid=" . $xrefid;
			$db->setQuery($query);
			$db->execute();

			// Delete From Checkin Details Table
			$query = "DELETE FROM #__jticketing_checkindetails	WHERE eventid=" . $xrefid;
			$db->setQuery($query);
			$db->execute();

			// Delete From order table
			$query = "DELETE FROM #__jticketing_order	WHERE event_details_id=" . $xrefid;
			$db->setQuery($query);
			$db->execute();

			// Delete From xref table
			$query = "DELETE FROM #__jticketing_integration_xref	WHERE id=" . $xrefid;
			$db->setQuery($query);
			$db->execute();
		}
	}

	/**
	 * UpdatePaypalEmail description
	 *
	 * @param   INT     $userid        UserId
	 * @param   String  $paypal_email  Email
	 *
	 * @return void
	 */
	public function updatePaypalEmail($userid, $paypal_email)
	{
		$db    = JFactory::getDBO();
		$paypal_email = trim($paypal_email);

		if (!empty($paypal_email))
		{
			$query = "UPDATE #__jticketing_integration_xref SET paypal_email='" . $paypal_email . "' WHERE userid=" . $userid;
			$db->setQuery($query);
			$db->execute();
		}

		return true;
	}

	/**
	 * FixavailableSeats description
	 *
	 * @param   INT     $available_current    Current available tickets
	 * @param   Object  $ticket_type_info_db  Ticket info
	 * @param   INT     $xrefid               Xref id
	 *
	 * @return void
	 */
	public function fixavailableSeats($available_current, $ticket_type_info_db, $xrefid)
	{
		$db         = JFactory::getDBO();
		$difference = 0;
		$difference = $available_current - $ticket_type_info_db->count;

		$query = "SELECT id from #__jticketing_order WHERE status LIKE 'C' AND event_details_id=" . $xrefid;
		$db->setQuery($query);
		$orders    = $db->loadObjectlist();
		$soldcount = '';

		if ($orders)
		{
			$soldcounts = '';

			foreach ($orders AS $order)
			{
				$soldres = '';
				$query   = "SELECT count(id) from #__jticketing_order_items WHERE order_id=" . $order->id . " AND type_id=" . $ticket_type_info_db->id;
				$db->setQuery($query);
				$soldres = $db->loadResult();

				if ($soldres)
				{
					$soldcounts[] = $soldres;
				}
			}

			$finalsoldcount = 0;

			foreach ($soldcounts AS $soldcount)
			{
				$finalsoldcount = $finalsoldcount + $soldcount;
			}

			$available_current = $available_current + $finalsoldcount;
		}
		else
		{
			if ($difference > 0)
			{
				$available_current = $ticket_type_info_db->count + $difference;
			}
			elseif ($difference < 0)
			{
				$positive_diff = ($difference * (-1));

				if ($ticket_type_info_db->count != 0)
				{
					$final_diff = $ticket_type_info_db->count - $positive_diff;

					// Do not make available as 0 since it will becomes unlimited seats
					if ($final_diff != 0)
					{
						$available_current = $ticket_type_info_db->count - $positive_diff;
					}
				}
			}
		}

		return $available_current;
	}

	/**
	 * SaveEvent description
	 *
	 * @param   INT     $eventid              Event Id
	 * @param   INT     $backend_integration  Integration set
	 * @param   String  $ev_creator           Event creator
	 *
	 * @return void
	 */
	public function saveEvent($eventid, $backend_integration = 1, $ev_creator = '')
	{
		$jteventHelper = new jteventHelper;
		$input = JFactory::getApplication()->input;
		$post  = $input->post;
		$this->loadJTclasses();
		$source = array(
			1 => 'com_community',
			2 => 'com_jticketing',
			3 => 'com_jevents',
			4 => 'com_easysocial'
		);

		// Validate  integration in backend option of JTIcketing
		if (!$this->validateIntegration($backend_integration))
		{
			return false;
		}

		// Get creator of event
		if (!$ev_creator)
		{
			$userid = JFactory::getUser()->id;
		}

		$dat                            = new Stdclass;
		$dat->source                    = $source[$backend_integration];
		$dat->paypal_email              = $post->get('paypal_email', '', 'STRING');
		$dat->userid                    = $userid;
		$com_params                     = JComponentHelper::getParams('com_jticketing');
		$show_access_level = $com_params->get('show_access_level');
		$default_accesslevels = $com_params->get('default_accesslevels');
		$collect_attendee_info_checkout = $com_params->get('collect_attendee_info_checkout');
		$db                             = JFactory::getDBO();
		$ticket_type_title              = $post->get('ticket_type_title', '', 'array');
		$ticket_type_id                 = $post->get('ticket_type_id', '', 'array');
		$ticket_type_desc               = $post->get('ticket_type_desc', '', 'array');
		$ticket_type_price              = $post->get('ticket_type_price', '', 'array');
		$ticket_type_available          = $post->get('ticket_type_available', '', 'array');
		$ticket_type_access 			= $post->get('ticket_type_access', '', 'array');
		$ticket_type_state 				= $post->get('ticket_type_state', '', 'array');
		$ticket_type_unlimited_seats = $post->get('ticket_type_unlimited_seats', '', 'ARRAY');

		// Save attendee fields which are created in JTicketing
		$ticket_fields = $post->get('ticket_field', '', 'ARRAY');
		$data_edit = 0;
		$jticketingmainhelper = new jticketingmainhelper;
		$jteventHelper        = new jteventHelper;

		$xrefid = $jticketingmainhelper->getEventrefid($eventid);

		if (!$xrefid)
		{
			$xrefid = $this->saveintegration($eventid, $dat);
		}
		else
		{
			$data_edit = 1;
			$xrefid = $this->updateintegration($xrefid, $dat);
		}

		// Delete removed ticket types if edited and removed some ticket types
		$jticketingmainhelper->DeleteTickettypes($ticket_type_id, $xrefid);

		foreach ($ticket_type_title as $key => $ticketType)
		{
			$where          = "";
			$detailspresent = '';

			if ($ticket_type_id[$key])
			{
				$where = " AND id=" . $ticket_type_id[$key];
				$query = "SELECT id,count,available,access,state
				 FROM #__jticketing_types
				 WHERE eventid = {$xrefid} " . $where;
				$db->setQuery($query);

				$detailspresent = $db->loadObject();
			}

			$order_detail = new stdClass;

			if ($detailspresent)
			{
				$order_detail->id = $ticket_type_id[$key];
			}
			else
			{
				$order_detail->id = '';
			}

			$order_detail->title = $ticketType;

			if (!empty($order_detail->title))
			{
				$order_detail->desc  = $ticket_type_desc[$key];
				$order_detail->price = $ticket_type_price[$key];
				$order_detail->count = $ticket_type_available[$key];
				$order_detail->unlimited_seats = $ticket_type_unlimited_seats[$key];

				if (empty($show_access_level))
				{
					$order_detail->access = $default_accesslevels;
				}
				else
				{
					$order_detail->access = $ticket_type_access[$key];
				}

				$order_detail->state 	= $ticket_type_state[$key];

				if ($order_detail->count != 0)
				{
					$order_detail->available = $ticket_type_available[$key];
				}

				$order_detail->eventid = $xrefid;

				if ($detailspresent->id)
				{
					$current_available_seats = 0;
					$current_available_seats = $ticket_type_available[$key];

					// Fix available value in table if count increases OR decrerases manually
					/* $order_detail->available = $jteventHelper->fixavailableSeats($current_available_seats, $detailspresent, $xrefid); */

					if (!$db->updateObject('#__jticketing_types', $order_detail, 'id'))
					{
						/* return false; */
					}
				}
				else
				{
					$order_detail->count = $ticket_type_available[$key];

					if (!$db->insertObject('#__jticketing_types', $order_detail, 'id'))
					{
						return false;
					}
				}
			}
		}

		// Call helper function to save attendee fields
		if ($collect_attendee_info_checkout)
		{
			$jteventHelper->saveCustomAttendee_fields($ticket_fields, $eventid, $userid);
		}

		if ($data_edit == 1)
		{
			// Find event xref id and add entries to reminder queues
			$jteventHelper->updateReminderQueue($xrefid);
		}
	}

	/**
	 * Saveintegration description
	 *
	 * @param   INT  $eventid  Event id
	 * @param   INT  $dat      Description
	 *
	 * @return  INT  Integration xref if
	 */
	public function saveintegration($eventid, $dat)
	{
		$db                        = JFactory::getDBO();
		$integration               = new stdClass;
		$integration->id           = '';
		$integration->eventid      = $eventid;
		$integration->source       = $dat->source;
		$integration->paypal_email = $dat->paypal_email;
		$integration->userid       = $dat->userid;

		if (!$db->insertObject('#__jticketing_integration_xref', $integration, 'id'))
		{
			return false;
		}
		else
		{
			return $db->insertid();
		}
	}

	/**
	 * Updateintegration description
	 *
	 * @param   INT     $xrefid  Description
	 * @param   STRING  $dat     Description
	 *
	 * @return  void
	 */
	public function updateintegration($xrefid, $dat)
	{
		$db                        = JFactory::getDBO();
		$integration               = new stdClass;
		$integration->id           = $xrefid;

		// If (!empty($dat->paypal_email))
		{
			$integration->paypal_email = $dat->paypal_email;
		}

		$db->updateObject('#__jticketing_integration_xref', $integration, 'id');

		return $xrefid;
	}

	/**
	 * loadJTclasses description
	 *
	 * @return void
	 */
	public function loadJTclasses()
	{
		// Load all required helpers.
		$jticketingmainhelperPath = JPATH_ROOT . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'main.php';

		if (!class_exists('jticketingmainhelper'))
		{
			JLoader::register('jticketingmainhelper', $jticketingmainhelperPath);
			JLoader::load('jticketingmainhelper');
		}

		$jticketingfrontendhelper = JPATH_ROOT . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'frontendhelper.php';

		if (!class_exists('jticketingfrontendhelper'))
		{
			JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
			JLoader::load('jticketingfrontendhelper');
		}

		$jteventHelperPath = JPATH_ROOT . DS . 'components' . DS . 'com_jticketing' . DS . 'helpers' . DS . 'event.php';

		if (!class_exists('jteventHelper'))
		{
			JLoader::register('jteventHelper', $jteventHelperPath);
			JLoader::load('jteventHelper');
		}
	}

	/**
	 * Validate JomSocial integration.
	 *
	 * @param   String  $backend_integration  Integration set
	 *
	 * @return  Boolean  Depend on the result
	 */
	public function validateIntegration($backend_integration)
	{
		$com_params  = JComponentHelper::getParams('com_jticketing');
		$integration = $com_params->get('integration');

		if ($integration != $backend_integration)
		{
			return false;
		}

		return true;
	}

	/**
	 * Delete field values in tjfields table
	 *
	 * @param   array   $content_id_array  array of content ID
	 * @param   string  $client            Client Name()
	 *
	 * @return  void
	 */
	public function deleteFieldValues($content_id_array,$client)
	{
		$db = JFactory::getDbo();

		if (!empty($content_id_array))
		{
			$content_id_str = implode("','", $content_id_array);
			$query = "DELETE FROM #__tjfields_fields_value
			WHERE  content_id IN ('" . $content_id_str . "') AND client LIKE '" . $client . "'";
			$db->setQuery($query);

			if (!$db->execute())
			{
			}
		}
	}

	/**
	 * Function to get specific col of specific event
	 *
	 * @param   int  $event_id       id of event
	 * @param   ARR  $columns_array  array of teh columns
	 *
	 * @return  Object  $statusDetails
	 *
	 * @since  1.0.0
	 */
	public function getEventColumn($event_id,$columns_array)
	{
		if (empty($event_id))
		{
			return false;
		}

		$db   = JFactory::getDBO();
		$query = $db->getQuery(true);

		$query->select($columns_array);
		$query->from($db->quoteName('#__jticketing_events'));
		$query->where($db->quoteName('id') . " = " . $event_id);

		$db->setQuery($query);
		$event = $db->loadObject();

		return $event;
	}
}
