	<?php
	/**
	* @package	Jticketing
	* @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
	* @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
	* @link http://www.techjoomla.com
	*/

	// no direct access
	defined('_JEXEC') or die('Restricted access');
	global $mainframe;

	$this->jticketingmainhelper=new jticketingmainhelper();

	$integration=$this->jticketingmainhelper->getIntegration(); // geting integration id;
	JHtml::_('behavior.modal', 'a.modal');
	$document =JFactory::getDocument();
	(JText::_('ORDER_VIEW'));
	jimport('joomla.filter.output');
	jimport( 'joomla.utilities.date');
	$input=JFactory::getApplication()->input;
	$user=JFactory::getUser();

	$com_params=JComponentHelper::getParams('com_jticketing');
	$integration = $com_params->get('integration');
	$siteadmin_comm_per = $com_params->get('siteadmin_comm_per');
	$private_key_cronjob = $com_params->get('private_key_cronjob');
	$currency = $com_params->get('currency');

	if(empty($user->id))
	{

	echo '<b>'.JText::_('USER_LOGOUT').'</b>';
	return;

	}

	$bootstrapclass="";
	$tableclass="table table-striped  table-hover ";
	$buttonclass="button";
	$buttonclassprimary="button";

	$bootstrapclass="JTICKETING_WRAPPER_CLASS";
	$tableclass="table table-striped table-hover ";
	$buttonclass="btn";
	$buttonclassprimary="btn  btn-default  btn-primary";
	$appybtnclass="btn  btn-default  btn-primary";

	$user=JFactory::getUser();
	$document =JFactory::getDocument();

	$integration=$this->jticketingmainhelper->getIntegration();
	if($integration==1) //if Jomsocial show JS Toolbar Header
	{
	$header='';
	$header=$this->jticketingmainhelper->getJSheader();
	if(!empty($header))
	echo $header;
	}
	?>
	<div  class="floattext">
	<h1 class="componentheading"><?php echo JText::_('MY_ORDERS'); ?>	</h1>
	</div>
	<?php
	$payment_statuses=array('P'=>JText::_('JT_PSTATUS_PENDING'),
	'C'=>JText::_('JT_PSTATUS_COMPLETED'),
		'D'=>JText::_('JT_PSTATUS_DECLINED'),
		'E'=>JText::_('JT_PSTATUS_FAILED'),
		'UR'=>JText::_('JT_PSTATUS_UNDERREVIW'),
		'RF'=>JText::_('JT_PSTATUS_REFUNDED'),
		'CRV'=>JText::_('JT_PSTATUS_CANCEL_REVERSED'),
		'RV'=>JText::_('JT_PSTATUS_REVERSED'),
	);

	if(JVERSION >= '1.6.0')
	$js_key="
	Joomla.submitbutton=function(task){ ";
	else
	$js_key="
	function submitbutton( task ){";

	$js_key.="
		document.adminForm.action.value=task;
		if (task =='cancel')
		{";
			if(JVERSION >= '1.6.0')
				$js_key.="	Joomla.submitform(task);";
			else
				$js_key.="document.adminForm.submit();";
		$js_key.="

		}
	}
	";

	$document->addScriptDeclaration($js_key);
	if(empty($this->lists['search_event']))
	{
	$this->lists['search_event']=$input->get('event','','INT');
	}

	$eventid=$input->get('event','','INT');
	$linkbackbutton='';

			if(empty($this->Data) or $this->noeventsfound==1)
			{


				echo '
				<form action="" method="post" name="adminForm"	id="adminForm">';

				?>
	<div class="<?php echo $bootstrapclass;?>  container-fluid">
	<div id="all" class="row">
		<div class = "col-lg-12 col-md-12 col-sm-12 col-xs-12">
	  <div style="float:right">
		 <?php
			if($this->noeventsfound!=1){ //if no events found dont show filter
				$search_event = $mainframe->getUserStateFromRequest( 'com_jticketingsearch_event', 'search_event','', 'string' );
				echo JHtml::_('select.genericlist', $this->status_event, "search_event", 'class="ad-status" size="1" onchange="document.adminForm.submit();" name="search_event"',"value", "text",$search_event);
				echo JHtml::_('select.genericlist', $this->search_paymentStatus, "search_paymentStatus", 'class="ad-status" size="1" onchange="document.adminForm.submit();" name="search_paymentStatus"',"value", "text", strtoupper($this->lists['search_paymentStatus']));
			}
			 ?>
		  </div>
		  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pull-right alert alert-info jtleft"><?php echo JText::_('NODATA');?></div>
		  <input type="hidden" name="option" value="com_jticketing" />
		  <input type="hidden" name="task" value="" />
		  <input type="hidden" name="boxchecked" value="0" />
		  <input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
		  <input type="hidden" name="defaltpaymentStatus" value="<?php echo $this->lists['search_paymentStatus'];?>" />
		  <input type="hidden" name="controller" value="orders" />
		  <input type="hidden" name="view" value="orders" />
		  <input type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
	</div>
	</div>
	</div>
	</form>
	<!-- newly added for JS toolbar inclusion  -->
	<?php
	if($integration==1)
	{

	$footer='';
	$footer=$this->jticketingmainhelper->getJSfooter();
	if(!empty($footer))
	echo $footer;
	}  // else pending

	?>
	<!-- eoc for JS toolbar inclusion	 -->
	<?php
	return;
	}
	?>
	<form action="" method="post" name="adminForm" id="adminForm">
	<div class="<?php echo $bootstrapclass;?> container-fluid">
	  <div id="all" class="row">
		 <div class="btn-toolbar pull-right">
			<?php
			   $search_event = $mainframe->getUserStateFromRequest( 'com_jticketingsearch_event', 'search_event','', 'string' );
			   echo JHtml::_('select.genericlist', $this->status_event, "search_event", 'class="ad-status" size="1" onchange="document.adminForm.submit();" name="search_event"',"value", "text", $search_event);
			   ?>
			<?php
			   echo JHtml::_('select.genericlist', $this->search_paymentStatus, "search_paymentStatus", 'class="ad-status col-lg-6 col-md-56col-sm-4 col-xs-12" size="1" onchange="document.adminForm.submit();" name="search_paymentStatus"',"value", "text", strtoupper($this->lists['search_paymentStatus']));
			   ?>
			<?php if(JVERSION>'3.0') {?>
			<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
<!--
			<div class = "col-lg-3 col-md-3 col-sm-4 col-xs-6">
-->
			<?php
			   echo $this->pagination->getLimitBox();
			   ?>
			<?php
			   }
			   ?>
<!--
			 </div>
-->
		 </div>
	  </div>
<!--
	  		<div class="clearfix"></div>
-->
	  <div id='no-more-tables'>
		 <table class="table table-striped table-bordered table-hover">
			<thead>
			   <tr>
				  <th  align="center"><?php echo JHtml::_( 'grid.sort','ORDER_ID','id', $this->lists['order_Dir'], $this->lists['order']); ?></th>
				  <th  align="center"><?php echo JHtml::_( 'grid.sort','PAY_METHOD','processor', $this->lists['order_Dir'], $this->lists['order']); ?></th>
				  <th align="center"><?php echo JText::_( 'NUMBEROFTICKETS_BOUGHT' );?></th>
				  <th align="center"><?php echo  JText::_( 'ORIGINAL_AMOUNT' ); ?></th>
				  <th align="center"><?php echo  JText::_( 'DISCOUNT_AMOUNT' ); ?></th>
				  <?php
					 if($this->jticketingparams->get('allow_taxation')){
					 ?>
				  <th align="center"><?php echo  JText::_( 'TAX_AMOUNT' ); ?></th>
				  <?php
					 }
					 ?>
				  <th align="center"><?php echo  JText::_( 'PAID_AMOUNT' ); ?></th>
				  <th align="center"><?php echo  JText::_( 'COUPON_CODE_DIS' ); ?></th>
				  <th  align="center"><?php echo JHtml::_( 'grid.sort','PAYMENT_STATUS','status', $this->lists['order_Dir'], $this->lists['order']); ?></th>
			   </tr>
			</thead>
			<?php
			   $totaltax=$i = 0;
			   $totalpaidamt=$totalnooftickets=$totalprice=$totalcommission=$totalearn=0;$subdisc=0;$subpaid=0;
			   foreach($this->Data as $data) {
					if($data->ticketscount<0)
					$data->ticketscount=0;
					if($data->original_amount<0)
					$data->original_amount=0;
					if($data->fee<0)
					$data->fee=0;
			   $totalnooftickets=$totalnooftickets+$data->ticketscount;
			   if($data->status=='C')
			   $totalpaidamt=$totalpaidamt+$data->original_amount;
			   $totalprice=$totalprice+$data->original_amount;
			   $totalcommission=$totalcommission+$data->fee;
			   $totaltax+=$data->order_tax;

			   if($data->order_id)
				$passorderid=$data->order_id;
				else
				$passorderid=$data->id;

			   $link_for_attendees = JRoute::_('index.php?option=com_jticketing&view=attendees&event='.$data->evid ."&order_id=".$passorderid."&Itemid=".$this->Itemid);
			   $link_for_orders = JRoute::_('index.php?option=com_jticketing&view=orders&layout=order&event='.$data->evid .'&orderid='.$passorderid.'&Itemid='.$this->Itemid.'&tmpl=component');
			   ?>
			<tr class="">
			   <td  align="center" data-title="<?php echo JText::_('ORDER_ID');?>">
				  <a rel="{handler: 'iframe', size: {x: 600, y: 600}}" class="jticketing_modal modal" href="<?php echo $link_for_orders;?>"><?php if($data->order_id) echo $data->order_id; else echo $data->id;?></a>
			   </td>
			   <td align="center"  data-title="<?php echo JText::_('PAY_METHOD');?>"><?php
				  if(!empty($data->processor) and $data->processor!='Free_ticket'){
					$plugin = JPluginHelper::getPlugin('payment', $data->processor);
					$pluginParams = new JRegistry();

					$pluginParams->loadString($plugin->params);
					$param = $pluginParams->get('plugin_name', $data->processor);
					echo $param;
				  }
				  else
				  {
					echo JText::_(($data->processor == NULL) ? "-" : $data->processor);
				  }

				  ?></td>
			   <td align="center" data-title="<?php echo JText::_('NUMBEROFTICKETS_BOUGHT');?>">
				  <?php echo $data->ticketscount ?>
			   </td>
			   <td align="center" data-title="<?php echo JText::_('ORIGINAL_AMOUNT');?>">
				  <?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($data->original_amount),2),$currency);?>
			   </td>
			   <td align="center" data-title="<?php echo JText::_('DISCOUNT_AMOUNT');?>">
				  <?php $subdisc+=$discount=$data->coupon_discount;
					 echo $this->jticketingmainhelper->getFromattedPrice( number_format(($discount),2),$currency);  ?>
			   </td>
			   <?php
				  if($this->jticketingparams->get('allow_taxation')){
				  ?>
			   <td align="center" data-title="<?php echo JText::_('TAX_AMOUNT');?>">
				  <?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($data->order_tax),2),$currency); ?>
			   </td>
			   <?php
				  }?>
			   <td align="center" data-title="<?php echo JText::_('PAID_AMOUNT');?>">
				  <?php $subpaid+=$data->paid_amount;
					 echo $this->jticketingmainhelper->getFromattedPrice( number_format(($data->paid_amount),2),$currency); ?>
			   </td>
			   <td align="center" data-title="<?php echo JText::_('COUPON_CODE_DIS');?>">
				  <?php if(!empty($data->coupon_code)){ echo $data->coupon_code. ' ';} else echo '-';?>
			   </td>
			   <td align="center" data-title="<?php echo JText::_('PAYMENT_STATUS');?>">
				  <?php echo $payment_statuses[$data->status]; ?>
			   </td>
			</tr>
			<?php
			   $i++;

			   } ?>
			<tr	class="jticket_row_head">
			   <td colspan="2" align="right" class = "hidden-xs">
				  <div class="jtright hidden-xs"><b><?php echo JText::_('TOTAL');?></b> </div>
			   </td>

			   <td align="center" data-title="<?php echo JText::_('TOTAL_NUMBEROFTICKETS_BOUGHT');?>">
				  <b><?php echo number_format($totalnooftickets, 0, '', '');?></b>
			   </td>
			   <td align="center" data-title="<?php echo JText::_('TOTAL_ORIGINAL_AMOUNT');?>">
				  <b><?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($totalprice),2),$currency); ?></b>
			   </td>
			   <td align="center" data-title="<?php echo JText::_('TOTAL_DISCOUNT_AMOUNT');?>">
				  <b><?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($totalearn),2),$currency); ?></b>
			   </td>
			   <?php
				  if($this->jticketingparams->get('allow_taxation')){
				  ?>
			   <td align="center" data-title="<?php echo JText::_('TOTAL_TAX_AMOUNT');?>">
				  <b><?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($totaltax),2),$currency); ?></b>
			   </td>
			   <?php
				  }?>
			   <td align="center" data-title="<?php echo JText::_('TOTAL_PAID_AMOUNT');?>">
				  <b><?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($subpaid),2),$currency); ?></b>
			   </td>
			   <td align="center" class = "hidden-xs hidden-sm"></td>
			   <td align="center" class = "hidden-xs hidden-sm"></td>
			</tr>
			<!--<tr >
			   <td align="right" colspan="8"><div class="jtright jtbold"><?php echo JText::_( 'SUBTOTAL'); ?></div></td>
			   <td align="center"><?php
				  //$subtotalamount=$this->jticketingmainhelper->getsubtotalamount();
				  echo number_format($totalprice, 2, '.', '');echo ' '.$currency;?></td>

			   </tr>

			   <tr>
			   <td align="right" colspan="8"><div class="jtright jtbold"><?php echo JText::_( 'PAID'); ?></div></td>
			   <td align="center"><?php
				  echo	number_format($totalpaidamt, 2, '.', '');
				  echo ' '.$currency;?></td>
			   </tr>
			   <tr>
			   <td align="right" colspan="8"><div class="jtright jtbold"><?php echo JText::_( 'BAL_AMT'); ?></div></td>
			   <td align="center"><?php
				  $balanceamt1=$totalprice-$totalpaidamt;
				   $balanceamt=number_format($balanceamt1, 2, '.', '');
					if($balanceamt=='-0.00')
					echo	'0.00';
					else
					echo number_format($balanceamt1, 2, '.', '');

					echo ' '.$currency;?></td>
			   </tr>-->
		 </table>
	  </div>
	  <input type="hidden" name="option" value="com_jticketing" />
	  <input type="hidden" name="task" value="display" />
	  <input type="hidden" name="boxchecked" value="0" />
	  <input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
	  <input type="hidden" name="controller" value="orders" />
	  <input type="hidden" name="view" value="orders" />
	  <input type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
	  <input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	  <input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
	</div>
	<!--row-->
	<?php
	  if(JVERSION<3.0)
		$class_pagination='pager';
	  else
		$class_pagination='pagination';
	  ?>
	<div class="<?php echo $class_pagination; ?>">
	  <?php echo $this->pagination->getListFooter(); ?>
	</div>
	</form>
	<!-- newly added for JS toolbar inclusion  -->
	<?php
	if($integration==1) //if Jomsocial show JS Toolbar Footer
	{
	$footer='';
	$footer=$this->jticketingmainhelper->getJSfooter();
	if(!empty($footer))
	echo $footer;
	}
	?>
	<!-- eoc for JS toolbar inclusion -->
