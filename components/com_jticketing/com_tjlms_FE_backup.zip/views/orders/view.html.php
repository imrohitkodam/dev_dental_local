<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

/**
 * Orders view
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingVieworders extends JViewLegacy
{
	/**
	 * Method to display events
	 *
	 * @param   object  $tpl  tpl
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function display($tpl = null)
	{
		global $mainframe, $option;
		$this->jticketingmainhelper = new jticketingmainhelper;
		$this->jticketingparams     = JComponentHelper::getParams('com_jticketing');
		$TjGeoHelper                = JPATH_ROOT . DS . 'components/com_tjfields/helpers/geo.php';

		if (!class_exists('TjGeoHelper'))
		{
			JLoader::register('TjGeoHelper', $TjGeoHelper);
			JLoader::load('TjGeoHelper');
		}

		$this->TjGeoHelper = new TjGeoHelper;
		$input = JFactory::getApplication()->input;
		$input->set('view', 'orders');
		$layout = JFactory::getApplication()->input->get('layout', 'default');
		$this->setLayout($layout);
		$mainframe = JFactory::getApplication();
		$params     = $mainframe->getParams('com_jticketing');
		$integration = $params->get('integration');

		// Native Event Manager.
		if($integration<1)
		{
		?>
			<div class="alert alert-info alert-help-inline">
		<?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
		?>
			</div>
		<?php
			return false;
		}

		$option    = $input->get('option');
		$user      = JFactory::getUser();
		$search_event = $mainframe->getUserStateFromRequest($option . 'search_event', 'search_event', '', 'string');
		$search_event = JString::strtolower($search_event);
		$search_paymentStatus = $mainframe->getUserStateFromRequest($option . 'search_paymentStatus', 'search_paymentStatus', '', 'string');
		$search_paymentStatus = JString::strtolower($search_paymentStatus);
		$status_event         = array();

		// If layout=my find events for which user has made orders
		if ($layout == 'my')
		{
			$eventlist = $this->jticketingmainhelper->geteventnamesBybuyer($user->id);
		}
		elseif ($layout == 'default')
		{
			// If layout=default find all events which are created by that user
			$eventlist = $this->jticketingmainhelper->geteventnamesByCreator($user->id);
		}

		$this->noeventsfound = 0;
		$status_event[] = JHtml::_('select.option', '0', JText::_('SELONE_EVENT'));

		if (!empty($eventlist))
		{
			foreach ($eventlist as $key => $event)
			{
				$event_id       = $event->id;
				$event_nm       = $event->title;
				$status_event[] = JHtml::_('select.option', $event_id, $event_nm);
			}
		}
		elseif ($layout == 'my' or $layout == 'default')
		{
			$this->noeventsfound = 1;
			parent::display($tpl);

			return;
		}

		$eventid = JRequest::getInt('event');
		$paymentStatus   = array();
		$paymentStatus[] = JHtml::_('select.option', '0', JText::_('SEL_PAY_STATUS'));
		$paymentStatus[] = JHtml::_('select.option', 'P', JText::_('JT_PSTATUS_PENDING'));
		$paymentStatus[] = JHtml::_('select.option', 'C', JText::_('JT_PSTATUS_COMPLETED'));
		$paymentStatus[] = JHtml::_('select.option', 'D', JText::_('JT_PSTATUS_DECLINED'));
		$paymentStatus[] = JHtml::_('select.option', 'E', JText::_('JT_PSTATUS_FAILED'));
		$paymentStatus[] = JHtml::_('select.option', 'UR', JText::_('JT_PSTATUS_UNDERREVIW'));
		$paymentStatus[] = JHtml::_('select.option', 'RF', JText::_('JT_PSTATUS_REFUNDED'));
		$paymentStatus[] = JHtml::_('select.option', 'CRV', JText::_('JT_PSTATUS_CANCEL_REVERSED'));
		$paymentStatus[] = JHtml::_('select.option', 'RV', JText::_('JT_PSTATUS_REVERSED'));
		$lists['search_event']         = $search_event;
		$lists['search_paymentStatus'] = $search_paymentStatus;
		$Itemid = $input->get('Itemid', '', 'GET');

		if (empty($Itemid))
		{
			$Session = JFactory::getSession();
			$Itemid  = $Session->get("JT_Menu_Itemid");
		}

		$this->paymentStatus = $paymentStatus;
		$this->status_event  = $status_event;
		$this->Itemid        = $Itemid;
		$order_id            = $input->get('orderid', '', 'STRING');
		$oid                 = $this->jticketingmainhelper->getIDFromOrderID($order_id);
		$order               = $this->jticketingmainhelper->getOrderInfo($oid);
		JLoader::import('buy', JPATH_SITE . DS . 'components' . DS . 'com_jticketing' . DS . 'models');
		$jticketingModelbuy = new jticketingModelbuy;
		$this->billinfo     = $jticketingModelbuy->getuserdata($oid);
		$this->user = JFactory::getUser();

		if ($layout == 'order')
		{
			// IF FREE TICKET SEND MAIL TO Buyer
			$sendmail = '';
			$sendmail = $input->get('sendmail', '', 'GET');

			if (!empty($sendmail))
			{
				$email = $this->jticketingmainhelper->sendmailnotify($order['order_info']['0']->order_id, 'afterordermail');
			}
		}

		if ($this->user->id)
		{
			if (!empty($order))
			{
				// Check if logged in user is owner of that event for that order
				if (isset($order['eventinfo']->created_by) and $order['eventinfo']->created_by == $this->user->id)
				{
					$this->order_authorized = 1;
				}
				else
				{
					// Check if logged in user has made this order
					$this->order_authorized = $this->jticketingmainhelper->getorderAuthorization($order["order_info"][0]->user_id);
				}

				$this->orderinfo  = $order['order_info'];
				$this->orderitems = $order['items'];
				$this->orderview  = 1;
			}
			else
			{
				$this->noOrderDetails = 1;
			}
		}
		else
		{
			$email = $input->get('email', '', 'STRING');

			if (md5($this->billinfo['BT']->user_email) != $email)
			{
				$this->noOrderDetails   = 1;
				$this->order_authorized = 0;
			}
			else
			{
				$this->order_authorized = 1;
				$this->orderinfo        = $order['order_info'];
				$this->orderitems       = $order['items'];
				$this->orderview        = 1;
			}
		}

		// Get data from the model
		$data       = $this->get('Data');
		$pagination = $this->get('Pagination');

		// Push data into the template
		$this->Data       = $data;
		$this->pagination = $pagination;

		// FOR ORDARING
		$filter_order_Dir = $mainframe->getUserStateFromRequest('com_jticketing.filter_order_Dir', 'filter_order_Dir', 'desc', 'word');
		$filter_type      = $mainframe->getUserStateFromRequest('com_jticketing.filter_order', 'filter_order', 'id', 'string');
		$title              = '';
		$lists['order_Dir'] = '';
		$lists['order']     = '';

		$title = $mainframe->getUserStateFromRequest('com_jticketing' . 'title', '', 'string');

		if ($title == null)
		{
			$title = '-1';
		}

		$this->search_paymentStatus = $paymentStatus;
		$lists['title']     = $title;
		$lists['order_Dir'] = $filter_order_Dir;
		$lists['order']     = $filter_type;
		$this->lists = $lists;
		parent::display($tpl);
	}
}
