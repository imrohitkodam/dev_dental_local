<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2016 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// no direct access
defined('_JEXEC') or die;
JHtml::script(JUri::root() . 'components/com_jticketing/assets/js/jquery.countdown.js');

$document               = JFactory::getDocument();
$params                 = JComponentHelper::getParams( 'com_jticketing' );
$orderCurrency          = $params->get('currency');
$jticketingMainHelper   = new jticketingmainhelper();
$document->addStyleSheet(JURI::root(true) . '/components/com_jticketing/assets/css/jticketing.css');

// Find Langitude Latitude of Location
if (empty($this->item->image))
{
	$imagePath = JRoute::_(JUri::base() . 'media/com_jticketing/images/default-event-image.png');
}
else
{
	$imagePath = 'media/com_jticketing/images/';
	$imagePath = JRoute::_(JUri::base() . $imagePath . $this->item->image, false);
}

$eventUrl                       = 'index.php?option=com_jticketing&view=event&id='.$this->item->id;
$eventUrl                       = JUri::root() . substr(JRoute::_($eventUrl), strlen(JUri::base(true))+1);
$user                           = JFactory::getUser();
$groups                         = $user->getAuthorisedViewLevels();
$guest                          = $user->get('guest');
$allowAccessLevelEnrollment     = 0;
$eventParams                    = $this->item;
$currentTime                    = JFactory::getDate()->toSql();

if ($this->item->venue != "0")
{
	$venueParams = json_decode($this->venuedatails, TRUE);
}

$eventParams = json_decode($eventParams->jt_params, TRUE);

if (!empty($eventParams) && !empty($venueParams))
{
	$venueParam = '';

	if (!empty($venueParams['host_url']))
	{
		$venueParam = $venueParams['host_url'];
	}

	$eventParam = $eventParams['event_url'];
	$launchUrl  = $venueParam  . "/" . $eventParam;
}

?>
<script>
	techjoomla.jQuery(document).ready(function() {
	jQuery("a span").attr('disabled', 'disabled');
	jQuery('adobe-enter-btn').unbind('click');
	jQuery('.adobe-enter-btn').addClass('disabled');
	jQuery('.adobe-enter-btn').addClass('inactiveLink');
	jQuery('.endevent').hide();

	if (jQuery('.adobe-enter-btn').length)
	{
		jQuery('.adobe-enter-btn').hide();
		var meetingBtn = '<a rel="popover" class="btn btn-info adobe-hidden-btn"><?php echo JText::_("COM_JTICKETING_MEETING_BUTTON") ?></a>';
		jQuery('.tj-adobeconnect').append(meetingBtn);
	}

				jQuery('[rel="popover"]').on('click', function (e) {
		jQuery('[rel="popover"]').not(this).popover('hide');
	});

	/*Add popover when enter meeting button is hidden*/
	jQuery('[rel="popover"]').popover({
		html: true,
		trigger: 'click',
		placement: 'top',
		content: function () {
			return '<button type="button" id="close" class="close" onclick="popup_close(this);">&times;</button><div class="tj-popover"><div class="tj-content"><?php echo JText::_("COM_JT_MEETING_ACCESS") ?></div></div>';
		}
	});

	jQuery('#countdown_timer').countdown({
	until:'<?php echo strtotime($this->item->startdate) - strtotime($currentTime); ?>',
	compact: true,
	onTick: watchCountdown
	});
	});

	// Add function for countdowntimer till Startdate
	function watchCountdown(periods)
	{
		jQuery('.startevent').css('color','#337ab7');
		jQuery('.startevent').css('font-family','Questrial');
		jQuery('#countdown_timer').css('color','#468847');
		if ((jQuery.countdown.periodsToSeconds(periods) < 5*60))
		{
			jQuery('#reverse_timer').addClass('text-success');
			jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('disabled');
			jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('inactiveLink');
			jQuery('.com_jticketing_meeting').show();
			jQuery('')
			jQuery('.adobe-enter-btn').addClass('btn-success');
			jQuery('.startevent').show();
			jQuery('.endevent').hide();
			jQuery('.adobe-enter-btn').show();
			jQuery('.adobe-hidden-btn').remove();
		}

		if ((jQuery.countdown.periodsToSeconds(periods) <= 1*0))
		{
			watchEventcountdowns()
		}
	}

	// Popover close button
	function popup_close(btn)
	{
		jQuery(btn).closest('.popover').hide();
	}

	// Add function for countdowntimer till Enddate
	function watchEventcountdowns()
	{
		jQuery('#countdown_timer').hide();
		jQuery('#reverse_timer').countdown({
		until: '<?php echo strtotime($this->item->enddate) - strtotime($currentTime); ?>',
		compact: true,
		onTick: watchRevcountdowns
		});
	}

	// Add function for countdowntimer till Enddate
	function watchRevcountdowns(periods)
	{
		jQuery('.counters').css('color', 'red');
		jQuery('.endevent').show();
		jQuery('.startevent').hide();

		if ((jQuery.countdown.periodsToSeconds(periods) < 5*60))
		{
			jQuery('#reverse_timer').addClass('text-success');
			jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('disabled');
			jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('inactiveLink');
			jQuery('.com_jticketing_meeting').show();
			jQuery('.adobe-enter-btn').addClass('btn-success');
			jQuery('.counters').css('color', 'red');
			jQuery('.endevent').show();
			jQuery('.startevent').hide();
		}

		if ((jQuery.countdown.periodsToSeconds(periods) <= 1*0))
		{
			console.log("reverse function End ko");
			jQuery('.counters').html(" <?php echo JText::_("COM_JTICKETING_EVENT_FINISHED") ?>");
			jQuery('.counters').css('color', 'red');
			jQuery('.countertime').hide();
			jQuery('#reverse_timer').css('color', 'red');
			jQuery('.com_jt_book').hide();
		}
	}
</script>

<?php
	if (!empty($this->accessLevelsForEnrollment))
	{
		// Check access levels for enrollment
		foreach ($groups as $group)
		{
			if (is_array($this->accessLevelsForEnrollment))
			{
				if (in_array($group, $this->accessLevelsForEnrollment, true))
				{
					$allowAccessLevelEnrollment = 1;
					break;
				}
			}
	   }
	}

	if($this->integration != 2)//NATIVE EVENT MANAGER
	{
		?>
		<div class="alert alert-info alert-help-inline">
			<?php echo JText::_('COMJTICKETING_INTEGRATION_NATIVE_NOTICE');	?>
		</div>
		<?php

		return false;
	}

	$this->item->short_description=trim($this->item->short_description);
?>
<div class="<?php echo JTICKETING_WRAPPER_CLASS;?>">
	<div class="container-fluid">
		<div itemscope itemtype="http://schema.org/Event">
			<div class="page-header" itemprop="name">
				<h1><?php echo $this->escape($this->item->title); ?></h1>
			</div>
			<hr/>
			<?php

			// Integration with Jlike
			if (file_exists(JPATH_SITE . '/' . 'components/com_jlike/helper.php'))
			{
				$showComments = -1;
				$showLikeButtons = 1;

				$JTicketingIntegrationsHelper = new JTicketingIntegrationsHelper();
				$jlikeHtml                    = $JTicketingIntegrationsHelper->DisplayjlikeButton($eventUrl, $this->item->id, $this->escape($this->item->title), $showComments, $showLikeButtons);
				if($jlikeHtml)
				echo $jlikeHtml;
			}
			?>
			<strong>
				<?php echo JText::_('COM_JTICKETING_EVENT_CATEGORY') . ' : ';?>
			</strong>
			<?php

			// Get itemid
			$singleEventItemid = $jticketingMainHelper->getItemId('index.php?option=com_jticketing&view=events&layout=default');

			if (empty($singleEventItemid))
			{
				$singleEventItemid = JFactory::getApplication()->input->get('Itemid');
			}

			$catUrl = 'index.php?option=com_jticketing&view=events&filter_events_cat=' . $this->item->catid . '&Itemid=' . $singleEventItemid;
			$catUrl = JUri::root() . substr(JRoute::_($catUrl), strlen(JUri::base(true))+1);

			if (!empty($this->item->category_id_title))
			{
				?>
				<a href="<?php echo $catUrl; ?>">
					<?php
					echo $this->item->category_id_title;
					?>
				</a>
				<?php
			}
			?>
			<hr class="hr hr-condensed"/>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<?php
					echo '<div id="fb-root"></div>';
					$fbLikeTweet = JUri::root() . 'components/com_jticketing/assets/js/fblike.js';
					echo "<script type='text/javascript' src='" . $fbLikeTweet."'></script>";

					// set metadata
					$config = JFactory::getConfig();
					$siteName = $config->get( 'sitename' );
					$document->addCustomTag( '<meta property="og:title" content="' . $this->escape($this->item->title) . '" />' );
					$document->addCustomTag( '<meta property="og:image" content="' . $imagePath . '" />' );
					$document->addCustomTag( '<meta property="og:url" content="' . $eventUrl . '" />' );
					$document->addCustomTag( '<meta property="og:description" content="'. nl2br($this->escape($this->item->short_description)) . '" />' );
					$document->addCustomTag( '<meta property="og:site_name" content="' . $siteName . '" />' );
					$document->addCustomTag( '<meta property="og:type" content="event" />' );
					$pid = $params->get('addthis_publishid','GET','STRING');

					if ($params->get('social_sharing'))
					{
						if ($params->get('social_shring_type')=='addthis')
						{
							$addThisShare='
							<!-- AddThis Button BEGIN -->
							<div class="addthis_toolbox addthis_default_style">

							<a class="addthis_button_facebook_like" fb:like:layout="button_count" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
							<a class="addthis_button_google_plusone" g:plusone:size="medium" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
							<a class="addthis_button_tweet" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
							<a class="addthis_button_pinterest_pinit" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
							<a class="addthis_counter addthis_pill_style" class="addthis_button" addthis:url="' . $eventUrl . '"></a>
							</div>
							<script type="text/javascript">
								var addthis_config ={ pubid: "' . $pid . '"};
							</script>
							<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid="' . $pid . '"></script>
							<!-- AddThis Button END -->' ;

							$addThisJs = 'http://s7.addthis.com/js/300/addthis_widget.js';
							$JTicketingIntegrationsHelper = new JTicketingIntegrationsHelper();
							$JTicketingIntegrationsHelper->loadScriptOnce($addThisJs);

							// output all social sharing buttons
							echo' <div id="rr" style="">
								<div class="social_share_container">
								<div class="social_share_container_inner">' .
									$addThisShare .
								'</div>
							</div>
							</div>
							';
						}
						else
						{
							echo '<div class="com_jticketing_horizontal_social_buttons">';
							echo '<div class="com_jticketing_float_left">
								<div class="fb-like" data-href="' . $eventUrl . '" data-send="true" data-layout="button_count" data-width="450" data-show-faces="true"></div>
								</div>';
							echo '<div class="com_jticketing_float_left">
									&nbsp; <div class="g-plus" data-action="share" data-annotation="bubble" data-href="' . $eventUrl . '"></div>
								</div>';
							echo '<div class="com_jticketing_float_left">
									&nbsp; <a href="https://twitter.com/share" class="twitter-share-button" data-url="' . $eventUrl . '" data-counturl="' . $eventUrl . '"  data-lang="en">Tweet</a>
								</div>';
							echo '</div>
								<div class="com_jticketing_clear_both"></div>';
						}
					}
					?>
				</div>
			</div>

			<?php
			echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'details'));
			echo JHtml::_('bootstrap.addTab', 'myTab', 'details', JText::_('COM_JTICKETING_EVENT_TAB_DETAILS', true));
			?>
			<div class="container-fluid">
				<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
					<div class="" >
						<img itemprop="image" class="jt_img-thumbnail com_jticketing_image_w98pc" src="<?php echo $imagePath;?>">
					</div>

					<?php
					if ($this->item->venue != '0')
					{
						?>
						<hr>
						<div id="" class="jticketing_align">
							<b>
								<?php
								if ($this->item->online_events != '0')
								{
									echo JText::_('COM_JTICKETING_LEGEND_VENUE') . ' - ' . $this->venueName;
								}
								else
								{
									echo JText::_('COM_JTICKETING_LEGEND_VENUE') . ' - ' . $this->venueName . ', ' . $this->venueAddress;
								}
								?>
							</b>
						</div>
						<?php
					}
					?>
					<div class="clearfix">&nbsp;</div>
					<div class="jticketing_align" >
						<?php echo $this->item->long_description; ?>
					</div>
					<div class="clearfix">&nbsp;</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
					<?php

					// load location template
					echo $this->loadTemplate('timer');

					$checkOfflineEvent = $this->item->online_events;

					if ($checkOfflineEvent == '0')
					{
						echo $this->loadTemplate('location');
					}
					?>
					<div class="box-style">
					<div class="jt-panel-heading"><?php echo JText::_("COM_JTICKETING_EVENT_TIME"); ?></div>
						<div class="jt-panel-body">
							<i class="fa fa-calendar" aria-hidden="true"></i>
								<?php
								$startDate =  JHtml::date($this->item->startdate, JText::_('COM_JTICKETING_DATE_FORMAT_DETAILS_EVENT'), true);
									echo $startDate
								?>
							<b> <?php echo JText::_("COM_JTICKETING_TO"); ?> </b>
								<?php
									$endDate =  JHtml::date($this->item->enddate, JText::_('COM_JTICKETING_DATE_FORMAT_DETAILS_EVENT'), true);
									echo $endDate;
								?>
							<br/>
							<i class="fa fa-clock-o" aria-hidden="true"></i>
								<?php
								$statrtTime =  JHtml::date($this->item->startdate, JText::_('COM_JTICKETING_TIME_FORMAT_DETAILS_EVENT'), true);
								$endTime =  JHtml::date($this->item->enddate, JText::_('COM_JTICKETING_TIME_FORMAT_DETAILS_EVENT'), true);
								echo $statrtTime;
								?>
							<b> <?php echo JText::_("COM_JTICKETING_TO"); ?> </b>
							<?php echo $endTime; ?>
							<div>
								<i class="fa fa-clock-o countdown-container counters" aria-hidden="true">
									<span class="startevent"><?php echo JText::_("COM_JTICKETING_EVENT_STARTSIN");?></span>
									<span class="endevent"><?php echo JText::_("COM_JTICKETING_EVENT_ENDSIN");?></span>
								</i>
								<span class="countertime">
									<span id='countdown_timer'></span>
									<span id='reverse_timer'></span>
								</span>
							</div>
						</div>
					</div>
					<div class="box-style">
						<div class="jt-panel-heading">
							<?php echo JText::_("COM_JTICKETING_TICKET_BOOK_FROM"); ?>
						</div>
						<div class="jt-panel-body">
							<i class="fa fa-calendar" aria-hidden="true"></i>
							<?php
								echo JHtml::date($this->item->booking_start_date, JText::_('COM_JTICKETING_DATE_FORMAT_DETAILS_EVENT'), true);
							?>
							<b> <?php echo JText::_("COM_JTICKETING_TO"); ?> </b>
							<?php
								echo JHtml::date($this->item->booking_end_date, JText::_('COM_JTICKETING_DATE_FORMAT_DETAILS_EVENT'), true);
							?>
						</div>
					</div>

					<?php
					if ((is_array($this->GetTicketTypes)) && (count($this->GetTicketTypes))):
					?>
					<div class="box-style">
						<div class="jt-panel-heading"><?php echo JText::_("TICKET_DETAILS"); ?></div>
							<table id="no-more-tables" class="table table-responsive">
								<thead>
									<tr>
										<td>
											<strong>
												<?php echo JText::_('COM_JTICKETING_TICKET_TYPE_TITLE'); ?>
											</strong>
										</td>
										<td>
											<strong>
												<?php echo JText::_('COM_JTICKETING_TICKET_TYPE_PRICE');?>
											</strong>
										</td>
										<td>
											<strong><?php echo JText::_('COM_JTICKETING_TICKET_TYPE_AVAILABLE');?>
											</strong>
										</td>
									</tr>
								</thead>
									<?php
									if ($this->availableSeats != '0' && $this->availableCount != '0' || $this->unlimitedSeats == '1')
									{
										foreach($this->GetTicketTypes as $TicketTypes)
										{
											if ($TicketTypes->hide_ticket_type or ($TicketTypes->unlimited_seats!=1 and $TicketTypes->count<=0))
											{
												continue;
											}
											?>
											<tr>
												<td data-title="<?php echo JText::_('COM_JTICKETING_TICKET_TYPE_TITLE');?>">
												 <?php echo $TicketTypes->title; ?>
												</td>
												<td data-title="<?php echo JText::_('COM_JTICKETING_TICKET_TYPE_PRICE');?>">
													<?php
													echo $jticketingMainHelper->getFromattedPrice( number_format(($TicketTypes->price),2),$orderCurrency);
													?>
												</td>
												<td data-title="<?php echo JText::_('COM_JTICKETING_TICKET_TYPE_AVAILABLE');?>">
													<?php
													if($TicketTypes->unlimited_seats)
													{
														echo JText::_('COM_JTICKETING_BUY_UNLIM_SEATS');
													}
													else
													{
														echo $TicketTypes->count.'/'.$TicketTypes->available;
													}
													?>
												</td>
											</tr>
											<?php
										}
									}
									else
									{
										?>
										<tr>
											<td colspan="3">
												<b>
													<?php echo JText::_("COM_JTICKETING_NO_TICKETS_AVILABLE"); ?>
												</b>
											</td>
										</tr>
										<?php
									}
									?>
							</table>
							<table class="table table-responsive">
								<tbody>
									<tr>
										<td class="com_jticketing_align_center">
											<?php
											if (array_key_exists('enrol_button', $this->eventData))
											{
												echo $this->eventData['enrol_button'];
											}

											if (array_key_exists('buy_button', $this->eventData))
											{
												echo $this->eventData['buy_button'];
											}
											elseif (array_key_exists('adobe_connect', $this->eventData))
											{
												echo $this->eventData['adobe_connect'];
											}
											?>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<?php echo JHtml::_('bootstrap.endTab');

			if ($this->extraData) :
				echo JHtml::_('bootstrap.addTab', 'myTab', 'extrafields', JText::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS', true));
				echo $this->loadTemplate('extrafields');
				echo JHtml::_('bootstrap.endTab');
			endif;

			echo JHtml::_('bootstrap.endTabSet'); ?>
		</div>
	</div>
</div>

<?php

// Integration with Jlike
if (file_exists(JPATH_SITE.'/'.'components/com_jlike/helper.php'))
{
	$showComments = 1;
	$showLikeButtons = 0;
	$JTicketingIntegrationsHelper = new JTicketingIntegrationsHelper();
	$jlikeHtml = $JTicketingIntegrationsHelper->DisplayjlikeButton($eventUrl, $this->item->id, $this->escape($this->item->title), $showComments, $showLikeButtons);
	if($jlikeHtml)
	echo $jlikeHtml;
}
?>

<style>
.tj-adobeconnect{margin-bottom:5px;}
</style>
<script>
function openSqueezeBox(givenlink)
{
	var width = techjoomla.jQuery(parent.window).width();
	var height = techjoomla.jQuery(parent.window).height();

	var wwidth = width-(width*0.10);
	var hheight = height-(height*0.10);
	parent.SqueezeBox.open(givenlink, { handler: 'iframe', size: {x: wwidth, y: hheight},classWindow: 'tjlms-modal'});
}
</script>
