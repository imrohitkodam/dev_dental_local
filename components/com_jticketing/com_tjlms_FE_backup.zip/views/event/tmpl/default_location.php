<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die;

// Getting Google Map API key
$com_params = JComponentHelper::getParams('com_jticketing');
$googlemap_apikey = $com_params->get('google_map_api_key');

// $this->response_a->status return the status of google map location
if ($this->response_a->status != 'ZERO_RESULTS')
{?>

	<div id="jticketing-event-map" class="jticketing-event-map box-style">
		<!-- begin: dynamic map -->
		<?php
			if ($this->response_a)
			{
				$lat = $this->response_a->results[0]->geometry->location->lat;
				$long = $this->response_a->results[0]->geometry->location->lng;
			}?>
		<div id="event-map" >
			<?php echo JText::_('COM_JTICKETING_MAPS_LOADING'); ?>
		</div>
		<div class="" itemprop="location" itemscope itemtype="http://schema.org/Place">
			<div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
				<br/>
				<span itemprop="streetAddress">
				<i class="icon icon-location"></i>
				<strong>
					<?php
					echo JText::_('COM_JTICKETING_EVENT_LOCATION') . ' : ';
					?>
				</strong>
				<?php
				echo $this->item->event_address;
				?>
				</span>
			</div>
			<hr class="hr hr-condensed"/>
			<div class="com_jticketing_align_center">
				<a href="http://maps.google.com/?q=<?php echo urlencode($this->item->event_address);?>"
					target="_blank" class="pull-left">
					<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
					<?php echo JText::_('COM_JTICKETING_EVENTS_FULL_MAP'); ?>
				</a>

				<a class="pull-right" href="index.php?option=com_jticketing&view=event&format=ical&id=<?php echo $this->item->id;?>" target="_blank">

					<span class="glyphicon glyphicon-export" aria-hidden="true"></span>
					<?php echo JText::_('COM_JTICKETING_EXPORT_ICAL'); ?>
				</a>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<?php
}
?>

<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=true&key=<?php echo $googlemap_apikey;?>"></script>
<script>
function initialize() {

	lat = "<?php echo $lat; ?>"
	lon = "<?php echo $long; ?>"
  var myLatlng = new google.maps.LatLng(lat,lon);
  var mapOptions = {
    zoom: 10,
    center: myLatlng
  }
  var map = new google.maps.Map(document.getElementById('event-map'), mapOptions);

  var marker = new google.maps.Marker({
      position: myLatlng,
      map: map,

  });
}

google.maps.event.addDomListener(window, 'load', initialize);

</script>



