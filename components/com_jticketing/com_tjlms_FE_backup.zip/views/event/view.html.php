<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die;
jimport('joomla.application.component.view');


/**
 * Class for Jticketing Event view
 *
 * @package  JTicketing
 * @since    1.5
 */
class JticketingViewEvent extends JViewLegacy
{
	protected $state;

	protected $item;

	protected $params;

	/**
	 * Method to display event
	 *
	 * @param   object  $tpl  template name
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function display($tpl = null)
	{
		$app  = JFactory::getApplication();
		$user = JFactory::getUser();
		$params     = $app->getParams('com_jticketing');
		$integration = $params->get('integration');
		$this->jticketingfrontendhelper = new jticketingfrontendhelper;
		$this->jticketingmainhelper     = new jticketingmainhelper;

		// Native Event Manager.
		if ($integration < 1)
		{
		?>
			<div class="alert alert-info alert-help-inline">
		<?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
		?>
			</div>
		<?php
			return false;
		}

		$this->state  = $this->get('State');
		$item   = $this->get('Data');
		$this->item = "";
		$groups = $user->getAuthorisedViewLevels();
		$i = 0;

		if (!empty($item->access) and in_array($item->access, $groups))
		{
			$this->item = $item;
			$i++;
		}
		elseif (empty($item->access))
		{
			$this->item = $item;
			$i++;
		}

		if (empty($this->item))
		{
			?>
				<div class="alert alert-info alert-help-inline">
					<?php	echo JText::_('COMJTICKETING_NOT_AUTHORISED_EVENT');	?>
				</div>
			<?php

			return false;
		}

		$venueid = $this->item->venue;
		$this->params = $app->getParams('com_jticketing');

		// Get integration set
		$this->integration = $this->params->get('integration', '', 'INT');

		if (!empty($this->item->catid))
		{
			$catNm = $this->getModel()->getCategoryName($this->item->catid);

			if (!empty($catNm))
			{
				$this->item->category_id_title = $catNm->title;
			}

			if ($this->item->venue != 0)
			{
				$this->venueName = $this->jticketingfrontendhelper->getVenue($this->item->venue)->name;
				$this->venueAddress = $this->jticketingfrontendhelper->getVenue($this->item->venue)->address;
				$this->venuedatails = $this->jticketingfrontendhelper->getVenue($this->item->venue)->params;
			}
		}

		$this->jtParams                   = $app->getParams('com_jticketing');
		$this->enableSelfEnrollment       = $this->jtParams->get('enable_self_enrollment', '', 'INT');
		$this->supressBuyButton           = $this->jtParams->get('supress_buy_button', '', 'INT');
		$this->accessLevelsForEnrollment  = $this->jtParams->get('accesslevels_for_enrollment');

		// Shows Book Ticket Button
		require_once JPATH_SITE . "/components/com_jticketing/models/events.php";
		$Jticketingfrontendhelper = new JticketingModelEvents;
		$this->eventData = $Jticketingfrontendhelper->getTJEventDetails($this->item->id);

		$this->extraData      = $this->get('DataExtra');
		$this->GetTicketTypes = $this->get('TicketTypes');

		$arrayCount = count($this->GetTicketTypes);

		for ($i = 0; $i < $arrayCount; $i++)
		{
			$this->availableSeats = $this->GetTicketTypes[$i]->available;
			$this->availableCount = $this->GetTicketTypes[$i]->count;
			$this->unlimitedSeats = $this->GetTicketTypes[$i]->unlimited_seats;

			if ($this->availableSeats != '0' && $this->availableSeats != '0' || $this->availableSeats == '1')
			{
				break;
			}
		}

		// Content triggers for short description
		$dispatcher = JDispatcher::getInstance();

		if (!empty($this->item->short_description) )
		{
			$item = new StdClass;
			$item->text = $this->item->short_description;
			JPluginHelper::importPlugin('content');
			$item->params = 'com_jticketing.short_description';
			$short_description = $dispatcher->trigger('onPrepareContent', array (& $item, & $item->params, 0));

			if (!empty($short_description) and $short_description['0'] != 1)
			{
				$this->item->short_description .= "<br/>" . $short_description['0'];
			}
		}

		// Content triggers for long description
		$dispatcher = JDispatcher::getInstance();
		$item->text = $this->item->long_description;
		JPluginHelper::importPlugin('content');
		$item->params = 'com_jticketing.long_description';
		$long_description = $dispatcher->trigger('onPrepareContent', array (& $item, & $item->params, 0));

		if (!empty($long_description)  and $long_description['0'] != 1)
		{
			$this->item->long_description .= "<br/>" . $long_description['0'];
		}

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			throw new Exception(implode("\n", $errors));
		}

		if ($this->_layout == 'edit')
		{
			$authorised = $user->authorise('core.create', 'com_jticketing');

			if ($authorised !== true)
			{
				throw new Exception(JText::_('JERROR_ALERTNOAUTHOR'));
			}
		}

		$input                          = JFactory::getApplication()->input;
		$userid                         = JFactory::getUser()->id;
		$eventid                        = $input->get('id', '', 'INT');
		$this->isEventbought 			= $this->jticketingmainhelper->isEventbought($eventid, $userid);
		$this->showbuybutton            = $this->jticketingmainhelper->showbuybutton($eventid);
		$this->buyTicketItemId  = $this->jticketingmainhelper->getItemId('index.php?option=com_jticketing&view=buy&layout=default');
		$this->_prepareDocument();

		// Google Map Data

		$address = str_replace(" ", "+", $this->item->event_address);
		$url = "http://maps.google.com/maps/api/geocode/json?address=$address&sensor=true";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$response = curl_exec($ch);
		curl_close($ch);
		$this->response_a = json_decode($response);

		parent::display($tpl);
	}

	/**
	 * Method to prepare document
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	protected function _prepareDocument()
	{
		$app   = JFactory::getApplication();
		$menus = $app->getMenu();
		$title = null;

		// Because the application sets a default page title,
		// we need to get it from the menu item itself
		$menu = $menus->getActive();

		if ($menu)
		{
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		}
		else
		{
			$this->params->def('page_heading', JText::_('COM_JTICKETING_DEFAULT_PAGE_TITLE'));
		}

		if (empty($title))
		{
			if (!empty($this->item))
			{
				$title = $this->item->title;
			}
			else
			{
				$title = $this->params->get('page_title', '');
			}
		}

		if (empty($title))
		{
			$title = $app->getCfg('sitename');
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 1)
		{
			$title = JText::sprintf('JPAGETITLE', $app->getCfg('sitename'), $title);
		}
		elseif ($app->getCfg('sitename_pagetitles', 0) == 2)
		{
			$title = JText::sprintf('JPAGETITLE', $title, $app->getCfg('sitename'));
		}

		$this->document->setTitle($title);

		if ($this->params->get('menu-meta_description'))
		{
			$this->document->setDescription($this->params->get('menu-meta_description'));
		}

		if ($this->params->get('menu-meta_keywords'))
		{
			$this->document->setMetadata('keywords', $this->params->get('menu-meta_keywords'));
		}

		if ($this->params->get('robots'))
		{
			$this->document->setMetadata('robots', $this->params->get('robots'));
		}
	}
}
