<?php
/**
* @version     1.5
* @package     com_jticketing
* @copyright   Copyright (C) 2014. All rights reserved.
* @license     GNU General Public License version 2 or later; see LICENSE.txt
* @author      Techjoomla <extensions@techjoomla.com> - http://techjoomla.com
*/
// no direct access
defined('_JEXEC') or die;
$com_params          = JComponentHelper::getParams('com_jticketing');
$googlemap_apikey = $com_params->get('google_map_api_key');
$jinput = JFactory::getApplication()->input;
if (!empty($jinput))
$eventId = $jinput->get('id', '', 'INT');
?>
<div class="form-group">
</div>
<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-3 col-xs-12  control-label ">
		<?php echo $this->form->getLabel('online_events'); ?>
	</div>
	<div class="col-lg-2 col-md-2 col-sm-9 col-xs-12">
		<?php $online_events = $this->form->getValue('online_events');?>

		<?php
		$jtOnline = " checked='checked' ";
		$jtOffline = "";

		if (empty($online_events))
		{
			$jtOnline = "";
			$jtOffline = " checked='checked' ";
		}

		?>

		<label class="radio-inline">
		  <input type="radio" id="jform_online_events0" value="1" class="" <?php echo $jtOnline;?>  name="jform[online_events]" >
		  <?php echo JText::_('COM_JTICKETING_YES');?>
		</label>
		<label class="radio-inline">
		  <input type="radio" id="jform_online_events1" value="0" class="" <?php echo $jtOffline;?> name="jform[online_events]" >
			<?php echo JText::_('COM_JTICKETING_NO');?>
		</label>
	</div>
</div>
<div class="form-group" id="venue_id">
	<div class="col-lg-2 col-md-2 col-sm-3 col-xs-12 control-label"><?php echo $this->form->getLabel('venue'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 controls"><?php echo $this->form->getInput('venue'); ?></div>
</div>

<div class="form-group" id="event-location">
	<div class="col-lg-2 col-md-2 col-sm-3 col-xs-12 control-label"><?php echo $this->form->getLabel('location'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 controls"><?php echo $this->form->getInput('location'); ?></div>
</div>
<div class="form-group" id="venuechoice_id">
	<div class=" col-lg-2 col-md-2 col-sm-3 col-xs-12  control-label ">
		<?php echo $this->form->getLabel('venuechoice'); ?>
	</div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12">
		<?php $venuechoice = $this->form->getValue('venuechoice');?>

		<?php
		$new = " checked='checked' ";
		$existing = "";

		if (empty($venuechoice))
		{
			$new = "";
			$existing = " checked='checked' ";
		}

		?>

		<label class="radio-inline">
		  <input type="radio" id="jform_venuechoice0" value="new" class="" <?php echo $new;?>  name="jform[venuechoice]" >
		  <?php echo JText::_('COM_JTICKETING_FORM_OPTION_CREAT_NEW_EVENT');?>
		</label>
		<label class="radio-inline">
		  <input type="radio" id="jform_venuechoice1" value="existing" class="" <?php echo $existing;?> name="jform[venuechoice]" >
			<?php echo JText::_('COM_JTICKETING_FORM_OPTION_EXISTING_EVENT');?>
		</label>
	</div>
	<input type="hidden" name="event_sco_id" class="event_sco_id" id="event_sco_id" value=""/>
	<input type="hidden" name="event_url" class="event_url" id="event_url" value=""/>
</div>
<div class="form-group" id="existingEvent">
	<div class="col-lg-2 col-md-2 col-sm-3 col-xs-12  control-label"><?php echo $this->form->getLabel('existing_event'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 controls"><?php echo $this->form->getInput('existing_event'); ?></div>
</div>
<!--
<script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places" type="text/javascript"></script>
-->
<script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places&key=<?php echo $googlemap_apikey;?>" type="text/javascript"></script>
<script type="text/javascript">
var onlineEvents = <?php echo $this->onlineEvents;?>

jQuery(document).ready(function()
{
	var event_id =  "<?php echo $eventId; ?>";

	if(!event_id)
	{
		validateVenue(this);
	}

	slectExistingEvent();
	var venuestatus = jQuery('input[type=radio][name="jform[online_events]"]:checked').val();
	if (venuestatus == '0' || onlineEvents == 0)
	{
		jQuery("#existingEvent").hide();
		jQuery("#venuechoice_id").hide();
	}
	else
	{
		jQuery("#existingEvent").show();
		jQuery("#venuechoice_id").show();
	}
	jQuery(".venueCheck").change(function()
	{
		slectExistingEvent();
	});

	var venue = document.getElementById("jform_venue").value;
	if(venue != '0')
	{
		jQuery("#event-location").hide();
		techjoomla.jQuery('#jform_location').removeAttr("required");
		techjoomla.jQuery('#jform_location').removeClass("required");
	}

	jQuery('input[type=radio][name="jform[venuechoice]"]').on('click', function(){
	var venuechoicestatus = jQuery('input[type=radio][name="jform[venuechoice]"]:checked').val();
		if(venuechoicestatus == 'existing')
		{
			jQuery("#existingEvent").show();
		}
		else
		{
			jQuery("#existingEvent").hide();
		}
	});
	jQuery('input[type=radio][name="jform[online_events]"]').on('click', function(){
		var venuestatus = jQuery(this).val();
		//~ validateVenue(this);
		if(venuestatus == '0')
		{
			jQuery("#existingEvent").hide();
			jQuery("#venuechoice_id").hide();
		}
	});

		jQuery('#venue_id').change(function() {

		var venuestatus = jQuery('input[type=radio][name="jform[online_events]"]:checked').val();
		var eventVal = jQuery("#jform_venue").val();

		if(venuestatus == 1 && eventVal != 0)
		{
			jQuery("#venuechoice_id").show();
			jQuery("#existingEvent").show();
		}

		if (eventVal == 0)
		{
			jQuery("#venuechoice_id, #existingEvent").hide();
		}

	});
});
	function eventCreate()
	{
		techjoomla.jQuery("#task").val("eventform.createSeminar");

		var values = techjoomla.jQuery('#adminForm').serialize();
		var flag = true;
		var base_url = "<?php echo JUri::base(); ?>";
		var url = base_url + "index.php?option=com_jticketing&task=eventform.createSeminar&tmpl=component";
		techjoomla.jQuery.ajax({
			type: 'POST',
			async: false,
			data: values,
			dataType: 'json',
			url: url,
			success: function(data)
			{
				console.log("success");

				if (data['status']['@attributes']['code'] == 'ok')
				{
					var venueurl = data['meeting_url'];
					var event_id = data['sco']['@attributes']['sco-id'];
					techjoomla.jQuery("#event_url").val(venueurl);
					techjoomla.jQuery("#event_sco_id").val(event_id);
					console.log("url" +venueurl);
					console.log("sco id" +event_id);
				}
				else
				{
					alert(data['error_message']);
					console.log(data);
					flag = false;
				}

			},
			error: function(response)
			{
				// show ckout error msg
				console.log(' ERROR!!' );
				return;
			}
		});

		if (flag == false)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	function decideLocation()
	{
		jQuery("#event-location").hide();
		var venuevalue = jQuery('#jform_venue').val();

		if (venuevalue == '0')
		{
			jQuery("#event-location").show();
		}
		else
		{
			jQuery("#event-location").hide();
			techjoomla.jQuery('#jform_location').removeAttr("required");
			techjoomla.jQuery('#jform_location').removeClass("required");
		}
	}

	function slectExistingEvent()
	{
		var venueId = document.getElementById("jform_venue").value;
		var venuestatus = jQuery('input[type=radio][name="jform[online_events]"]:checked').val();
		var existingUrl = '';
		<?php if(!empty($existingUrl)) { ?>
		existingUrl="<?php echo $existingUrl;?>";
		<?php } ?>
		var url = "index.php?option=com_jticketing&task=eventform.getAllMeetings";

		if(venueId != '0' && venuestatus == '1')
		{
			techjoomla.jQuery.ajax({
				type: 'POST',
				async: false,
				data:{
				'venueId':venueId
				},
				dataType: 'json',
				url: url,
				success: function(data)
				{
					techjoomla.jQuery('#jform_existing_event option').remove();
					var option, index;
					var eventList = data['0']['report-bulk-objects']['row'];
					if (eventList !== undefined && eventList !== null)
					{
						var op = "<option value='abcde' selected='selected'> <?php echo JText::_('COM_JTICKETING_FORM_SELECT_EXISTING_EVENT_OPTION'); ?> </option>";
						techjoomla.jQuery("#jform_existing_event").append(op);
						for(index = 0; index < eventList.length; ++index)
						{
							var eventvalue = eventList[index]['url'] .replace(/^\s+|\s+$/g, "");

							if(existingUrl==eventvalue)
							{
								var op="<option value='"+eventvalue+"' selected='selected'>"  +eventList[index]['name']+ " (" + eventList[index]['date-modified'] + ")"+ "</option>" ;
							}
							else
							{
								var op="<option value='"+eventvalue+"' >"  +eventList[index]['name']+ " (" + eventList[index]['date-modified'] + ")"+ "</option>" ;
							}

							techjoomla.jQuery('#jform_existing_event').append(op);
						}

						jQuery("#jform_existing_event").trigger("liszt:updated");
					}
				},
				error: function(response)
				{
					//techjoomla.jQuery('').show('slow');
					// show ckout error msg
					console.log(' ERROR!!' );
					return;
				}
			});
		}
	}

	function existingEventSelection()
	{
		var venueId = document.getElementById("jform_venue").value;
		var venueurl = techjoomla.jQuery('#jform_existing_event :selected').val();
		techjoomla.jQuery("#event_url").val(venueurl);
		techjoomla.jQuery.ajax({
			type: 'POST',
			async: false,
			data:
			{
				'venueId':venueId,
				'venueurl':venueurl
			},
			dataType: 'json',
			url: 'index.php?option=com_jticketing&task=event.getScoID',
			success: function(data)
			{
				techjoomla.jQuery("#event_sco_id").val(data);
			},
			error: function(response)
			{
				// show ckout error msg
				console.log(' ERROR!!' );
				return;
			}
		});

	}
	// Google Map autosuggest  for location
	function initialize()
	{
		input = document.getElementById('jform_location');
		var autocomplete = new google.maps.places.Autocomplete(input);
	}
	google.maps.event.addDomListener(window, 'load', initialize);
</script>
