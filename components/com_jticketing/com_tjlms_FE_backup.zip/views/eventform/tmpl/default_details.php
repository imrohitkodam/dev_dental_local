<?php
/**
 * @version     1.5
 * @package     com_jticketing
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Techjoomla <extensions@techjoomla.com> - http://techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

?>

<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label "><?php echo $this->form->getLabel('title'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12"><?php echo $this->form->getInput('title'); ?></div>
</div>

<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label "><?php echo $this->form->getLabel('catid'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12"><?php echo $this->form->getInput('catid'); ?></div>
</div>

<!--
<div class="form-group">
-->
	<?php $canState = false; ?>
	<?php $canState = $canState = JFactory::getUser()->authorise('core.edit.own','com_jticketing'); ?>

	<?php
	if(!$canState): ?>
<!--
		<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label ">
			<?php //echo $this->form->getLabel('state'); ?>
		</div>
-->
			<?php
			$state_string = JText::_('COM_JTICKETING_UNPUBLISH');
			$state_value = 0;
			if($this->item->state == 1):
				$state_string = JText::_('COM_JTICKETING_PUBLISH');
				$state_value = 1;
			endif;
			?>
<!--
		<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12"><?php //echo $state_string; ?></div>

		<input type="hidden" name="jform[state]" value="<?php //echo $state_value; ?>" />
-->
	<?php
	else: ?>
<!--
		<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label ">
			<?php //echo $this->form->getLabel('state'); ?>
		</div>
		<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12">
-->
			<?php //echo $this->form->getInput('state');
				$state = $this->form->getValue('state');?>

			<?php
			$jtPublish = " checked='checked' ";
			$jtUnpublish = "";

			if (empty($state))
			{
				$jtPublish = "";
				$jtUnpublish = " checked='checked' ";
			}

			  $jtPublish;
			?>

<!--
			<label class="radio-inline">
			  <input type="radio" class="" <?php //echo $jtPublish;?> value="1" id="jform_state1" name="jform[state]" >
			  <?php //echo JText::_('COM_JTICKETING_YES');?>
			</label>
			<label class="radio-inline">
			  <input type="radio" class="" <?php //echo $jtUnpublish;?> value="0" id="jform_state0" name="jform[state]" >
				<?php //echo JText::_('COM_JTICKETING_NO');?>
			</label>
-->
<!--
		</div>
-->
	<?php
	endif; ?>

<!--
</div>
-->

<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label "><?php echo $this->form->getLabel('access'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12"><?php echo $this->form->getInput('access'); ?></div>
</div>

<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label "><?php echo $this->form->getLabel('image'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12">
		<?php echo $this->form->getInput('image'); ?>

			<br />
			<p class="bg-warning "><?php
			//echo JText::_("COM_JTICKETING_FILE_UPLOAD_FILESIZE_WARNING");
			//echo "<br/>";
			//echo sprintf(JText::_("COM_JTICKETING_FILE_UPLOAD_FILESIZE_LIMIT"), $this->params->get('maxSizeLimit'));
			//echo "<br/>";
			//echo sprintf(JText::_("COM_JTICKETING_FILE_UPLOAD_ALLOWED_EXTENSIONS"), $this->params->get('allowedFileExtensions'));
			echo sprintf(JText::_("COM_JTICKETING_FILE_UPLOAD_ALLOWED_EXTENSIONS"), 'jpg, jpeg, png');
			?></p>


		<?php if (!empty($this->item->image)) : ?>
			<?php
			$imagePath = 'media/com_jticketing/images/';
			$imagePath = JRoute::_(JUri::root() . $imagePath . $this->item->image, false);
			?>
			<div class="text-warning">
				<?php echo JText::_('COM_JTICKETING_EXISTING_IMAGE_MSG');?>
			</div>
			<div class="text-info">
				<?php echo JText::_('COM_JTICKETING_EXISTING_IMAGE');?>
			</div>
			<div >
				<img class='img-thumbnail com_jticketing_image_w98pc' src='<?php echo $imagePath;?>' alt="<?php echo $this->item->title; ?>" />
			</div>

		<?php endif; ?>
	</div>
</div>

<input type="hidden" name="jform[image]" id="jform_image_hidden" value="<?php echo $this->item->image ?>" />

<!--
<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label "><?php echo $this->form->getLabel('short_description'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12">
		<?php //echo $this->form->getInput('short_description');
			$description = $this->form->getValue('short_description')?>
		<textarea  rows="5" name="jform[short_description]" id="jform_short_description" class="form-control" ><?php if (!empty($description)){ echo trim($description);}?></textarea>
	</div>
</div>
-->

<div class="form-group">
	<div class=" col-lg-2 col-md-2 col-sm-2 col-xs-12 control-label "><?php echo $this->form->getLabel('long_description'); ?></div>
	<div class="col-lg-10 col-md-10 col-sm-9 col-xs-12"><?php echo $this->form->getInput('long_description'); ?></div>
</div>

