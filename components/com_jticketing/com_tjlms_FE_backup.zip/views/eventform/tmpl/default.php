<?php
/**
 * @version     1.5
 * @package     com_jticketing
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Techjoomla <extensions@techjoomla.com> - http://techjoomla.com
 */
// no direct access
defined('_JEXEC') or die;

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$root_url=JUri::root();
$document = JFactory::getDocument();

if($this->integration != 2)//NATIVE EVENT MANAGER
{
	?>
		<div class="alert alert-info alert-help-inline">
			<?php	echo JText::_('COMJTICKETING_INTEGRATION_NATIVE_NOTICE');	?>
		</div>
	<?php

	return false;
}
?>

<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if(task == 'eventform.save')
		{
			var venueChoice = techjoomla.jQuery('input:radio[name =\"jform[venuechoice]\"]:checked').val();

			if (venueChoice == "new")
			{
				var seminar = eventCreate();

				if (seminar == false)
				{
					return false;
				}
			}

			var venue = document.getElementById("jform_venue").value;
			if(venue == '')
			{
				alert("<?php echo $this->escape(JText::_('COM_JTICKETING_VALIDATION_FORM_FAILED_VENUE_NAME')); ?>");
				return false;
			}

			if (venue == '0')
			{
				techjoomla.jQuery("input:radio[name=\"jform[online_events]\"][value ='0']").prop('checked', true);
			}

			if (techjoomla.jQuery("input[name =\"ticket_type_title[]\"]").val() == '')
			{
				alert("<?php echo $this->escape(JText::_('COM_JTICKETING_VALIDATION_FORM_FAILED_TICKET_TITLE')); ?>");
				return false;
			}
			else
			{
				var result = validateVenue(venue);

				if(result)
				{
					Joomla.submitform(task);
				}
				else
				{
					return false;
				}
			}
		}

		if(task == 'event.cancel')
		{
			Joomla.submitform(task);
		}
		else
		{
			if (document.formvalidator.isValid(document.getElementById('adminForm')))
			{
				Joomla.submitform(task);
			}
			else
			{
				alert("<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>");
			}
		}
	}

	techjoomla.jQuery(document).ready(function()
	{
		jQuery('input[type=radio][name="jform[online_events]"]').on('click', function(){
				var venuestatus = jQuery(this).val();
				validateVenue(this);
			});
		<?php if (!empty($this->item->image)) : ?>
			techjoomla.jQuery('#jform_image').removeAttr("required");
			techjoomla.jQuery('#jform_image').removeClass("required");
		<?php endif; ?>
		<?php if (!empty($this->item->id)) : ?>
			techjoomla.jQuery('#edit_ticket_title .edit_ticket_title').removeAttr("required");
			techjoomla.jQuery('#edit_ticket_title .edit_ticket_title').removeClass("required");

		<?php endif; ?>

		techjoomla.jQuery('#adminForm').submit(function(event)
		{
			if(techjoomla.jQuery('#jform_image').val() != '')
			{
				techjoomla.jQuery('#jform_image_hidden').val(techjoomla.jQuery('#jform_image').val());
			}
		});
	});

	function validateVenue(obj)
	{
		var venuetype = jQuery("input[name='jform[online_events]']:checked").val();
		var startdate = jQuery('#jform_startdate').val();
		var enddate = jQuery('#jform_enddate').val();
		var event_start_time_hour = jQuery('#event_start_time_hour').val();
		var event_online = jQuery("input[name='jform[online_events]']:checked").val();
		var event_start_time_min = jQuery('#event_start_time_min').val();
		var event_start_time_ampm = jQuery('#event_start_time_ampm').val();
		var event_end_time_hour = jQuery('#event_end_time_hour').val();
		var event_end_time_min = jQuery('#event_end_time_min').val();
		var event_end_time_ampm = jQuery('#event_end_time_ampm').val();
		var created_by = jQuery('#jform_created_by_id').val();

		var invalidVenue = 0;

		if(startdate === '' && enddate === '')
		{
			alert("<?php echo JText::_('COM_JTICKETING_EVENTFORM_VENUE_VALID'); ?>");
			return false;
		}

		jQuery.ajax({
		type: 'POST',
		dataType: 'JSON',
		url: 'index.php?option=com_jticketing&task=event.getAvailableVenue',
		data:{
				startdate : startdate, enddate : enddate,
				event_start_time_hour : event_start_time_hour,
				event_start_time_min: event_start_time_min,
				event_start_time_ampm : event_start_time_ampm,
				event_end_time_hour : event_end_time_hour,
				event_end_time_min : event_end_time_min,
				event_online : event_online,
				event_end_time_ampm : event_end_time_ampm,
				venuetype : venuetype,
				created_by : created_by},
				success: function(data){
					techjoomla.jQuery('#jform_venue option').remove();

					if (data !== undefined && data !== null)
						{
							var op = "<option value='"+"0"+"'> <?php echo JText::_('COM_JTICKETING_FORM_VENUE_DEFAULT_OPTION'); ?> </option>";
							techjoomla.jQuery("#jform_venue").append(op);
							for(index = 0; index < data.length; ++index)
							{
								var op="<option value="  +data[index]['id']+ ">"  +data[index]['name']+   '</option>' ;
								techjoomla.jQuery('#jform_venue').append(op);
							}
							 jQuery("#jform_venue").trigger("liszt:updated");
						}
				}
		});

		if(invalidVenue == 1)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	function validateForm()
	{
		var validatedDates=validateDates();

		if(validatedDates===false)
		{
			return false;
		}

		return true;
	}

	function validateDates()
	{
		var event_start_date_old = techjoomla.jQuery('#jform_startdate').val();
		var event_end_date_old  = techjoomla.jQuery('#jform_enddate').val();

		var booking_start_date_old  = techjoomla.jQuery('#jform_booking_start_date').val();
		var booking_end_date_old  = techjoomla.jQuery('#jform_booking_end_date').val();

		/* Check if all date fields are filled up. */
		if(event_start_date_old==='' ||  event_end_date_old==='' || booking_start_date_old==='' || booking_end_date_old==='')
		{
			alert("<?php echo JText::_('COM_JTICKETING_EVENTFORM_FILL_DATE_FIELDS'); ?>");

			return false;
		}

		var event_start_date = new Date(event_start_date_old);
		var event_end_date  = new Date(event_end_date_old);
		var booking_start_date  = new Date(booking_start_date_old);
		var booking_end_date  = new Date(booking_end_date_old);

		/* 'Event Start Date' must be lower than or equal to 'Event End Date'. */
		if((event_start_date> event_end_date))
		{
			alert("<?php  echo JText::_('COM_JTICKETING_EVENT_START_DATE_LESS_EVENT_END_DATE_ERROR'); ?>");
			techjoomla.jQuery('#jform_startdate').focus();

			return false;
		}

		/* 'Booking Start Date' must be lower than or equal to 'Event Start Date'. */
		if(!(booking_start_date <= event_start_date))
		{
			alert("<?php echo JText::_('COM_JTICKETING_EVENT_BOOKING_START_DATE_LEES_EVENT_START_DATE_ERROR'); ?>");
			techjoomla.jQuery('#jform_booking_start_date').focus();

			return false;
		}

		/* 'Booking Start Date' must be lower than or equal to 'Booking End Date'. */
		if(!(booking_start_date<= booking_end_date))
		{
			alert("<?php  echo JText::_('COM_JTICKETING_EVENT_BOOKING_START_DATE_LESS_BOOKING_END_DATE_ERROR'); ?>");
			techjoomla.jQuery('#jform_booking_start_date').focus();

			return false;
		}

		/* 'Booking End Date' must be lower than or equal to 'Event End Date'. */
		if(!(booking_end_date <= event_end_date))
		{
			alert("<?php  echo JText::_('COM_JTICKETING_EVENT_BOOKING_END_DATE_LOWER_EVENT_END_DATE_ERROR'); ?>");
			techjoomla.jQuery('#jform_booking_end_date').focus();

			return false;
		}

		return true;
	}
</script>

<div class="<?php echo JTICKETING_WRAPPER_CLASS;?> jtick-wrapper">
	<hr/>

	<div class="event-form<?php echo $this->pageclass_sfx?>">
	<?php if ($this->params->get('show_page_heading', 1)) : ?>
		<div class="page-header">
			<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		</div>
	<?php endif; ?>
	</div>

	<div id="eventform1" class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

			<form id="adminForm" action="" method="post" class="form-validate form-horizontal" enctype="multipart/form-data" onsubmit="return validateForm();" >

				<?php
				// Added 0 because joomla's accordian in bs2 format.
				// Kee
				if (JVERSION >= '3.0' && 0) :?>
					<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'details'));
							echo JHtml::_('bootstrap.addTab', 'myTab', 'details', JText::_('COM_JTICKETING_EVENT_TAB_DETAILS', true));

									echo JHtml::_('bootstrap.startAccordion', 'myAccordian', array('active' => 'collapse1'));
									echo JHtml::_('bootstrap.addSlide', 'myAccordian', JText::_('COM_JTICKETING_EVENT_TAB_BASIC'), 'collapse1', $class='');
										echo $this->loadTemplate('details');
									echo JHtml::_('bootstrap.endSlide');


									echo JHtml::_('bootstrap.addSlide', 'myAccordian', JText::_('COM_JTICKETING_EVENT_TAB_TIME'), 'collapse2', $class='');
										echo $this->loadTemplate('time');
									echo JHtml::_('bootstrap.endSlide');

									echo JHtml::_('bootstrap.addSlide', 'myAccordian', JText::_('COM_JTICKETING_EVENT_TAB_LOCATION'), 'collapse3', $class='');
										echo $this->loadTemplate('location');
									echo JHtml::_('bootstrap.endSlide');

								echo JHtml::_('bootstrap.endAccordion');

							echo JHtml::_('bootstrap.endTab');

							if($this->form_extra)
							{
								echo JHtml::_('bootstrap.addTab', 'myTab', 'extrafields', JText::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS', true));
									echo $this->loadTemplate('extrafields');
								echo JHtml::_('bootstrap.endTab');
							}

							// Tab start for ticket types.
							echo JHtml::_('bootstrap.addTab', 'myTab', 'tickettypes', JText::_('COM_JTICKETING_EVENT_TAB_TICKET_TYPES', true));
								echo $this->loadTemplate('tickettypes');
							echo JHtml::_('bootstrap.endTab');

							// Tab start for Attendee Fields.
							if($this->collect_attendee_info_checkout)
							{
								echo JHtml::_('bootstrap.addTab', 'myTab', 'attendeefields', JText::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS_ATTENDEE', true));
								echo $this->loadTemplate('attendeefields');
							echo JHtml::_('bootstrap.endTab');
							}
						?>
					<?php echo JHtml::_('bootstrap.endTabSet'); ?>

				<?php else:?>

					<ul id="myTab" class="nav nav-tabs">

						<li class="active">
							<a href="#details" data-toggle="tab">
								<?php echo JText::_('COM_JTICKETING_EVENT_TAB_DETAILS');?>
							</a>
						</li>

						<li>
							<a href="#tickettypes" data-toggle="tab">
								<?php echo JText::_('COM_JTICKETING_EVENT_TAB_TICKET_TYPES');?>
							</a>
						</li>

						<?php
						if($this->form_extra)
						{
							?>
							<li>
								<a href="#extrafields" data-toggle="tab">
									<?php echo JText::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS');?>
								</a>
							</li>
							<?php
						}
						?>



						<?php
						if($this->collect_attendee_info_checkout)
						{
							?>
							<li>
								<a href="#attendeefields" data-toggle="tab">
									<?php echo JText::_('COM_JTICKETING_EVENT_TAB_EXTRA_FIELDS_ATTENDEE');?>
								</a>
							</li>
							<?php
						}
						?>

					</ul>

					<div id="myTabContent" class="tab-content">

						<div class="tab-pane fade in active" id="details">
							<?php
								echo $this->loadTemplate('details');
								echo $this->loadTemplate('time');
								echo $this->loadTemplate('location');
							?>
						</div>
						<div class="tab-pane fade in" id="tickettypes">
							<?php echo $this->loadTemplate('tickettypes'); ?>
						</div>
						<div class="tab-pane fade in" id="extrafields">
							<?php
							if (empty($this->item->id))
							{?>
								<div class="alert alert-info">
									<?php echo JText::_('COM_JTICKETING_EVENT_EXTRA_DETAILS_SAVE_PROD_MSG');?>
								</div>
								<?php
							}
							else if($this->form_extra)
							{
								?>
									<?php
									echo $this->loadTemplate('extrafields');
									?>

								<?php
							}
							?>
						</div>
						<?php
						if($this->collect_attendee_info_checkout)
						{
							?>
							<div class="tab-pane fade in" id="attendeefields">
								<?php echo $this->loadTemplate('attendeefields'); ?>
							</div>
							<?php
						}
						?>
					</div>

				<?php endif;?>

				<div class="">
					<button type="button" class="btn btn-default  btn-primary com_jticketing_margin validate"  onclick="Joomla.submitbutton('eventform.save')">
						<span><?php echo JText::_('JSUBMIT'); ?></span>
					</button>

					<a class="btn  btn-default  com_jticketing_margin" href="<?php echo JRoute::_('index.php?option=com_jticketing&task=eventform.cancel'); ?>" title="<?php echo JText::_('JCANCEL'); ?>">
						<?php echo JText::_('JCANCEL'); ?>
					</a>
				</div>

				<input type="hidden" name="option" value="com_jticketing" />
				<input type="hidden" name="task" id="task" value="eventform.save" />
				<input type="hidden" name="id" value="<?php if (!empty($this->item->id)) echo $this->item->id; ?>"/>

				<input type="hidden" name="jform[id]" value="<?php if (!empty($this->item->id)) echo $this->item->id; ?>"/>

				<?php if(empty($this->item->created_by)) : ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo JFactory::getUser()->id; ?>" />
				<?php else : ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo $this->item->created_by; ?>" />
				<?php endif; ?>

				<?php echo JHtml::_('form.token'); ?>

			</form>

		</div>
	</div>
</div>
