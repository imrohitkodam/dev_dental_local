<?php
/**
* @package    jticketing
* @author     Techjoomla
* @copyright  Copyright 2012 - Techjoomla
* @license    http://www.gnu.org/licenses/gpl-3.0.html
**/
jimport( 'joomla.application.module.helper');
$document = JFactory::getDocument();

//no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$document->addStyleSheet(JUri::root().'components/com_jticketing/assets/css/jticketing.css');
$document->addScript(JUri::root(true).'/components/com_jticketing/assets/js/masonry.pkgd.min.js');
$jticketingfrontendhelper = JPATH_ROOT . '/components/com_jticketing/helpers/frontendhelper.php';

if (!class_exists('jticketingfrontendhelper'))
{
	JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
	JLoader::load('jticketingfrontendhelper');
}

$frontendhelper = new jticketingfrontendhelper();
$frontendhelper->loadjticketingAssetFiles();
$tjClass        = 'JTICKETING_WRAPPER_CLASS ';
JLoader::import('main', JPATH_SITE.DS.'components'.DS.'com_jticketing'.DS.'helpers');
$MainHelper          = new jticketingmainhelper();
$singleEventItemid   = $MainHelper->getItemId('index.php?option=com_jticketing&view=events&layout=all',1);
$buyTicketItemId     = $MainHelper->getItemId('index.php?option=com_jticketing&view=buy&layout=default',1);

// @model helper object
$modJTicketingHelper = new modJTicketingHelper();
$featured_camp       = $params->get('featured_camp');
$data                = $modJTicketingHelper->getData($params);
$show_ticket_types   = $params->get('ticket_type');
$pin_width           = $params->get('mod_pin_width', '230', 'INT');
$pin_padding         = $params->get('mod_pin_padding', '10', 'INT');
$arraycnt = count($data);
?>

<div id="mod_jticketing_container<?php echo $module->id;?>" class="<?php echo $tjClass.$params->get('moduleclass_sfx'); ?> container-fluid" >
	<?php for ($i = 0;$i < $arraycnt; $i++)
	{ ?>
		<div class="panel panel-default jticketing_pin_item">
			<?php
			if ($data[$i]['event']->online_events == 1)
			{
				$eventImg = 'Online';
				$eventName = JText::_("COM_JTICKETING_VENUE_TYPEONLINE");
			}
			if ($data[$i]['event']->featured == 1)
			{
				$eventFeaturedImg = 'Featured';
				$eventFeaturedName = JText::_("COM_JTICKETING_EVENT_TYPEONLINE_FEATURED");
			}
			?>
			<div class="jt-descrip">
				<div class="jticketing_pin_img" >
					<?php
					$moduleImage = $params->get('image');
					if (!empty($moduleImage))
					{  ?>
						<!-- Image-->
						<div class="jticketing_pin_layout_element jticketing_pin_img" >
							<a class="" href="<?php echo JUri::root().substr(JRoute::_('index.php?option=com_jticketing&view=event&id='.$data[$i]['event']->id.'&Itemid='.$singleEventItemid),strlen(JUri::base(true))+1);?>" style=" background:url(<?php
							   $imagePath = 'media/com_jticketing/images/';
							   $imagePath = JRoute::_(JUri::base() . $imagePath . $data[$i]['event']->image, false);
							   echo $imagePath; ?>);  background-position: center center; background-size: 100% 100%; background-repeat: no-repeat;">
							</a>
						</div>
					<?php
					} ?>
				</div>
				<!-- Image div ends-->
				<!-- Event Title-->
				<div class="jt-heading jticketing_align">
					<?php
					if ($data[$i]['event']->online_events == 1)
					{?>
						<span class="jt_online_text"><?php echo $eventName;?></span>
					<?php
					}
					if($data[$i]['event']->featured == 1)
					{?>
						<span class="jt_featured_text"><?php echo $eventFeaturedName;?></span>
					<?php
					} ?>
					<a href="<?php echo JRoute::_('index.php?option=com_jticketing&view=event&id='.$data[$i]['event']->id.'&Itemid='.$singleEventItemid,false);?>">
						<strong><?php echo $data[$i]['event']->title; ?></strong>
					</a>
				</div>
				<!-- caption starts-->
				<div class="caption">
					<div class="com_jticketing_paddingh10 com_jticketing_paddingv5">
						<i class="fa fa-map-marker" aria-hidden="true"></i>
						<?php
							if ($data[$i]['event']->online_events == "1")
							{
								if ($data[$i]['event']->online_provider == "plug_tjevents_adobeconnect")
								{
									echo JText::_('COM_JTICKETING_ADOBECONNECT_PLG_NAME') . " - " . $data[$i]['event']->name;
								}
							}
							elseif($data[$i]['event']->online_events == "0")
							{
								if ($data[$i]['event']->venue != "0")
								{
									echo $data[$i]['event']->name . " : " . JText::_('COM_JTICKETING_BILLIN_ADDR') .  "- " . $data[$i]['event']->address . ", " . $data[$i]['event']->city . ", " . $data[$i]['event']->region . ", " . $data[$i]['event']->coutryName . ", " . JText::_('COM_JTICKETING_FORM_LBL_VENUE_ZIPCODE') . " - " . $data[$i]['event']->zipcode;
								}
								else
								{
									echo $data[$i]['event']->location;
								}
							}
							else
							{
								echo "-";
							}
						?>
					</div>
					<!--jticketing_place-->
				</div>
				<!--caption ends-->
			</div>

			<?php if($show_ticket_types == 1)
			{ ?>
				<div class="caption">
					<div class="jticketing_caption">
						<?php echo JText::_('MOD_JTICKETING_EVENT_JT_TICKET_TYPES'); ?>
					</div>
					<!--jticketing_caption-->
					<div class="ticket-table">
						<?php if($data[$i]['ticket_types'])
						{ ?>
							<table class="table table-bordered">
								<tr>
									<th>
										<?php echo JText::_('MOD_JTICKETING_EVENT_TYPE');?>
									</th>
									<th>
										<?php echo JText::_('MOD_JTICKETING_EVENT_PRICE');?>
									</th>
									<th>
										<?php echo JText::_('MOD_JTICKETING_EVENT_NO_SEATS');?>
									</th>
								</tr>
								<?php
								$ticket_type = $data[$i]['ticket_types'];
								for($j=0;$j<count($ticket_type);$j++)
								{ ?>
									<tr>
										<td>
										 <?php
											if($ticket_type[$j]->title)
											{
												echo $ticket_type[$j]->title;
											}
											else
											{
												echo "-";
											}
											?>
										</td>
										<td>
										 <?php
											if($ticket_type[$j]->price)
											{
												echo $frontendhelper->getFromattedPrice($ticket_type[$j]->price);
											}
											else
											{
												echo "-";
											}

											?>
										</td>
										<td>
										 <?php
											if($ticket_type[$j]->count)
											{
												echo $ticket_type[$j]->count;
											}
											else
											{
												echo "-";
											}
											?>
										</td>
									</tr>
							<?php
								} ?>
							</table>
						<?php
						} ?>
					</div>
				</div>
			<?php
			} ?>
			<div class="caption com_jticketing_paddingh10 com_jticketing_paddingv5">
				<?php
				$start_date = $params->get('show_event_start_end_date');

				if (!empty($start_date))
				{
					$statrtDate = JFactory::getDate($data[$i]['event']->startdate)->Format(JText::_('MOD_JTICKETING_EVENT_DATE_FORMAT_SHOW_AMPM'));
					$startDate =  JHtml::date($data[$i]['event']->startdate, JText::_('MOD_JTICKETING_EVENT_DATE_FORMAT_SHOW_AMPM'), true);?>
					<div class="small">
						<span class="" >
							<div class="jt-start"><?php echo JText::_('MOD_JTICKETING_EVENT_EVENT_STARTDATE');?></div>
							<?php echo $startDate; ?>
					   </span>
					   <?php
						if ( !empty($data[$i]['event']->enddate) && ($data[$i]['event']->enddate != '0000-00-00 00:00:00'))
						{
							$endDate = JFactory::getDate($data[$i]['event']->enddate)->Format(JText::_('MOD_JTICKETING_EVENT_DATE_FORMAT_SHOW_AMPM'));
							$endDate =  JHtml::date($data[$i]['event']->enddate, JText::_('MOD_JTICKETING_EVENT_DATE_FORMAT_SHOW_AMPM'), true);
								?>
							<strong>&nbsp;<?php echo JText::_('MOD_JTICKETING_EVENT_TO'); ?></strong>
							<br>
							<span class="" >
								<?php echo $endDate; ?>
							</span>
					   <?php
					   } ?>
					</div>
					<hr class="hr hr-condensed"/>
					<?php
				}
					$endDate = $params->get('show_booking_start_end_date');

					if (!empty($endDate))
					{ ?>
						<div class="small">
							<span class="" >
								<div class="jt-start"><?php echo JText::_('MOD_JTICKETING_EVENT_EVENT_BOOKING_START_DATE');?></div>
								<?php echo JFactory::getDate($data[$i]['event']->booking_start_date)->Format(JText::_('MOD_JTICKETING_EVENT_DATE_FORMAT_SHOW_SHORT')); ?>
							</span>
							<?php
						  if ( !empty($data[$i]['event']->booking_end_date) && ($data[$i]['event']->booking_end_date != '0000-00-00 00:00:00'))
						  {
						  ?>
							<div class="jt-start"><?php echo JText::_('MOD_JTICKETING_EVENT_EVENT_BOOKING_END_DATE'); ?></div>
							<span class="" >
								<?php echo JFactory::getDate($data[$i]['event']->booking_end_date)->Format(JText::_('MOD_JTICKETING_EVENT_DATE_FORMAT_SHOW_SHORT')); ?>
							</span>
					   <?php } ?>
						</div>
					<?php
					} ?>
				 <div class="center">
					<?php
					$jticketingmainhelper = new jticketingmainhelper;
					$eventdata = $jticketingmainhelper->getAllEventDetails($data[$i]['event']->id);
					$userID = JFactory::getUser()->id;
					$Jticketingfrontendhelper = new Jticketingfrontendhelper;
					$event_data        = $Jticketingfrontendhelper->renderBookingHTML($data[$i]['event']->id, $userID, $eventdata );

					/*echo $event_data['details_button'];
					if (array_key_exists('enroll_button', $event_data))
					{
						echo $event_data['enroll_button'];
					}elseif (array_key_exists('buy_button', $event_data))
					{
						echo $event_data['buy_button'];
					}elseif (array_key_exists( 'adobe_connect', $event_data))
					{
						echo $event_data['adobe_connect'];
					}

					if (array_key_exists('guest_meeting_btn', $event_data))
					{
						echo $event_data['guest_meeting_btn'];
					}*/

				?>
				 </div>
			  </div>
			  <!--caption-->
		</div>
   <?php } ?>

</div>
<style>
#mod_jticketing_container<?php echo $module->id;?> .jticketing_pin_item { width: <?php echo $pin_width . 'px'; ?> !important; }
</style>

<script type="text/javascript">
	var container = document.querySelector('#mod_jticketing_container<?php echo $module->id;?>');

	var msnry = new Masonry( container, {

	 // options
	 columnWidth: <?php echo $pin_width; ?>,
	 gutter: <?php echo $pin_padding; ?>,
	 itemSelector: '.jticketing_pin_item'
	});

	techjoomla.jQuery(document).ready(function()
	{
		var msnry = new Masonry( container, {
		 // options
		 columnWidth: <?php echo $pin_width; ?>,
		 gutter: <?php echo $pin_padding; ?>,
		 itemSelector: '.jticketing_pin_item'
		});

		setTimeout(function(){
			var container = document.querySelector('#container');
			var msnry = new Masonry( container, {
			  // options
			columnWidth: <?php echo $pin_width; ?>,
			gutter: <?php echo $pin_padding; ?>,
			itemSelector: '.jticketing_pin_item'
			});
		},500);

		setTimeout(function(){
			var container = document.querySelector('#container');
			var msnry = new Masonry( container, {
			  // options
			 columnWidth: <?php echo $pin_width; ?>,
			 gutter: <?php echo $pin_padding; ?>,
			 itemSelector: '.jticketing_pin_item'
			});
		},1000);
	});
</script>
