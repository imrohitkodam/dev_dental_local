<?php
// no direct access
defined( '_JEXEC' ) or die( ';)' );
JHtml::_('behavior.modal', 'a.modal');
$document =JFactory::getDocument();
$integration=$this->jticketingmainhelper->getIntegration();
jimport('joomla.filter.output');
jimport( 'joomla.utilities.date');
$bootstrapclass="";
$tableclass="adminlist tablecss table-striped table-hover";
$buttonclass="button";
$buttonclassprimary="button";
$com_params=JComponentHelper::getParams('com_jticketing');
$integration = $com_params->get('integration');
$siteadmin_comm_per = $com_params->get('siteadmin_comm_per');
$show_js_toolbar = $com_params->get('show_js_toolbar');
$currency= $com_params->get('currency');
$bootstrapclass="JTICKETING_WRAPPER_CLASS";
$tableclass="table table-striped table-hover ";
$buttonclass="btn";
$buttonclassprimary="btn btn-primary";
$appybtnclass="btn btn-primary";

$user =JFactory::getUser();
if(empty($user->id))
{

	echo '<b>'.JText::_('USER_LOGOUT').'</b>';
	return;

}
$payment_statuses=array('P'=>JText::_('JT_PSTATUS_PENDING'),
'C'=>JText::_('JT_PSTATUS_COMPLETED'),
		'D'=>JText::_('JT_PSTATUS_DECLINED'),
		'E'=>JText::_('JT_PSTATUS_FAILED'),
		'UR'=>JText::_('JT_PSTATUS_UNDERREVIW'),
		'RF'=>JText::_('JT_PSTATUS_REFUNDED'),
		'CRV'=>JText::_('JT_PSTATUS_CANCEL_REVERSED'),
		'RV'=>JText::_('JT_PSTATUS_REVERSED'),
);
?>
<?php
$integration=$this->jticketingmainhelper->getIntegration();
if($integration==1) //if Jomsocial show JS Toolbar Header
{
	$jspath=JPATH_ROOT.DS.'components'.DS.'com_community';
	$header='';
	$header=$this->jticketingmainhelper->getJSheader();
	if(!empty($header))
	echo $header;
}
?>

<div  class="floattext">
	<h1 class="componentheading"><?php echo JText::_('ATTND_LIST'); ?>	</h1>
</div>
<?php


		if(!$this->lists['search_event']){
			$input=JFactory::getApplication()->input;
			$eventid = $input->get('event','','INT');
			$eventnm=$this->jticketingmainhelper->getEventcustominfo($eventid,'title');
			$evnt_nm=$eventnm;


		}
		else{
			$eventid =$this->lists['search_event'];
			$eventnm=$this->jticketingmainhelper->getEventcustominfo($this->lists['search_event'],'title');
			$evnt_nm=$eventnm;

		}


$linkbackbutton='';

if($eventid)
{
	$linkbackbutton=$this->jticketingmainhelper->BackButtonSite($eventid,$this->Itemid);
	echo "<div class='techjoomla-bootstrap'>
	<div  class='row-fluid'><div class='pull-right jtickspacer-bottom span12'><a class='btn btn-small btn-info' onclick='window.history.go(-1)'><i class='icon-circle-arrow-left'></i> ".JText::_('BACK')."</a></div></div></div>";// Back Button
}
	echo '<form action="" method="post" name="adminForm" id="adminForm">';
?>


	<?php
	if(empty($this->Data))
	{
		echo JText::_('NODATA');

		?>
	<input type="hidden" name="option" value="com_jticketing" />
	<input type="hidden" name="task" id="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
	<input type="hidden" name="controller" value="attendees" />
	<input type="hidden" name="view" value="attendees" />
	<input type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
	</form>

	<?php
		if($integration==1)
		{
			$footer='';
			$footer=$this->jticketingmainhelper->getJSfooter();
			if(!empty($footer))
				echo $footer;
		}
		return;
	}
	?>



<div class="<?php echo JTICKETING_WRAPPER_CLASS;?>">
	<div id="all" class="row-fluid">
		<div style="float:left">
		<?php  echo JHtml::_('select.genericlist', $this->status_event, "search_event", 'class="ad-status" size="1"
					onchange="javascript:document.getElementById(\'task\').value =\'\';	document.adminForm.submit();" name="search_event"',"value", "text", $this->lists['search_event']);
		?>

		</div>
		<?php if(JVERSION>='3.0') {?>
	<div class="btn-group pull-right hidden-phone">
		<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
			<?php
			echo $this->pagination->getLimitBox();
			?>
	</div>
	<?php } ?>
<table border="0" width="100%" class="<?php echo $tableclass;?>">
	<tr >
		<th ><?php echo JHtml::_( 'grid.sort','ATTENDER_NAME','name', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<th ><?php echo JHtml::_( 'grid.sort','BOUGHTON','cdate', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<th align="center"><?php echo JText::_( 'TICKET_TYPE_TITLE' );?></th>
		<th ><?php echo JHtml::_( 'grid.sort','TICKET_TYPE_RATE','amount', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<!--<th align="center"><?php echo JText::_( 'NUMBEROFTICKETS_BOUGHT' );?></th>
		<th align="center"><?php echo  JText::_( 'TOTAL_AMOUNT' ); ?></th>-->
		<th ><?php echo JHtml::_( 'grid.sort','PAYMENT_STATUS','status', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<th align="center"><?php echo  JText::_( 'PREVIEW_TICKET' ); ?></th>
	</tr>

	<?php
			$i = 0;
			$totalnooftickets=$totalprice=$totalcommission=$totalearn=0;
			foreach($this->Data as $data) {

			$totalnooftickets=$totalnooftickets+$data->ticketcount;
			$totalprice=$totalprice+$data->amount;
			$totalearn=$totalearn+$data->totalamount;
					 if(empty($data->thumb))
					 	$data->thumb = 'components/com_community/assets/user_thumb.png';
						$link = JRoute::_('index.php?option=com_community&view=profile&userid='.$data->user_id);

	?>
	<tr class="">
			<td align="center">
				<?php echo ucfirst($data->name);?>
			</td>
			<td align="center"><?php

			$jdate = new JDate($data->cdate);


			 if(JVERSION<'1.6.0')
			 echo  str_replace('00:00:00','',$jdate->Format('d-m-Y'));

			else
			 echo  str_replace('00:00:00','',$jdate->Format('d-m-Y'));

			 ?></td>
			 <td align="center"><?php echo $data->ticket_type_title; ?></td>
			<td align="center"><?php echo $data->amount.' '.$currency;?></td>
			<!--<td align="center"><?php echo $data->ticketcount ?></td>
			<td align="center"><?php echo $data->totalamount.$currency;?></td>-->
			<td align="center"><?php echo $payment_statuses[$data->status];?></td>
			<td	align="center">
				<?php



				if($data->status=='C')
				{

				 $link = JRoute::_('index.php?option=com_jticketing&view=mytickets&tmpl=component&layout=ticketprint&$jticketing_usesess=0&jticketing_eventid='.$data
				 ->evid.'&jticketing_userid='.$data->user_id.'&jticketing_ticketid='.$data->id.'&jticketing_order_items_id='.$data->order_items_id);
				?>

				<a rel="{handler: 'iframe', size: {x: 600, y: 600}}" href="<?php echo $link; ?>" class="modal">
					<span class="editlinktip hasTip" title="<?php echo JText::_('PREVIEW_DES');?>" ><?php echo JText::_('PREVIEW');?></span>
				</a>
				<?php
				}
				else
				echo '-';
				?>


			</td>

	</tr>
	<?php $i++;} ?>
			<tr>
			<td colspan="4" align="right"><b><?php echo JText::_('TOTAL');?></b></td>
			<td align="center"><b><?php echo number_format($totalnooftickets, 2, '.', '');?></b></td>
			<!--<td align="center"><b><?php echo number_format($totalearn, 2, '.', '').$currency;?></b></td>-->
			<td></td>
			</tr>

	</table>
	</div><!--row-fluid-->

		<div class="row-fluid">
		<div class="span12">
			<?php
				if(JVERSION<3.0)
					$class_pagination='pager';
				else
					$class_pagination='pagination';
			?>
			<div class="<?php echo $class_pagination; ?> com_jgive_align_center">
				<?php echo $this->pagination->getListFooter(); ?>
			</div><!--span12-->
		</div><!--row-fluid-->
<input type="hidden" name="option" value="com_jticketing" />
<input type="hidden" name="event" value="com_jticketing" />
<input type="hidden" name="task" id="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
<input type="hidden" name="controller" value="attendees" />
<input type="hidden" name="view" value="attendees" />
<input type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />

</div>
</div>

</form>

<!-- newly added for JS toolbar inclusion  -->
<?php
if($integration==1) //if Jomsocial show JS Toolbar Footer
{
$footer='';
	$footer=$this->jticketingmainhelper->getJSfooter();
	if(!empty($footer))
	echo $footer;
}
?>
<!-- eoc for JS toolbar inclusion	 -->

