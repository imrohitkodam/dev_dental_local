<?php
// no direct access
defined( '_JEXEC' ) or die( ';)' );
jimport( 'joomla.utilities.date');
jimport('joomla.filter.output');
$tableclass="table table-striped  table-hover";
$document=JFactory::getDocument();
$jticketingmainhelper = new jticketingmainhelper();
$com_params=JComponentHelper::getParams('com_jticketing');
$integration = $com_params->get('integration');
$siteadmin_comm_per = $com_params->get('siteadmin_comm_per');
$show_js_toolbar = $com_params->get('show_js_toolbar');
$currency = $com_params->get('currency');
$user =JFactory::getUser();
$input=JFactory::getApplication()->input;

if(empty($user->id))
{

	echo '<b>'.JText::_('USER_LOGOUT').'</b>';
	return;
}

if(JVERSION >= '1.6.0')
	$js_key="
	Joomla.submitbutton = function(task){ ";
else
	$js_key="
	function submitbutton( task ){";

	$js_key.="
		document.adminForm.action.value=task;
		if (task =='cancel')
		{";
	        if(JVERSION >= '1.6.0')
				$js_key.="	Joomla.submitform(task);";
			else
				$js_key.="document.adminForm.submit();";
	    $js_key.="

		}
	}
";

	$document->addScriptDeclaration($js_key);
	if($integration==1) //if Jomsocial show JS Toolbar Header
	{
		$jspath=JPATH_ROOT.DS.'components'.DS.'com_community';
		if(file_exists($jspath))
		{
			require_once($jspath.DS.'libraries'.DS.'core.php');
		}
		$header='';
		$header=$this->jticketingmainhelper->getJSheader();
		if(!empty($header))
		echo $header;
	}
?>
<div  class="floattext">
	<h3 class="componentheading"><?php echo JText::_('TICK_SALES'); ?>	</h3>
</div>
<?php

		$eventid =$this->lists['search_event'];

		if(!$eventid)
		$eventid=$input->get('event','','INT');
	$linkbackbutton='';

		//eoc for JS toolbar inclusion
if(empty($this->Data))
{
	echo '
	<form action="" method="post" name="adminForm"	id="adminForm">';
	echo '<div class="alert alert-info ">'. JText::_('NODATA').'</div>';
	?>

<input type="hidden" name="option" value="com_jticketing" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
<input type="hidden" name="controller" value="allticketsales" />
<input type="hidden" name="view" value="allticketsales" />
<input type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>" />

</form>

	<?php
	if($integration==1)
	{
		$footer='';
		$footer=$this->jticketingmainhelper->getJSfooter();
		if(!empty($footer))
			echo $footer;
	}
	return;
}
?>

<div class="<?php echo JTICKETING_WRAPPER_CLASS;?>">
<form action="" method="post" name="adminForm" id="adminForm">
		<div id="all" class="row-fluid">
			<div style="float:left">
			<?php echo JHtml::_('select.genericlist', $this->status_event, "search_event", 'class="ad-status" size="1"
				onchange="document.adminForm.submit();" name="search_event"',"value", "text", $this->lists['search_event']);		 ?>
			</div>

			<?php if(JVERSION>='3.0') {?>
			<div class="btn-group pull-right hidden-phone">
			<?php
				echo $this->pagination->getLimitBox();
			?>
			</div>
			<?php }?>


		<div class="table-responsive">
			<br/><table 	class="table table-striped  table-hover">
				<tr>
					<th ><?php echo JHtml::_( 'grid.sort','EVENT_NAME','title', $this->lists['order_Dir'], $this->lists['order']); ?></th>
					<!--<th ><?php echo JHtml::_( 'grid.sort','BOUGHTON','cdate', $this->lists['order_Dir'], $this->lists['order']); ?></th>-->
					<th ><?php echo JHtml::_( 'grid.sort','NUMBEROFTICKETS_SOLD','eticketscount', $this->lists['order_Dir'], $this->lists['order']); ?></th>
					<th align="center"><?php echo  JText::_( 'EARNINGTOTAL_AMOUNT' ); ?></th>
					<th align="center"><?php echo  JText::_( 'COMMISSION' ); ?></th>
					<th align="center"><?php echo  JText::_( 'TOTAL_AMOUNT' ); ?></th>
			</tr>
				<?php
				$i = $subtotalamount=0;$sclass='';

				$totalnooftickets=$totalprice=$totalcommission=$totalearn=0;
				foreach($this->Data as $data)
				{
				$totalnooftickets=$totalnooftickets+$data->eticketscount;
				$totalprice=$totalprice+$data->eamount;
				$totalcommission=$totalcommission+$data->ecommission;
				$totalearn=$totalearn+($data->eamount-$data->ecommission);
				 if(empty($data->thumb))
					$data->thumb = JUri::root().'components/com_community/assets/event_thumb.png';
				 else
						$data->thumb = JUri::root().$data->thumb;
				$link = JRoute::_(JUri::base().'index.php?option=com_jticketing&view=attendee_list&event='.$data->evid.'&Itemid='.$this->Itemid);
		?>
				<tr>
						<td>

								<!--<img width="32" class="avatar"  src="<?php echo $data->thumb;?>" />-->
								<a href="<?php echo $link;?>"><?php echo ucfirst($data->title);?></a>
						</td>
						<!--<td align="center"><?php

					$jdate = new JDate($data->cdate);


						 if(JVERSION<'1.6.0')
						 echo  str_replace('00:00:00','',$jdate->Format('d-m-Y'));

						else
						 echo  str_replace('00:00:00','',$jdate->Format('d-m-Y'));
						  ?></td>-->

						<td align="center"><?php echo $data->eticketscount ?></td>
						<td align="center"><?php echo $jticketingmainhelper->getFromattedPrice( number_format(($data->eamount),2),$currency); ?></td>
						<td align="center"><?php echo $jticketingmainhelper->getFromattedPrice( number_format(($data->ecommission),2),$currency); ?></td>
						<td align="center"><?php	$subtotalearn=$data->eamount-$data->ecommission;
							echo $jticketingmainhelper->getFromattedPrice( number_format(($subtotalearn),2),$currency); ?>
						</td>
				</tr>
			<?php $i++;} ?>
			<tr>
			<td><div class="jtright"><b><?php echo JText::_('TOTAL');?></b></div></td>

			<td ><b><?php echo number_format($totalnooftickets, 0, '', '');?></b></td>
			<td ><b><?php echo $jticketingmainhelper->getFromattedPrice( number_format(($totalprice),2),$currency); ?></b></td>
			<td ><b><?php echo $jticketingmainhelper->getFromattedPrice( number_format(($totalcommission),2),$currency); ?></b></td>
			<td ><b><?php echo $jticketingmainhelper->getFromattedPrice( number_format(($totalearn),2),$currency); ?></b></td>
			</tr>

				<!--<tr rowspan="2" height="20">
					<td align="right" colspan="4"></td>
					<td align="center"></td>
				</tr>
				<tr >
					<td align="right" colspan="4"><div class="jtright"><?php echo JText::_( 'SUBTOTAL'); ?></div></td>
					<td align="center"><?php 		$user=JFactory::getUser();
					echo number_format($totalearn, 2, '.', '');echo ' '.$currency;?></td>
				</tr>

				<tr>
				<td align="right" colspan="4"><div class="jtright"><?php echo JText::_( 'PAID'); ?></div></td>
				<td align="center"><?php 		$user = JFactory::getuser();
				 $totalpaidamount=$this->jticketingmainhelper->getpaidamount();
					 echo	number_format($totalpaidamount, 2, '.', '');
					echo ' '.$currency;?></td>
				</tr>

				<tr>
					<td align="right" colspan="4"><div class="jtright"><?php echo JText::_( 'BAL_AMT'); ?></div></td>
					<td align="center"><?php
					$balanceamt1=$totalearn-$totalpaidamount;
				  $balanceamt=number_format($balanceamt1, 2, '.', '');
						if($balanceamt=='-0.00')
						echo	'0.00';
						else
						echo number_format($balanceamt1, 2, '.', '');

						echo ' '.$currency;?></td>
				</tr>-->

				</table>
			</div>
			<input type="hidden" name="option" value="com_jticketing" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="defaltevent" value="<?php echo $this->lists['search_event'];?>" />
			<input type="hidden" name="controller" value="allticketsales" />
			<input type="hidden" name="view" value="allticketsales" />
			<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
			<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
		</div><!--row fluid -->

		<div class="row-fluid">
			<div class="span12">
				<?php
					if(JVERSION<3.0)
						$class_pagination='pager';
					else
						$class_pagination='pagination';
				?>
				<div class="<?php echo $class_pagination; ?> com_jgive_align_center">
					<?php echo $this->pagination->getListFooter(); ?>
				</div>
			</div><!--span12-->
		</div><!--row-fluid-->
</form>
</div><!--bootstrap-->
	<!-- newly added for JS toolbar inclusion  -->
<?php
if($integration==1) //if Jomsocial show JS Toolbar Footer
{
$footer='';
	$footer=$this->jticketingmainhelper->getJSfooter();
	if(!empty($footer))
	echo $footer;
}
?>
<!-- eoc for JS toolbar inclusion	 -->
