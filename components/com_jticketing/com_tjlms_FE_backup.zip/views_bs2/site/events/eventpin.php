<?php
   /**
    * @version    SVN: <svn_id>
    * @package    JTicketing
    * @author     Techjoomla <extensions@techjoomla.com>
    * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
    * @license    GNU General Public License version 2 or later.
    */

// No direct access.
defined('_JEXEC') or die();
$jticketingmainhelper =new jticketingmainhelper();
$app  = JFactory::getApplication();

$this->jt_params     = $app->getParams('com_jticketing');
$this->enable_self_enrollment     =  $this->jt_params->get('enable_self_enrollment', '', 'INT');
$this->supress_buy_button     =  $this->jt_params->get('supress_buy_button', '', 'INT');
$this->accesslevels_for_enrollment     =  $this->jt_params->get('accesslevels_for_enrollment');
$user   = JFactory::getUser();
$groups = $user->getAuthorisedViewLevels();
$guest  = $user->get('guest');
$allow_access_level_enrollment = 0;
$currentTime = JFactory::getDate()->toSql();
JHtml::script(  JUri::root() . 'components/com_jticketing/assets/js/jquery.countdown.js');

// Check access levels for enrollment
foreach ($groups as $group)
{
	if (in_array($group, $this->accesslevels_for_enrollment))
	{
		$allow_access_level_enrollment = 1;
		break;
	}
}
	$integration = $this->jt_params->get('integration', '', 'INT');
?>

<script>
		techjoomla.jQuery(document).ready(function() {

			jQuery("a span").attr('disabled','disabled');
			jQuery('adobe-enter-btn').unbind('click');
			jQuery('.adobe-enter-btn').addClass('disabled');
			jQuery('.adobe-enter-btn').addClass('inactiveLink');
			jQuery('.endevent_<?php echo $eventdata->id; ?>').hide();

			if (jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?>').find('.adobe-enter-btn').length)
			{
				jQuery('.adobe-enter-btn').hide();
				var meetingBtn = '<a rel="popover" class="btn btn-info adobe-hidden-btn"><?php echo JText::_("COM_JTICKETING_MEETING_BUTTON") ?></a>';
				jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?>').find('.tj-adobeconnect').append(meetingBtn);
			}

			jQuery('#countdown_timer_<?php echo $eventdata->id; ?>').countdown({
				until:'<?php echo strtotime($eventdata->startdate) - strtotime($currentTime); ?>',
				compact: true,
				onTick: watchCountdown_<?php echo $eventdata->id; ?>
			});

			jQuery('[rel="popover"]').on('click', function (e) {
				jQuery('[rel="popover"]').not(this).popover('hide');
			});

			/*Add popover when enter meeting button is hidden*/
			jQuery('[rel="popover"]').popover({
				html: true,
				trigger: 'click',
				placement: 'top',
				content: function () {
					return '<button type="button" id="close" class="close" onclick="popup_close(this);">&times;</button><div class="tj-popover"><div class="tj-content"><?php echo JText::_("COM_JT_MEETING_ACCESS") ?></div></div>';
				}
			});
		});

		/*Popover close button*/
		function popup_close(btn)
		{
			jQuery(btn).closest('.popover').hide();
		}

		// Add function for countdowntimer till Startdate
		function watchCountdown_<?php echo $eventdata->id; ?>(periods)
		{
			jQuery('.startevent_<?php echo $eventdata->id; ?>').css('color','#337ab7');
			jQuery('#countdown_timer_<?php echo $eventdata->id; ?>').css('color','#468847');

			if ((jQuery.countdown.periodsToSeconds(periods) < 5*60) && (jQuery.countdown.periodsToSeconds(periods) > 1*0))
			{
				jQuery('#reverse_timer_<?php echo $eventdata->id; ?>').addClass('text-success');
				jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('disabled');
				jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('inactiveLink');
				jQuery('.adobe-enter-btn').addClass('btn-success');
				jQuery('.startevent_<?php echo $eventdata->id; ?>').show();
				jQuery('.endevent_<?php echo $eventdata->id; ?>').hide();
				jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?> .adobe-enter-btn').show();
				jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?> .adobe-hidden-btn').remove();
			}

			if ((jQuery.countdown.periodsToSeconds(periods) <= 1*0))
			{
				watchEventcountdowns_<?php echo $eventdata->id; ?>();
			}
		}

		// Add function for countdowntimer till Enddate
		function watchEventcountdowns_<?php echo $eventdata->id; ?>()
		{
			jQuery('.endevent_<?php echo $eventdata->id; ?>').show();
			jQuery('.startevent_<?php echo $eventdata->id; ?>').hide();
			jQuery('#countdown_timer_<?php echo $eventdata->id; ?>').hide();
			jQuery('#reverse_timer_<?php echo $eventdata->id; ?>').countdown({
			until: '<?php echo strtotime($eventdata->enddate) - strtotime($currentTime); ?>',
			compact: true,
			onTick: watchRevcountdowns_<?php echo $eventdata->id; ?>
			});
		}

		// Add function for countdowntimer till Enddate
		function watchRevcountdowns_<?php echo $eventdata->id; ?>(periods)
		{
			if (jQuery.countdown.periodsToSeconds(periods) >= 1*0)
			{
				jQuery('#reverse_timer_<?php echo $eventdata->id; ?>').addClass('text-success');
				jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('disabled');
				jQuery('.tj-adobeconnect .adobe-enter-btn').removeClass('inactiveLink');
				jQuery('.adobe-enter-btn').addClass('btn-success');
				jQuery('.counter_<?php echo $eventdata->id; ?>').css('color', 'red');
				jQuery('.endevent_<?php echo $eventdata->id; ?>').show();
				jQuery('.startevent_<?php echo $eventdata->id; ?>').hide();
				jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?> .adobe-enter-btn').show();
				jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?> .adobe-hidden-btn').remove();
			}

			if ((jQuery.countdown.periodsToSeconds(periods) <= 1*0))
			{
				jQuery('.counter_<?php echo $eventdata->id; ?>').text("<?php echo JText::_("COM_JTICKETING_EVENT_FINISHED") ?>");
				jQuery('.counter_<?php echo $eventdata->id; ?>').css('color', 'red');
				jQuery('#reverse_timer_<?php echo $eventdata->id; ?>').css('color', 'red');
				jQuery('.jticketing_pin_layout_element_<?php echo $eventdata->id;?> .adobe-enter-btn').remove();
			}
		}
</script>

<div class="jticket_pin_item_<?php echo $random_container;?>" >
<!--Panel starts-->
	<div class=" panel-default jticketing_pin_item jticketing_pin_layout_element_<?php echo $eventdata->id;?>">

			<?php
			if ($eventdata->online_events == 1)
			{
				$eventImg = 'Online';
				$eventName = JText::_("COM_JTICKETING_VENUE_TYPEONLINE");
			}

			if ($eventdata->featured == 1)
			{
				$eventFeaturedImg = 'Featured';
				$eventFeaturedName = JText::_("COM_JTICKETING_EVENT_TYPEONLINE_FEATURED");
			}
			?>

			<!--panel-heading ends-->
			<div class="jt-descrip">
				<div class="jticketing_pin_img" >
					<a href="<?php echo $jticketingmainhelper->getEventlink($eventdata->id);?>" style=" background:url(<?php

						if ($integration == 2)
						{
							$imagePath = 'media/com_jticketing/images/';
						}

						if ($integration == 4)
						{
							$imagePath = '/media/com_easysocial/avatars/event/'.$eventdata->id.'/';
						}

						if(empty($eventdata->image))
						{
							$imagePath = JRoute::_(JUri::base() .'media/com_jticketing/images/default-event-image.png');
						}
						else
						{
							$imagePath = JRoute::_(JUri::base() . $imagePath . $eventdata->image);
						}

						echo $imagePath; ?>);  background-position: center center; background-size: 100% 100%; background-repeat: no-repeat;">
					</a>
				</div>
			<!-- Image div ends-->
            	<div class="jt-heading">
				<?php if ($eventdata->online_events == 1)
				{?>
					<span class="jt_online_text"><?php echo $eventName;?></span>
				<?php
				}
				if($eventdata->featured == 1)
				{?>
					<span class="jt_featured_text"><?php echo $eventFeaturedName;?></span>
				<?php
				}
?>
				<a href="<?php echo  $jticketingmainhelper->getEventlink($eventdata->id);?>">
					<h4><?php echo $eventdata->title; ?></h4>
				</a>
			</div>
			<!-- caption starts-->
			<div class="caption">
				<div class="com_jticketing_paddingh10 com_jticketing_paddingv5">
					<i class="fa fa-map-marker" aria-hidden="true"></i>
					<?php echo $eventdata->location;  ?>
				 </div>
				 <!--jticketing_place-->
			</div>
			<!--caption ends-->

			<div class="com_jticketing_paddingh10 com_jticketing_paddingv5">

				<!--
							<div class="row small">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<strong><?php echo JText::_('COM_JTICKETING_EVENT_STARTDATE') . ' : ';?></strong>
									<?php echo JFactory::getDate($eventdata->startdate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_AMPM')); ?>
								</div>
							</div>

							<?php
							if (!empty($enddate) and $enddate != '0000-00-00 00:00:00')
							{
							?>
							<div class="row small">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<strong><?php echo JText::_('COM_JTICKETING_EVENT_ENDDATE') . ' : ';?></strong>
									<?php echo JFactory::getDate($enddate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_AMPM')); ?>
								</div>
							</div>
							<?php
							}
							?>
				-->
				<div class="small">
					<span class="" >
						<div class="jt-start"><?php echo JText::_('COM_JTICKETING_EVENT_DATE') . ': ';?></div>
						<?php
							$statrtDate = JFactory::getDate($eventdata->startdate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_FJY'));
							$startDate =  JHtml::date($eventdata->startdate, JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_FJY'), true);
							echo $startDate;
							?>
					</span>
					<?php
					if (!empty($eventdata->enddate) and $eventdata->enddate != '0000-00-00 00:00:00')
					{
					?>
						<strong>&nbsp;<?php echo JText::_('COM_JTICKETING_EVENT_PIN_TO'); ?></strong>
						<br>
						<span class="" >
						<?php
							$endDate = JFactory::getDate($eventdata->enddate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_FJY'));
							$endDate =  JHtml::date($eventdata->enddate, JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_FJY'), true);
							echo $endDate; ?>
						</span>
					<?php
					}
					?>
				</div>
				<!--
				<?php
				if (!empty($eventdata->booking_start_date))
				{
				?>
			<div class="row small">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<strong><?php echo JText::_('COM_JTICKETING_EVENT_BOOKING_START_DATE') . ' : ';?></strong>
					<?php echo JFactory::getDate($eventdata->booking_start_date)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT')); ?>
				</div>
			</div>
			<?php
			}
			?>

			<?php
			if (!empty($eventdata->booking_start_date))
			{
			?>
			<div class="row small">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<strong><?php echo JText::_('COM_JTICKETING_EVENT_BOOKING_END_DATE') . ' : ';?></strong>
					<?php echo JFactory::getDate($eventdata->booking_end_date)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT')); ?>

				</div>
			</div>
			<?php
			}
			?>
-->
			<div class="small">
				<?php
				if (!empty($eventdata->booking_start_date))
				{
				?>
					<div class="jt-start"><?php echo JText::_('COM_JTICKETING_EVENTPIN_BOOKING_DATE') . ': ';?></div>

					<span class="" >
					<?php echo JHtml::date($eventdata->booking_start_date, JText::_('COM_JTICKETING_EVEMTPIN_BOOKING_DATE_FORMAT'), true);
					?>
					</span>
					<?php
				} ?>

				<?php
				if (!empty($eventdata->booking_start_date))
				{
				?>
					<strong>&nbsp;<?php echo JText::_('COM_JTICKETING_EVENT_PIN_TO'); ?></strong>
					<span class="" >
						<br>
						<?php echo JHtml::date($eventdata->booking_end_date, JText::_('COM_JTICKETING_EVEMTPIN_BOOKING_DATE_FORMAT'), true);?>
					</span>
				<?php
				}
				?>
			</div>

			<div class="countdown-container center">
				<div class="countdown-containers counter_<?php echo $eventdata->id; ?>">
					<span class="startevent_<?php echo $eventdata->id; ?>"><?php echo JText::_("COM_JTICKETING_EVENT_STARTSIN");?></span>
					<span class="endevent_<?php echo $eventdata->id; ?>"><?php echo JText::_("COM_JTICKETING_EVENT_ENDSIN");?></span>
					<span id='countdown_timer_<?php echo $eventdata->id; ?>'></span>
					<span id='reverse_timer_<?php echo $eventdata->id; ?>'></span>
				</div>
			</div>

<!--
			<hr class="hr hr-condensed"/>
-->

		</div>

		<div class="center">

		<?php
			/*	echo $eventdata->details_button;

				if (property_exists($eventdata, 'enroll_button'))
				{
					echo $eventdata->enroll_button;
				}elseif (property_exists($eventdata, 'buy_button'))
				{
					echo $eventdata->buy_button;
				}elseif (property_exists($eventdata, 'adobe_connect'))
				{
					echo $eventdata->adobe_connect;
				}

				if (property_exists($eventdata, 'guest_meeting_btn'))
				{
					echo $eventdata->guest_meeting_btn;
				}
			*/
				?>
			</div>
		</div>
		</div>
		<!-- Panel Body ends -->
</div>

<style>
.tj-adobeconnect{margin-bottom:5px;}
</style>
<script>
function openSqueezeBox(givenlink)
{
	var width = techjoomla.jQuery(parent.window).width();
	var height = techjoomla.jQuery(parent.window).height();

	var wwidth = width-(width*0.10);
	var hheight = height-(height*0.10);
	parent.SqueezeBox.open(givenlink, { handler: 'iframe', size: {x: wwidth, y: hheight},classWindow: 'tjlms-modal'});
}
</script>
