<?php
/**
* @version     1.5
* @package     com_jticketing
* @copyright   Copyright (C) 2014. All rights reserved.
* @license     GNU General Public License version 2 or later; see LICENSE.txt
* @author      Techjoomla <extensions@techjoomla.com> - http://techjoomla.com
*/
// no direct access
defined('_JEXEC') or die;
?>
<script>
	jQuery(document).ready(function()
		{
			jQuery(".changevenue").change(function()
			{
				validateVenue(this);
			});
		});

		function validateVenue(obj)
		{
			var venuetype = jQuery("input[name='jform[online_events]']:checked").val();
			var startdate = document.getElementById('jform_startdate').value;
			var enddate = document.getElementById('jform_enddate').value;
			var venuetype = jQuery("input[name='jform[online_events]']:checked").val();
			var event_start_time_hour = document.getElementById('event_start_time_hour').value;
			var event_start_time_min = document.getElementById('event_start_time_min').value;
			var event_start_time_ampm = document.getElementById('event_start_time_ampm').value;
			var event_end_time_hour = document.getElementById('event_end_time_hour').value;
			var event_end_time_min = document.getElementById('event_end_time_min').value;
			var event_end_time_ampm = document.getElementById('event_end_time_ampm').value;

			var invalidVenue = '0';

			if(startdate === '' && enddate === '')
			{
				alert("<?php echo JText::_('COM_JTICKETING_EVENTFORM_VENUE_VALID'); ?>");
				return false;
			}

				jQuery.ajax({
				async: false,
				type: 'POST',
				dataType: 'json',
				url: 'index.php?option=com_jticketing&task=eventform.bookVenue',

				beforeSend: function(){jQuery('#jform_venue').empty(); jQuery("#jform_venue").trigger("liszt:updated");},
				data:{
				startdate : startdate,
				enddate : enddate,
				event_start_time_hour : event_start_time_hour,
				event_start_time_min: event_start_time_min,
				event_start_time_ampm : event_start_time_ampm,
				event_end_time_hour : event_end_time_hour,
				event_end_time_min : event_end_time_min,
				event_online : venuetype,
				event_end_time_ampm : event_end_time_ampm,
				venuetype : venuetype
				},
				success: function(data){

					if (data !== undefined && data !== null)
						{
							var op = "<option value='"+"0"+"' selected='selected'> <?php echo JText::_('COM_JTICKETING_FORM_VENUE_DEFAULT_OPTION'); ?> </option>";
							techjoomla.jQuery("#jform_venue").append(op);

							for(index = 0; index < data.length; ++index)
							{
								var op="<option value="  +data[index]['id']+  ">"  +data[index]['name']+   '</option>' ;
								techjoomla.jQuery('#jform_venue').append(op);
							}

							 jQuery("#jform_venue").trigger("liszt:updated");
						}

						if(data == 'failure')
						{
							alert("<?php echo JText::_('COM_JTICKETING_EVENTFORM_VENU_INVALID'); ?>");
							invalidVenue = 1;
						}
				}
			});

			if(invalidVenue == 1)
			{
				return false;
			}
			else
			{
				return true;
			}
	}
</script>
<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('startdate'); ?></div>
	<div class="controls">
		<?php
			//echo $this->form->getInput('startdate');

			for($i = 1; $i <= 12; $i++)
			{
				$hours[] = JHtml::_('select.option', $i, $i);
			}

			$minutes   = array();
			$minutes[] = JHtml::_('select.option', 0, '00');
			$minutes[] = JHtml::_('select.option', 15, '15');
			$minutes[] = JHtml::_('select.option', 30, '30');
			$minutes[] = JHtml::_('select.option', 45, '45');

			$amPmSelect   = array();
			$amPmSelect[] = JHtml::_('select.option', 'AM', 'am' );
			$amPmSelect[] = JHtml::_('select.option', 'PM', 'pm' );

			if(!isset($this->item->startdate) or $this->item->startdate=='0000-00-00 00:00:00')
			{
				$selectedmin = JFactory::getDate()->Format('i');
				$startAmPm   = JFactory::getDate()->Format('H')>= 12 ? 'PM' : 'AM';
				$final_start_event_date = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$selectedStartHour = JFactory::getDate()->Format('H');

			}
			else
			{
				$startAmPm   = JFactory::getDate($this->item->startdate)->Format('H');
				$startAmPm   = JHtml::date($this->item->startdate,JText::_('H'), true);
				$startAmPm  = $startAmPm >= 12 ? 'PM' : 'AM';
				$selectedmin = JFactory::getDate($this->item->startdate)->Format('i');
				$selectedmin = JHtml::date($this->item->startdate,JText::_('i'), true);
				$selectedStartHour = JFactory::getDate($this->item->startdate)->Format('H');
				$selectedStartHour = JHtml::date($this->item->startdate,JText::_('H'), true);

				if($selectedStartHour > 12)
				{
					$selectedStartHour = $selectedStartHour - 12;
				}

				$final_start_event_date = JFactory::getDate($this->item->startdate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$final_start_event_date = JHtml::date($this->item->startdate,JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'), true);
			}

			if($selectedStartHour=='00' or $selectedStartHour=='0')
			{
				$selectedStartHour = 12;
			}

			//static calendar($value, $name, $id, $format= '%Y-%m-%d', $attribs=null)
			echo $calender = JHtml::_('calendar', $final_start_event_date, 'jform[startdate]', 'jform_startdate', JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER'), 'onchange="validateVenue(this);"');

			echo "&nbsp;&nbsp;";

			echo $startHourSelect = JHtml::_('select.genericlist', $hours, 'event_start_time_hour', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $selectedStartHour, false );

			echo $startMinSelect = JHtml::_('select.genericlist', $minutes, 'event_start_time_min', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $selectedmin, false );

			echo $startAmPmSelect = JHtml::_('select.genericlist', $amPmSelect, 'event_start_time_ampm', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $startAmPm, false);

			echo "<br/>";

			echo "<i>" . JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER_DESC') . "</i>";
		?>
	</div>
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('enddate'); ?></div>
	<div class="controls">
		<?php
			//echo $this->form->getInput('enddate');

			$selectedStartHour = $selectedmin = $startAmPm = $end_date_event = '';

			// Set date to current date.
			$end_date_event = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));

			if(!isset($this->item->enddate))
			{
				$selectedmin = JFactory::getDate()->Format('i');
				$startAmPm   = JFactory::getDate()->Format('H') >= 12 ? 'PM' : 'AM';
				$final_end_event_date = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$selectedStartHour = JFactory::getDate()->Format('H');
			}
			else
			{
				$startAmPm = JFactory::getDate($this->item->enddate)->Format('H');
				$startAmPm   = JHtml::date($this->item->enddate,JText::_('H'), true);
				$startAmPm  = $startAmPm >= 12 ? 'PM' : 'AM';
				$selectedmin = JFactory::getDate($this->item->enddate)->Format('i');
				$selectedmin = JHtml::date($this->item->enddate,JText::_('i'), true);
				$selectedStartHour = JFactory::getDate($this->item->enddate)->Format('H');
				$selectedStartHour = JHtml::date($this->item->enddate,JText::_('H'), true);

				if($selectedStartHour>12)
				{
					$selectedStartHour = $selectedStartHour - 12;
				}

				$final_end_event_date = JFactory::getDate($this->item->enddate)->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
				$final_end_event_date = JHtml::date($this->item->enddate,JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'), true);
			}

			if($selectedStartHour=='00' OR $selectedStartHour=='0')
			{
				$selectedStartHour = 12;
			}

			echo $calendar = JHtml::_('calendar', $final_end_event_date, 'jform[enddate]', 'jform_enddate', JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER'), 'onchange="validateVenue(this);"');

			echo "&nbsp;&nbsp;";

			echo $endHourSelect = JHtml::_('select.genericlist', $hours, 'event_end_time_hour', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $selectedStartHour, false );

			echo $endMinSelect = JHtml::_('select.genericlist',  $minutes , 'event_end_time_min', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text',$selectedmin , false );

			echo $endAmPmSelect = JHtml::_('select.genericlist', $amPmSelect, 'event_end_time_ampm', array('class'=>'required input input-mini chzn-done changevenue'), 'value', 'text', $startAmPm, false );

			echo "<br/>";

			echo "<i>" . JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER_DESC') . "</i>";
		?>
	</div>
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('booking_start_date'); ?></div>
	<div class="controls">
		<?php
			//echo $this->form->getInput('booking_start_date');
			if(!isset($this->item->booking_start_date) or $this->item->booking_start_date=='0000-00-00 00:00:00')
			{
				$booking_start_date = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
			}
			else
			{
				$booking_start_date = JHtml::date($this->item->booking_start_date, JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'), true);
			}

			echo $calendar = JHtml::_('calendar', $booking_start_date, 'jform[booking_start_date]','jform_booking_start_date', JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER'));

			echo "<br/>";

			echo "<i>" . JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER_DESC') . "</i>";
		?>
	</div>
</div>

<div class="control-group">
	<div class="control-label"><?php echo $this->form->getLabel('booking_end_date'); ?></div>
	<div class="controls">
		<?php
			//echo $this->form->getInput('booking_end_date');

			if(!isset($this->item->booking_end_date) or $this->item->booking_end_date=='0000-00-00 00:00:00')
			{
				$booking_end_date = JFactory::getDate()->Format(JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'));
			}
			else
			{
				$booking_end_date = JHtml::date($this->item->booking_end_date, JText::_('COM_JTICKETING_DATE_FORMAT_SHOW_SHORT'), true);
			}

			echo $calendar = JHtml::_('calendar', $booking_end_date, 'jform[booking_end_date]','jform_booking_end_date', JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER'));

			echo "<br/>";

			echo "<i>" . JText::_('COM_JTICKETING_DATE_FORMAT_CALENDER_DESC') . "</i>";
		?>
	</div>
</div>
