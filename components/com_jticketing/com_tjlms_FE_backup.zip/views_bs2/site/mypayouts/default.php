<?php
// no direct access
defined( '_JEXEC' ) or die( ';)' );
global $mainframe;
$document=JFactory::getDocument();

$input=JFactory::getApplication()->input;
$eventid = $input->get('event','','INT');
$integration=$this->jticketingmainhelper->getIntegration();
$com_params=JComponentHelper::getParams('com_jticketing');
$integration = $com_params->get('integration');
$siteadmin_comm_per = $com_params->get('siteadmin_comm_per');
$currency = $com_params->get('currency');
$allow_buy_guestreg = $com_params->get('allow_buy_guestreg');
$tnc = $com_params->get('tnc');
jimport('joomla.filter.output');

$user =JFactory::getUser();
if(empty($user->id)){

	echo '<b>'.JText::_('USER_LOGOUT').'</b>';
	return;
}

$integration=$this->jticketingmainhelper->getIntegration();
if($integration==1) //if Jomsocial show JS Toolbar Header
{
	$header='';
	$header=$this->jticketingmainhelper->getJSheader();
	if(!empty($header))
	echo $header;
}
?>

<!-- Header toolbar -->
<div  class="floattext">
		<h1 class="componentheading"><?php echo JText::_('MY_EVENT_PAYOUTS'); ?>	</h1>
</div>

<?php
$eventid=$input->get('event','','INT');
$linkbackbutton='';

if(empty($this->Data))
{?>
<div class="<?php echo JTICKETING_WRAPPER_CLASS; ?>">
<div id="all" class="row-fluid">
<div class="alert alert-info span6">
<?php
	echo JText::_('NODATA');
?>
</div>
</div></div>
<?php
$input=JFactory::getApplication()->input;
$eventid = $input->get('event','','INT');
//if Jomsocial show JS Toolbar Header
if($integration==1){
	$footer='';
	$footer=$this->jticketingmainhelper->getJSfooter();
	if(!empty($footer))
	echo $footer;

}

	return;
}
?>
<div class="<?php echo JTICKETING_WRAPPER_CLASS; ?>">
<form action="" method="post" name="adminForm" id="adminForm">
<div id="all" class="row-fluid">
	<?php if(JVERSION>'3.0') {?>

	<div class="btn-group pull-right hidden-phone">
			<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php
				echo $this->pagination->getLimitBox();
				?>
		</div>
		<?php } ?>
<div class="table-responsive">
<table class="table table-striped table-hover">
	<tr >
		<th ><?php echo JHtml::_( 'grid.sort','PAYPAL_EMAIL_MASSPAYMENT','payee_id', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<th align="center"><?php echo JText::_( 'TRANSACTIONID'); ?></th>
		<th ><?php echo JHtml::_( 'grid.sort','PAYOUTDATE','date', $this->lists['order_Dir'], $this->lists['order']); ?></th>
		<th ><?php echo JHtml::_( 'grid.sort','PAYOUTAMOUNT','amount', $this->lists['order_Dir'], $this->lists['order']); ?></th>
	</tr>


	<?php
			$i = 0;
			$totalpaidamount=0;
			 foreach($this->Data as $data) {
					 if(empty($data->thumb))
					 	$data->thumb = 'components/com_community/assets/user_thumb.png';



	?>
	<tr >
			<td ><?php echo $data->payee_id;?></td>
			<td align="center"><?php echo $data->transction_id;?></td>
			<td align="center"><?php
								if(JVERSION<'1.6.0')
									echo JHtml::_( 'date', $data->date, '%Y/%m/%d');
								else
									echo JHtml::_( 'date', $data->date, 'Y-m-d');

								?>
			</td>

			<td align="center"><?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($data->amount),2),$currency);?></td>
	</tr>
	<?php $i++;} ?>
			<tr rowspan="2" height="20">
				<td align="right" colspan="3"></td>
				<td align="center"></td>
			</tr>
			<tr >
				<td align="right" colspan="3"><div class="jtright"><b><?php echo JText::_( 'SUBTOTAL'); ?></b></div></td>
				<td align="center"><b><?php
				 $subtotalamount=$this->subtotalamount;
				echo $this->jticketingmainhelper->getFromattedPrice( number_format(($this->subtotalamount),2),$currency);?></b></td>
			</tr>

			<tr>
			<td align="right" colspan="3"><div class="jtright"><b><?php echo JText::_( 'PAID'); ?></b></div></td>
			<td align="center"><b><?php echo $this->jticketingmainhelper->getFromattedPrice( number_format(($this->totalpaidamt),2),$currency);?></b></td>
			</tr>

			<tr>
				<td align="right" colspan="3"><b><div class="jtright"><?php echo JText::_( 'BAL_AMT'); ?></b></div></td>
				<td align="center"><b><?php
				$balanceamt1=$subtotalamount-$this->totalpaidamt;
			  $balanceamt=number_format($balanceamt1, 2, '.', '');
					if($balanceamt=='-0.00')
					echo $this->jticketingmainhelper->getFromattedPrice( number_format((0.00),2),$currency);
					else
					echo $this->jticketingmainhelper->getFromattedPrice( number_format(($balanceamt1),2),$currency);

					?></b></td>
			</tr>


</table>
</div>
<input type="hidden" name="option" value="com_jticketing" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="mypayouts" />
<input type="hidden" name="view" value="mypayouts" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
</div><!--row-fluid-->
<div class="row-fluid">
		<div class="span12">
			<?php
				if(JVERSION<3.0)
					$class_pagination='pager';
				else
					$class_pagination='pagination';
			?>
			<div class="<?php echo $class_pagination; ?> com_jgive_align_center">
				<?php echo $this->pagination->getListFooter(); ?>
			</div>
		</div><!--span12-->
	</div><!--row-fluid-->

</form>
</div><!--bootstrap-->
<!-- newly added for JS toolbar inclusion  -->
<?php
if($integration==1) //if Jomsocial show JS Toolbar Footer
{
$footer='';
	$footer=$this->jticketingmainhelper->getJSfooter();
	if(!empty($footer))
	echo $footer;
}
?>
<!-- eoc for JS toolbar inclusion	 -->
