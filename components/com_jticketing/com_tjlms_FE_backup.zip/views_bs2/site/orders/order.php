<?php
/**
 *  @package    JTIcketing
 *  @copyright  Copyright (c) 2009-2013 TechJoomla. All rights reserved.
 *  @license    GNU General Public License version 2, or later
 */
defined( '_JEXEC' ) or die( ';)' );

/*if user is on payment layout and log out at that time undefined order is is found
in such condition send to home page or provide error msg
*/

$params = JComponentHelper::getParams( 'com_jticketing' );
$integration = $params->get('integration','','INT');
$helperobj=new jticketingmainhelper();
$user=JFactory::getUser();
$jinput=JFactory::getApplication()->input;
$logedin_user = $user->id;
$session =JFactory::getSession();
$is_zero_amountOrder=$session->get('JT_is_zero_amountOrder');
$JT_coupon_code=$session->get('JT_coupon_code');

$paymentStatus['P']=JText::_('JT_PSTATUS_PENDING');$paymentStatus['C']=JText::_('JT_PSTATUS_COMPLETED');
$paymentStatus['D']=JText::_('JT_PSTATUS_DECLINED');$paymentStatus['E']=JText::_('JT_PSTATUS_FAILED');
$paymentStatus['UR']=JText::_('JT_PSTATUS_UNDERREVIW');$paymentStatus['RF']=JText::_('JT_PSTATUS_REFUNDED');
$paymentStatus['CRV']=JText::_('JT_PSTATUS_CANCEL_REVERSED');$paymentStatus['RV']=JText::_('JT_PSTATUS_REVERSED');
$billinfo = '';
if(isset($this->orderinfo))
{
	$coupon_code=$this->orderinfo[0]->coupon_code;
	if(isset($this->orderinfo[0]->address_type) && $this->orderinfo[0]->address_type == 'BT')
	{
		$billinfo = $this->orderinfo[0];
	}
	else if(isset($this->orderinfo[1]->address_type) && $this->orderinfo[1]->address_type == 'BT')
	{
			$billinfo = $this->orderinfo[1];
	}
}
if(isset($this->orderinfo))
{
	$where="  AND a.id=".$this->orderinfo['0']->order_id;
	if($this->orderinfo['0']->order_id)
	{
		$orderdetails = $helperobj->getallEventDetailsByOrder($where);
		$link = $helperobj->getEventlink($orderdetails[0]->eventid);

	}

	$this->orderinfo = $this->orderinfo[0];
}
$orders_email=( isset($this->orders_email) )?$this->orders_email:0;
$emailstyle="style='background-color: #cccccc'";

$order_currency =$params->get('currency');

//show login to guest if the option 'allow_buy_guest' is disable
if(!$user->id && !$params->get( 'allow_buy_guest' ) )
{
?>
<div class="well" >
	<div class="alert alert-error">
		<span ><?php echo JText::_('COM_JTICKETING_LOGIN'); ?> </span>
	</div>
</div>
<?php
	return false;
}
if($this->order_authorized == 0)
{
?>
<div class="well" >
	<div class="alert alert-error">
		<span ><?php echo JText::_('COM_JTICKETING_ORDER_UNAUTHORISED'); ?> </span>
	</div>
</div>
<?php
	return false;
}


if(isset($this->orderview))
{
	if(!empty($orderdetails))
	{
		$freeticket=JText::_('ETICKET_PRINT_DETAILS_FREE');
		$freeticket=str_replace('[EVENTNAME]',$orderdetails[0]->title,$freeticket);
		$freeticket=str_replace('[EMAIL]',$billinfo->user_email,$freeticket);
	}

?>
	<?php
	if(!empty($billinfo))
	{
		?>
		<div class="<?php echo JTICKETING_WRAPPER_CLASS; ?>">
			<h3 class=""><?php echo JText::_('JT_ORDERS_REPORT'); ?></h3>
				<div class="row-fluid">
					<?php
					$eventid=$session->get('JT_eventid',0);
							if($this->orderinfo->amount<=0)
							{
								echo '<div class="alert alert-info span12">'.$freeticket;
							}
							elseif ($this->orderinfo->status == 'P')
							{
								echo '<div class="alert alert-info span12">'.JText::sprintf('ETICKET_PRINT_DETAILS',$billinfo->user_email);
								echo '</b></div>';
							}
					?>
				</div>
		</div>
	<?php
	}
}	?>


	<div class="<?php echo JTICKETING_WRAPPER_CLASS; ?>">
		<?php if(isset($this->orderview))
			{
				?>
				<div class="row-fluid">
					<div class="span12 ">

						<div class="pull-right">
							<br/>
							<input type="button" class="btn btn-success" onclick="printDiv()" value="<?php echo JText::_('COM_JTICKEING_PRINT');?>">

							<a  class="btn btn-info" href="<?php echo $link; ?>"><?php echo JText::_('COM_JTICKETING_BACK_EVENT'); ?></a>
						</div>
					</div>
				</div>
		<?php
			}	?>
		<div id="printDiv">
			<div class="row-fluid">
				<hr class="hr hr-condensed"/>
				<!--SHOW COMAPNY DETAILS ON LEFT SIDE-->
					<?php
						$company_name = $params->get('company_name','','STRING');
						$company_address = $params->get('company_address','','STRING');
						$company_vat_no = $params->get('company_vat_no','','STRING');
					?>

				<div class="">
					<div class="span8">
						<div class="span4">
								<?php
								if(isset($orderdetails[0]->image))
								{

									if($integration == 2)
									{
										$imagePath = 'media/com_jticketing/images/';
									}
									else
									{
										$imagePath = '';
									}

									$imagePath = JRoute::_(JUri::base() . $imagePath . $orderdetails[0]->image, false);
									?>
									<img class="img-polaroid com_jticketing_image_w98pc" src="<?php echo $imagePath;?>">
							<?php	}	?>
						</div>
						<div class="span4">
								<h3 class="no-print"><a target="_blank" href="<?php echo $link; ?>"><?php echo $orderdetails[0]->title; ?></a></h3>
								<h3 class="only-in-print"><?php echo $orderdetails[0]->title; ?></h3>

						</div>
					</div>

					<div style="text-align:right">
							<div class="pull-right " >
									<div>
										<?php 	echo $company_name;	?>
									</div>
									<div>
										<?php 	echo $company_address;	?>
									</div>
									<div>
										<?php 	echo $company_vat_no;	?>
									</div>
							</div>
							<div style="clear:both"></div>
							<div class="pull-right " >
								<div>
									<strong><?php echo JText::_('COM_JTICKETING_ORDER_ID'); ?></strong>  <?php echo $this->orderinfo->orderid_with_prefix ; ?>
								</div>
								<!--SHOW ORDER STATUS-->
								<div class="row-fluid">
									<strong><?php echo JText::_('COM_JTICKETING_ORDER_PAYMENT_STATUS'); ?></strong>  <?php echo $paymentStatus[$this->orderinfo->status]; ?>
								</div>
								<!--SHOW ORDER STATUS-->
								<div>
									<strong><?php echo JText::_('COM_JTICKETING_ORDER_DATE'); ?></strong>  <?php echo $this->orderinfo->cdate ; ?>

								</div>
							</div>
					</div>
				</div>
			<!--COMPANY DETAILS ENDS-->

			<!--USER INFO STRAT-->
		<?php	if(!empty($billinfo))
		{
			?>
			<div class="span12">
				<hr class="hr hr-condensed"/>
					<div class="pull-left " >
							<div>
								<?php echo $billinfo->firstname.' '.$billinfo->lastname;?>
							</div>
								<?php
								if(!empty($billinfo->vat_number))
									{
										?>
										<div>
											<?php echo $billinfo->vat_number;?>
										</div>
							<?php 	}	?>

							<div>
								<?php echo $billinfo->phone;?>
							</div>
							<div>
								<?php echo $billinfo->user_email;?>
							</div>
							<div>
								<?php echo $billinfo->address.' '.$billinfo->city;?>
							</div>
							<div>
								<?php echo $billinfo->zipcode;
								if (!empty($billinfo->state_code))
								{
									echo ", ".$state = $this->TjGeoHelper->getRegionNameFromId($billinfo->state_code);
								}

								if (!empty($billinfo->state_code))
								{
									echo ", ".$country = $this->TjGeoHelper->getCountryNameFromId($billinfo->country_code);
								}
								?>

							</div>

					</div>
			</div>
			<!--USER INFO ENDS-->
		<?php
		}	?>


		</div><!--ROW FLUID ENDS-->

		<!--TICKET INFO START-->
			<div class="row-fluid">
				<hr class="hr hr-condensed"/>
				<div class="span12 well"> <!-- cart detail start -->
				<?php
						if($this->orderinfo->processor=="bycheck" || $this->orderinfo->processor=="byorder")
						{
						$plugin = JPluginHelper::getPlugin('payment', $this->orderinfo->processor);
						$params = new JRegistry($plugin->params);
						?>
							<div class="jt-payment-info">
								<h3><?php echo JText::_('COM_JTICKETING_PAYMENT_INFO'); ?></h3>
							<?php
							echo $params->get('plugin_mail','');
							?>
							</div>
						<?php
						}
						?>
					<h3><?php echo JText::_('COM_JTICKETING_TICKET_INFO'); ?></h3>
						<?php
								$price_col_style = "style=\"".(!empty($orders_email)?'text-align: right;' :'')."\"";
								$showoptioncol=0;
						?>
						<div class="table-responsive">
						<table style="width: 100%; border: 1px solid black;">
							<tr style="vertical-align:middle;border:0">
								<th style="background-color: #ccc;  padding: 7px;" class="jtitem_num" width="5%" align="right" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo JText::_('COM_JTICKETING_NO'); ?></th>
								<th style="background-color: #ccc;  padding: 7px;" class="jtitem_name" align="left" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo  JText::_('COM_JTICKETING_PRODUCT_NAM'); ?></th>
								<th style="background-color: #ccc;  padding: 7px;" class="jtitem_qty" align="left" style="<?php echo ($orders_email)?'text-align: left;' :'';  ?>" ><?php echo JText::_('COM_JTICKETING_PRODUCT_QTY'); ?></th>
								<th style="background-color: #ccc;  padding: 7px;" class="jtitem_price" align="left" <?php echo $price_col_style;  ?> ><?php echo JText::_('COM_JTICKETING_PRODUCT_PRICE'); ?></th>
								<th style="background-color: #ccc;  padding: 7px;" class="jtitem_tprice" align="left" <?php echo $price_col_style;  ?> ><?php echo JText::_('COM_JTICKETING_PRODUCT_TPRICE'); ?></th>
							</tr>

							<?php
								$tprice = 0;
								$i=1;

								foreach ($this->orderitems as $order)
								{
									$totalprice=0;
									if(!isset($order->price))
									$order->price=0;
								?>
								<tr class="row0">
									<td style="vertical-align:middle;border:0;padding: 7px;" class="jtitem_num" ><?php echo $i++;?></td>
									<td style="vertical-align:middle;border:0;padding: 7px;" class="jtitem_name" ><?php echo $order->order_item_name;?></td>
									<td style="vertical-align:middle;border:0;padding: 7px;" class="jtitem_qty" ><?php echo $order->ticketcount;?></td>

									<td style="vertical-align:middle;border:0;padding: 7px;" class="jtitem_price" <?php echo $price_col_style;  ?>><span><?php echo $helperobj->getFromattedPrice( number_format(($order->price),2),$order_currency);?></span></td>

									<td style="vertical-align:middle;border:0;padding: 7px;" class="jtitem_tprice" <?php echo $price_col_style;  ?>><span><?php $totalprice=$order->price*$order->ticketcount;echo $helperobj->getFromattedPrice(number_format($totalprice,2),$order_currency); ?></span></td>
									<?php
										$tprice = $totalprice+$tprice;
									?>
								</tr>
							<?php
								}
							?>

							<tr>
								<td colspan="5">&nbsp;</td>
							</tr>
							<tr>
								<?php	$col=3;
									if($showoptioncol==1)
								{	 $col=3; }?>
								<td style="background-color: #ccc;  padding: 7px;" colspan="<?php echo $col;?>" > </td>
								<td style="background-color: #ccc;  padding: 7px;" class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_PRODUCT_TOTAL'); ?></strong></td>
								<td style="background-color: #ccc;  padding: 7px;" class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "cop_discount" ><?php echo $helperobj->getFromattedPrice( number_format($tprice,2),$order_currency); ?></span></td>
							</tr>
							<!--discount price -->

							<?php
							$coupon_code=trim($coupon_code);
							$total_amount_after_disc=$this->orderinfo->original_amount;
							if($this->orderinfo->coupon_discount>0)
							{
								$total_amount_after_disc=$total_amount_after_disc-$this->orderinfo->coupon_discount;
							?>
								<tr>
									<td colspan="<?php echo $col;?>" > </td>
									<td style="vertical-align:middle;border:1;padding: 7px;" class="jtitem_tprice_label" align="left"><strong><?php echo sprintf(JText::_('COM_JTICKETING_PRODUCT_DISCOUNT'),$this->orderinfo->coupon_code); ?></strong></td>
									<td style="vertical-align:middle;border:1;padding: 7px;" class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "coupon_discount" >
									<?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->coupon_discount,2),$order_currency);
									?>
									</span></td>
								</tr>
								<!-- total amt after Discount row-->
								<tr class="dis_tr" 		<?php
								// echo $cop_style;  ?>>
									<td colspan = "<?php echo $col;?>"></td>
									<td style="vertical-align:middle;border:1;padding: 7px;" class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_NET_AMT_PAY');?></strong></td>
									<td style="vertical-align:middle;border:1;padding: 7px;" class="jtitem_tprice" <?php echo $price_col_style; ?> ><span id= "total_dis_cop" >
									<?php
										echo $helperobj->getFromattedPrice(number_format($total_amount_after_disc,2),$order_currency);
									?></span></td>
								</tr>
							<?php
							}

							if(isset($this->orderinfo->order_tax) and $this->orderinfo->order_tax>0)
							{
								$tax_json=$this->orderinfo->order_tax_details;
								$tax_arr=json_decode($tax_json,true);
							?>
								<tr>
									<td style="vertical-align:middle;border:1;padding: 7px;" colspan="<?php echo $col;?>" > </td>
									<td style="vertical-align:middle;border:1;padding: 7px;" class="jtitem_tprice_label" align="left"><strong><?php echo JText::sprintf('TAX_AMOOUNT',$tax_arr['percent']).""; ; ?></strong></td>
									<td style="vertical-align:middle;border:1;padding: 7px;" class="jtitem_tprice" <?php echo $price_col_style;  ?>><span id= "tax_amt" ><?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->order_tax,2),$order_currency); ?></span></td>
								</tr>
							<?php
							}?>

							<tr>
								<td style="background-color: #ccc;  padding: 7px;" colspan="<?php echo $col;?>" > </td>
								<td style="background-color: #ccc;  padding: 7px;" class="jtitem_tprice_label" align="left"><strong><?php echo JText::_('COM_JTICKETING_ORDER_TOTAL'); ?></strong></td>
								<td style="background-color: #ccc;  padding: 7px;" class="jtitem_tprice" <?php echo $price_col_style;  ?>><strong><span id="final_amt_pay"	name="final_amt_pay"><?php echo $helperobj->getFromattedPrice(number_format($this->orderinfo->amount,2),$order_currency); ?></span></strong></td>
							</tr>

						</table>
						</div>
				</div><!--SAPN!2 ENDS-->
			</div><!--ROW FLUID ENDS-->
			</div><!--PRINT ENDS-->
		<!--TICKET INFO ENDS-->
	</div><!--bootstrap ends-->

<script type="text/javascript">

	function printDiv()
	{
		var printContents = document.getElementById('printDiv').innerHTML;
		var originalContents = document.body.innerHTML;

		document.body.innerHTML = printContents;

		window.print();

		document.body.innerHTML = originalContents;
	}
</script>
