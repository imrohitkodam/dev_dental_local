<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die('Restricted access');
global $mainframe;
$this->jticketingmainhelper = new jticketingmainhelper;
$integration                = $this->jticketingmainhelper->getIntegration();

$document = JFactory::getDocument();
jimport('joomla.filter.output');
jimport('joomla.utilities.date');
JHtml::_('behavior.modal', 'a.modal');
$input               = JFactory::getApplication()->input;
$user                = JFactory::getUser();
$com_params          = JComponentHelper::getParams('com_jticketing');
$integration         = $com_params->get('integration');
$siteadmin_comm_per  = $com_params->get('siteadmin_comm_per');
$private_key_cronjob = $com_params->get('private_key_cronjob');
$currency            = $com_params->get('currency');

if (empty($user->id))
{
	echo '<b>' . JText::_('USER_LOGOUT') . '</b>';

	return;
}

$user        = JFactory::getUser();
$document    = JFactory::getDocument();
$integration = $this->jticketingmainhelper->getIntegration();

// If Jomsocial show JS Toolbar Header
if ($integration == 1)
{
	$header = '';
	$header = $this->jticketingmainhelper->getJSheader();

	if (!empty($header))
	{
		echo $header;
	}
}
?>
<script type="text/javascript">
	techjoomla.jQuery(document).ready(function()
	{

		techjoomla.jQuery('.jt_selectbox').attr('data-chosen', 'com_jticketing');
	});
</script>
<div  class="floattext">
	<h1 class="componentheading"><?php
echo JText::_('COM_JTICKETING_ALL_ORDERS');
?>	</h1>
</div>
<?php
$payment_statuses = array(
	'P' => JText::_('JT_PSTATUS_PENDING'),
	'C' => JText::_('JT_PSTATUS_COMPLETED'),
	'D' => JText::_('JT_PSTATUS_DECLINED'),
	'E' => JText::_('JT_PSTATUS_FAILED'),
	'UR' => JText::_('JT_PSTATUS_UNDERREVIW'),
	'RF' => JText::_('JT_PSTATUS_REFUNDED'),
	'CRV' => JText::_('JT_PSTATUS_CANCEL_REVERSED'),
	'RV' => JText::_('JT_PSTATUS_REVERSED')
);


$js_key = "
Joomla.submitbutton=function(task){ ";
$js_key .= "
		document.adminForm.action.value=task;
		if (task =='cancel')
		{";
$js_key .= "	Joomla.submitform(task);";
$js_key .= "
		}
	}
";

$js_key .= "
function selectstatusorder(appid,processor,ele)
{
	document.getElementById('order_id').value = appid;
	document.getElementById('payment_status').value = ele.value;
	document.getElementById('processor').value = processor;
	document.adminForm.task.value='orders.save';
	task='orders.save';";

if (JVERSION >= '1.6.0')
{
	$js_key .= "
		Joomla.submitform(task);";
}

$js_key .= "}";
$document->addScriptDeclaration($js_key);
$document->addScriptDeclaration($js_key);

if (empty($this->lists['search_event']))
{
	$this->lists['search_event'] = $input->get('event', '', 'INT');
}

$eventid        = $input->get('event', '', 'INT');
$linkbackbutton = '';

if (empty($this->Data) or $this->noeventsfound == 1)
{?>
<div class="<?php echo JTICKETING_WRAPPER_CLASS; ?>">
<form action="" method="post" name="adminForm"	id="adminForm">
	<div id="all" class="row-fluid">
		<div style="float:right">
		<?php
		// If no events found dont show filter
		if ($this->noeventsfound != 1)
		{
			$search_event = $mainframe->getUserStateFromRequest('com_jticketingsearch_event', 'search_event', '', 'string');
		$cls =  'class="jt_selectbox" size="1" onchange="document.adminForm.submit();"';
		echo JHtml::_('select.genericlist', $this->status_event, "search_event", $cls, "value", "text", $search_event);
		$clsp =  'class="jt_selectbox" size="1" onchange="document.adminForm.submit();" name="search_paymentStatus"';
		echo JHtml::_('select.genericlist', $this->search_paymentStatus, "search_paymentStatus", $clsp, "value", "text", strtoupper($this->lists['search_paymentStatus']));
		}
		?>
		</div>
		<div class="span6 pull-left alert alert-info jtleft"><?php echo JText::_('NODATA');?></div>
			<input type="hidden" name="option" value="com_jticketing" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="defaltevent" value="<?php	echo $this->lists['search_event'];?>" />
			<input type="hidden" name="defaltpaymentStatus" value="<?php echo $this->lists['search_paymentStatus'];?>" />
			<input type="hidden" name="controller" value="orders" />
			<input type="hidden" name="view" value="orders" />
			<input type="hidden" name="Itemid" value="<?php	echo $this->Itemid;?>" />
		</div>

</form>
</div>
<!-- newly added for JS toolbar inclusion  -->
<?php
if ($integration == 1)
{
	$footer = '';
	$footer = $this->jticketingmainhelper->getJSfooter();

	if (!empty($footer))
	{
		echo $footer;
	}
}
?>
<!-- eoc for JS toolbar inclusion	 -->
<?php
	return;
}
?>

<div class="<?php echo JTICKETING_WRAPPER_CLASS; ?>">
<form action="" method="post" name="adminForm" id="adminForm">
	<div id="all" class="row-fluid">
		<div style="float:left">
		<?php
		$search_event = $mainframe->getUserStateFromRequest('com_jticketingsearch_event', 'search_event', '', 'string');
		$cls =  'class="jt_selectbox" size="1" onchange="document.adminForm.submit();"';
		echo JHtml::_('select.genericlist', $this->status_event, "search_event", $cls, "value", "text", $search_event);
		$clsp =  'class="jt_selectbox" size="1" onchange="document.adminForm.submit();" name="search_paymentStatus"';
		echo JHtml::_('select.genericlist', $this->search_paymentStatus, "search_paymentStatus", $clsp, "value", "text", strtoupper($this->lists['search_paymentStatus']));
		?>
				</div>
		<?php
		if (JVERSION > '3.0')
		{
		?>
	<div class="btn-group pull-right hidden-phone">
		<label for="limit" class="element-invisible"><?php		echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
			<?php	echo $this->pagination->getLimitBox();?>
	</div>
	<?php
		}
	?>
<div class="table-responsive order">
<table class="table table-striped table-hover ">
	<tr>
		<th  align="center">
			<?php	echo JHtml::_('grid.sort', 'ORDER_ID', 'id', $this->lists['order_Dir'], $this->lists['order']);	?>
		</th>
		<th  align="center">
			<?php
			echo JHtml::_('grid.sort', 'PAY_METHOD', 'processor', $this->lists['order_Dir'], $this->lists['order']);
			?>
		</th>
		<th align="center"><?php	echo JText::_('NUMBEROFTICKETS_SOLD');?></th>
		<th align="center"><?php	echo JText::_('ORIGINAL_AMOUNT');?></th>
		<th align="center"><?php	echo JText::_('DISCOUNT_AMOUNT');?></th>
		<?php
		if ($this->jticketingparams->get('allow_taxation'))
		{
		?>
		<th align="center"><?php	echo JText::_('TAX_AMOUNT');?></th>
		<?php
		}
		?>
		<th align="center"><?php	echo JText::_('PAID_AMOUNT');?></th>
		<th align="center"><?php	echo JText::_('COM_JTICKETING_FEE');?></th>
		<th align="center"><?php	echo JText::_('COUPON_CODE_DIS');?></th>
		<th  align="center"><?php
		echo JHtml::_('grid.sort', 'PAYMENT_STATUS', 'status', $this->lists['order_Dir'], $this->lists['order']);
		?></th>
	</tr>
<?php
$i            = $subfee = $totaltax = 0;
$totalpaidamt = $totalnooftickets = $totalprice = $totalcommission = $totalearn = 0;
$subdisc      = 0;
$subpaid      = 0;

foreach ($this->Data as $data)
{
	if ($data->ticketscount < 0)
	{
		$data->ticketscount = 0;
	}

	if ($data->original_amount < 0)
	{
		$data->original_amount = 0;
	}

	if ($data->fee < 0)
	{
		$data->fee = 0;
	}

	$totalnooftickets = $totalnooftickets + $data->ticketscount;

	if ($data->status == 'C')
	{
		$totalpaidamt = $totalpaidamt + $data->original_amount;
	}

	$totalprice      = $totalprice + $data->original_amount;
	$totalcommission = $totalcommission + $data->fee;
	$totaltax += $data->order_tax;

	if ($data->order_id)
	{
		$passorderid = $data->order_id;
	}
	else
	{
		$passorderid = $data->id;
	}

	$url = 'index.php?option=com_jticketing&view=attendees&event=';
	$link_for_attendees = JRoute::_($url . $data->evid . "&order_id=" . $passorderid . "&Itemid=" . $this->Itemid);
	$url = 'index.php?option=com_jticketing&view=attendees&event=';
	$url_order = 'index.php?option=com_jticketing&view=orders&layout=order&event=';
	$link_for_orders    = JRoute::_($url_order . $data->evid . '&orderid=' . $passorderid . '&Itemid=' . $this->Itemid . '&tmpl=component');
?>

	<tr class="">
		<td  class = "dis_modal" align="center">
		<a rel="{handler: 'iframe', size: {x: 600, y: 600}}" class="modal" href="<?php
		echo $link_for_orders;?>">
		<?php

		if ($data->order_id)
		{
			echo $data->order_id;
		}
		else
		{
			echo $data->id;
		}
		?></a>
		</td>
		<td align="center">
			<?php
			if (!empty($data->processor) and $data->processor != 'Free_ticket')
			{
				$plugin       = JPluginHelper::getPlugin('payment', $data->processor);
				$pluginParams = new JRegistry;
				$pluginParams->loadString($plugin->params);
				$param = $pluginParams->get('plugin_name', $data->processor);
				echo $param;
			}
			else
			{
				echo ($data->processor == NULL) ? "-" : $data->processor;
			}
			?>
		</td>
		<td align="center"><?php	echo $data->ticketscount;?></td>
		<td align="center">
			<?php
			echo $this->jticketingmainhelper->getFromattedPrice(number_format(($data->original_amount), 2), $currency);
			?>
		</td>
		<td align="center">
		<?php
		$subdisc += $discount = $data->coupon_discount;
		echo $this->jticketingmainhelper->getFromattedPrice(number_format(($discount), 2), $currency);
		?>
		</td>

		<?php
		if ($this->jticketingparams->get('allow_taxation'))
		{
		?>
		<td align="center">
			<?php
			echo $this->jticketingmainhelper->getFromattedPrice(number_format(($data->order_tax), 2), $currency);
			?>
			</td>
		<?php
		}
		?>
		<td align="center">
		<?php
			$subpaid += $data->paid_amount;
			echo $this->jticketingmainhelper->getFromattedPrice(number_format(($data->paid_amount), 2), $currency);
		?>
		</td>
		<th align="center">
			<?php
				$subfee += $data->fee;
				echo $this->jticketingmainhelper->getFromattedPrice(number_format(($data->fee), 2), $currency);
			?>
		</th>
		<td align="center">
			<?php
			if (!empty($data->coupon_code))
			{
				echo $data->coupon_code . ' ';
			}
			else
			{
				echo '-';
			}
			?>
		</td>
		<td align="center">
			<?php
			if (($data->status) and (!empty($data->processor)))
			{
				$processor = "'" . $data->processor . "'";
				$class = 'class="jt_selectbox" onChange="selectstatusorder(' . $data->id . ',' . $processor . ',this);"';
				echo JHtml::_('select.genericlist', $payment_statuses, "pstatus" . $i, $class, "value", "text", $data->status);
			}
			else
			{
				echo $payment_statuses[$data->status];
			}
		?>
		</td>
	</tr>
	<?php
	$i++;
}
?>
	<tr	class="jticket_row_head"	>
		<td colspan="2" align="right"><div class="jtright"><b><?php			echo JText::_('TOTAL');	?></b></div></td>
		<td align="center">
			<b><?php echo number_format($totalnooftickets, 0, '', '');?></b>
		</td>
		<td align="center">
			<b><?php	echo $this->jticketingmainhelper->getFromattedPrice(number_format(($totalprice), 2), $currency);?></b>
		</td>
		<td align="center">
			<b><?php	echo $this->jticketingmainhelper->getFromattedPrice(number_format(($subdisc), 2), $currency);?></b>
		</td>
		<?php
		if ($this->jticketingparams->get('allow_taxation'))
		{
		?>
		<td align="center">
			<b><?php
			echo $this->jticketingmainhelper->getFromattedPrice(number_format(($totaltax), 2), $currency);
		?></b>
		</td>
		<?php
		}
		?>
		<td align="center">
			<b><?php
			echo $this->jticketingmainhelper->getFromattedPrice(number_format(($subpaid), 2), $currency);
			?></b>
		</td>
		<td align="center">
			<b><?php
			echo $this->jticketingmainhelper->getFromattedPrice(number_format(($subfee), 2), $currency);
			?></b>
		</td>
		<td align="center"></td>
			</tr>
		</table>
	</div>
	<input type="hidden" name="option" value="com_jticketing" />
	<input type="hidden" id='order_id' name="order_id" value="" />
	<input type="hidden" id='payment_status' name="payment_status" value="" />
	<input type="hidden" id='processor' name="processor" value="" />
	<input type="hidden" name="task" value="" />			<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="defaltevent" value="<?php	echo $this->lists['search_event'];?>" />
	<input type="hidden" name="controller" value="orders" />
	<input type="hidden" name="view" value="orders" />
	<input type="hidden" name="Itemid" value="<?php	echo $this->Itemid;?>" />
	<input type="hidden" name="filter_order" value="<?php	echo $this->lists['order'];?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php	echo $this->lists['order_Dir'];?>" />
	</div><!--row-fluid-->
	<?php
	$class_pagination = 'pagination';
	?>
	<div class="<?php	echo $class_pagination;?>">
	<?php	echo $this->pagination->getListFooter();?>
	</div>
</form>
</div>
<!-- newly added for JS toolbar inclusion  -->
<?php
if ($integration == 1)
{
	$footer = '';
	$footer = $this->jticketingmainhelper->getJSfooter();

	if (!empty($footer))
	{
		echo $footer;
	}
}
?>
<!-- eoc for JS toolbar inclusion	 -->
