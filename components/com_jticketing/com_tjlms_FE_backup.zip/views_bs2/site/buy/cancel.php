<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die('Restricted access');
$session   = JFactory::getSession();
$session->set('JT_orderid','');
$session->set("JT_fee",'');
echo $msg = JText::_('OPERATION_CANCELLED');
$user = JFactory::getUser();
$input = JFactory::getApplication()->input;
$eventid = $input->get('eventid', '', 'INT');
$jticketingmainhelper = new jticketingmainhelper;
$itemid = $jticketingmainhelper->getItemId($linkcreateevent);
$integration = $jticketingmainhelper->getIntegration();

if ($integration == 2)
{
	$linkcreateevent = JRoute::_(JUri::base() . '?option=com_jticketing&view=events' . '&Itemid=' . $itemid);
}

if ($integration == 3)
{
	$linkcreateevent = JRoute::_(JUri::base() . '?option=com_jevents&task=month.calendar' . '&Itemid=' . $itemid);
}

if ($integration == 1)
{
	$linkcreateevent = JRoute::_(JUri::base() . '?option=com_community&view=events&task=viewevent' . '&Itemid=' . $itemid);
}

echo "<div style='float:right'><a href='" . $linkcreateevent . "'>" . JText::_('BACK') . "</a></div>";
