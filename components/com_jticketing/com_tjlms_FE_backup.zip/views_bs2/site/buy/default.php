<?php
/**
* @version    SVN: <svn_id>
* @package    JTicketing
* @author     Techjoomla <extensions@techjoomla.com>
* @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
* @license    GNU General Public License version 2 or later.
*/
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.keepalive');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.modal', 'a.modal');
JHtml::_('behavior.calendar');

$document = JFactory::getDocument();
$step_no  = 1;
$root_url = JUri::root();
   ?>
<script type="text/javascript">
   techjoomla.jQuery(document).ready(function()
   {
   	/* Skip country and state dropdowns from chosen js and css*/
   	techjoomla.jQuery('#country').attr('data-chosen', 'com_jticketing');
   	techjoomla.jQuery('#state').attr('data-chosen', 'com_jticketing');
   });

   var root_url="<?php
      echo $root_url;
      ?>";
   var loadingMsg="Loading..";
   var terms_enabled=<?php
      echo $this->article;
      ?>;

   function cancelTicket()
   {
   	var r=confirm("<?php
      echo JText::_('COM_JTICKETING_CANCEL_TICKET', true);
      ?>");

   	if (r==true)
   	{
   		techjoomla.jQuery.ajax({
   		url: root_url+'index.php?option=com_jticketing&task=buy.clearSession',
   		type: 'GET',
   		dataType: 'json',
   		success: function(data)
   		{

   		}
   	});
   		<?php
      $session   = JFactory::getSession();
      		$session->set('JT_orderid','');
      		$session->set("JT_fee",'');

      	if (!empty($_SERVER["HTTP_REFERER"]))
      	{
      ?>

   window.location.replace("<?php	echo $_SERVER["HTTP_REFERER"];?>");
   		<?php
      }
      else
      {
      ?>

		window.history.go(-1);

   		<?php
      }
      ?>

   	}
   	else
   	{
   		return false;
   	}

   }

   function jticketing_generateState(countryId,Dbvalue,totalprice)
   {
   	var country=techjoomla.jQuery('#'+countryId).val();
   	if(country==undefined)
   	{
   		return (false);
   	}
   	techjoomla.jQuery.ajax({
   		url: root_url+'index.php?option=com_jticketing&task=buy.loadState&country='+country+'&tmpl=component',
   		type: 'GET',
   		dataType: 'json',
   		success: function(data)
   		{
   			if(countryId=='country')
   			{
   				statebackup=data;
   			}
   			generateoption(data,countryId,Dbvalue);
   		}
   	});

   		jQuery("select").trigger("liszt:updated");  /* IMP : to update to chz-done selects*/


   }

   function generateoption(data,countryId,Dbvalue)
   {
   	var country=techjoomla.jQuery('#'+countryId).val();
   	var options, index, select, option;
   	if(countryId=='country'){
   		select = techjoomla.jQuery('#state');
   		default_opt = 'Select State';
   	}

   	select.find('option').remove().end();

   	selected="selected=\"selected\"";
   	var op='<option '+selected+' value="">'  +default_opt+   '</option>'     ;
   	if(countryId=='country'){
   		techjoomla.jQuery('#state').append(op);
   	}



   	if (data !== undefined && data !== null)
   	{
   		options = data;
   		for (index = 0; index < data.length; ++index)
   		{
   			selected="";
   			if(name==Dbvalue)
   				selected="selected=\"selected\"";
   			var opObj = data[index];
   			selected="";

   			if (opObj.id==Dbvalue)
   			{
   				selected="selected=\"selected\"";
   			}
   			var op='<option '+selected+' value=\"'+opObj.id+'\">'  +opObj.region+   '</option>';

   			{
   				techjoomla.jQuery('#state').append(op);
   			}



   		}	 // end of for


   	}

   	jQuery("select").trigger("liszt:updated");  /* IMP : to update to chz-done selects*/
   }

   function select_attendee(obj)
   {

   	var selected_attende=obj.value;
   	if(selected_attende==undefined || selected_attende<=0)
   	{
   		//find Prent div and clear all text and hidden fields
   		var parent_div = techjoomla.jQuery(obj).parent().parent().parent().parent().find('div');
   		var all_elements = techjoomla.jQuery(parent_div).find('input[id*="attendee_field_"],select[id*="attendee_field_"]');
   				all_elements.each(function(){


   				var  ele_type = techjoomla.jQuery(this).attr('type');
   				switch(ele_type){
   					case 'checkbox':
   						break;
   					case 'radio':
   						break;
   					default:
   						techjoomla.jQuery(this).val('');
   				}
   		});
   		//End find Prent div and clear all text and hidden fields
   		return (false);
   }


   	var hidden_attendee_field = techjoomla.jQuery(obj).parent().parent().parent().find('input[id*="attendee_field_attendee_id"]');
   	hidden_attendee_field.val(selected_attende);
   	techjoomla.jQuery.ajax({
   		url: '?option=com_jticketing&task=buy.selectAttendee&attendee_id='+selected_attende+'&tmpl=component&format=raw',
   		type: 'GET',
   		dataType: 'json',
   		success: function(data)
   		{
   			//prefill All data of selected	Attendee
   			techjoomla.jQuery.each(data, function(name, val){

   				var el = techjoomla.jQuery(obj).parent().parent().parent().find('input[id*="attendee_field_'+name+'"],select[id*="attendee_field_'+name+'"]');
   				var  type = el.attr('type');

   				switch(type){
   					case 'checkbox':
   						el.attr('checked', 'checked');
   						break;
   					case 'radio':
   						el.filter('[value="'+val+'"]').attr('checked', 'checked');
   						break;
   					default:
   						el.val(val);
   				}
   			});
   			//End prefill All data of selected	Attendee
   		}
   	});

   }

</script>
<div class="<?php echo JTICKETING_WRAPPER_CLASS;?>">
   <div class="row-fluid">
      <div class="jticketing-form">
         <div class="fuelux wizard-example">
            <div class="jticketing_steps_parent row-fluid">
               <!--MyWizard-->
               <div id="MyWizard" class="wizard">
                  <!--<ul class=" steps nav " id="jticketing-steps">-->
                  <ol class="jticketing-steps-ol steps clearfix" id="jticketing-steps">
                     <li id="id_step_select_ticket" data-target="#step_select_ticket" class="active">
                        <span class="badge badge-info"><?php
                           echo $step_no;
                           $step_no++;
                           ?></span>
                        <span class="hidden-phone hidden-tablet"><?php
                           echo JText::_('COM_JTICKETING_SELECT_TICKET_STEP');
                           ?></span>
                        <span class="chevron"></span>
                     </li>
                     <?php
                        if (!empty($this->collect_attendee_info_checkout))
                        {
                        ?>
                     <li id="id_step_select_attendee" data-target="#step_select_attendee">
                        <span class="badge"><?php
                           echo $step_no;
                           $step_no++;
                           ?></span>
                        <span class="hidden-phone hidden-tablet"><?php
                           echo JText::_('COM_JTICKETING_SELECT_ATTENDEE_STEP');
                           ?></span>
                        <span class="chevron"></span>
                     </li>
                     <?php
                        }

                        ?>
                     <li id="id_step_billing_info" data-target="#step_billing_info">
                        <span class="badge"><?php
                           echo $step_no;
                           $step_no++;
                           ?></span>
                        <span class="hidden-phone hidden-tablet"><?php
                           echo JText::_('COM_JTICKETING_SELECT_BILLING_STEP');
                           ?></span>
                        <span class="chevron"></span>
                     </li>
                     <li id="id_step_payment_info" data-target="#step_payment_info" id="payment-info-li">
                        <span class="badge"><?php
                           echo $step_no;
                           $step_no++;
                           ?></span>
                        <span class="hidden-phone hidden-tablet"><?php
                           echo JText::_('COM_JTICKETING_PAYMENT_STEP');
                           ?></span>
                        <span class="chevron"></span>
                     </li>
                  </ol>
               </div>
               <!--MyWizard END-->
               <!--tab-content step-content-->
               <div class="tab-content step-content" id="TabConetent">
                  <div class="tab-pane step-pane active" id="step_select_ticket">
                     <?php
                     	$com_params = JComponentHelper::getParams('com_jticketing');
						$socialintegration    = $com_params->get('integration');

						if ($socialintegration == '2')
						{
							if ($this->EventData->online_events == 1)
							{
								$default_select_ticket = $this->jticketingmainhelper->getViewpath('buy', 'default_select_online_ticket');
							}
							else
							{
								$default_select_ticket = $this->jticketingmainhelper->getViewpath('buy', 'default_select_ticket');

							}
						}
						else
						{
							$default_select_ticket = $this->jticketingmainhelper->getViewpath('buy', 'default_select_ticket');
						}

                        ob_start();
                        include $default_select_ticket;
                        $html = ob_get_contents();
                        ob_end_clean();

                        echo $html;
                        ?>
                  </div>
                  <?php
                     if (!empty($this->collect_attendee_info_checkout))
                     {
                     ?>
                  <div class="tab-pane step-pane" id="step_select_attendee">
                  </div>
                  <?php
                     }
                     ?>
                  <div class="tab-pane step-pane" id="step_billing_info">
                     <?php
                        $billpath = $this->jticketingmainhelper->getViewpath('buy', 'default_billing');

                        ob_start();
                        include $billpath;
                        $html = ob_get_contents();
                        ob_end_clean();

                        echo $html;
                        ?>
                  </div>
                  <div class="tab-pane step-pane" id="step_payment_info">
                  </div>
               </div>
               <!--End tab-content step-content-->
               <br>
               <!--prev_next_wizard_actions-->
               <div class="prev_next_wizard_actions">
                  <div class="form-actions">
                     <button id="btnWizardPrev" type="button" style="display:none" class="btn btn-prev pull-left" > <i class="icon-arrow-left" ></i><?php
                        echo JText::_('COM_JTICKETING_PREV');
                        ?></button>
                     <button id="btnWizardNext" type="button" class="btn btn-success btn-next pull-right" data-last="Finish" >
                     <?php
                        echo JText::_('COM_JTICKETING_SAVE_AND_NEXT');
                        ?>
                     <i class="icon-arrow-right"></i>
                     </button>
                     <button id="sa_cancel" type="button" class="btn btn-danger pull-right" style="margin-right:1%;" onclick="cancelTicket()"><?php
                        echo JText::_('COM_JTICKETING_CANCEL');
                        ?></button>
                  </div>
               </div>
               <!--END prev_next_wizard_actions-->
            </div>
         </div>
      </div>
   </div>
</div>
