<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die;

require_once JPATH_COMPONENT . '/controller.php';

/**
 * Event controller class.
 *
 * @since  1.7
 */
class JticketingControllerEvent extends JticketingController
{
	/**
	 * Method to check out an item for editing and redirect to the edit form.
	 *
	 * @return  void
	 *
	 * @since	1.6
	 */
	public function edit()
	{
		$app = JFactory::getApplication();

		// Get the previous edit id (if any) and the current edit id.
		$previousId = (int) $app->getUserState('com_jticketing.edit.event.id');
		$editId     = JFactory::getApplication()->input->getInt('id', null, 'array');

		// Set the user id for the user to edit in the session.
		$app->setUserState('com_jticketing.edit.event.id', $editId);

		// Get the model.
		$model = $this->getModel('Event', 'JticketingModel');

		// Check out the item
		if ($editId)
		{
			$model->checkout($editId);
		}

		// Check in the previous user.
		if ($previousId && $previousId !== $editId)
		{
			$model->checkin($previousId);
		}

		// Redirect to the edit screen.
		$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=eventform&layout=edit', false));
	}

	/**
	 * Method to save a user's profile data.
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function save()
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Initialise variables.
		$app   = JFactory::getApplication();
		$model = $this->getModel('Event', 'JticketingModel');

		// Get the user data.
		$data = JFactory::getApplication()->input->get('jform', array(), 'array');

		// Validate the posted data.
		$form = $model->getForm();

		if (!$form)
		{
			JError::raiseError(500, $model->getError());

			return false;
		}

		// Validate the posted data.
		$data = $model->validate($form, $data);

		// Check for errors.
		if ($data === false)
		{
			// Get the validation messages.
			$errors = $model->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n; $i++)
			{
				if ($errors[$i] instanceof Exception)
				{
					$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				}
				else
				{
					$app->enqueueMessage($errors[$i], 'warning');
				}
			}

			// Save the data in the session.
			$app->setUserState('com_jticketing.edit.event.data', JRequest::getVar('jform'), array());

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		// Attempt to save the data.
		$return = $model->save($data);

		// Check for errors.
		if ($return === false)
		{
			// Save the data in the session.
			$app->setUserState('com_jticketing.edit.event.data', $data);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setMessage(JText::sprintf('Save failed', $model->getError()), 'warning');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		// Check in the profile.
		if ($return)
		{
			$model->checkin($return);
		}

		// Clear the profile id from the session.
		$app->setUserState('com_jticketing.edit.event.id', null);

		// Redirect to the list screen.
		$this->setMessage(JText::_('COM_JTICKETING_ITEM_SAVED_SUCCESSFULLY'));
		$menu =& JSite::getMenu();
		$item = $menu->getActive();
		$this->setRedirect(JRoute::_($item->link, false));

		// Flush the data from the session.
		$app->setUserState('com_jticketing.edit.event.data', null);
	}

	/**
	 * Method to get book venue
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getAvailableVenue()
	{
		$array_venue = array();
		$post = JFactory::getApplication()->input->post;
		$array_venue['venue']		= $post->get('venue', '', 'INT');
		$startdate					= $post->get('startdate', '', 'STRING');
		$enddate					= $post->get('enddate', '', 'STRING');

		// Get formatted start time & end time for event.
		$formattedTime = $this->getFormattedTime($post);

		// Append formatted start time & end time for event to startdate & enddate.
		$startdate = $startdate . " " . $formattedTime['event_start_time'];
		$enddate = $enddate . " " . $formattedTime['event_end_time'];
		$array_venue['start_dt_timestamp'] = strtotime($startdate);
		$array_venue['end_dt_timestamp']   = strtotime($enddate);
		$array_venue['created_by']   = $post->get('created_by', '0', 'INT');
		$array_venue['event_online']   = $post->get('event_online', '', 'INT');

		require_once JPATH_COMPONENT . '/models/eventform.php';
		$JticketingModelEvent = new JticketingModelEventform;
		$result = $JticketingModelEvent->getAvailableVenue($array_venue);
		echo json_encode($result);

		/*if ($result)
		{
			echo "success";
		}
		else
		{
			echo "failure";
		}*/

		jexit();
	}

	/**
	 * Function used to get the formaated time
	 *
	 * @param   ARRAY  $post  Post data
	 *
	 * @return  string  $formattedTime  Final formatted time
	 *
	 * @since  1.0.0
	 */
	private function getFormattedTime($post)
	{
		// Get all non-jform data for event start time fields.
		$event_start_time_ampm = strtolower($post->get('event_start_time_ampm', '', 'string'));
		$event_start_time_hour = $post->get('event_start_time_hour', '', 'int');
		$event_start_time_min  = $post->get('event_start_time_min', '', 'int');
		$event_start_time      = $event_start_time_hour;

		// Convert hours into 24 hour format.
		if (($event_start_time_ampm == 'pm') && ($event_start_time_hour != '12'))
		{
			$event_start_time = $event_start_time_hour + 12;
		}
		elseif (($event_start_time_ampm == 'am') && ($event_start_time_hour == '12'))
		{
			$event_start_time = $event_start_time_hour - 12;
		}

		// Get minutes and attach seconds.
		$event_start_time .= ":" . $event_start_time_min;
		$event_start_time .= ":" . '00';

		// Get all non-jform data for event start time fields.
		$event_end_time_ampm = strtolower($post->get('event_end_time_ampm', '', 'string'));
		$event_end_time_hour = $post->get('event_end_time_hour', '', 'int');
		$event_end_time_min  = $post->get('event_end_time_min', '', 'int');
		$event_end_time      = $event_end_time_hour;

		// Convert hours into 24 hour format.
		if (($event_end_time_ampm == 'pm') && ($event_end_time_hour != '12'))
		{
			$event_end_time = $event_end_time_hour + 12;
		}

		// Checking time 12am is it then convert to 24 hour time
		elseif (($event_end_time_ampm == 'am') && ($event_end_time_hour == '12'))
		{
			$event_end_time = $event_end_time_hour - 12;
		}

		// Get minutes and attach seconds.
		$event_end_time .= ":" . $event_end_time_min;
		$event_end_time .= ":" . '00';

		$formattedTime = array();

		// Set return values.
		$formattedTime['event_start_time'] = $event_start_time;
		$formattedTime['event_end_time']   = $event_end_time;

		return $formattedTime;
	}

	/**
	 * Cancel description
	 *
	 * @return description
	 */
	public function cancel()
	{
		$app        = JFactory::getApplication();
		$previousId = (int) $app->getUserState('com_raector_crm.edit.project.id');

		if ($previousId)
		{
			// Get the model.
			$model = $this->getModel('Project', 'Raector_crmModel');
			$model->checkin($previousId);
		}

		$menu =& JSite::getMenu();
		$item = $menu->getActive();
		$this->setRedirect(JRoute::_($item->link, false));
	}

	/**
	 * remove description
	 *
	 * @return void
	 */
	public function remove()
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Initialise variables.
		$app   = JFactory::getApplication();
		$model = $this->getModel('Event', 'JticketingModel');

		// Get the user data.
		$data = JFactory::getApplication()->input->get('jform', array(), 'array');

		// Validate the posted data.
		$form = $model->getForm();

		if (!$form)
		{
			JError::raiseError(500, $model->getError());

			return false;
		}

		// Validate the posted data.
		$data = $model->validate($form, $data);

		// Check for errors.
		if ($data === false)
		{
			// Get the validation messages.
			$errors = $model->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++)
			{
				if ($errors[$i] instanceof Exception)
				{
					$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				}
				else
				{
					$app->enqueueMessage($errors[$i], 'warning');
				}
			}

			// Save the data in the session.
			$app->setUserState('com_jticketing.edit.event.data', $data);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		// Attempt to save the data.
		$return = $model->delete($data);

		// Check for errors.
		if ($return === false)
		{
			// Save the data in the session.
			$app->setUserState('com_jticketing.edit.event.data', $data);

			// Redirect back to the edit screen.
			$id = (int) $app->getUserState('com_jticketing.edit.event.id');
			$this->setMessage(JText::sprintf('Delete failed', $model->getError()), 'warning');
			$this->setRedirect(JRoute::_('index.php?option=com_jticketing&view=event&layout=edit&id=' . $id, false));

			return false;
		}

		// Check in the profile.
		if ($return)
		{
			$model->checkin($return);
		}

		// Clear the profile id from the session.
		$app->setUserState('com_jticketing.edit.event.id', null);

		// Redirect to the list screen.
		$this->setMessage(JText::_('COM_JTICKETING_ITEM_DELETED_SUCCESSFULLY'));
		$menu =& JSite::getMenu();
		$item = $menu->getActive();
		$this->setRedirect(JRoute::_($item->link, false));

		// Flush the data from the session.
		$app->setUserState('com_jticketing.edit.event.data', null);
	}

	/**
	 * remove renderbook
	 *
	 * @return void
	 */
	public function renderbook()
	{
		$eventid = 1;
		$data = $this->renderBookingHTML($eventid);
		print_r($data);
	}

	/**
	 * Render booking HTML
	 *
	 * @param   int  $eventid  id of event
	 * @param   int  $userid   userid
	 *
	 * @return  booking HTML
	 *
	 * @since   1.0
	 */
	public function renderBookingHTML($eventid, $userid='')
	{
		require_once JPATH_SITE . "/components/com_jticketing/models/event.php";

		if (empty($eventid))
		{
			return false;
		}

		$model = new JticketingModelEvent;

		return $model->renderBookingHTML($eventid, $userid);
	}
}
