<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

/**
 * controller for order
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingControllerorders extends JControllerLegacy
{
	/**
	 * Changes order status for example pending to completed
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function save()
	{
		$model         = $this->getModel('orders');
		$input         = JFactory::getApplication()->input;
		$post          = $input->post;
		$paymentHelper = JPATH_SITE . '/components/com_jticketing/models/payment.php';

		if (!class_exists('jticketingModelpayment'))
		{
			JLoader::register('jticketingModelpayment', $paymentHelper);
			JLoader::load('jticketingModelpayment');
		}

		$orderobj = new jticketingModelorders;

		if ($post->get('payment_status') == 'C')
		{
			$order_id  = $post->get('order_id');
			$obj       = new jticketingModelpayment;
			$member_id = $obj->getEventMemberid($order_id, 'P');
			$orderobj->update_order_status($order_id, $post->get('payment_status'));
			$eventupdate          = $obj->eventupdate($order_id, $member_id);
			$jticketingmainhelper = new jticketingmainhelper;
			$email                = $jticketingmainhelper->sendmailnotify($order_id, 'afterordermail');
			$orderobj->events_types_count_decrease($order_id);

			// Add entries to reminder queue to send reminder for Event
			$order                      = $jticketingmainhelper->getorderinfo($order_id);
			$orderid = $order['order_info']['0']->orderid_with_prefix;
			$reminder_data              = $jticketingmainhelper->getticketDetails($order['eventinfo']->id, $order['items']['0']->order_items_id);
			$reminder_data->ticketprice = $order['order_info']['0']->amount;
			$reminder_data->nofotickets = 1;
			$reminder_data->totalprice  = $order['order_info']['0']->amount;
			$reminder_data->eid         = $order['eventinfo']->id;
			$eventupdate                = $obj->addtoReminderQueue($reminder_data, $order);
			$link = 'index.php?option=com_jticketing&view=orders&layout=order&orderid=' . $orderid . '';
		}
		else
		{
			$order_id  = $post->get('order_id');
			$status    = $orderobj->get_order_status($order_id);
			$obj       = new jticketingModelpayment;
			$member_id = $obj->getEventMemberid($order_id, 'C');
			$orderobj->events_types_count_increase($order_id);
			$orderobj->update_order_status($order_id, $post->get('payment_status'));
			$link = 'index.php?option=com_jticketing&view=orders&layout=orders';
		}

		$this->setRedirect($link, $msg);
	}

	/**
	 * Retry payment gateway on confirm payment view frontend.
	 *
	 * @return  json.
	 *
	 * @since   1.6
	 */
	public function retryPayment()
	{
		$input = JFactory::getApplication()->input;
		$getdata = $input->get;
		$pg_plugin = $getdata->get('gateway_name', '', 'STRING');
		$order = $getdata->get('order', '', 'STRING');
		$orders = (explode("-", $order));
		$order_id = $orders[1];
		$modelObj = $this->getModel('payment');
		$payment_getway_form = $modelObj->getHTMLS($pg_plugin, $order_id, $order);

		echo json_encode($payment_getway_form);
		jexit();
	}

	/**
	 * Get Ticket types data
	 *
	 * @param   integer  $eventid  eventid
	 *
	 * @return  array  ticket types
	 *
	 * @since   1.0
	 */
	public function gettickettypesdata($eventid)
	{
		if (empty($eventid))
		{
			$eventid = $input->get('eventid');
		}

		if (empty($client))
		{
			echo "Please select integration in backend option";
		}

		$jticketingmainhelper     = new jticketingmainhelper;
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$integration              = $jticketingmainhelper->getIntegration();
		$client                   = $jticketingfrontendhelper->getClientName($integration);

		if (empty($client))
		{
			echo "Please select integration in backend option";
		}

		$query = "SELECT id FROM #__jticketing_types WHERE state=1 AND eventid = " . $integration;
		$db->setQuery($query);

		return $ticket_types = $db->loadAssocList();
	}

	/**
	 * Book tickets based on data
	 *
	 * @param   integer  $userid        eventid
	 * @param   string   $profile_type  profile_type
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getUserMobile($userid, $profile_type = 'joomla')
	{
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$data1 = $dispatcher->trigger('jt_OnBeforeMobileforReminder', array($userid, $profile_type));

		if (!empty($data1['0']))
		{
			return $mobile_no = $data1['0'];
		}

		/* @TODO for bajaj add this to plugin
		if($userid)
		{
		$query = "SELECT mobile FROM #__tjlms_user_xref WHERE `user_id`=".$userid;
		$db->setQuery($query);

		return $mobile_no = $db->loadResult();
		}*/

		$db    = JFactory::getDBO();
		$query = "SELECT profile_value FROM #__user_profiles WHERE `profile_key` like 'profile.phone'";
		$db->setQuery($query);

		return $mobile_no = $db->loadResult();
	}

	/**
	 * Book tickets based on data
	 *
	 * @param   integer  $userid             userid
	 * @param   string   $useremail          useremail
	 * @param   integer  $eventid            eventid
	 * @param   array    $ticket_types_data  ticket_types_data
	 * @param   integer  $checkout_mode      checkout_mode
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function bookTicket($userid = '', $useremail = '', $eventid = '', $ticket_types_data = array(), $checkout_mode = 'registered')
	{
		$returndata = array();
		$mainframe  = JFactory::getApplication();

		// Load various helpers
		$path                             = JPATH_ROOT . '/components/com_jticketing/helpers/main.php';
		$jticketingfrontendhelper         = JPATH_ROOT . '/components/com_jticketing/helpers/frontendhelper.php';
		$JTicketingIntegrationsHelperPath = JPATH_ROOT . '/components/com_jticketing/helpers/integrations.php';
		$helperPath                       = JPATH_SITE . '/components/com_jticketing/helpers/event.php';
		$mediaHelperPath                  = JPATH_SITE . '/components/com_jticketing/helpers/media.php';
		$field_manager_path               = JPATH_SITE . '/components/com_tjfields/helpers/tjfields.php';

		if (!class_exists('jticketingmainhelper'))
		{
			JLoader::register('jticketingmainhelper', $path);
			JLoader::load('jticketingmainhelper');
		}

		if (!class_exists('jticketingfrontendhelper'))
		{
			JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
			JLoader::load('jticketingfrontendhelper');
		}

		if (!class_exists('JTicketingIntegrationsHelper'))
		{
			JLoader::register('JTicketingIntegrationsHelper', $JTicketingIntegrationsHelperPath);
			JLoader::load('JTicketingIntegrationsHelper');
		}

		if (!class_exists('jteventHelper'))
		{
			JLoader::register('jteventHelper', $helperPath);
			JLoader::load('jteventHelper');
		}

		if (file_exists($field_manager_path))
		{
			if (!class_exists('TjfieldsHelper'))
			{
				JLoader::register('TjfieldsHelper', $field_manager_path);
				JLoader::load('TjfieldsHelper');
			}
		}

		if (!class_exists('jticketingMediaHelper'))
		{
			JLoader::register('jticketingMediaHelper', $mediaHelperPath);
			JLoader::load('jticketingMediaHelper');
		}

		$com_params               = JComponentHelper::getParams('com_jticketing');
		$db                       = JFactory::getDBO();
		$jticketingmainhelper     = new jticketingmainhelper;
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$input                    = JFactory::getApplication()->input;
		$email_options            = $com_params->get('email_options');
		$enable_reminder          = JComponentHelper::getParams('com_jticketing');
		$integration              = $jticketingmainhelper->getIntegration();
		$client                   = $jticketingfrontendhelper->getClientName($integration);

		if (empty($eventid))
		{
			$eventid = $input->get('eventid');
		}

		if (empty($userid))
		{
			$userid = $input->get('userid');
		}

		$customer_note = $input->get('customer_note');

		if ($checkout_mode == 'registered')
		{
			if (empty($userid))
			{
				$user = JFactory::getUser();
			}
			else
			{
				$user = JFactory::getUser($userid);
			}

			if (empty($user->id))
			{
				$returndata['msg']     = "Please select logged in user";
				$returndata['success'] = "0";

				return $returndata;
			}
		}
		elseif ($checkout_mode == 'guest')
		{
			if (empty($useremail))
			{
				$returndata['msg']     = "Please select user email";
				$returndata['success'] = "0";

				return $returndata;
			}
		}

		$eventCreater = $jticketingmainhelper->getEventCreator($eventid);

		if ($userid == $eventCreater)
		{
			return true;
		}

		$data            = array();
		$data['eventid'] = $eventid;
		$data['client']  = $client;

		if (empty($data['integraton_id']))
		{
			$data['integraton_id'] = $jticketingfrontendhelper->getIntegrationID($data['eventid'], $data['client']);
		}

		if ($user)
		{
			if (isset($user->name))
			{
				$data['fnam'] = $data['name'] = $user->name;
			}

			if (isset($user->email))
			{
				$data['email1'] = $data['email'] = $user->email;
			}

			if (isset($user->id))
			{
				$data['phon'] = $this->getUserMobile($user->id);
				$data['phon'] = str_replace('"', "", $data['phon']);
			}

			if ($user->id)
			{
				$data['user_id'] = $user->id;
			}
		}
		elseif ($checkout_mode = 'guest')
		{
			$data['fnam']    = $data['name'] = "";
			$data['email1']  = $data['email'] = $email;
			$data['user_id'] = 0;
		}

		$data['coupon_code']             = '';
		$data['coupon_discount']         = 0;
		$data['coupon_discount_details'] = '';
		$data['order_tax']               = 0;
		$data['order_tax_details']       = 0;
		$data['processor']               = 'Free_ticket';
		$data['customer_note']           = '';
		$data['parent_order_id']         = 0;

		if (empty($ticket_types_data))
		{
			$query = "SELECT id FROM #__jticketing_types WHERE state=1 AND  eventid = " . $data['integraton_id'];
			$db->setQuery($query);
			$ticket_types          = $db->loadAssocList();
			$data['no_of_tickets'] = count($ticket_types);

			foreach ($ticket_types as $ticket_type)
			{
				$key                                         = $ticket_type['id'];
				$ticket_types_data['type_ticketcount'][$key] = 1;
			}
		}

		$paymenthelper = JPATH_ROOT . '/components/com_jticketing/models/payment.php';

		if (!class_exists('jticketingModelpayment'))
		{
			JLoader::register('jticketingModelpayment', $paymenthelper);
			JLoader::load('jticketingModelpayment');
		}

		$JticketingModelbuypath = JPATH_ROOT . '/components/com_jticketing/models/buy.php';

		if (!class_exists('JticketingModelbuy'))
		{
			JLoader::register('JticketingModelbuy', $JticketingModelbuypath);
			JLoader::load('JticketingModelbuy');
		}

		$JticketingModelbuy       = new JticketingModelbuy;
		$JticketingModelorderpath = JPATH_ROOT . '/components/com_jticketing/models/orders.php';

		if (!class_exists('JticketingModelorders'))
		{
			JLoader::register('JticketingModelorders', $JticketingModelorderpath);
			JLoader::load('JticketingModelorders');
		}

		$JticketingModelorders         = new JticketingModelorders;

		$ticketPrice = $JticketingModelbuy->getTicketTypes(key($ticket_types_data['type_ticketcount']));
		$data['original_amt']          = $ticketPrice;
		$data['amount']                = $ticketPrice;
		$data['fee']                   = 0;
		$data['no_of_tickets'] = 1;
		$insert_order_id               = $jticketingfrontendhelper->createMainOrder($data);
		$orderdata['inserted_orderid'] = $insert_order_id;
		$JticketingModelbuy->updateOrderItems($ticket_types_data, $insert_order_id);
		$JticketingModelbuy->billingaddr($user->id, $data, $insert_order_id);
		$order                           = $jticketingmainhelper->getorderinfo($insert_order_id);

		$confirm_order                   = array();
		$confirm_order['buyer_email']    = '';
		$confirm_order['status']         = 'C';
		$confirm_order['transaction_id'] = "";
		$confirm_order['raw_data']       = "";
		$confirm_order['processor']       = $data['processor'];
		$guest_email                     = '';
		$jticketingModelpayment          = new jticketingModelpayment;
		$jticketingModelpayment->updatesales($confirm_order, $insert_order_id);

		// Updated for Adding entries in jomsocial confirmed members
		$member_id   = $jticketingModelpayment->getEventMemberid($insert_order_id, 'C');
		$eventupdate = $jticketingModelpayment->eventupdate($insert_order_id, $member_id);

		if (in_array('ticket_email', $email_options))
		{
			$email = $jticketingmainhelper->sendmailnotify($insert_order_id, 'afterordermail');
		}

		if (in_array('order_email', $email_options))
		{
			$email = $jticketingModelpayment->sendInvoiceEmail($insert_order_id);
		}

		// For Guest user attach email
		if (!$order['order_info']['0']->user_id)
		{
			$guest_email = "&email=" . md5($order['order_info']['0']->user_email);
		}

		$reminder_data = $jticketingmainhelper->getticketDetails($eventid, $order['items']['0']->order_items_id);

		// If online event create user on adobe site and register for this event
		if ($reminder_data->online_events == 1)
		{
			$jtFrontendHelper = new Jticketingfrontendhelper;
			$venueDetail = $jtFrontendHelper->getVenue($reminder_data->venue);

			$eventParams = json_decode($reminder_data->jt_params, true);
			$venueParams = json_decode($venueDetail->params, true);
			$jt_params = new stdClass;

			$enroll_user = JFactory::getUser($userid);
			$jt_params->user_id  = $userid;
			$jt_params->name     = $enroll_user->name;
			$jt_params->email    = $enroll_user->email;
			$jt_params->password = $this->rand_str(8);
			$jt_params->meeting_url = $eventParams['event_url'];
			$jt_params->api_username = $venueParams['api_username'];
			$jt_params->api_password = $venueParams['api_password'];
			$jt_params->host_url = $venueParams['host_url'];
			$jt_params->sco_id = $eventParams['event_sco_id'];
			$jt_params->sco_url = $venueParams['sco_url'];

			// TRIGGER After create event
			$dispatcher = JDispatcher::getInstance();
			JPluginHelper::importPlugin('tjevents');

			$result = $dispatcher->trigger('tj_inviteUsers', array($jt_params));
		}

		$eventupdate = $jticketingModelpayment->addtoReminderQueue($reminder_data, $order);

		if (!empty($order))
		{
			$returndata['msg']       = JText::sprintf('COM_JTICKETING_BOOKING_SUCCESS', $order['order_info'][0]->user_email);
			$returndata['success']   = "1";
			$returndata['orderdata'] = $order;
			$returndata['inserted_orderid'] = $orderdata['inserted_orderid'];
		}
		else
		{
			$returndata['msg']       = JText::_('COM_JTICKETING_BOOKING_FAIL');
			$returndata['success']   = "0";
			$returndata['orderdata'] = "";
		}

		$input  = JFactory::getApplication()->input;
		$option = $input->get('option');

		if (!$userid)
		{
			$guest_email = "&email=" . md5($useremail);
		}

		$itemid = $input->get('itemid');

		// If called from jticketing redirect to invoice view
		if ($option == 'com_jticketing')
		{
			if ($mainframe->isSite())
			{
				$return_url = JRoute::_("index.php?option=com_jticketing&view=mytickets&Itemid=" . $itemid, false);
				$mainframe->enqueueMessage($returndata['msg'], 'success');
				$mainframe->redirect($return_url);
			}
		}

		return $returndata;
	}

	/**
	 * Generate random no
	 *
	 * @param   integer  $length  length for field
	 * @param   string   $chars   Allowed characters
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function rand_str($length = 32, $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890')
	{
		// Length of character list
		$chars_length = (strlen($chars) - 1);

		// Start our string
		$string = $chars{rand(0, $chars_length)};

		// Generate random string
		for ($i = 1; $i < $length; $i = strlen($string))
		{
			// Grab a random character from our list
			$r = $chars{rand(0, $chars_length)};

			// Make sure the same two characters don't appear next to each other
			if ($r != $string{$i - 1})
			{
				$string .= $r;
			}
		}

		// Return the string
		return $string;
	}

	/**
	 * Send Reminders to client
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendReminder()
	{
		$model    = $this->getModel('orders');
		$response = $model->sendReminder();
	}

	/**
	 * This function fixes available seats for ticket types(if only one ticket type present)
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function fixSeats()
	{
		$db = JFactory::getDBO();

		$query = "SELECT SUM( orderd.ticketscount ) AS seats, xref.eventid,xref.id
		FROM  #__jticketing_order AS orderd,  #__jticketing_integration_xref AS xref
		WHERE STATUS =  'C'
		AND orderd.event_details_id = xref.id
		GROUP BY orderd.event_details_id";
		$db->setQuery($query);
		$eventlists = $db->loadObjectList();

		if (!empty($eventlists))
		{
			foreach ($eventlists AS $events)
			{
				$obj          = new StdClass;
				$obj->eventid = $events->id;
				$query        = "SELECT count(`id`) FROM #__jticketing_types WHERE eventid=" . $obj->eventid;
				$db->setQuery($query);
				$records = 0;
				$records = $db->loadResult();

				if ($records == 1)
				{
					$query        = "SELECT available FROM #__jticketing_types WHERE eventid=" . $obj->eventid;
					$db->setQuery($query);
					$available  = $db->loadResult();
					echo "count==" . $obj->count = $available - $events->seats;

					if (!$db->updateObject('#__jticketing_types', $obj, 'eventid'))
					{
					}
				}
			}
		}
	}

	/**
	 * Send Pending ticket Emails to purchaser
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendPendingTicketEmails()
	{
		$db = JFactory::getDBO();

		$input                  = JFactory::getApplication()->input;
		$Jticketingmainhelper   = new Jticketingmainhelper;
		$com_params             = JComponentHelper::getParams('com_jticketing');
		$integration            = $com_params->get('integration');
		$pkey_for_pending_email = $com_params->get("pkey_for_pending_email");
		$input                  = JFactory::getApplication()->input;
		$private_keyinurl       = $input->get('pkey', '', 'STRING');
		$passed_start           = $input->get('start_date', '', 'STRING');
		$passed_end             = $input->get('end_date', '', 'STRING');
		$accessible_groups_str  = $input->get('accessible_groups', '', 'STRING');
		$accessible_groups      = explode(",", $accessible_groups_str);
		$event_ids              = $input->get('event_id', '', 'STRING');
		$today_date             = date('Y-m-d');
		$skipuser = '';

		if ($pkey_for_pending_email != $private_keyinurl)
		{
			echo "You are Not authorized To send Pending mails";

			return;
		}

		$pending_email_batch_size = $com_params->get("pending_email_batch_size");
		$enb_batch                = $com_params->get("pending_email_enb_batch");
		$path                     = JPATH_ROOT . '/components/com_jticketing/helpers/main.php';
		$jticketingfrontendhelper = JPATH_ROOT . '/components/com_jticketing/helpers/frontendhelper.php';

		if (!class_exists('jticketingfrontendhelper'))
		{
			JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
			JLoader::load('jticketingfrontendhelper');
		}

		if (!class_exists('jticketingmainhelper'))
		{
			JLoader::register('jticketingmainhelper', $path);
			JLoader::load('jticketingmainhelper');
		}

		$Jticketingfrontendhelper = new Jticketingfrontendhelper;
		$Jticketingfrontendhelper->loadHelperClasses();
		$jticketingmainhelper = new jticketingmainhelper;
		$clientnm             = $Jticketingfrontendhelper->getClientName($integration);

		if ($integration == 2)
		{
			$query = "SELECT orderd.*,xref.eventid AS eventid
			FROM  #__jticketing_order AS orderd,#__jticketing_events AS events,#__jticketing_integration_xref AS xref
			WHERE orderd.STATUS =  'C' AND orderd.ticket_email_sent=0
			AND orderd.event_details_id = xref.id AND xref.eventid=events.id AND  DATE(NOW()) <= DATE(`startdate`)";

			if ($passed_start)
			{
				$query .= " AND DATE(`startdate`)>='$passed_start' ";
			}

			if ($passed_end)
			{
				$query .= " AND DATE(`startdate`)<='$passed_end'";
			}

			if ($event_ids)
			{
				$event_id_arr = explode(",", $event_ids);
				$event_id_str = implode("','", $event_id_arr);
				$query .= " AND events.id IN ('$event_id_str')";
			}
		}
		else
		{
			$query = "SELECT orderd.*,xref.eventid
			FROM  #__jticketing_order AS orderd,#__jticketing_integration_xref AS xref WHERE orderd.STATUS =  'C' AND orderd.ticket_email_sent=0
			AND orderd.event_details_id = xref.id AND xref.source='" . $clientnm . "'";
		}

		if ($enb_batch == '1')
		{
			$query .= " LIMIT {$pending_email_batch_size}";
		}

		$db->setQuery($query);
		$orders = $db->loadObjectList();
		$result = array();
		$i      = 0;

		foreach ($orders AS $orderdata)
		{
			$allow_email = $email = 0;

			if ($integration != 2)
			{
				$eventdetails = $Jticketingmainhelper->getAllEventDetails($orderdata->eventid);

				if (date($eventdetails->startdate) < $today_date)
				{
					continue;
				}
			}

			if ($accessible_groups_str)
			{
				$uid = $orderdata->user_id;
				$query = $db->getQuery(true);
				$query
				->select('title')->from('#__usergroups')
				->where('id IN (' . implode(',', array_values(JFactory::getUser($uid)->groups)) . ')');
				$db->setQuery($query);
				$groups = $db->loadColumn();
				$allow_email = count(array_intersect($groups, $accessible_groups));

				if ($allow_email)
				{
					$email = $jticketingmainhelper->sendmailnotify($orderdata->id, 'afterordermail');
				}
				else
				{
					$skipuser = 1;
				}
			}
			else
			{
				$email = $jticketingmainhelper->sendmailnotify($orderdata->id, 'afterordermail');
			}

			echo "To Email===" . $orderdata->email;

			if ($skipuser)
			{
				echo "===Skipping since group is==" . implode(",", $groups);
			}

			echo "==mailsent===" . $email;
			echo "<br/>";
			echo "<br/>";
			$i++;
		}
	}

	/**
	 * This will add pending entries to reminder queue
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function addPendingEntriestoQueue()
	{
		$db = JFactory::getDBO();

		$input = JFactory::getApplication()->input;
		$pkay  = $input->get('pkey', '');

		if ($pkey != "ascd2456")
		{
		}

		$path                             = JPATH_ROOT . '/components/com_jticketing/helpers/main.php';
		$jticketingfrontendhelper         = JPATH_ROOT . '/components/com_jticketing/helpers/frontendhelper.php';
		$JTicketingIntegrationsHelperPath = JPATH_ROOT . '/components/com_jticketing/helpers/integrations.php';
		$helperPath                       = JPATH_SITE . '/components/com_jticketing/helpers/event.php';
		$mediaHelperPath                  = JPATH_SITE . '/components/com_jticketing/helpers/media.php';
		$field_manager_path               = JPATH_SITE . '/components/com_tjfields/helpers/tjfields.php';

		if (!class_exists('jticketingfrontendhelper'))
		{
			JLoader::register('jticketingfrontendhelper', $jticketingfrontendhelper);
			JLoader::load('jticketingfrontendhelper');
		}

		if (!class_exists('jticketingmainhelper'))
		{
			JLoader::register('jticketingmainhelper', $path);
			JLoader::load('jticketingmainhelper');
		}

		$paymenthelper = JPATH_ROOT . '/components/com_jticketing/models/payment.php';

		if (!class_exists('jticketingModelpayment'))
		{
			JLoader::register('jticketingModelpayment', $paymenthelper);
			JLoader::load('jticketingModelpayment');
		}

		$JticketingModelbuypath = JPATH_ROOT . '/components/com_jticketing/models/buy.php';

		if (!class_exists('JticketingModelbuy'))
		{
			JLoader::register('JticketingModelbuy', $JticketingModelbuypath);
			JLoader::load('JticketingModelbuy');
		}

		$JticketingModelbuy       = new JticketingModelbuy;
		$jticketingModelpayment   = new jticketingModelpayment;
		$Jticketingfrontendhelper = new Jticketingfrontendhelper;
		$Jticketingfrontendhelper->loadHelperClasses();
		$jticketingmainhelper = new jticketingmainhelper;
		$query                = "SELECT orderd.*,xref.eventid AS eventid
		FROM  #__jticketing_order AS orderd,  #__jticketing_integration_xref AS xref
		WHERE STATUS =  'C'
		AND orderd.event_details_id = xref.id";
		$db->setQuery($query);
		$orders = $db->loadObjectList();

		foreach ($orders AS $orderdata)
		{
			$order = $jticketingmainhelper->getorderinfo($orderdata->id);

			if ($order['order_info']['0']->user_id)
			{
				$order['order_info']['0']->user_email = JFactory::getUser($order['order_info']['0']->user_id)->email;
			}

			$reminder_data              = '';
			$reminder_data              = $jticketingmainhelper->getticketDetails($orderdata->eventid, $order['items']['0']->order_items_id);
			$reminder_data->ticketprice = $data->ticketprice;
			$reminder_data->nofotickets = $data->ticketscount;
			$reminder_data->totalprice  = $data->amount;
			$reminder_data->eid         = $orderdata->eventid;

			$eventupdate = $jticketingModelpayment->addtoReminderQueue($reminder_data, $order);
		}
	}
}
