<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die;
jimport('joomla.application.component.modelform');
jimport('joomla.event.dispatcher');

/**
 * Model for getting event list
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingModelEvent extends JModelForm
{
	private $item = '';
	/**
	 * Method to populate state
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	protected function populateState()
	{
		$app = JFactory::getApplication('com_jticketing');

		// Load state from the request userState on edit or from the passed variable on default
		if (JFactory::getApplication()->input->get('layout') == 'edit')
		{
			$id = JFactory::getApplication()->getUserState('com_jticketing.edit.event.id');
		}
		else
		{
			$id = JFactory::getApplication()->input->get('id');
			JFactory::getApplication()->setUserState('com_jticketing.edit.event.id', $id);
		}

		$this->setState('event.id', $id);

		// Load the parameters.
		$params       = $app->getParams();
		$params_array = $params->toArray();

		if (isset($params_array['item_id']))
		{
			$this->setState('event.id', $params_array['item_id']);
		}

		$this->setState('params', $params);
	}

	/**
	 * Method to get an ojbect.
	 *
	 * @param   integer  $id  The id of the object to get.
	 *
	 * @return  mixed	Object on success, false on failure.
	 */
	public function &getData($id = null)
	{
		if (empty($this->item))
		{
			$this->item = false;

			if (empty($id))
			{
				$id = $this->getState('event.id');
			}

			// Get a level row instance.
			$table = $this->getTable();

			// Attempt to load the row.
			if ($table->load($id))
			{
				// Check published state.
				if ($published = $this->getState('filter.published'))
				{
					if ($table->state != $published)
					{
						return $this->_item;
					}
				}

				// Convert the JTable to a clean JObject.
				$properties  = $table->getProperties(1);
				$this->_item = JArrayHelper::toObject($properties, 'JObject');
			}
			elseif ($error = $table->getError())
			{
				$this->setError($error);
			}
		}

		$this->item =& $this->_item;

		if (!empty($this->item))
		{
			if ($this->item->venue == "0")
			{
				$this->item->event_address = $this->item->location;
			}
			else
			{
				$jticketingfrontendhelper = new jticketingfrontendhelper;
				$this->item->event_address = $jticketingfrontendhelper->getVenue($this->item->venue)->address;
			}
		}

		return $this->item;
	}

	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param   string  $type    The table type to instantiate
	 * @param   string  $prefix  A prefix for the table class name. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTable($type = 'Event', $prefix = 'JticketingTable', $config = array())
	{
		$this->addTablePath(JPATH_COMPONENT_ADMINISTRATOR . '/tables');

		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to check in an item.
	 *
	 * @param   integer  $id  The id of the row to check out.
	 *
	 * @return	boolean  True on success, false on failure.
	 *
	 * @since	1.6
	 */
	public function checkin($id = null)
	{
		// Get the id.
		$id = (!empty($id)) ? $id : (int) $this->getState('event.id');

		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Attempt to check the row in.
			if (method_exists($table, 'checkin'))
			{
				if (!$table->checkin($id))
				{
					$this->setError($table->getError());

					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to check out an item.
	 *
	 * @param   integer  $id  The id of the row to check out.
	 *
	 * @return	boolean  True on success, false on failure.
	 *
	 * @since	1.6
	 */
	public function checkout($id = null)
	{
		// Get the user id.
		$id = (!empty($id)) ? $id : (int) $this->getState('event.id');

		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Get the current user object.
			$user = JFactory::getUser();

			// Attempt to check the row out.
			if (method_exists($table, 'checkout'))
			{
				if (!$table->checkout($user->get('id'), $id))
				{
					$this->setError($table->getError());

					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   string  $data      An optional array of data for the form to interogate.
	 * @param   string  $loadData  True if the form is to load its own data (default case), false if not.
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jticketing.event', 'event', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return	mixed	The data for the form.
	 *
	 * @since	1.6
	 */
	protected function loadFormData()
	{
		$data = $this->getData();

		return $data;
	}

	/**
	 * Method to save form
	 *
	 * @param   string  $data  An optional array of data for the form to interogate.
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function save($data)
	{
		$jteventHelper = new jteventHelper;
		$dispatcher    = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('jt_OnBeforeEventCreate', array($data));
		$id     = (!empty($data['id'])) ? $data['id'] : (int) $this->getState('event.id');
		$state  = (!empty($data['state'])) ? 1 : 0;
		$user   = JFactory::getUser();

		if ($id)
		{
			// Check the user can edit this item
			$authorised = $user->authorise('core.edit', 'com_jticketing') || $authorised = $user->authorise('core.edit.own', 'com_jticketing');

			// The user cannot edit the state of the item.
			if ($user->authorise('core.edit.state', 'com_jticketing') !== true && $state == 1)
			{
				$data['state'] = 0;
			}
		}
		else
		{
			// Check the user can create new items in this section
			$authorised = $user->authorise('core.create', 'com_jticketing');

			// The user cannot edit the state of the item.
			if ($user->authorise('core.edit.state', 'com_jticketing') !== true && $state == 1)
			{
				$data['state'] = 0;
			}
		}

		if ($authorised !== true)
		{
			JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		$table = $this->getTable();

		if ($table->save($data) === true)
		{
			return $id;
		}
		else
		{
			return false;
		}

		$socialintegration = $com_params->get('integrate_with', 'none');
		$streamAddEvent    = $com_params->get('streamAddEvent', 0);

		if ($socialintegration != 'none')
		{
			$user     = JFactory::getUser();
			$libclass = $jteventHelper->getJticketSocialLibObj();

			// Add in activity.
			if ($streamAddEvent)
			{
				$action      = 'addevent';
				$link = JUri::root() . substr(JRoute::_('index.php?option=com_jticketing&view=event&id=' . $id), strlen(JUri::base(true)) + 1);
				$eventLink   = '<a class="" href="' . $link . '">' . $data['title'] . '</a>';
				$originalMsg = JText::sprintf('COM_JTICKETING_ACTIVITY_ADD_EVENT', $eventLink);
				$libclass->pushActivity($user->id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
			}
		}

		// TRIGGER After create event
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('jt_OnAfterEventCreate', array($data));
	}

	/**
	 * Method to delete event
	 *
	 * @param   string  $data  post data
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function delete($data)
	{
		$id = (!empty($data['id'])) ? $data['id'] : (int) $this->getState('event.id');

		if (JFactory::getUser()->authorise('core.delete', 'com_jticketing') !== true)
		{
			JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		$table = $this->getTable();

		if ($table->delete($data['id']) === true)
		{
			return $id;
		}
		else
		{
			return false;
		}

		// TRIGGER After create event
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('jt_OnAfterDeleteEvent', array($data, $id));

		return true;
	}

	/**
	 * Method to get category name
	 *
	 * @param   string  $id  id of category
	 *
	 * @return	string  category name
	 *
	 * @since   1.0
	 */
	public function getCategoryName($id)
	{
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);

		if (isset($id))
		{
			$query->select('title')->from('#__categories')->where('id = ' . $id);
			$db->setQuery($query);
		}

		return $db->loadObject();
	}

	/**
	 * Method to get the form for extra fields.This form file will be created by field manager.
	 *
	 * @param   array  $id  An optional array of data for the form to interogate.
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getDataExtra($id = null)
	{
		if (empty($id))
		{
			$id = $this->getState('event.id');
		}

		if (empty($id))
		{
			return false;
		}

		$TjfieldsHelperPath = JPATH_SITE . DS . 'components' . DS . 'com_tjfields' . DS . 'helpers' . DS . 'tjfields.php';

		if (!class_exists('TjfieldsHelper'))
		{
			JLoader::register('TjfieldsHelper', $TjfieldsHelperPath);
			JLoader::load('TjfieldsHelper');
		}

		$tjFieldsHelper = new TjfieldsHelper;
		$data               = array();
		$data['client']     = 'com_jticketing.event';
		$data['content_id'] = $id;
		$extra_fields_data = $tjFieldsHelper->FetchDatavalue($data);

		return $extra_fields_data;
	}

	/**
	 * Method to get ticket types
	 *
	 * @param   array  $id  An optional array of data for the form to interogate.
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function GetTicketTypes($id = null)
	{
		if (empty($id))
		{
			$id = $this->getState('event.id');
		}

		if (empty($id))
		{
			return false;
		}

		$jticketingmainhelper = new jticketingmainhelper;
		$GetTicketTypes       = $jticketingmainhelper->getEventDetails($id);

		return $GetTicketTypes;
	}

	/**
	 * Render booking HTML
	 *
	 * @param   int  $eventid  id of event
	 * @param   int  $userid   userid
	 *
	 * @return  booking HTML
	 *
	 * @since   1.0
	 */
	public function renderBookingHTML($eventid,$userid='')
	{
		$path = JPATH_ROOT . '/components/com_jticketing/helpers/frontendhelper.php';

		if (!class_exists('Jticketingfrontendhelper'))
		{
			JLoader::register('Jticketingfrontendhelper', $path);
			JLoader::load('Jticketingfrontendhelper');
		}

		$path = JPATH_ROOT . '/components/com_jticketing/helpers/main.php';

		if (!class_exists('Jticketingmainhelper'))
		{
			JLoader::register('Jticketingmainhelper', $path);
			JLoader::load('Jticketingmainhelper');
		}

		$Jticketingfrontendhelper = new Jticketingfrontendhelper;
		$Jticketingmainhelper = new Jticketingmainhelper;
		$eventdata = $Jticketingmainhelper->getAllEventDetails($eventid);
		$HTML = $Jticketingfrontendhelper->renderBookingHTML($eventid, $userid, $eventdata);

		$HTML['online_html'] = '';

		if ($eventdata->online_events)
		{
			if ($HTML['isboughtEvent'] || $eventdata->created_by == $userid)
			{
				$params = json_decode($eventdata->jt_params, "true");

				// TRIGGER After create event
				$dispatcher = JDispatcher::getInstance();
				JPluginHelper::importPlugin('tjevents');
				$result = $dispatcher->trigger('generateMeeting_HTML', array($params,$eventdata));

				if (!empty($result['0']))
				{
					$HTML['online_html'] = $result['0'];
				}
			}
		}

		return $HTML;
	}

	/**
	 * This is used to get venue name
	 *
	 * @param   int  $id  order id
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getVenue($id)
	{
		$db = JFactory::getDBO();
		$sql = "SELECT params FROM #__jticketing_venues WHERE #__jticketing_venues.id =" . $id;
		$db->setQuery($sql);
		$venueName = $db->loadResult();

		return $venueName;
	}
}
