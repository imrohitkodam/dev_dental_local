<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');
jimport('joomla.database.table.user');
/**
 * Model for order for creating order and process order
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingModelorders extends JModelLegacy
{
	/**
	 * Constructor
	 *
	 * @since   1.0
	 */
	public function __construct()
	{
		parent::__construct();
		global $mainframe, $option;
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');

		// Get pagination request variables
		$limit      = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $input->get('limitstart', '0', 'INT');

		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->jticketingmainhelper = new jticketingmainhelper;
	}

	/**
	 * Get data for a order
	 *
	 * @return  object  $this->_data  payout data
	 *
	 * @since   1.0
	 */
	public function getData()
	{
		if (empty($this->_data))
		{
			$query       = $this->_buildQuery();
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_data;
	}

	/**
	 * Bulid query
	 *
	 * @return  string  $query  query
	 *
	 * @since   1.0
	 */
	public function _buildQuery()
	{
		$where = $this->_buildContentWhere();
		$query = $this->jticketingmainhelper->getOrderData($where);

		// For ordering
		global $mainframe, $option;
		$mainframe        = JFactory::getApplication();
		$db               = JFactory::getDBO();
		$filter_order     = '';
		$filter_order_Dir = '';
		$qry1             = '';
		$filter_order     = $mainframe->getUserStateFromRequest($option . 'filter_order', 'filter_order', 'title', 'cmd');
		$filter_order_Dir = $mainframe->getUserStateFromRequest($option . 'filter_order_Dir', 'filter_order_Dir', 'desc', 'word');

		if ($filter_order)
		{
			$qry1 = "SHOW COLUMNS FROM #__jticketing_order";

			if ($qry1)
			{
				$db->setQuery($qry1);
				$exists1 = $db->loadobjectlist();

				foreach ($exists1 as $key1 => $value1)
				{
					$allowed_fields[] = $value1->Field;
				}

				if (in_array($filter_order, $allowed_fields))
				{
					$query .= " ORDER BY o.$filter_order $filter_order_Dir";
				}
			}
		}

		return $query;
	}

	/**
	 * Bulid query condition
	 *
	 * @return  string  $where where condition for query
	 *
	 * @since   1.0
	 */
	public function _buildContentWhere()
	{
		global $mainframe, $option;
		$mainframe = JFactory::getApplication();
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();

		// Geting integration id
		$integration          = $this->jticketingmainhelper->getIntegration();
		$option               = $input->get('option');
		$layout               = $input->get('layout', '', 'STRING');
		$user                 = JFactory::getUser();
		$eventid              = $search_event = $mainframe->getUserStateFromRequest($option . 'search_event', 'search_event', '', 'string');
		$search_paymentStatus = $mainframe->getUserStateFromRequest($option . 'search_paymentStatus', 'search_paymentStatus', '', 'string');
		$where                = "";

		if (isset($eventid))
		{
			$intxrefidevid = $this->jticketingmainhelper->getEventrefid($eventid);

			if ($intxrefidevid)
			{
				$where[] = "  	event_details_id={$intxrefidevid}";
			}
		}

		if ($search_paymentStatus)
		{
			$paymentStatus = JString::strtoupper($search_paymentStatus);
			$where[]       = "	 	status LIKE '{$paymentStatus}'";
		}

		$where1 = '';

		if ($user and $layout == 'my')
		{
			$where[] = "  user.user_id=" . $user->id;
		}

		// If all orders view show only events that are created by that user
		if ($user and $layout == 'default')
		{
			$where[] = "  i.userid=" . $user->id;
		}

		$integration = $this->jticketingmainhelper->getIntegration();

		if ($integration == 1)
		{
			$source = 'com_community';
		}
		elseif ($integration == 2)
		{
			$source = 'com_jticketing';
		}
		elseif ($integration == 3)
		{
			$source = 'com_jevents';
		}
		elseif ($integration == 4)
		{
			$source = 'com_easysocial';
		}

		$where[] = "  i.source='" . $source . "'";

		// If layout=my find events for which user has made orders
		if ($layout == 'my')
		{
			$eventlist = $this->jticketingmainhelper->geteventnamesBybuyer($user->id);
		}
		elseif ($layout == 'default')
		{
			// If layout=default find all events which are created by that user
			$eventlist = $this->jticketingmainhelper->geteventnamesByCreator($user->id);
		}

		if (!empty($eventlist))
		{
			foreach ($eventlist as $key => $event)
			{
				if (isset($event->integrid))
				{
					$eventintgrid[] = $event->integrid;
				}
			}

			if (!empty($eventintgrid))
			{
				$eventintgrid = implode("','", $eventintgrid);
				$where[]      = "	o.event_details_id IN ('" . $eventintgrid . "')";
			}
		}

		if (!empty($where))
		{
			$where1 = "	WHERE " . implode('	AND  ', $where);
		}

		return $where1;
	}

	/**
	 * get total count
	 *
	 * @return  int  $this->_total  total count
	 *
	 * @since   1.0
	 */
	public function getTotal()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_total))
		{
			$query        = $this->_buildQuery();
			$this->_total = $this->_getListCount($query);
		}

		return $this->_total;
	}

	/**
	 * get pagination
	 *
	 * @return  object  $this->_pagination  pagination values
	 *
	 * @since   1.0
	 */
	public function getPagination()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_pagination;
	}

	/**
	 * get eventname
	 *
	 * @return  object  $this->_data  event data
	 *
	 * @since   1.0
	 */
	public function getEventName()
	{
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');
		$eventid   = $input->get('event', '', 'INT');
		$query     = $this->jticketingmainhelper->getEventName($eventid);
		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Get Event details
	 *
	 * @return  object  $this->_data  event data
	 *
	 * @since   1.0
	 */
	public function Eventdetails()
	{
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');
		$eventid   = $input->get('event', '', 'INT');
		$query     = "SELECT title FROM #__community_events
			  WHERE id = {$eventid}";
		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Store order
	 *
	 * @param   integer  $post  post data for order
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function store($post)
	{
		$db                  = JFactory::getDBO();
		$res                 = new stdClass;
		$res->id             = $post->get('order_id');
		$res->mdate          = date("Y-m-d H:i:s");
		$res->transaction_id = md5($post->get('order_id'));
		$res->payee_id       = $post->get('buyer_email');
		$res->status         = trim($post->get('pstatus'));
		$res->processor      = $post->get('processor');
		$res->extra          = json_encode($post->get());

		if (!$db->updateObject('#__jticketing_order', $res, 'id'))
		{
			return false;
		}

		if ($post->get('pstatus') == 'C')
		{
			$query = "SELECT type_id,count(ticketcount) as ticketcounts
					FROM #__jticketing_order_items where order_id=" . $post->get('order_id') . " GROUP BY type_id";
			$db->setQuery($query);
			$orderdetails = $db->loadObjectlist();

			foreach ($orderdetails as $orderdetail)
			{
				$typedata = '';
				$restype  = new stdClass;
				$query    = "SELECT count
					FROM #__jticketing_types where id=" . $orderdetail->type_id;
				$db->setQuery($query);
				$typedata       = $db->loadResult();
				$restype->id    = $orderdetail->type_id;
				$restype->count = $typedata - $orderdetail->ticketcounts;
				$db->updateObject('#__jticketing_types', $restype, 'id');
			}
		}
	}

	/**
	 * Delete order
	 *
	 * @param   integer  $orderid  id of jticketing_order table to delete
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function delete_order($orderid)
	{
		$db          = JFactory::getDBO();
		$id          = implode(',', $orderid);
		$integration = $this->jticketingmainhelper->getIntegration();

		for ($i = 0; $i < 2; $i++)
		{
			$data = $this->jticketingmainhelper->getOrder_ticketcount($id, $i);
			$db->setQuery($data);
			$result = $db->loadobjectlist();

			// Variable for conformation
			$confrim = 0;

			foreach ($result as $temp_result)
			{
				// Update the Type ticeket count
				if ($i == 0)
				{
					// When Deleting Confirmed order increase count in types table
					$query = " Update #__jticketing_types SET count = count+$temp_result->cnt where id=" . $temp_result->type_id;
					$db->setQuery($query);
					$confrim = $db->execute();
				}
			}

			// When Deleting Confirmed order decresing the confromcount in community_events table & deleting the community_events_members confirmed users
			if ($i == 0 && (!empty($result)) && $integration == 1)
			{
				$confrim = $this->jticketingmainhelper->unJoinMembers($id);
			}
		}

		// Delete the order from order table
		$delete_order = "delete from #__jticketing_order where id IN ( $id )";
		$db->setQuery($delete_order);
		$confrim = $db->execute();

		// Delete the order item
		$delete_order_item = "delete from #__jticketing_order_items where order_id IN ( $id )";
		$db->setQuery($delete_order_item);
		$confrim = $db->execute();

		if ($confrim)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Decrease ticket available seats
	 *
	 * @param   integer  $order_id  id of jticketing_order table
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function events_types_count_decrease($order_id)
	{
		$db   = JFactory::getDBO();
		$data = $this->jticketingmainhelper->getOrder_ticketcount($order_id, 0);
		$db->setQuery($data);
		$result  = $db->loadobjectlist();
		$confrim = 0;

		foreach ($result as $temp_result)
		{
			// Update the Type ticeket count
			$query = " Update #__jticketing_types SET count = count-$temp_result->cnt where id=" . $temp_result->type_id;
			$db->setQuery($query);
			$confrim = $db->execute();
		}
	}

	/**
	 * Increase ticket available seats
	 *
	 * @param   integer  $order_id  id of jticketing_order table
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function events_types_count_increase($order_id)
	{
		$db          = JFactory::getDBO();
		$integration = $this->jticketingmainhelper->getIntegration();
		$data        = $this->jticketingmainhelper->getOrder_ticketcount($order_id, 0);
		$db->setQuery($data);
		$result  = $db->loadobjectlist();
		$confrim = 0;

		foreach ($result as $temp_result)
		{
			// Update the Type ticeket count
			$query = " Update #__jticketing_types SET count = count+$temp_result->cnt where id=" . $temp_result->type_id;
			$db->setQuery($query);
			$confrim = $db->execute();
		}

		if ($integration == 1)
		{
			$confrim = $this->jticketingmainhelper->unJoinMembers($order_id);
		}
	}

	/**
	 * Get order status based on order id
	 *
	 * @param   integer  $order_id  id of jticketing_order table
	 *
	 * @return  string order status like C,P
	 *
	 * @since   1.0
	 */
	public function get_order_status($order_id)
	{
		$db    = JFactory::getDBO();
		$query = "SELECT status from #__jticketing_order where id=$order_id";
		$db->setQuery($query);

		return $result = $db->loadResult($query);
	}

	/**
	 * Update order status based on order id
	 *
	 * @param   integer  $order_id  id of jticketing_order table
	 * @param   string   $status    status to change
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function update_order_status($order_id, $status)
	{
		$db    = JFactory::getDBO();
		$query = "UPDATE #__jticketing_order SET status='$status' where id=$order_id";
		$db->setQuery($query);
		$db->execute();
	}

	/**
	 * Send remiders to client
	 *
	 * @param   int  $plug_call  this is 1 if function called from jticketing system plugin
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendReminder($plug_call = 0)
	{
		$Jticketingmainhelper = new Jticketingmainhelper;
		$com_params           = JComponentHelper::getParams('com_jticketing');
		jimport('joomla.filesystem.file');
		$db                  = JFactory::getDBO();
		$pkey_for_reminder   = $com_params->get("pkey_for_reminder");
		$send_auto_reminders = $com_params->get("send_auto_reminders");

		if ($send_auto_reminders != 1)
		{
			return false;
		}

		$input            = JFactory::getApplication()->input;
		$private_keyinurl = $input->get('pkey', '', 'STRING');
		$return_msg       = array();

		if ($pkey_for_reminder != $private_keyinurl)
		{
			echo "You are Not authorized To send mails";

			return;
		}
		else
		{
			if ($plug_call == 0)
			{
				echo "*****************************<br />";
				echo "Sending Reminders <br />";
				echo "----------------------------- <br />";
			}

			$batch_size_reminders = $com_params->get("batch_size_reminders");
			$enb_batch            = $com_params->get("enb_batch");

			// Send  manual emails(which are added to queue from backend attendee list view)
			$return_msg[] = $this->sendManualEmail($enb_batch, $batch_size_reminders);

			// Send normal reminder emails so no need to pass flag
			$return_msg[] = $this->sendEmailReminder($enb_batch, $batch_size_reminders);
			$return_msg[] = $this->sendSMSReminder($enb_batch, $batch_size_reminders);

			// Add entries to log files
			jimport('joomla.log.log');
			$tablemsg = '';
			$tablemsg .= "<table>";

			if (empty($return_msg['0']) and empty($return_msg['1']))
			{
				if ($plug_call == 0)
				{
					echo "===No records found==";
				}

				return;
			}

			foreach ($return_msg as $msgs)
			{
				foreach ($msgs AS $msg)
				{
					// $tablemsg .= "<tr><td align=\"center\"></td>";
					$tablemsg .= "<td>" . $msg["msg"] . "</td>";
					JLog::addLogger(array('text_file' => 'com_jticketing.reminder.php'), JLog::ALL, $msg["msg"]);
					$tablemsg .= "</tr>";
				}
			}

			if ($plug_call == 0)
			{
				$tablemsg .= "</table>";
				echo $tablemsg;
			}
		}
	}

	/**
	 * Send SMS Reminders
	 *
	 * @param   string   $enb_batch             enable batch or not
	 * @param   integer  $batch_size_reminders  status to change
	 * @param   integer  $sent_delayed          if message is delayed give it preference
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendManualEmail($enb_batch, $batch_size_reminders, $sent_delayed = 0)
	{
		$Jticketingmainhelper = new Jticketingmainhelper;
		$com_params           = JComponentHelper::getParams('com_jticketing');
		$db                   = JFactory::getDBO();
		$return_msg           = array();
		$query                = "select *
		from #__jticketing_queue l
		WHERE sent=" . $sent_delayed . "  AND reminder_type='manual_email' AND  DATE(NOW()) = DATE(`date_to_sent`)
		order by date_to_sent desc";

		if ($enb_batch == '1')
		{
			$query .= " LIMIT {$batch_size_reminders}";
		}

		$db->setQuery($query);
		$reminder_ids = $db->loadObjectList();

		if (empty($reminder_ids))
		{
			return array();
		}

		$i = 0;

		foreach ($reminder_ids AS $reminder)
		{
			if (!empty($reminder->content) and !empty($reminder->email))
			{
				$query = "";

				// Find event start date
				$query = "SELECT event_details_id from #__jticketing_order where  status='C' AND id=" . $reminder->order_id;
				$db->setQuery($query);
				$event_integration_id = $db->loadResult($query);

				// If order is deleted dont send reminder
				if (!$event_integration_id)
				{
					continue;
				}

				$query = "";
				$query = "SELECT eventid from #__jticketing_integration_xref where id=$event_integration_id";
				$db->setQuery($query);
				$eventid = $db->loadResult($query);

				// If order is deleted dont send reminder
				if (!$eventid)
				{
					continue;
				}

				$eventdetails = $Jticketingmainhelper->getAllEventDetails($eventid);

				// If event is deleted dont send reminder
				if (!$eventdetails)
				{
					continue;
				}

				// If event unpublished dont send reminder
				if ($eventdetails->event_state != 1)
				{
					continue;
				}

				$today_date = JFactory::getDate();
				$email      = $Jticketingmainhelper->jtsendMail($mailfrom, $fromname, $reminder->email, $reminder->subject, $reminder->content, $mode = 1);

				if ($email == 1)
				{
					$return_msg['success'] = 1;
					$obj                   = new StdClass;
					$obj->id               = $reminder->id;
					$obj->sent             = 1;
					$obj->sent_date        = date("Y-m-d H:i:s");

					if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
					{
						$return_msg[$i]['success'] = 0;
						$return_msg[$i]['msg']     = "Database error";

						return $return_msg;
					}

					$return_msg[$i]['success'] = 1;
					$return_msg[$i]['msg']     = "Successfully Sent to " . $reminder->email;
					$i++;
				}
				else
				{
					// If email not sent set it as delayed
					$obj            = new StdClass;
					$obj->id        = $reminder->id;
					$obj->sent      = 0;
					$obj->sent_date = date("Y-m-d H:i:s");

					if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
					{
						$return_msg[$i]['success'] = 0;
						$return_msg[$i]['msg']     = "Database error";

						return $return_msg;
					}

					$return_msg[$i]['success'] = 0;
					$return_msg[$i]['msg']     = "Failed to sent" . $reminder->email;
					$i++;
				}
			}
		}
	}

	/**
	 * Send Email Reminders
	 *
	 * @param   string   $enb_batch             enable batch or not
	 * @param   integer  $batch_size_reminders  size of batch
	 * @param   integer  $sent_delayed          if message is delayed give it preference
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendEmailReminder($enb_batch, $batch_size_reminders, $sent_delayed = 0)
	{
		$db                   = JFactory::getDBO();
		$Jticketingmainhelper = new Jticketingmainhelper;
		$jteventHelper        = new jteventHelper;
		$return_msg           = array();
		$app                  = JFactory::getApplication();
		$mailer               = JFactory::getMailer();
		$mailfrom             = $app->getCfg('mailfrom');
		$fromname             = $app->getCfg('fromname');
		$sitename             = $app->getCfg('sitename');

		// Delete all entries in queue which are not sent
		$query              = "";
		$input              = JFactory::getApplication()->input;
		$do_not_add_pending = $input->get('do_not_add_pending');
		$debug              = $input->get('jt_debug');

		if (empty($do_not_add_pending))
		{
			$jteventHelper->addPendingEntriestoQueue();
		}

		$query = "";
		$query = "select queue.*,remtypes.replytoemail
		from #__jticketing_queue AS queue ,#__jticketing_reminder_types AS remtypes
		WHERE queue.reminder_type_id=remtypes.id
		AND  remtypes.state=1 AND queue.sent=" . $sent_delayed . "
		AND queue.reminder_type='email' AND  DATE(NOW()) = DATE(`date_to_sent`)
		order by date_to_sent desc";

		if ($enb_batch == '1')
		{
			$query .= " LIMIT {$batch_size_reminders}";
		}

		$db->setQuery($query);
		$reminder_ids = $db->loadObjectList();

		if ($debug)
		{
			print_r($reminder_ids);
		}

		if (empty($reminder_ids))
		{
			return array();
		}

		$i = 0;

		foreach ($reminder_ids AS $reminder)
		{
			// Find all reminder data
			$query                   = "";
			$reminder->reminder_type = trim($reminder->reminder_type);
			$reminder->content       = trim($reminder->content);

			if ($reminder->reminder_type == "email" and !empty($reminder->content) and !empty($reminder->email))
			{
				$query = "";

				// Find event start date
				$db    = JFactory::getDBO();
				$query = "SELECT event_details_id from #__jticketing_order where  status='C' AND id=" . $reminder->order_id;
				$db->setQuery($query);
				$event_integration_id = $db->loadResult($query);

				// If order is deleted dont send reminder
				if (!$event_integration_id)
				{
					continue;
				}

				$query = "";
				$query = "SELECT eventid from #__jticketing_integration_xref where id=$event_integration_id";
				$db->setQuery($query);
				$eventid = $db->loadResult($query);

				// If order is deleted dont send reminder
				if (!$eventid)
				{
					continue;
				}

				$eventdetails = $Jticketingmainhelper->getAllEventDetails($eventid);

				// If event is deleted dont send reminder
				if (!$eventdetails)
				{
					continue;
				}

				// If event unpublished dont send reminder
				if ($eventdetails->event_state != 1)
				{
					continue;
				}

				$today_date = date('Y-m-d');

				// Check if date has not passed
				if (strtotime($eventdetails->startdate) < strtotime($today_date))
				{
					$obj            = new StdClass;
					$obj->id        = $reminder->id;
					$obj->sent      = 2;
					$obj->sent_date = date("Y-m-d H:i:s");

					if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
					{
						$return_msg[$i]['success'] = 0;
						$return_msg[$i]['msg']     = "Database error";

						return $return_msg;
					}

					continue;
				}

				$toemail_bcc = '';
				$dispatcher  = JDispatcher::getInstance();
				JPluginHelper::importPlugin('system');
				$resp = $dispatcher->trigger('jt_OnBeforeReminderEmail', array($reminder->email));

				if (!empty($resp['0']))
				{
					$toemail_bcc = $resp['0'];
				}

				// $email = $Jticketingmainhelper->jt_sendmail($reminder->email, $reminder->subject, );
				// $email  = $mailer->sendMail($mailfrom, $fromname, $reminder->email, $reminder->subject, $reminder->content, $mode = 1, $toemail_bcc);

				if ($toemail_bcc)
				{
					$bcc_str = explode(",", $toemail_bcc);
				}
				else
				{
					$bcc_str = '';
				}

				$sub   = $reminder->subject;

				// $email = $Jticketingmainhelper->jtsendMail($mailfrom, $fromname, $reminder->email, $sub, $reminder->content, $mode = 1, '', $bcc_str);
				$email = $Jticketingmainhelper->jtsendMail(
				$mailfrom, $fromname, $reminder->email, $sub, $reminder->content,
				$mode = 1, $bcc_str, '', '', $reminder->replytoemail,
				$reminder->replytoemail, ''
				);

				if ($email == 1)
				{
					$return_msg['success'] = 1;
					$obj                   = new StdClass;
					$obj->id               = $reminder->id;
					$obj->sent             = 1;
					$obj->sent_date        = date("Y-m-d H:i:s");

					if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
					{
						$return_msg[$i]['success'] = 0;
						$return_msg[$i]['msg']     = "Database error";

						return $return_msg;
					}

					$return_msg[$i]['success'] = 1;
					$return_msg[$i]['msg']     = "Successfully Sent to " . $reminder->email;

					// Set flag as 1 if date_to_sent is less than above reminder of same order ID
					$query = "";
					$query = "SELECT id from #__jticketing_queue where sent=0
							AND order_id=" . $reminder->order_id . " AND reminder_type='email'
							AND date_to_sent<='" . $reminder->date_to_sent . "'";
					$db->setQuery($query);
					$queueIDS = $db->loadobjectlist();

					if (isset($queueIDS))
					{
						foreach ($queueIDS AS $queueID)
						{
							$obj            = new StdClass;
							$obj->id        = $queueID->id;
							$obj->sent      = 2;
							$obj->sent_date = date("Y-m-d H:i:s");

							if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
							{
								$return_msg[$i]['success'] = 0;
								$return_msg[$i]['msg']     = "Database error";
							}
						}
					}

					$i++;
				}
				else
				{
					// If email not sent set it as delayed
					$obj            = new StdClass;
					$obj->id        = $reminder->id;
					$obj->sent      = 3;
					$obj->sent_date = date("Y-m-d H:i:s");

					if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
					{
						$return_msg[$i]['success'] = 0;
						$return_msg[$i]['msg']     = "Database error";

						return $return_msg;
					}

					$return_msg[$i]['success'] = 0;
					$return_msg[$i]['msg']     = "Failed to sent" . $reminder->email;
					$i++;
				}
			}
		}

		return $return_msg;
	}

	/**
	 * Send SMS Reminders
	 *
	 * @param   string   $enb_batch             enable batch or not
	 * @param   integer  $batch_size_reminders  status to change
	 * @param   integer  $sent_delayed          if message is delayed give it preference
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendSMSReminder($enb_batch, $batch_size_reminders, $sent_delayed = 0)
	{
		$db                   = JFactory::getDBO();
		$Jticketingmainhelper = new Jticketingmainhelper;
		$jteventHelper        = new jteventHelper;
		$return_msg           = array();

		/* Find only latest reminders of sms type for that event suppose 3 reminders of week,day and month
		 * and if email reminder not sent previously or error occured for monthly,weekly then only send one day reminder
		 */

		$input              = JFactory::getApplication()->input;
		$do_not_add_pending = $input->get('do_not_add_pending');

		if (empty($do_not_add_pending))
		{
			// $jteventHelper->addPendingEntriestoQueue();
		}

		$query = "";
		$query = "select queue.*,remtypes.replytoemail
		from #__jticketing_queue AS queue ,#__jticketing_reminder_types AS remtypes
		WHERE queue.reminder_type_id=remtypes.id
		AND  remtypes.state=1 AND queue.sent=" . $sent_delayed . "
		AND queue.reminder_type='sms' AND  DATE(NOW()) = DATE(`date_to_sent`)
		order by date_to_sent desc";

		if ($enb_batch == '1')
		{
			$query .= " LIMIT {$batch_size_reminders}";
		}

		$db->setQuery($query);
		$reminder_ids = $db->loadObjectList();

		if (empty($reminder_ids))
		{
			return array();
		}

		$i = 0;

		foreach ($reminder_ids AS $reminder)
		{
			/*Find all reminder data
			$query = "";
			$query = "SELECT * from #__jticketing_queue where  id=" . $reminder_id->id;
			$db->setQuery($query);
			$reminders = $db->loadObjectList();*/

			// Foreach ($reminders AS $reminder)
			{
				$reminder->content = trim($reminder->content);

				if ($reminder->reminder_type == 'sms' and !empty($reminder->content) and !empty($reminder->mobile_no))
				{
					// Find event start date
					$query = "";
					$query = "SELECT event_details_id from #__jticketing_order where
				status='C' AND id=" . $reminder->order_id;
					$db->setQuery($query);
					$event_integration_id = $db->loadResult($query);

					// If order is deleted dont send reminder
					if (!$event_integration_id)
					{
						continue;
					}

					$query = "";
					$query = "SELECT eventid from #__jticketing_integration_xref where id=" . $event_integration_id;
					$db->setQuery($query);
					$eventid = $db->loadResult($query);

					// If order is deleted dont send reminder
					if (!$eventid)
					{
						continue;
					}

					$eventdetails = $Jticketingmainhelper->getAllEventDetails($eventid);

					// If event is deleted dont send reminder
					if (!$eventdetails)
					{
						continue;
					}

					// If event is unpublished do not send reminder
					if ($eventdetails->event_state != 1)
					{
						continue;
					}

					$today_date = JFactory::getDate();

					// Check if date has not passed
					if (strtotime($eventdetails->startdate) < strtotime($today_date))
					{
						$obj            = new StdClass;
						$obj->id        = $reminder->id;
						$obj->sent      = 2;
						$obj->sent_date = date("Y-m-d H:i:s");

						if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
						{
							$return_msg[$i]['success'] = 0;
							$return_msg[$i]['msg']     = "Database error";

							return $return_msg;
						}

						continue;
					}

					$vars            = new StdClass;
					$vars->mobile_no = trim($reminder->mobile_no);
					$dispatcher      = JDispatcher::getInstance();
					$params          = JComponentHelper::getParams('com_jticketing');

					$smsgateways = $params->get('smsgateways');
					JPluginHelper::importPlugin('tjsms', $smsgateways);
					$res = $dispatcher->trigger($smsgateways . 'send_message', array($reminder->content,$vars));

					if (!empty($res[0]))
					{
						$response = $res[0];
					}

					if (!empty($response))
					{
						$obj            = new StdClass;
						$obj->id        = $reminder->id;
						$obj->sent      = 1;
						$obj->sent_date = date("Y-m-d H:i:s");

						if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
						{
							$return_msg[$i]['success'] = 0;
							$return_msg[$i]['msg']     = "Database error";

							return $return_msg;
						}

						// Set flag as 1 if date_to_sent is less than above reminder of same order ID
						$query = "";
						$query = "SELECT id from #__jticketing_queue where sent=0
						AND order_id=" . $reminder->order_id . "
						AND reminder_type='email' AND date_to_sent<='" . $reminder->date_to_sent . "'";
						$db->setQuery($query);
						$queueIDS = $db->loadobjectlist();

						if (isset($queueIDS))
						{
							foreach ($queueIDS AS $queueID)
							{
								$obj            = new StdClass;
								$obj->id        = $queueID->id;
								$obj->sent      = 2;
								$obj->sent_date = date("Y-m-d H:i:s");

								if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
								{
									$return_msg[$i]['success'] = 0;
									$return_msg[$i]['msg']     = "Database error";
								}
							}
						}

						$return_msg[$i]['success'] = 1;
						$return_msg[$i]['msg']     = "Successfully Sent to " . $vars->mobile_no;
						$i++;
					}
					else
					{
						// If sms not sent set it as delayed
						$obj            = new StdClass;
						$obj->id        = $reminder->id;
						$obj->sent      = 0;
						$obj->sent_date = date("Y-m-d H:i:s");

						if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
						{
							$return_msg[$i]['success'] = 0;
							$return_msg[$i]['msg']     = "Database error";

							return $return_msg;
						}
					}
				}
			}
		}

		return $return_msg;
	}

	/**
	 * function to add data to queue
	 *
	 * @param   object  $reminder  data of reminder
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function addtoQueue($reminder)
	{
		$db                 = JFactory::getDBO();
		$obj                = new StdClass;
		$obj->sent          = $reminder->sent;
		$obj->reminder_type = $reminder->reminder_type;
		$obj->date_to_sent  = $reminder->date_to_sent;
		$obj->subject       = $reminder->subject;
		$obj->content       = $reminder->content;
		$obj->email         = $reminder->email;
		$obj->order_id      = $reminder->order_id;

		if (!empty($reminder->id))
		{
			$obj->id = $reminder->id;

			if (!$db->updateObject('#__jticketing_queue', $obj, 'id'))
			{
			}
		}
		else
		{
			if (!$db->insertObject('#__jticketing_queue', $obj, 'id'))
			{
			}
		}
	}
}
