<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */
defined('_JEXEC') or die(';)');
jimport('joomla.application.component.model');
jimport('joomla.database.table.user');

/**
 * Class for Jticketing Attendee List Model
 *
 * @package  JTicketing
 * @since    1.5
 */
class JticketingModelattendee_List extends JModelLegacy
{
	/**
	 * Constructor
	 *
	 * @since   1.0
	 */
	public function __construct()
	{
		parent::__construct();
		global $mainframe, $option;
		$mainframe  = JFactory::getApplication();
		$input      = JFactory::getApplication()->input;
		$mainframe  = JFactory::getApplication();
		$option     = $input->get('option');
		$limit      = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $input->get('limitstart', '0', 'INT');
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$this->jticketingmainhelper = new jticketingmainhelper;
	}

	/**
	 * Method to get data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getData()
	{
		if (empty($this->_data))
		{
			$query       = $this->_buildQuery();
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_data;
	}

	/**
	 * Method to build query
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function _buildQuery()
	{
		$where = $this->_buildContentWhere();
		$query = $this->jticketingmainhelper->getAttendeesData($where);

		if ($where)
		{
			$query .= $where;
		}

		$query .= " GROUP BY order_items_id";
		global $mainframe, $option;
		$mainframe        = JFactory::getApplication();
		$db               = JFactory::getDBO();
		$filter_order     = '';
		$filter_order_Dir = '';
		$qry1             = '';
		$filter_order     = $mainframe->getUserStateFromRequest($option . 'filter_order', 'filter_order', 'title', 'cmd');
		$filter_order_Dir = $mainframe->getUserStateFromRequest($option . 'filter_order_Dir', 'filter_order_Dir', 'desc', 'word');

		if ($filter_order)
		{
			$qry1 = "SHOW COLUMNS FROM #__jticketing_order";

			if ($qry1)
			{
				$db->setQuery($qry1);
				$exists1 = $db->loadobjectlist();

				foreach ($exists1 as $key1 => $value1)
				{
					$allowed_fields[] = $value1->Field;
				}

				if (in_array($filter_order, $allowed_fields))
				{
					$query .= " ORDER BY ordertbl.$filter_order $filter_order_Dir";
				}
			}
		}

		return $query;
	}

	/**
	 * Method to build where content
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function _buildContentWhere()
	{
		$user = JFactory::getUser();
		global $mainframe, $option;
		$integration              = $this->jticketingmainhelper->getIntegration();
		$input                    = JFactory::getApplication()->input;
		$mainframe                = JFactory::getApplication();
		$option                   = $input->get('option');
		$search_event = $search_event_list = $mainframe->getUserStateFromRequest($option . 'search_event_list', 'search_event_list', '', 'string');
		$search_paymentStatuslist = $mainframe->getUserStateFromRequest($option . 'search_paymentStatuslist', 'search_paymentStatuslist', '', 'string');

		if (!empty($search_event))
		{
			$eventid = JString::strtolower($search_event);
		}

		if (empty($eventid))
		{
			$eventid = JRequest::getInt('event');
		}

		$where = "";

		// IF Event Filter Selected
		if ($eventid)
		{
			$event_refid = $this->jticketingmainhelper->getEventrefid($eventid);

			if ($event_refid)
			{
				$where .= "  AND ordertbl.event_details_id =" . $event_refid;
			}
		}
		else
		{
			$eventlist = $this->jticketingmainhelper->geteventnamesByCreator($user->id);

			if (!empty($eventlist))
			{
				$intxrefidevidarr = '';

				foreach ($eventlist as $key => $event)
				{
					$intxrefidevid1 = '';
					$intxrefidevid1 = $this->jticketingmainhelper->getEventrefid($event->id);

					if ($intxrefidevid1)
					{
						$intxrefidevidarr[] = $intxrefidevid1;
					}
				}

				$intxrefidevid2 = implode("','", $intxrefidevidarr);
				$where .= "  AND ordertbl.event_details_id IN  ('" . $intxrefidevid2 . "')";
			}
		}

		if ($search_paymentStatuslist)
		{
			$where .= "  AND ordertbl.status LIKE '" . $search_paymentStatuslist . "'";
		}

		if ($integration == 1)
		{
			$where .= "  AND b.creator=" . $user->id;
		}

		if ($integration == 2)
		{
			$where .= "  AND b.created_by=" . $user->id;
		}

		if ($integration == 3)
		{
			$where .= "  AND ev.created_by=" . $user->id;
		}

		if ($integration == 4)
		{
			$where .= "  AND evntstbl.creator_uid=" . $user->id;
		}

		if ($where)
		{
			return $where;
		}
		else
		{
			return '';
		}
	}

	/**
	 * Method to get total records
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTotal()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_total))
		{
			$query        = $this->_buildQuery();
			$this->_total = $this->_getListCount($query);
		}

		return $this->_total;
	}

	/**
	 * Method to get pagination
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getPagination()
	{
		// Lets load the content if it doesn’t already exist
		if (empty($this->_pagination))
		{
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_pagination;
	}

	/**
	 * Method to get eventname
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventName()
	{
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$input     = JFactory::getApplication()->input;
		$mainframe = JFactory::getApplication();
		$option    = $input->get('option');
		$eventid   = $input->get('event_list', '', 'INT');
		$query     = $this->jticketingmainhelper->getEventName($eventid);
		$this->_db->setQuery($query);
		$this->_data = $this->_db->loadResult();

		return $this->_data;
	}

	/**
	 * Method to get customer name
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getCustomerNote()
	{
		$input       = JFactory::getApplication()->input;
		$attendee_id = $input->get('attendee_id', '', 'INT');

		if (!$attendee_id)
		{
			return false;
		}

		$query = "SELECT o.customer_note
		FROM #__jticketing_order as o
		LEFT JOIN #__jticketing_order_items as oi ON oi.order_id = o.id
		WHERE oi.attendee_id=" . $attendee_id;
		$this->_db->setQuery($query);

		return $this->_db->loadResult();
	}

	/**
	 * Clear session
	 *
	 * @param   ARRAY  $items      array of items
	 * @param   int    $state      publish/unpublish
	 * @param   int    $trackData  array of online event tracking data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function setItemState_checkin($items, $state, $trackData = '')
	{
		$db = JFactory::getDBO();
		$jticketingmainhelper = new jticketingmainhelper;
		$eventId = is_array($trackData) ? $eventObj['event_id'] : $trackData;
		$eventdata = $jticketingmainhelper->getAllEventDetails($eventId);
		$multipleday = $jticketingmainhelper->isMultidayEvent($eventdata);

		if (is_array($items))
		{
			foreach ($items as $id)
			{
				$multidayflag = 0;
				$query = "SELECT ticketid,checkin FROM #__jticketing_checkindetails  WHERE  ticketid=" . $id;
				$db->setQuery($query);
				$checkin_data = $db->loadObject();
				$query        = "SELECT a.status,a.id,a.name,a.email,a.event_details_id,b.attendee_id,
								a.user_id,b.attendee_id FROM #__jticketing_order AS a,#__jticketing_order_items AS b
								WHERE a.id=b.order_id AND  b.id=$id";
				$db->setQuery($query);
				$result                  = $db->loadObject();

				if ($result->status != 'C')
				{
					continue;
				}

				$restype                 = new StdClass;
				$restype->ticketid       = $id;
				$restype->checkintime    = date('Y-m-d H:i:s');
				$restype->checkin        = $state;
				$restype->eventid        = $result->event_details_id;
				$restype->attendee_id    = $result->user_id;
				$restype->attendee_name  = $result->name;
				$restype->attendee_email = $result->email;

				if (!empty($checkin_data))
				{
					if ($multipleday == 1)
					{
						$multidayflag = 1;

						if (!$db->insertObject('#__jticketing_checkindetails', $restype, 'ticketid'))
						{
						}
					}
					elseif (!$db->updateObject('#__jticketing_checkindetails', $restype, 'ticketid'))
					{
					}
				}
				else
				{
					if (!$db->insertObject('#__jticketing_checkindetails', $restype, 'ticketid'))
					{
					}
				}

				// Now UPDATE INTEGRATIONXREF TABLE FOR CHECKIN COUNT
				if ($result->event_details_id)
				{
					if ($state == 1)
					{
						$query = "SELECT ticketid,checkin FROM #__jticketing_checkindetails  WHERE checkin=1 AND  ticketid=" . $id;
						$db->setQuery($query);
						$checkin_data_array = $db->loadAssoclist();

						// If multi day event and already done chekin do not increase checkin count for same ticket and event
						// if (!empty($checkin_data_array) and count($checkin_data_array)<=1)
						{
							$query = "UPDATE #__jticketing_integration_xref SET checkin=checkin+1  WHERE id=" . $result->event_details_id;
						}
					}
					else
					{
						$query = "UPDATE #__jticketing_integration_xref SET checkin=checkin-1 WHERE checkin>0 AND id=" . $result->event_details_id;
					}

					$db->setQuery($query);
					$db->execute();
				}

				if ($state == 1)
				{
					$com_params           = JComponentHelper::getParams('com_jticketing');
					$socialintegration    = $com_params->get('integrate_with', 'none');
					$streamCheckinTicket  = $com_params->get('streamCheckinTicket', 0);

					if (isset($result->user_id))
					{
						$actor_id = $result->user_id;
					}
					else
					{
						$actor_id = $user->id;
					}

					$jteventHelper        = new jteventHelper;

					if ($socialintegration != 'none' and !empty($result->user_id))
					{
						// Add in activity.
						if ($streamCheckinTicket == 1)
						{
							$libclass    = $jteventHelper->getJticketSocialLibObj();
							$action      = 'streamCheckinTicket';
							$orderinfo   = $jticketingmainhelper->getorderinfo($result->id);
							$eventLink   = '<a class="" href="' . $orderinfo['eventinfo']->event_url . '">' . $orderinfo['eventinfo']->summary . '</a>';
							$collect_attendee_info = $com_params->get('collect_attendee_info_checkout', '0');

							if ($result->attendee_id and $collect_attendee_info)
							{
								$field_array = array(
									'first_name',
									'last_name',
								);

								// Get Attendee Details
								$attendee_details = $jticketingmainhelper->getAttendees_details($result->attendee_id, $field_array);

								if (isset($attendee_details['first_name']))
								{
									$buyername = implode(" ", $attendee_details);
								}
								else
								{
									$db = JFactory::getDBO();

									// If collect attendee info is set  to no in backend then take first and last name from billing info.
									if ($result->id)
									{
										$query = "SELECT firstname,lastname FROM #__jticketing_users WHERE order_id=" . $result->id;
										$db->setQuery($query);
										$attname = $db->loadObject();
										$buyername = $attname->firstname . ' ' . $attname->lastname;
									}
								}

								$originalMsg = JText::sprintf('COM_JTICKETING_CHECKIN_SUCCESS_ACT_NAME', $buyername, $eventLink);
							}
							else
							{
								$originalMsg = JText::sprintf('COM_JTICKETING_CHECKIN_SUCCESS_ACT', $eventLink);
							}

							$libclass->pushActivity($actor_id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
						}
					}
				}

				$this->onAfterEventAttendance($result, $state, $trackData);
			}
		}

		return 1;
	}

	/**
	 * This function used to return formated event data
	 *
	 * @param   ARRAY  $result     array of user order details
	 * @param   int    $state      attendee stata
	 * @param   ARRAY  $trackData  online event tracking data
	 *
	 * @return  on success, return event tracking data
	 *
	 * @since   1.0
	 */
	public function onAfterEventAttendance($result, $state, $trackData = '')
	{
		if (empty($trackData))
		{
			$trackData = array();
			$jticketingMainHelper = new Jticketingmainhelper;
			$eventDetails = $jticketingMainHelper->getAllEventDetails($result->event_details_id);
			$trackData['user_id'] = $result->user_id;
			$trackData['event_id'] = $result->event_details_id;
			$trackData['completed'] = $result->status == 'C' ? 1 : 0;
			$trackData['state'] = $state;
			$trackData['spent_time'] = strtotime($eventDetails->enddate) - strtotime($eventDetails->startdate);
		}

		JPluginHelper::importPlugin('tjevent');
		$dispatcher = JDispatcher::getInstance();
		$result = $dispatcher->trigger('on_AttendanceEvent', array($trackData));

		return $trackData;
	}
}
