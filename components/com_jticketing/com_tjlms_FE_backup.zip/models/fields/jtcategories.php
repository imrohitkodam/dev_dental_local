<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

defined('JPATH_BASE') or die;
JFormHelper::loadFieldClass('list');

/**
 * getting html list of categories
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JFormFieldJtcategories extends JFormFieldList
{
	/**
	 * The form field type.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $type = 'jtcategories';

	/**
	 * Method to get a list of options for a list input.
	 *
	 * @return	array		An array of JHtml options.
	 *
	 * @since   11.4
	 */
	protected function getOptions()
	{
		$app  = JFactory::getApplication();
		$params         = JComponentHelper::getParams('com_jticketing');
		$integration = $params->get('integration');

		// Native Event Manager.
		if($integration<1)
		{
		?>
			<div class="alert alert-info alert-help-inline">
		<?php echo JText::_('COMJTICKETING_INTEGRATION_NOTICE');
		?>
			</div>
		<?php
			return false;
		}

		$helperPath               = JPATH_ROOT . '/components/com_jticketing/helpers/event.php';
		$options = array();

		if (!class_exists('jteventHelper'))
		{
			JLoader::register('jteventHelper', $helperPath);
			JLoader::load('jteventHelper');
		}

		$defoptions[] = JHtml::_('select.option', "0",JText::_('COMJTICKETING_CATEGORY_SELECT_ALL'));

		$jteventHelper = new jteventHelper;
		$options = $jteventHelper->getEventCategories();
		$options = array_merge($defoptions, $options);

		return $options;
	}
}
