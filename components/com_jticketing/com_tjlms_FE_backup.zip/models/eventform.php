<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.modelform');
jimport('joomla.event.dispatcher');

require_once JPATH_SITE . "/components/com_tjfields/filterFields.php";
/**
 * model for showing order
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */
class JticketingModelEventForm extends JModelForm
{
	use TjfieldsFilterField;

	/**
	 * Method to auto-populate the model state.
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	protected function populateState()
	{
		$app = JFactory::getApplication('com_jticketing');

		// Load state from the request userState on edit or from the passed variable on default
		if (JFactory::getApplication()->input->get('layout') == 'edit')
		{
			$id = JFactory::getApplication()->getUserState('com_jticketing.edit.event.id');
		}
		else
		{
			$id = JFactory::getApplication()->input->get('id');
			JFactory::getApplication()->setUserState('com_jticketing.edit.event.id', $id);
		}

		$this->setState('event.id', $id);

		// Load the parameters.
		$params       = $app->getParams();
		$params_array = $params->toArray();

		if (isset($params_array['item_id']))
		{
			$this->setState('event.id', $params_array['item_id']);
		}

		$this->setState('params', $params);
	}

	/**
	 * Method to get data
	 *
	 * @param   integer  $id  The id of the object to get.
	 *
	 * @return  mixed  Object on success, false on failure.
	 *
	 * @since   1.0
	 */
	public function getData($id = null)
	{
		if (empty($this->_item))
		{
			$this->_item = false;

			if (empty($id))
			{
				$id = $this->getState('event.id');
			}

			// Get a level row instance.
			$table = $this->getTable();

			// Attempt to load the row.
			if ($table->load($id))
			{
				$user    = JFactory::getUser();
				$id      = $table->id;
				$canEdit = $user->authorise('core.edit', 'com_jticketing') || $user->authorise('core.create', 'com_jticketing');

				if (!$canEdit && $user->authorise('core.edit.own', 'com_jticketing'))
				{
					$canEdit = $user->id == $table->created_by;
				}

				if (!$canEdit)
				{
					JError::raiseWarning('', JText::_('JERROR_ALERTNOAUTHOR'));
				}

				// Check state state.
				if ($state = $this->getState('filter.state'))
				{
					if ($table->state != $state)
					{
						return $this->_item;
					}
				}

				// Convert the JTable to a clean JObject.
				$properties  = $table->getProperties(1);
				$this->_item = JArrayHelper::toObject($properties, 'JObject');
			}
			elseif ($error = $table->getError())
			{
				$this->setError($error);
			}
		}

		return $this->_item;
	}

	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param   string  $type    The table type to instantiate
	 * @param   string  $prefix  A prefix for the table class name. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getTable($type = 'Event', $prefix = 'JticketingTable', $config = array())
	{
		$this->addTablePath(JPATH_COMPONENT_ADMINISTRATOR . '/tables');

		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to check in an item.
	 *
	 * @param   integer  $id  The id of the row to check out.
	 *
	 * @return  boolean  True on success, false on failure.
	 *
	 * @since	1.6
	 */
	public function checkin($id = null)
	{
		// Get the id.
		$id = (!empty($id)) ? $id : (int) $this->getState('event.id');

		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Attempt to check the row in.
			if (method_exists($table, 'checkin'))
			{
				if (!$table->checkin($id))
				{
					$this->setError($table->getError());

					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to check in an item.
	 *
	 * @param   integer  $id  The id of the row to check out.
	 *
	 * @return  boolean  True on success, false on failure.
	 *
	 * @since	1.6
	 */
	public function checkout($id = null)
	{
		// Get the user id.
		$id = (!empty($id)) ? $id : (int) $this->getState('event.id');

		if ($id)
		{
			// Initialise the table
			$table = $this->getTable();

			// Get the current user object.
			$user = JFactory::getUser();

			// Attempt to check the row out.
			if (method_exists($table, 'checkout'))
			{
				if (!$table->checkout($user->get('id'), $id))
				{
					$this->setError($table->getError());

					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   string  $data      An optional array of data for the form to interogate.
	 * @param   string  $loadData  True if the form is to load its own data (default case), false if not.
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_jticketing.event', 'eventform', array('control' => 'jform', 'load_data' => $loadData));

		if (empty($form))
		{
			return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return	mixed	The data for the form.
	 *
	 * @since	1.6
	 */
	protected function loadFormData()
	{
		$data = JFactory::getApplication()->getUserState('com_jticketing.edit.event.data', array());

		if (empty($data))
		{
			$data = $this->getData();
		}

		return $data;
	}

	/**
	 * Method to save form
	 *
	 * @param   string  $data              An optional array of data for the form to interogate.
	 * @param   string  $extra_jform_data  True if the form is to load its own data (default case), false if not.
	 * @param   string  $post              post data
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function save($data, $extra_jform_data, $post)
	{
		$id                   = (!empty($data['id'])) ? $data['id'] : (int) $this->getState('event.id');
		$state                = (!empty($data['state'])) ? 1 : 0;
		$user                 = JFactory::getUser();
		$app                  = JFactory::getApplication();
		$com_params           = $app->getParams('com_jticketing');
		$jticketingmainhelper = new jticketingmainhelper;

		// Add booking time as end of the day
		$tempEndDate        = new DateTime($data['booking_end_date']);
		$tempEndDate->setTime(23, 59, 59);
		$data['booking_end_date']       = $tempEndDate->format('Y-m-d H:i:s');

		if ($id)
		{
			// Check the user can edit this item.
			$authorised = $user->authorise('core.edit', 'com_jticketing') || $authorised = $user->authorise('core.edit.own', 'com_jticketing');

			// The user cannot edit the state of the item.
			if ($user->authorise('core.edit.state', 'com_jticketing') !== true && $state == 1)
			{
				$data['state'] = 0;
			}
		}
		else
		{
			// Check the user can create new items in this section.
			$authorised = $user->authorise('core.create', 'com_jticketing');

			// The user cannot edit the state of the item.
			if ($user->authorise('core.edit.state', 'com_jticketing') !== true && $state == 1)
			{
				$data['state'] = 0;
			}

			// For new record, Add created time.
			$data['created'] = date('Y-m-d H:i:s');
		}

		if ($authorised !== true)
		{
			JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		// Tweak for image file upload.
		// Store uploaded file path in a temp variable.
		$tempImage = $data['image'];

		// Unset image file index from data array.
		unset($data['image']);

		// End by komal
		// $data['jt_params']['online_provider'] = $data['online_provider'];
		$data['jt_params']['event_url'] = $post->get('event_url', '', 'STRING');
		$data['jt_params']['event_sco_id'] = $post->get('event_sco_id', '', 'INT');
		$data['jt_params'] = json_encode($data['jt_params']);

		$table = $this->getTable();

		// Clean Data like date fields convert to database format
		$data = $this->CleanEventData($data);

		if ($table->save($data) === true)
		{
			// Save event id into integration xref table.
			$obj                      = new stdclass;
			$obj->userid              = $user->id;
			$obj->eventid             = $table->id;
			$obj->source              = 'com_jticketing';
			$obj->paypal_email        = $post->get('paypal_email', '', 'STRING');
			$jticketingfrontendhelper = new jticketingfrontendhelper;
			$XrefId                   = $jticketingfrontendhelper->getXreftableID($obj->source, $obj->eventid);
			$db                       = JFactory::getDBO();

			if (!$id)
			{
				if (!$db->insertObject('#__jticketing_integration_xref', $obj, 'id'))
				{
					echo $db->stderr();

					return false;
				}
			}
			else
			{
				$obj->id = $XrefId;

				if (!$db->updateObject('#__jticketing_integration_xref', $obj, 'id'))
				{
					echo $db->stderr();

					return false;
				}
			}

			$XrefId = $obj->id;

			$content_id = $data['id'];

			$extra_field_data = array();
			$extra_field_data['content_id'] = $content_id;
			$extra_field_data['client'] = 'com_jticketing.event';
			$extra_field_data['fieldsvalue'] = $extra_jform_data;

			// Save extra fields data.
			$this->saveExtraFields($extra_field_data, $table->id);

			// Save ticket types.
			$this->saveTicketTypes($post, $table->id);
			$this->collect_attendee_info_checkout = $com_params->get('collect_attendee_info_checkout');

			// Save Custom Attendee Fields
			if ($this->collect_attendee_info_checkout)
			{
				$ticket_fields = $post->get('ticket_field', '', 'ARRAY');
				$jteventHelper = new jteventHelper;
				$ticket_obj    = $jteventHelper->saveCustomAttendee_fields($ticket_fields, $table->id, $user->id);
			}

			// Restore the unsetted image file index from data array.
			$data['image'] = $tempImage;

			// Save uploaded image.
			$jticketingMediaHelper = new jticketingMediaHelper;
			$uploadSuccess         = $jticketingMediaHelper->uploadEventImage($table->id);

			if (!$uploadSuccess)
			{
				return false;
			}

			$jteventHelper = new jteventHelper;
			$jteventHelper->updatePaypalEmail($user->id, $obj->paypal_email);

			if ($id)
			{
				$ev_xref_id = $jticketingmainhelper->getEventrefid($id);
			}

			$socialintegration = $com_params->get('integrate_with', 'none');
			$streamAddEvent    = $com_params->get('streamAddEvent', 0);

			if ($socialintegration != 'none')
			{
				$user     = JFactory::getUser();
				$libclass = $jteventHelper->getJticketSocialLibObj();

				// Add in activity.
				if ($streamAddEvent and $table->id)
				{
					$action      = 'addevent';
					$link        = JUri::root() . substr(JRoute::_('index.php?option=com_jticketing&view=event&id=' . $table->id), strlen(JUri::base(true)) + 1);
					$eventLink   = '<a class="" href="' . $link . '">' . $data['title'] . '</a>';
					$originalMsg = JText::sprintf('COM_JTICKETING_ACTIVITY_ADD_EVENT', $eventLink);
					$libclass->pushActivity($user->id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
				}
			}

			return $id;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Method to save form
	 *
	 * @param   string  $data  An optional array of data for the form to interogate.
	 *
	 * @return	JForm	A JForm object on success, false on failure
	 *
	 * @since   1.0
	 */
	public function delete($data)
	{
		$id = (!empty($data['id'])) ? $data['id'] : (int) $this->getState('event.id');

		if (JFactory::getUser()->authorise('core.delete', 'com_jticketing') !== true)
		{
			JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));

			return false;
		}

		$table = $this->getTable();

		if ($table->delete($data['id']) === true)
		{
			return $id;
		}
		else
		{
			return false;
		}

		return true;
	}

	/**
	 * Method to save form
	 *
	 * @param   string  $post     post values
	 * @param   int     $eventid  id of event
	 *
	 * @return	void
	 *
	 * @since   1.0
	 */
	public function saveTicketTypes($post, $eventid = '')
	{
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$integrationID = $jticketingfrontendhelper->getIntegrationID($eventid, $client = 'com_jticketing');

		if ($eventid)
		{
			$tickettype = $jticketingfrontendhelper->getTicketTypes($integrationID);

			$tickettypesIds     = array();
			$ticket_type_count1 = array();

			foreach ($tickettype as $key => $value)
			{
				$tickettypesIds[$key] = $tickettype[$key]->id;
			}

			$ids        = $post->get('ticket_type_id', '', 'ARRAY');
			$delete_ids = array_diff($tickettypesIds, $ids);
			$obj         = $jticketingfrontendhelper->deleteTicket($delete_ids);
			$tickettype1 = $jticketingfrontendhelper->getTicketTypes($integrationID);

			foreach ($tickettype1 as $key => $value)
			{
				$ticket_type_count1[] = (int) ($tickettype1[$key]->available - $tickettype1[$key]->count);
			}

			$post->set('ticket_type_count', $ticket_type_count1);
		}

		$user   = JFactory::getUser();
		$userid = $user->id;

		if ($eventid)
		{
			$editflag = 1;
		}

		if (!$userid)
		{
			$userid = 0;

			return false;
		}

		$objtopass = new stdClass;

		if ($eventid)
		{
			$ticket_obj = $jticketingfrontendhelper->createTicketTypeObj($post, $integrationID);
		}
	}

	/**
	 * Method to validate the extraform data.
	 *
	 * @param   array  $data  The form to validate against.
	 *
	 * @return  mixed  Array of filtered data if valid, false otherwise.
	 *
	 * @see     JFormRule
	 * @see     JFilterInput
	 * @since   12.2
	 */
	public function CleanEventData($data)
	{
		$startdate_timestamp = strtotime($data['startdate']);
		$data['startdate']   = date('Y-m-d H:i:s', $startdate_timestamp);

		$enddate_timestamp = strtotime($data['enddate']);
		$data['enddate']   = date('Y-m-d H:i:s', $enddate_timestamp);

		$booking_start_date_timtestamp = strtotime($data['booking_start_date']);
		$data['booking_start_date']    = date('Y-m-d H:i:s', $booking_start_date_timtestamp);

		$booking_end_date_timtestamp = strtotime($data['booking_end_date']);
		$data['booking_end_date']    = date('Y-m-d H:i:s', $booking_end_date_timtestamp);

		return $data;
	}

	/**
	 * Method to get book venue
	 *
	 * @param   array  $array_venue  An array to get the booked values
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function bookVenue($array_venue)
	{
		$venue = $array_venue['venue'];
		$array_venue['start_dt_timestamp'];
		$array_venue['end_dt_timestamp'];
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query = "SELECT  v.id,v.name FROM   #__jticketing_venues AS v
		WHERE NOT EXISTS(SELECT NULL FROM #__jticketing_events AS ed WHERE ed.venue = v.id AND(('"
		. $array_venue["start_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
		. $array_venue["end_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
		. $array_venue["start_dt_timestamp"] . "' <= UNIX_TIMESTAMP(ed.startdate) AND '"
		. $array_venue["end_dt_timestamp"] . "' >= UNIX_TIMESTAMP(ed.enddate))
		 ))";
		$db->setQuery($query);
		$events = $db->loadObjectList();

		return $events;

		/*$events = $db->loadColumn();
		if (in_array($venue, $events))
		{
			return true;
		}
		else
		{
			return false;
		}*/
	}

	/**
	 * This is used to get venue name
	 *
	 * @param   int  $id  order id
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getVenue($id)
	{
		$db = JFactory::getDBO();
		$sql = "SELECT params FROM #__jticketing_venues WHERE #__jticketing_venues.id =" . $id;
		$db->setQuery($sql);
		$venueName = $db->loadResult();

		return $venueName;
	}

	/**
	 * Method to get book venue
	 *
	 * @param   array  $event  An array to get the item values
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getvenuehtml($event)
	{
		$array_venue = array();
		$db = JFactory::getDbo();
		$selectedvenue = $event->venue;

		$array_venue['venue'] = $selectedvenue;

		$array_venue['start_dt_timestamp'] = $event->startdate;
		$array_venue['end_dt_timestamp'] = $event->enddate;
		$array_venue['event_online'] = $event->online_events;
		$array_venue['created_by'] = $event->created_by;

		$getvenue = $this->getAvailableVenue($array_venue);
		$options = array();

		foreach ($getvenue as $u)
		{
			$options[] = JHtml::_('select.option', $u->id, $u->name);
		}

		return JHtml::_('select.genericlist', $options, $u->name, 'class="inputbox"  size="5"', 'value', 'text', $selectedvenue);
	}

	/**
	 * Method to get book venue
	 *
	 * @param   array  $array_venue  An array to get the booked values
	 *
	 * @return	void
	 *
	 * @since	1.6
	 */
	public function getAvailableVenue($array_venue)
	{
		$db = JFactory::getDbo();
		$jinput = JFactory::getApplication()->input;
		$eventid = $jinput->get('id', '', 'STRING');

		$venue = $array_venue['venue'];
		$array_venue['start_dt_timestamp'];
		$array_venue['end_dt_timestamp'];
		$array_venue['event_online'];
		$created_by = $array_venue['created_by'];
		$query = $db->getQuery(true);

		if (!empty($eventid))
		{
		$query = "SELECT  v.id,v.name,v.created_by,v.privacy,v.state FROM   #__jticketing_venues AS v
			WHERE NOT EXISTS(SELECT NULL FROM #__jticketing_events AS ed WHERE ed.venue = v.id AND(('"
		. $array_venue["start_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
		. $array_venue["end_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
		. $array_venue["start_dt_timestamp"] . "' <= UNIX_TIMESTAMP(ed.startdate) AND '"
		. $array_venue["end_dt_timestamp"] . "' >= UNIX_TIMESTAMP(ed.enddate))
		 )) AND v.online = "
		. $array_venue['event_online'] . " AND v.state = 1 AND (v.created_by ='"
		. $created_by . "' OR v.privacy = 1) AND v.id != '" . $eventid . "'";
		}
		else
		{
			$query = "SELECT  v.id,v.name,v.created_by,v.privacy,v.state FROM   #__jticketing_venues AS v
			WHERE NOT EXISTS(SELECT NULL FROM #__jticketing_events AS ed WHERE ed.venue = v.id AND(('"
		. $array_venue["start_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
		. $array_venue["end_dt_timestamp"] . "' BETWEEN UNIX_TIMESTAMP(ed.startdate) AND UNIX_TIMESTAMP(ed.enddate)) OR ('"
		. $array_venue["start_dt_timestamp"] . "' <= UNIX_TIMESTAMP(ed.startdate) AND '"
		. $array_venue["end_dt_timestamp"] . "' >= UNIX_TIMESTAMP(ed.enddate))
		 )) AND v.online = " . $array_venue['event_online'] . " AND v.state = 1 AND (v.created_by ='" . $created_by . "' OR v.privacy = 1)";
		}

		$db->setQuery($query);
		$events = $db->loadObjectList();

		return $events;
	}
}
