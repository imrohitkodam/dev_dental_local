<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2015 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die(';)');
jimport('joomla.application.component.model');
jimport('joomla.database.table.user');

/**
 * Model for post processing payment
 *
 * @package     JTicketing
 * @subpackage  component
 * @since       1.0
 */

class JticketingModelpayment extends JModelLegacy
{
	/**
	 * Constructor
	 *
	 * @since   1.0
	 */
	public function __construct()
	{
		parent::__construct();

		$TjGeoHelper = JPATH_ROOT . DS . 'components/com_tjfields/helpers/geo.php';

		if (!class_exists('TjGeoHelper'))
		{
			JLoader::register('TjGeoHelper', $TjGeoHelper);
			JLoader::load('TjGeoHelper');
		}

		$this->TjGeoHelper = new TjGeoHelper;
		$this->_db         = JFactory::getDBO();
	}

	/**
	 * Gives payment html from plugin
	 *
	 * @param   string   $pg_plugin  name of plugin like paypal
	 * @param   integer  $oid        id of jticketing_order
	 *
	 * @return  html  payment html
	 *
	 * @since   1.0
	 */
	public function confirmpayment($pg_plugin, $oid)
	{
		$post = JRequest::get('post');
		$vars = $this->getPaymentVars($pg_plugin, $oid);

		if (!empty($post) && !empty($vars))
		{
			if (!empty($result))
			{
				$vars = $result[0];
			}

			JPluginHelper::importPlugin('payment', $pg_plugin);
			$dispatcher = JDispatcher::getInstance();

			if (isset($vars->is_recurring) and $vars->is_recurring == 1)
			{
				$result = $dispatcher->trigger('onTP_ProcessSubmitRecurring', array($post, $vars));
			}
			else
			{
				$result = $dispatcher->trigger('onTP_ProcessSubmit', array($post, $vars));
			}
		}
		else
		{
			JFactory::getApplication()->enqueueMessage(JText::_('SOME_ERROR_OCCURRED'), 'error');
		}
	}

	/**
	 * Gives vars to be used in plugin by parsing them in plugin structure
	 *
	 * @param   string   $pg_plugin  name of plugin like paypal
	 * @param   integer  $orderid    id of jticketing_order
	 *
	 * @return  html  payment html
	 *
	 * @since   1.0
	 */
	public function getPaymentVars($pg_plugin, $orderid)
	{
		$db                   = JFactory::getDBO();
		$jticketingmainhelper = new jticketingmainhelper;
		$params               = JComponentHelper::getParams('com_jticketing');
		$siteadmin_comm_per   = $params->get('siteadmin_comm_per');
		$gateways             = $params->get('gateways');
		$handle_transactions  = $params->get('handle_transactions');
		$session              = JFactory::getSession();
		$orderItemid          = $jticketingmainhelper->getItemId('index.php?option=com_jticketing&view=orders');
		$chkoutItemid         = $jticketingmainhelper->getItemId('index.php?option=com_jticketing&view=buy');

		// Append prefix and order_id
		$pass_data      = $this->getdetails($orderid);
		$vars           = new stdClass;
		$vars->order_id = $pass_data->order_id;
		$vars->user_id  = $pass_data->user_id;

		if (isset($pass_data->firstname))
		{
			$vars->user_firstname = $pass_data->firstname;
		}

		if (isset($pass_data->lastname))
		{
			$vars->user_lastname = $pass_data->lastname;
		}

		if (isset($pass_data->address))
		{
			$vars->user_address = $pass_data->address;
		}

		if (isset($pass_data->user_email))
		{
			$vars->user_email = $pass_data->user_email;
		}

		if (isset($pass_data->user_city))
		{
			$vars->user_city = $pass_data->user_city;
		}

		if (isset($pass_data->user_zip))
		{
			$vars->user_zip = $pass_data->user_zip;
		}

		if (isset($pass_data->phone))
		{
			$vars->phone = $pass_data->phone;
		}

		$guest_email = '';

		if (!$pass_data->user_id && $params->get('allow_buy_guest'))
		{
			$guest_email = "&email=" . md5($pass_data->user_email);
		}

		$vars->item_name = $pass_data->order_item_name;
		$submiturl       = "index.php?option=com_jticketing&task=payment.confirmpayment&processor={$pg_plugin}";
		$vars->submiturl = JRoute::_($submiturl, false);
		$return_url      = "index.php?option=com_jticketing&view=orders&layout=order";
		$return_url .= $guest_email . "&orderid=" . $pass_data->order_id . "&processor={$pg_plugin}&Itemid=" . $orderItemid;
		$vars->return        = JURI::root() . substr(JRoute::_($return_url, false), strlen(JURI::base(true)) + 1);
		$cancel_return       = "index.php?option=com_jticketing&view=buy&layout=cancel&processor={$pg_plugin}&Itemid=" . $chkoutItemid;
		$vars->cancel_return = JURI::root() . substr(JRoute::_($cancel_return, false), strlen(JURI::base(true)) + 1);
		$url                 = JURI::root() . "index.php?option=com_jticketing&task=payment.processpayment" . $guest_email;
		$url .= "&processor=" . $pg_plugin . "&order_id=" . $pass_data->order_id;
		$vars->url           = $vars->notify_url = JRoute::_($url, false);
		$vars->currency_code = $pass_data->currency;
		$vars->comment       = $pass_data->customer_note;
		$vars->amount        = $pass_data->order_amt;

		if ($pass_data->fee > 0)
		{
			$session->set("JT_fee", $pass_data->fee);
		}

		$res     = new stdClass;
		$res->id = $orderid;

		if ($pass_data->processor == 'paypal' and $handle_transactions == 1)
		{
			$vars->business = $this->getEventownerEmail($orderid);
			$res->fee       = 0;
		}
		else
		{
			$res->fee = $session->get("JT_fee");
		}

		if (!$db->updateObject('#__jticketing_order', $res, 'id'))
		{
		}

		$vars->userInfo = $this->userInfo($orderid);

		if (isset($vars->userInfo->country))
		{
			$vars->country_code = $vars->userInfo->country;
		}

		if (isset($vars->userInfo->state))
		{
			$vars->state_code = $vars->userInfo->state;
		}

		// For Adpative payment
		$jticketingModelpayment     = new jticketingModelpayment;
		$vars->adaptiveReceiverList = $jticketingModelpayment->getReceiverList($vars, $pg_plugin, $orderid);

		// Get event owner: For stripe
		$eventid     = $jticketingmainhelper->getEventID_from_OrderID($orderid);
		$vars->owner = $jticketingmainhelper->getEventCreator($eventid);
		$vars->bootstrapVersion = $params->get("currentBSViews");

		// Get commision amount
		$vars->commision = $jticketingmainhelper->getTransactionFee($orderid);
		$vars->client    = "jticketing";

		return $vars;
	}

	/**
	 * Get billing details
	 *
	 * @param   integer  $orderid  id of jticketing_order table
	 *
	 * @return  array  $billDetails  billing details
	 *
	 * @since   1.0
	 */
	public function userInfo($orderid)
	{
		$user  = JFactory::getUser();
		$db    = JFactory::getDBO();
		$query = "Select `user_id`,`user_email`,`firstname`,`lastname`,`country_code`,
		`state_code`,`address`,`city`,`phone`,`zipcode`
		 FROM #__jticketing_users WHERE order_id=" . $orderid . '
		 ORDER BY `id` DESC';
		$db->setQuery($query);
		$billDetails = $db->loadAssoc();

		// Make address in 2 lines
		if (isset($billDetails['country_code']))
		{
			$billDetails['country_code'] = $this->TjGeoHelper->getCountryNameFromId($billDetails['country_code']);
		}

		if (isset($billDetails['state_code']))
		{
			$billDetails['state_code'] = $this->TjGeoHelper->getRegionNameFromId($billDetails['state_code']);
		}

		$billDetails['add_line2'] = '';
		$remove_character         = array(
			"\n",
			"\r\n",
			"\r"
		);

		$billDetails['add_line1'] = str_replace($remove_character, ' ', $billDetails['address']);

		return $billDetails;
	}

	/**
	 * Changes gateway html when clicked on checkout
	 *
	 * @return  array  $billDetails  biling infor of the payee
	 *
	 * @since   1.0
	 */
	public function changegateway()
	{
		JLoader::import('payment', JPATH_SITE . DS . 'components' . DS . 'com_jticketing' . DS . 'models');
		$db              = JFactory::getDBO();
		$jinput          = JFactory::getApplication()->input;
		$model           = new jticketingModelpayment;
		$selectedGateway = $jinput->get('gateways', '');
		$order_id        = $jinput->get('order_id', '');
		$return          = '';

		if (!empty($selectedGateway) && !empty($order_id))
		{
			$model->updateOrderGateway($selectedGateway, $order_id);
			$payhtml = $model->getHTML($order_id);
		}

		echo $payhtml[0];
		jexit();
	}

	/**
	 * Get payment gateway html from plugin
	 *
	 * @param   integer  $order_id  id of jticketing_order table
	 *
	 * @return  html
	 *
	 * @since   1.0
	 */
	public function getHTML($order_id)
	{
		$pass_data = $this->getdetails($order_id);
		$vars      = $this->getPaymentVars($pass_data->processor, $order_id);
		JPluginHelper::importPlugin('payment', $pass_data->processor);
		$dispatcher = JDispatcher::getInstance();
		$html       = $dispatcher->trigger('onTP_GetHTML', array($vars));

		return $html;
	}

	/**
	 * Get payment gateway html from plugin
	 *
	 * @param   integer  $pg_plugin  id of jticketing_order table
	 *
	 * @param   integer  $order_id   id of jticketing_order table
	 *
	 * @param   integer  $order      id of jticketing_order table
	 *
	 * @return  html
	 *
	 * @since   1.0
	 */
	public function getHTMLS($pg_plugin, $order_id, $order)
	{
		$pass_data = $this->getdetails($order_id);
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->update("#__jticketing_order AS JTO");
		$query->set("JTO.processor = '" . $pg_plugin . "', JTO.status = 'P'");
		$query->where("JTO.order_id= '" . $order . "'");
		$db->setQuery($query);
		$result = $db->execute();

		$vars      = $this->getPaymentVars($pass_data->processor, $order_id);
		JPluginHelper::importPlugin('payment', $pg_plugin);
		$dispatcher = JDispatcher::getInstance();
		$html       = $dispatcher->trigger('onTP_GetHTML', array($vars));

		return $html;
	}

	/**
	 * Get all order details based on id
	 *
	 * @param   integer  $tid  id of jticketing_order table
	 *
	 * @return  array
	 *
	 * @since   1.0
	 */
	public function getdetails($tid)
	{
		$params = JComponentHelper::getParams('com_jticketing');
		$query  = "SELECT ou.firstname,ou.user_email,ou.phone,ou.user_id
				FROM #__jticketing_users as ou
				where ou.order_id=" . $tid . " AND ou.address_type='BT'";
		$this->_db->setQuery($query);
		$orderdetails = $this->_db->loadObjectlist();
		$query        = "SELECT o.fee,o.amount,o.customer_note,o.processor,o.order_id
				FROM #__jticketing_order  as o
				where o.id=" . $tid;
		$this->_db->setQuery($query);
		$orderamt                    = $this->_db->loadObjectlist();
		$orderdetails['0']->order_id = $orderamt[0]->order_id;
		$query                       = "SELECT i.type_id,t.title as order_item_name,sum(i.ticketcount) as ticketcount, t.price
		 FROM #__jticketing_order_items as i JOIN
		 #__jticketing_types as t ON t.id=i.type_id
		 WHERE i.order_id=" . $tid . " GROUP BY i.type_id";
		$this->_db->setQuery($query);
		$orderlist['items'] = $this->_db->loadObjectList();
		$itemarr            = array();

		foreach ($orderlist['items'] as $item)
		{
			$itemarr[] = $item->order_item_name;
		}

		if ($itemarr[0])
		{
			$itemstring = implode('\n', $itemarr);
		}

		$orderdetails['0']->order_item_name = $itemstring;
		$orderdetails['0']->processor       = $orderamt[0]->processor;
		$orderdetails['0']->order_amt       = $orderamt[0]->amount;
		$orderdetails['0']->fee             = $orderamt[0]->fee;
		$orderdetails['0']->currency        = $params->get('currency');
		$orderdetails['0']->customer_note   = preg_replace('/\<br(\s*)?\/?\>/i', " ", $orderamt[0]->customer_note);

		return $orderdetails['0'];
	}

	/**
	 * Post Processing for order
	 *
	 * @param   string  $post       post data
	 * @param   string  $pg_plugin  payment gateway name
	 * @param   int     $order_id   id of jticketing_order table
	 *
	 * @return  array
	 *
	 * @since   1.0
	 */
	public function processpayment($post, $pg_plugin, $order_id)
	{
		// Trigger Before process Paymemt
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result      = $dispatcher->trigger('jt_OnBeforeProcessPayment', array($post, $order_id, $pg_plugin));
		$session     = JFactory::getSession();
		$com_params  = JComponentHelper::getParams('com_jticketing');
		$currency    = $com_params->get('currency');
		$jinput      = JFactory::getApplication()->input;
		$id          = $order_id;
		$return_resp = array();

		// Authorise Post Data
		if (!empty($post['plugin_payment_method']) && $post['plugin_payment_method'] == 'onsite')
		{
			$plugin_payment_method = $post['plugin_payment_method'];
		}

		$dispatcher     = JDispatcher::getInstance();
		$post['client'] = 'jticketing';
		JPluginHelper::importPlugin('payment', $pg_plugin);
		$data = $dispatcher->trigger('onTP_Processpayment', array($post));
		$data = $data[0];

		// $res  = @$this->storelog($pg_plugin, $data);

		$jticketingmainhelper = new jticketingmainhelper;
		$orderItemid          = $jticketingmainhelper->getItemId('index.php?option=com_jticketing&view=orders');
		$chkoutItemid         = $jticketingmainhelper->getItemId('index.php?option=com_jticketing&view=buy');

		// Get order id
		if (empty($order_id))
		{
			// Here we get order_id in Format JT_JKJKJK_0012
			$order_id = $data['order_id'];
		}

		// Get order_id in format 12
		$id = $jticketingmainhelper->getIDFromOrderID($order_id);

		// Start for guest checkout
		$query = "SELECT ou.user_id,ou.user_email
		FROM #__jticketing_users as ou
		WHERE ou.address_type='BT' AND ou.order_id=" . $id;
		$this->_db->setQuery($query);
		$user_detail = $this->_db->loadObject();
		$params      = JComponentHelper::getParams('com_jticketing');
		$guest_email = "";

		if (!$user_detail->user_id && $params->get('allow_buy_guest'))
		{
			$guest_email = "&email=" . md5($user_detail->user_email);
		}

		$data['processor'] = $pg_plugin;
		$data['status']    = trim($data['status']);
		$query             = "SELECT o.amount
				FROM #__jticketing_order  as o
				where o.id=" . $id;
		$this->_db->setQuery($query);
		$order_amount          = $this->_db->loadResult();
		$return_resp['status'] = '0';

		if ($order_amount == 0)
		{
			$data['order_id']       = $id;
			$data['total_paid_amt'] = 0;
			$data['processor']      = $pg_plugin;
			$data['status']         = 'C';
		}

		if (($data['status'] == 'C' && $order_amount == $data['total_paid_amt']) or ($data['status'] == 'C' && $order_amount == 0))
		{
			$data['status']        = 'C';
			$return_resp['status'] = '1';
		}
		elseif ($order_amount != $data['total_paid_amt'] and $data['processor'] != 'adaptive_paypal')
		{
			$data['status']        = 'E';
			$return_resp['status'] = '0';
		}
		elseif (empty($data['status']))
		{
			$data['status']        = 'P';
			$return_resp['status'] = '0';
		}

		if ($data['status'] != 'C' && !empty($data['error']))
		{
			$return_resp['msg'] = $data['error']['code'] . " " . $data['error']['desc'];
		}

		$this->updateOrder($id, $user_detail->user_id, $data, $return_resp);

		// Clear order session
		$session->set('JT_orderid', '');
		$session->set('JT_fee', '');
		$return = "index.php?option=com_jticketing&view=orders&layout=order";
		$return .= $guest_email . "&orderid=" . ($order_id) . "&processor={$pg_plugin}&Itemid=" . $orderItemid;
		$return_resp['return'] = JUri::root() . substr(JRoute::_($return, false), strlen(JUri::base(true)) + 1);

		// Trigger After Process Payment
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('jt_OnAfterProcessPayment', array($post, $order_id, $pg_plugin));

		return $return_resp;
	}

	/**
	 * Check if order is already processed
	 *
	 * @param   string  $transaction_id  transaction_id for order
	 * @param   string  $order_id        id of jticketing_order
	 *
	 * @return  int  1 or 0
	 *
	 * @since   1.0
	 */
	public function Dataprocessed($transaction_id, $order_id)
	{
		$db    = JFactory::getDBO();
		$query = "SELECT event_details_id
				FROM #__jticketing_order where id=" . $order_id . " AND transaction_id='" . $transaction_id . "' AND status='C'";
		$db->setQuery($query);
		$eventdata = $db->loadResult();

		if (!empty($eventdata))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	/**
	 * Update order its status,seats and other data
	 *
	 * @param   string  $id           id for jticketing_order
	 * @param   string  $userid       userid of payee
	 * @param   array   $data         data of jticketing_order
	 * @param   string  $return_resp  return_resp
	 *
	 * @return  int  1 or 0
	 *
	 * @since   1.0
	 */
	public function updateOrder($id, $userid, $data, $return_resp)
	{
		$processed = 0;

		// Imp Check if Data is processed and Status is already Completed
		$processed = $this->Dataprocessed($data['transaction_id'], $id);

		if ($processed == 1)
		{
			$return_resp['status'] = '1';

			return $return_resp;
		}

		if ($data['status'] == 'C' and $processed != 1)
		{
			$this->updateOrderEvent($id, $data, $userid);
			$return_resp['status'] = '1';
		}
		elseif (!empty($data['status']))
		{
			$this->updateStatus($data);
		}

		$com_params           = JComponentHelper::getParams('com_jticketing');
		$email_options        = $com_params->get('email_options', '');

		if (in_array('order_email', $email_options) and $data['status'] != 'C')
		{
			$this->sendInvoiceEmail($id);
		}

		return $return_resp;
	}

	/**
	 * Update order and send invoice and add payout entry
	 *
	 * @param   string  $id         id for jticketing_order
	 * @param   string  $data       userid of payee
	 * @param   string  $member_id  payee id
	 *
	 * @return  int  1 or 0
	 *
	 * @since   1.0
	 */
	public function updateOrderEvent($id, $data, $member_id)
	{
		$com_params           = JComponentHelper::getParams('com_jticketing');
		$socialintegration    = $com_params->get('integrate_with', 'none');
		$streamBuyTicket      = $com_params->get('streamBuyTicket', 0);
		$email_options        = $com_params->get('email_options', '');
		$user                 = JFactory::getUser();
		$jticketingmainhelper = new jticketingmainhelper;
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$jteventHelper        = new jteventHelper;
		$orderinfo   = $jticketingmainhelper->getorderinfo($id);

		if ($socialintegration != 'none')
		{
			// Add in activity.
			if ($streamBuyTicket == 1 and !empty($user->id))
			{
				$libclass    = $jteventHelper->getJticketSocialLibObj();
				$action      = 'streamBuyTicket';
				$eventLink   = '<a class="" href="' . $orderinfo['eventinfo']->event_url . '">' . $orderinfo['eventinfo']->summary . '</a>';
				$originalMsg = JText::sprintf('COM_JTICKETING_PURCHASED_TICKET', $eventLink);
				$libclass->pushActivity($user->id, $act_type = '', $act_subtype = '', $originalMsg, $act_link = '', $title = '', $act_access = 0);
			}
		}

		$this->updatesales($data, $id);
		$member_id   = $this->getEventMemberid($id, $data['status']);
		$eventupdate = $this->eventupdate($id, $member_id);

		// Send Ticket Email.
		if (in_array('ticket_email', $email_options))
		{
			$email = $jticketingmainhelper->sendmailnotify($id, 'afterordermail');
		}

		// Send Invoice Email.
		$jticketingModelpayment = new jticketingModelpayment;

		if (in_array('order_email', $email_options))
		{
			$jticketingModelpayment->sendInvoiceEmail($id);
		}

		// Add entries to reminder queue to send reminder for Event
		$reminder_data              = $jticketingmainhelper->getticketDetails($orderinfo['eventinfo']->id, $orderinfo['items']['0']->order_items_id);
		$eventType = $reminder_data->online_events;
		$meeting_url = json_decode($reminder_data->jt_params);
		$reminder_data->ticketprice = $orderinfo['order_info']['0']->amount;
		$reminder_data->nofotickets = 1;
		$reminder_data->totalprice  = $orderinfo['order_info']['0']->amount;
		$reminder_data->eid         = $orderinfo['eventinfo']->id;
		$eventupdate                = $this->addtoReminderQueue($reminder_data, $orderinfo);

		if ($socialintegration == '2')
		{
			$venueDetails               = $jticketingfrontendhelper->getVenue($orderinfo['eventinfo']->venue);
			$orderDetails               = $jticketingmainhelper->getOrderDetail($order_id);
			$randomPassword               = $jticketingmainhelper->rand_str(8);
			$venueParams                = json_decode($venueDetails->params);
			$venueParams->user_id  = $orderDetails->user_id;
			$venueParams->name     = $orderDetails->name;
			$venueParams->email    = $orderDetails->email;
			$venueParams->password = $randomPassword;
			$venueParams->meeting_url = json_decode($meeting_url->event_url);

			if ($eventType == '1')
			{
				// TRIGGER After create event
				$dispatcher = JDispatcher::getInstance();
				JPluginHelper::importPlugin('tjevents');
				$result = $dispatcher->trigger('tj_inviteUsers', array($venueParams));
			}
		}

		// Add payout entry
		$payout_id = $this->addPayoutEntry($id, $data['transaction_id'], $data['status'], $data['processor']);
	}

	/**
	 * Get payout ID and status from payout table
	 *
	 * @param   string  $transactionID  id for jticketing_order
	 * @param   string  $userid         userid of payee
	 *
	 * @return  array  payout array
	 *
	 * @since   1.0
	 */
	public function getPayoutId($transactionID, $userid)
	{
		$db    = JFactory::getDBO();
		$query = "SELECT `id`,`status`
		FROM `#__jticketing_ticket_payouts`
		WHERE `transction_id`='" . $transactionID . "' AND `user_id`=" . $userid;
		$db->setQuery($query);

		return $db->loadAssoc();
	}

	/**
	 * Update payout entry
	 *
	 * @param   string  $order_id   id for jticketing_order
	 * @param   string  $txnid      txnid
	 * @param   array   $status     status
	 * @param   string  $pg_plugin  name of plugin
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function addPayoutEntry($order_id, $txnid, $status, $pg_plugin)
	{
		// GET BUSINESS EMAIL
		$plugin           = JPluginHelper::getPlugin('payment', $pg_plugin);
		$pluginParams     = json_decode($plugin->params);
		$businessPayEmial = "";

		if (property_exists($pluginParams, 'business'))
		{
			$businessPayEmial = trim($pluginParams->business);
		}
		else
		{
			return array();
		}

		$params              = JComponentHelper::getParams('com_jticketing');
		$handle_transactions = $params->get('handle_transactions');

		if ($pg_plugin == 'adaptive_paypal' or ($pg_plugin == 'paypal' and $handle_transactions == 1))
		{
			// Lets set the paypal email if admin is not handling transactions
			$jticketingmainhelper     = new jticketingmainhelper;
			$adaptiveDetails          = $jticketingmainhelper->getorderEventInfo($order_id);
			$modelpath                = JPATH_SITE . "/administrator/components/com_jticketing/models/mypayouts.php";
			$class                    = "jticketingModelmypayouts";
			$jticketingModelmypayouts = $jticketingmainhelper->loadJTClass($modelpath, $class);

			$reportStatus = ($status == 'C') ? 1 : 0;

			foreach ($adaptiveDetails as $userReport)
			{
				$jticketingModelpayment = new jticketingModelpayment;
				$payDetail              = $jticketingModelpayment->getPayoutId($txnid, $userReport['owner']);

				if (!empty($payDetail) && $payDetail['status'] == $reportStatus)
				{
					/* Payout already present mean $payDetail will not empty
					and STATUS is same then dont process.
					For new payout,this will not process*/
					break;
				}

				$post                   = array();
				$post['id']             = empty($payDetail['id']) ? '' : $payDetail['id'];
				$post['user_id']        = $userReport['owner'];
				$post['payee_name']     = $jticketingmainhelper->getUserName($post['user_id']);
				$post['paypal_email']   = $userReport['pay_detail'];
				$post['transaction_id'] = $txnid;
				$post['amount']         = $userReport['commissonCutPrice'];
				$post['payout_date']    = date('Y-m-d');
				$post['status']         = $reportStatus;

				if ($pg_plugin == 'paypal')
				{
					$post['payment_comment'] = "paypal directly paid to event owner";
				}
				else
				{
					$post['payment_comment'] = "adaptive pay";
				}

				$jticketingModelmypayouts->savePayout($post);
			}
		}
	}

	/**
	 * Send invoice email after payment
	 *
	 * @param   string  $id  id in jticketing_order
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function sendInvoiceEmail($id)
	{
		$db = JFactory::getDBO();
		$com_params           = JComponentHelper::getParams('com_jticketing');
		$mail_to              = $com_params->get('mail_to');
		$jticketingmainhelper = new jticketingmainhelper;
		$orderItemid          = $jticketingmainhelper->getItemId('index.php?option=com_jticketing&view=orders');
		$jinput               = JFactory::getApplication()->input;
		$order                = $jticketingmainhelper->getorderinfo($id);

		if (isset($order['eventinfo']->created_by))
		{
			$order['eventinfo']->created_by = trim($order['eventinfo']->created_by);
			$order['eventinfo']->created_by = (int) ($order['eventinfo']->created_by);
			$query = "SELECT email
				FROM #__users where id=" . $order['eventinfo']->created_by;
			$db->setQuery($query);
			$creator_email = $db->loadResult();
		}

		$app                  = JFactory::getApplication();
		$sitename             = $app->getCfg('sitename');
		$eventtitle           = "";
		$mailfrom             = $app->getCfg('mailfrom');
		$fromname             = $app->getCfg('fromname');

		if (isset($order['eventinfo']->title))
		{
			$eventtitle = $order['eventinfo']->title;
		}

		$this->orderinfo        = $order['order_info'];
		$this->orderitems       = $order['items'];
		$this->orders_site      = 1;
		$this->orders_email     = 1;
		$this->order_authorized = 1;

		if (in_array('event_buyer', $mail_to))
		{
			if ($this->orderinfo[0]->address_type == 'BT')
			{
				$uemail = $billemail[] = $this->orderinfo[0]->user_email;
			}
			elseif ($this->orderinfo[1]->address_type == 'BT')
			{
				$uemail = $billemail[] = $this->orderinfo[1]->user_email;
			}
		}

		$guest_email = '';

		// Add invoice link with the html
		if (!$order['order_info'][0]->user_id && $com_params->get('allow_buy_guest'))
		{
			$guest_email = "&email=" . md5($uemail);
		}

		if (!JFactory::getUser()->id && $com_params->get('guest'))
		{
			$jinput->set('email', md5($billemail));
		}

		if (in_array('event_creator', $mail_to) and isset($creator_email))
		{
			$billemail[] = $creator_email;
		}

		if (in_array('site_admin', $mail_to))
		{
			$billemail[] = $mailfrom;
		}

		$billemail = array_unique($billemail);
		$currenturl_base = "index.php?option=com_jticketing&view=orders&layout=order";
		$currenturl_base .= $guest_email . "&orderid=" . $order['order_info'][0]->orderid_with_prefix;
		$currenturl_base .= "&processor=" . $order['order_info'][0]->processor . "&Itemid=" . $orderItemid;
		$currenturl = JUri::root() . substr(JRoute::_($currenturl_base, false), strlen(JUri::base(true)) + 1);

		// Check for view override
		$view = $jticketingmainhelper->getViewpath('orders', 'order');
		ob_start();
		include $view;
		$invoicehtml = ob_get_contents();
		ob_end_clean();

		$invoicehtml .= '<div class=""><div><span>' . JText::_("COM_JTICKETING_INVOICE_LINK");
		$invoicehtml .= '</span></div><div><span>' . $currenturl . '</span></div></div>';
		$subject = JText::sprintf('COM_JTICKETING_INVOICE_EMAIL', $eventtitle, '');

		// Trigger After Process Payment
		$dispatcher = JDispatcher::getInstance();
		JPluginHelper::importPlugin('system');
		$result = $dispatcher->trigger('jt_OnBeforeInvoiceEmail', array($billemail, $subject, $invoicehtml));
		$jticketingmainhelper->jtsendMail($mailfrom, $fromname, $billemail, $subject, $invoicehtml, 1);
	}

	/**
	 * Get userid of payee from order
	 *
	 * @param   string  $order_id      order_id in jticketing_order
	 * @param   string  $order_status  order_status like C and P
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventMemberid($order_id, $order_status)
	{
		$db = JFactory::getDBO();

		if ($order_status == 'P' OR $order_status == 'RF')
		{
			$query = "SELECT user_id
				FROM #__jticketing_order where id=" . $order_id . "  AND status NOT LIKE 'C' ";
		}
		else
		{
			$query = "SELECT user_id
					FROM #__jticketing_order where id=" . $order_id . "  AND status='C'";
		}

		$db->setQuery($query);

		return $user_id = $db->loadResult();
	}

	/**
	 * Store login data
	 *
	 * @param   string  $name  name of plugin
	 * @param   string  $data  data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function storelog($name, $data)
	{
		$data1              = array();
		$data1['raw_data']  = $data['raw_data'];
		$data1['JT_CLIENT'] = "com_jticketing";
		$dispatcher         = JDispatcher::getInstance();
		JPluginHelper::importPlugin('payment', $name);
		$data = $dispatcher->trigger('onTP_Storelog', array($data1));
	}

	/**
	 * Update status
	 *
	 * @param   string  $data  data
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function updateStatus($data)
	{
		$db                  = JFactory::getDBO();
		$res                 = new stdClass;
		$res->id             = $data['order_id'];
		$res->mdate          = date("Y-m-d H:i:s");
		$res->transaction_id = $data['transaction_id'];
		$res->status         = $data['status'];
		$res->extra          = json_encode($data['raw_data']);

		if (!$db->updateObject('#__jticketing_order', $res, 'id'))
		{
		}

		if ($res->status == 'C')
		{
			$query = "SELECT type_id,count(ticketcount) as ticketcounts
					FROM #__jticketing_order_items where order_id=" . $data['order_id'] . " GROUP BY type_id";
			$db->setQuery($query);
			$orderdetails = $db->loadObjectlist();

			foreach ($orderdetails as $orderdetail)
			{
				$typedata = '';
				$restype  = new stdClass;
				$query    = "SELECT count
					FROM #__jticketing_types where id=" . $orderdetail->type_id;
				$db->setQuery($query);
				$typedata       = $db->loadResult();
				$restype->id    = $orderdetail->type_id;
				$restype->count = $typedata + $orderdetail->ticketcounts;
				$db->updateObject('#__jticketing_types', $restype, 'id');
			}
		}
	}

	/**
	 * Update sales data
	 *
	 * @param   array  $data  data
	 * @param   int    $id    order id
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function updatesales($data, $id)
	{
		$db                  = JFactory::getDBO();
		$res                 = new stdClass;
		$res->id             = $id;
		$res->mdate          = date("Y-m-d H:i:s");
		$res->transaction_id = $data['transaction_id'];
		$res->payee_id       = $data['buyer_email'];
		$res->status         = $data['status'];
		$res->processor      = $data['processor'];
		$res->extra          = json_encode($data['raw_data']);

		if (!$db->updateObject('#__jticketing_order', $res, 'id'))
		{
			return false;
		}

		$query = "SELECT type_id,count(ticketcount) as ticketcounts
				FROM #__jticketing_order_items where order_id=" . $id . " GROUP BY type_id";
		$db->setQuery($query);
		$orderdetails = $db->loadObjectlist();

		foreach ($orderdetails as $orderdetail)
		{
			$typedata = '';
			$restype  = new stdClass;
			$query    = "SELECT count
				FROM #__jticketing_types where id=" . $orderdetail->type_id;
			$db->setQuery($query);
			$typedata       = $db->loadResult();
			$restype->id    = $orderdetail->type_id;
			$restype->count = $typedata - $orderdetail->ticketcounts;
			$db->updateObject('#__jticketing_types', $restype, 'id');
		}
	}

	/**
	 * Update event data for jomsocial and other integration for event members
	 *
	 * @param   array  $order_id   id of jticketing_order table
	 * @param   int    $member_id  user id of payee
	 *
	 * @return  boolean
	 *
	 * @since   1.0
	 */
	public function eventupdate($order_id, $member_id)
	{
		$com_params             = JComponentHelper::getParams('com_jticketing');
		$integration            = $com_params->get('integration');
		$siteadmin_comm_per     = $com_params->get('siteadmin_comm_per');
		$guest_reg_id           = $com_params->get('guest_reg_id');
		$auto_fix_seats         = $com_params->get('auto_fix_seats');
		$currency               = $com_params->get('currency');
		$affect_js_native_seats = $com_params->get('affect_js_native_seats');
		$jticketingmainhelper   = new jticketingmainhelper;

		if ($affect_js_native_seats != '1')
		{
			return;
		}

		$integration = $jticketingmainhelper->getIntegration();

		if ($integration == 1)
		{
			$db    = JFactory::getDBO();
			$user  = JFactory::getUser();
			$query = "SELECT event_details_id,amount,ticketscount
		   		        FROM #__jticketing_order where id=" . $order_id . " AND status='C'";
			$db->setQuery($query);
			$eventdata = $db->loadObject();
			$query     = "SELECT eventid
		   		        FROM #__jticketing_integration_xref where id=" . $eventdata->event_details_id . "  AND source='com_community'";
			$db->setQuery($query);
			$eventid = $db->loadResult();
			$qry     = "SELECT confirmedcount FROM #__community_events
					WHERE id=" . $eventid;
			$db->setQuery($qry);
			$cnt                 = $db->loadResult();
			$arr                 = new stdClass;
			$arr->id             = $eventid;
			$arr->confirmedcount = $cnt + $eventdata->ticketscount;
			$db->updateObject('#__community_events', $arr, 'id');

			// Added for bug fix for bug  #12043
			$qry = "SELECT id FROM #__community_events_members
					  WHERE eventid=" . $eventdata->event_details_id . "
					  AND memberid=" . $member_id . "
					  AND status=0";
			$db->setQuery($qry);

			$invited_row_id = $db->loadResult();

			if ($invited_row_id)
			{
				$qry = "UPDATE `#__community_events_members` SET `status`=1
					WHERE `id`=" . $invited_row_id;
				$db->setQuery($qry);
				$db->execute($qry);
				$eventdata->ticketscount--;
			}

			if ($eventdata->ticketscount)
			{
				for ($i = 0; $i < $eventdata->ticketscount; $i++)
				{
					// Get site admin id
					if (!$member_id)
					{
						if (!empty($guest_reg_id))
						{
							$member_id = $guest_reg_id;
						}
					}

					if (!$member_id)
					{
						continue;
					}

					$qry = "SELECT id FROM #__community_events_members
					  WHERE eventid=" . $eventid . "
					 AND memberid=" . $member_id . "
					 AND status=1";
					$db->setQuery($qry);
					$member_already_present = $db->loadResult();

					if ($member_already_present)
					{
						continue;
					}

					$dat             = new stdClass;
					$dat->id         = '';
					$dat->eventid    = $eventid;
					$dat->memberid   = $member_id;
					$dat->status     = 1;
					$dat->permission = 3;
					$dat->invited_by = 0;
					$dat->approval   = 0;
					$dat->created    = date("Y-m-d H:i:s");

					if (!$db->insertObject('#__community_events_members', $dat, 'id'))
					{
						echo $db->stderr();
					}
				}
			}

			// For bug fix for bug  #12043
			if ($auto_fix_seats == '1')
			{
				$this->fixDB($eventid);
			}
		}

		return true;
	}

	/**
	 * Update event data for jomsocial and other integration for event members
	 *
	 * @param   array  $order_id  id of jticketing_order table
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventownerEmail($order_id)
	{
		$db = JFactory::getDBO();

		// Retrieve XrefID
		$sql = "SELECT event_details_id FROM #__jticketing_order  WHERE id=" . $order_id;
		$db->setQuery($sql);
		$eventid = $db->LoadResult();
		$query   = "SELECT  xref.paypal_email AS paypal_email FROM #__jticketing_integration_xref AS xref
		WHERE  paypal_email<>'' AND   id=" . $eventid;
		$db->setQuery($query);
		$paypalemail = $db->loadResult();

		if (!empty($paypalemail))
		{
			return $paypalemail;
		}
	}

	/**
	 * Get all event data for jomsocial based on creator
	 *
	 * @param   int  $creator  creator of event
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getEventData($creator)
	{
		$db    = JFactory::getDBO();
		$query = "SELECT events.id,events.creator, sum(ticket.amount) AS nprice, sum(ticket.fee) AS nfee
							  FROM #__community_events AS events
					          LEFT JOIN #__jticketing_events_xref AS eventdetails
							  ON events.id = eventdetails.eventid
							  LEFT JOIN #__jticketing_order AS ticket
							  ON eventdetails.eventid = ticket.event_details_id
							  WHERE ticket.status = 'C'
							  AND events.creator ='" . $creator . "' GROUP BY events.creator";
		$db->setQuery($query);
		$rows = $db->loadObject();

		return $rows;
	}

	/**
	 * Fix database member count values for jomsocial
	 *
	 * @param   int  $eventid  eventid
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function fixDB($eventid)
	{
		// Remove inconsitent entries from community event members table
		$db = JFactory::getDBO();

		// Load list of all user who bought tickets for event
		$qry = "SELECT id, user_id,ticketscount
		FROM `#__jticketing_order`
		WHERE event_details_id=" . $eventid;
		$db->setQuery($qry);
		$orders = $db->loadObjectList();

		// Calculate ticket count for all users who bought tickets
		$members = array();

		foreach ($orders as $o)
		{
			if (!array_key_exists($o->user_id, $members))
			{
				$members[$o->user_id]['ticketscount'] = $o->ticketscount;
			}
			else
			{
				$members[$o->user_id]['ticketscount'] = $members[$o->user_id]['ticketscount'] + $o->ticketscount;
			}
		}

		$todelete = array();

		foreach ($members as $key => $val)
		{
			// Get all event members of type mebmer(permission=3)
			$qry = "SELECT id,status,invited_by
			FROM `#__community_events_members`
			WHERE eventid=" . $eventid . " AND permission=3 AND memberid=" . $key;
			$db->setQuery($qry);
			$mb = $db->loadObjectList();

			// If count of a members attendance is greater than no. of tickets he bought
			if (count($mb) > $val['ticketscount'])
			{
				$cnt = 0;

				foreach ($mb as $m)
				{
					$cnt++;

					// If count of a members attendance is greater than no. of tickets he bought
					if ($cnt > $val['ticketscount'])
					{
						$todelete[] = $m->id;
					}
				}
			}
		}

		// Delete all rows calculated above
		if (isset($todelete))
		{
			if (count($todelete) > 0)
			{
				$todel = implode($todelete, ',');
				$qry   = "DELETE FROM `#__community_events_members`
					WHERE id IN(" . $todel . ")";
				$db->setQuery($qry);
				$db->execute();
			}
		}

		return true;
	}

	/**
	 * Update selected gateway in database
	 *
	 * @param   string  $selectedGateway  gateway that is selected
	 * @param   int     $order_id         order_id of the order which is selected
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function updateOrderGateway($selectedGateway, $order_id)
	{
		$db             = JFactory::getDBO();
		$row            = new stdClass;
		$row->id        = $order_id;
		$row->processor = $selectedGateway;

		if (!$this->_db->updateObject('#__jticketing_order', $row, 'id'))
		{
			echo $this->_db->stderr();

			return 0;
		}

		return 1;
	}

	/**
	 * Get data for adaptive payment
	 *
	 * @param   string  $vars       vars for adaptive payment
	 * @param   int     $pg_plugin  payment gateway name
	 * @param   int     $orderid    orderid of the order which is selected
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function getReceiverList($vars, $pg_plugin, $orderid)
	{
		// GET BUSINESS EMAIL
		$plugin           = JPluginHelper::getPlugin('payment', $pg_plugin);
		$pluginParams     = json_decode($plugin->params);
		$businessPayEmial = "";

		if (property_exists($pluginParams, 'business'))
		{
			$businessPayEmial = trim($pluginParams->business);
		}
		else
		{
			return array();
		}

		$params              = JComponentHelper::getParams('com_jticketing');
		$handle_transactions = $params->get('handle_transactions', 0);

		if ($pg_plugin == 'adaptive_paypal')
		{
			// Lets set the paypal email if admin is not handling transactions
			$adaptiveDetails      = array();
			$jticketingmainhelper = new jticketingmainhelper;
			$adaptiveDetails      = $jticketingmainhelper->getorderEventInfo($orderid);

			$params = JComponentHelper::getParams('com_jticketing');

			/*
			if($handle_transactions==0){
			$commission_per = $params->get("siteadmin_comm_per",0);
			$adminCommisson_per =  (($vars->amount * $commission_per)/100 );
			$commission_flat = $params->get("siteadmin_comm_flat",0);
			$adminCommisson=$adminCommisson_per+$commission_flat;
			}*/

			// GET BUSINESS EMAIL
			$plugin           = JPluginHelper::getPlugin('payment', $pg_plugin);
			$pluginParams     = json_decode($plugin->params);
			$businessPayEmial = "";

			if (property_exists($pluginParams, 'business'))
			{
				$businessPayEmial = trim($pluginParams->business);
			}

			$receiverList                = array();
			$receiverList[0]             = array();
			$tamount                     = 0;
			$receiverList[0]['receiver'] = $businessPayEmial;
			$receiverList[0]['amount']   = $adaptiveDetails['0']['commission'];
			$receiverList[0]['primary']  = false;

			if (!empty($adaptiveDetails[$businessPayEmial]))
			{
				// Primary account
				unset($adaptiveDetails[$businessPayEmial]);
			}
			else
			{
				// $tamount = $tamount + $receiverList[0]['amount'];
			}

			// Add other receivers
			$index = 1;

			foreach ($adaptiveDetails as $detail)
			{
				$receiverList[$index]['receiver'] = $detail['pay_detail'];

				// Changed above 2 lines by sagar to make event owner as primary receiver
				$receiverList[$index]['amount']  = $vars->amount;
				$receiverList[$index]['primary'] = true;
				$index++;
			}

			return $receiverList;
		}
	}

	/**
	 * Get data for stripe payment
	 *
	 * @param   string  $data    data for stripe payment
	 * @param   int     $refund  refund 1 or 0
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function stripeAddPayout($data, $refund = 0)
	{
		$db             = JFactory::getDBO();
		$transaction_id = $data['data']['object']['charge'];

		if (!$transaction_id)
		{
			return;
		}

		// Get Event Owner ID
		$query = $db->getQuery(true);

		// Select campaign owner id
		$query->select($db->quoteName(array('e.userid', 'o.original_amount')));
		$query->from($db->quoteName('#__jticketing_integration_xref', 'e'));
		$query->join('INNER', $db->quoteName('#__jticketing_order', 'o') .
		' ON (' . $db->quoteName('e.id') . ' = ' . $db->quoteName('o.event_details_id') . ')');
		$query->where($db->quoteName('o.transaction_id') . ' = ' . "'" . $transaction_id . "'");

		// Reset the query using our newly populated query object.
		$db->setQuery($query);

		// Load the result
		$orderObject = $db->loadObject();

		// Get Payout ID
		$query = $db->getQuery(true);
		$query->select($db->quoteName(array('id')));
		$query->from($db->quoteName('#__jticketing_ticket_payouts', 'p'));
		$query->where($db->quoteName('p.transction_id') . ' = ' . "'" . $transaction_id . "'");
		$db->setQuery($query);

		// Get payout ID
		$payout_id = $db->loadResult();

		// Add Payout
		$res = new stdClass;

		if ($payout_id)
		{
			$res->id = $payout_id;
		}
		else
		{
			$res->id = '';
		}

		$res->user_id       = $orderObject->userid;
		$res->payee_name    = JFactory::getUser($orderObject->userid)->name;
		$res->date          = date("Y-m-d H:i:s");
		$res->transction_id = $transaction_id;

		// If fee is refunded then means total amount is paid to campaign promoter
		if ($refund == 1)
		{
			$res->amount = $orderObject->original_amount;
		}
		else
		{
			$res->amount = $orderObject->original_amount - ($data['data']['object']['amount'] / 100);
		}

		$res->status     = 1;
		$res->ip_address = '';
		$res->type       = 'stripe';

		if ($res->id)
		{
			if (!$db->updateObject('#__jticketing_ticket_payouts', $res, 'id'))
			{
			}
		}
		else
		{
			if (!$db->insertObject('#__jticketing_ticket_payouts', $res, 'id'))
			{
			}
		}

		return true;
	}

	/**
	 * Add data to reminder queue
	 *
	 * @param   array  $reminder_data  Reminder data
	 * @param   array  $order          Order date
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function addtoReminderQueue($reminder_data, $order)
	{
		$jticketingmainhelper     = new jticketingmainhelper;
		$jticketingfrontendhelper = new jticketingfrontendhelper;
		$db                       = JFactory::getDBO();
		$query                    = "Select * FROM #__jticketing_reminder_types WHERE state=1";
		$db->setQuery($query);
		$reminder_types = $db->loadObjectList();

		foreach ($reminder_types AS $reminder)
		{
			$days         = $reminder->days;
			$date         = JFactory::getDate($reminder_data->startdate);
			$today        = date('Y-m-d');
			$date_expires = strtotime($date . ' -' . $days . 'day');
			$date_expires = date('Y-m-d H:i:s', $date_expires);
			$isexist  = $isexistsms = 0;

			// If reminder expired no need to edit it
			if (strtotime($date_expires) < strtotime($today))
			{
				continue;
			}

			$reminder_type_id = $reminder->id;
			$reminder_user_id = $order['order_info']['0']->user_id;

			if ($reminder->email == 1)
			{
				$query = $db->getQuery(true);
				$query->select('id');
				$query->from($db->quoteName('#__jticketing_queue'));
				$query->where($db->quoteName('reminder_type_id') . " = " . $reminder_type_id);
				$query->where($db->quoteName('reminder_type') . " = " . $db->quote('email'));
				$query->where($db->quoteName('user_id') . " = " . $reminder_user_id);

				// @TODO remove this for bajaj
				$dispatcher = JDispatcher::getInstance();
				JPluginHelper::importPlugin('system');
				$data1 = $dispatcher->trigger('jt_OnBeforeReminderEntry', array($reminder_type_id));

				if (!empty($data1['0']))
				{
				}
				else
				{
					$query->where($db->quoteName('event_id') . " = " . $order['order_info']['0']->event_integration_id);
				}

				$db->setQuery($query);
				$isexist = $db->loadResult();
				$res                          = new stdClass;
				$res->id                      = '';
				$res->reminder_type_id        = $reminder->id;
				$reminder_data->send_reminder = 1;
				$reminder_data->reminder_type = $res->reminder_type = "email";
				$reminder_data->email_config  = array(
					'message_body' => $reminder->email_template
				);
				$reminder_data->css_file      = $reminder->css;
				$res->content                 = $jticketingmainhelper->getticketHTML($reminder_data);
				$res->user_id                 = $order['order_info']['0']->user_id;
				$res->event_id                 = $order['order_info']['0']->event_integration_id;
				$img_path = 'img src="' . JUri::root();
				$res->content = str_replace('img src="' . JUri::root(), 'img src="', $res->content);
				$res->content = str_replace('img src="', $img_path, $res->content);
				$res->content = str_replace("background: url('" . JUri::root(), "background: url('", $res->content);
				$res->content = str_replace("background: url('", "background: url('" . JUri::root(), $res->content);

				// Replace subject
				$reminder_data->email_config = array(
					'message_body' => $reminder->subject
				);
				$reminder_data->css_file     = $reminder->css;
				$res->subject                = $jticketingmainhelper->getticketHTML($reminder_data);

				$res->date_to_sent = $date_expires;

				if (!empty($order['order_info']['0']->user_email))
				{
					$res->email = $order['order_info']['0']->user_email;
				}

				if (isset($order['order_info']['0']->phone))
				{
					if (isset($order['order_info']['0']->country_mobile_code))
					{
						$res->mobile_no = $order['order_info']['0']->country_mobile_code . $order['order_info']['0']->phone;
					}
					else
					{
						$res->mobile_no = $order['order_info']['0']->phone;
					}
				}

				if (isset($order['order_info']['0']->order_id))
				{
					$res->order_id = $order['order_info']['0']->order_id;
				}

				if (!$isexist)
				{
					if (!$db->insertObject('#__jticketing_queue', $res, 'id'))
					{
					}
				}
				else
				{
					// If entry already existed in jticketing queue just update queue
					if (!empty($reminder_data->reminder_queue_id) and $isexist == $reminder_data->reminder_queue_id)
					{
						$res->id = $reminder_data->reminder_queue_id;

						if (!$db->updateObject('#__jticketing_queue', $res, 'id'))
						{
						}
					}
				}
			}

			if ($reminder->sms == 1)
			{
				$query = $db->getQuery(true);
				$query->select('id');
				$query->from($db->quoteName('#__jticketing_queue'));
				$query->where($db->quoteName('reminder_type_id') . " = " . $reminder_type_id);
				$query->where($db->quoteName('reminder_type') . " = " . $db->quote('sms'));
				$query->where($db->quoteName('user_id') . " = " . $reminder_user_id);

				// @TODO remove this for bajaj since they allow booking of event only once
				$dispatcher = JDispatcher::getInstance();
				JPluginHelper::importPlugin('system');
				$data1 = $dispatcher->trigger('jt_OnBeforeReminderEntry', array($reminder_type_id));

				if (!empty($data1['0']))
				{
				}
				else
				{
					$query->where($db->quoteName('event_id') . " = " . $order['order_info']['0']->event_integration_id);
				}

				$db->setQuery($query);
				$isexistsms = $db->loadResult();

				$res                          = new stdClass;
				$res->id                      = '';
				$res->reminder_type_id        = $reminder->id;
				$res->reminder_type           = "sms";
				$reminder_data->email_config  = array('message_body' => $reminder->sms_template);
				$reminder_data->send_reminder = 1;
				$res->date_to_sent            = $date_expires;
				$res->sent                    = 0;
				$res->subject                 = "";
				$res->content                 = $jticketingmainhelper->getticketHTML($reminder_data);
				$res->user_id                 = $order['order_info']['0']->user_id;
				$res->event_id                 = $order['order_info']['0']->event_integration_id;

				if (isset($order['order_info']['0']->user_email))
				{
					$res->email = $order['order_info']['0']->user_email;
				}

				if (isset($order['order_info']['0']->phone))
				{
					if (isset($order['order_info']['0']->country_mobile_code))
					{
						$res->mobile_no = $order['order_info']['0']->country_mobile_code . $order['order_info']['0']->phone;
					}
					else
					{
						$res->mobile_no = $order['order_info']['0']->phone;
					}
				}
				/*elseif (isset($reminder_data['phone']))
				{
					$res->mobile_no = $reminder_data['phone'];
				}*/

				if (isset($order['order_info']['0']->order_id))
				{
					$res->order_id = $order['order_info']['0']->order_id;
				}

					if (!$isexistsms)
					{
						if ($res->mobile_no)
						{
							if (!$db->insertObject('#__jticketing_queue', $res, 'id'))
							{
							}
						}
					}
					else
					{
						// If entry already existed in jticketing queue just update queue
						if (!empty($reminder_data->reminder_queue_id) and $isexistsms == $reminder_data->reminder_queue_id)
						{
								$res->id = $reminder_data->reminder_queue_id;

								if (!$db->updateObject('#__jticketing_queue', $res, 'id'))
								{
								}
						}
					}
			}
		}
	}
}
