<?php
/**
 * @version    SVN: <svn_id>
 * @package    JTicketing
 * @author     Techjoomla <extensions@techjoomla.com>
 * @copyright  Copyright (c) 2009-2016 TechJoomla. All rights reserved.
 * @license    GNU General Public License version 2 or later.
 */

// No direct access
defined('_JEXEC') or die;
/**
 * Class JTicketingRouter
 *
 * @since  3.3
 */
class JTicketingRouter extends JComponentRouterBase
{
	/**
	 * Build the route for the com_content component
	 *
	 * @param   array  &$query  An array of URL arguments
	 *
	 * @return   array  The URL arguments to use to assemble the subsequent URL.
	 *
	 * @since  1.5
	 */
	public function build(&$query)
	{
		$segments = array();

		// Get a menu item based on Itemid or currently active
		$app = JFactory::getApplication();
		$menu = $app->getMenu();

		$params = JComponentHelper::getParams('com_jticketing');
		$db = JFactory::getDbo();

		// We need a menu item.  Either the one specified in the query, or the current active one if none specified
		if (empty($query['Itemid']))
		{
			$menuItem = $menu->getActive();
			$menuItemGiven = false;
		}
		else
		{
			$menuItem = $menu->getItem($query['Itemid']);

			$menuItemGiven = true;
		}

		// Check again
		if ($menuItemGiven && isset($menuItem) && $menuItem->component != 'com_jticketing')
		{
			$menuItemGiven = false;
			unset($query['Itemid']);
		}

		// Check if view is set.
		if (isset($query['view']))
		{
			$view = $query['view'];
		}
		else
		{
			// We need to have a view in the query or it is an invalid URL
			return $segments;
		}

		if (isset($query['view']))
		{
			$segments[] = $query['view'];
			unset($query['view']);
		}

		switch ($view)
		{
			case 'eventform':
				if (isset($query['id']))
				{
					$segments[] = $query['id'];
					unset($query['id']);
				}
			break;

			case 'event':
				if (isset($query['id']))
				{
					$segments[] = $query['id'];
					unset($query['id']);
				}
			break;

			case 'buy':
				if (isset($query['eventid']))
				{
					$segments[] = $query['eventid'];
					unset($query['eventid']);
				}

				if (isset($query['layout']))
				{
					unset($query['layout']);
				}

				if (isset($query['Itemid']))
				{
					unset($query['Itemid']);
				}
			break;

			case 'orders':
				if (isset($query['layout']))
				{
					$segments[] = $query['layout'];
				}

				if (isset($query['orderid']))
				{
					$segments[] = $query['orderid'];
					unset($query['orderid']);
				}

				if (isset($query['tmpl']))
				{
					unset($query['tmpl']);
				}

			break;
		}

		return $segments;
	}

	/**
	 * Parse the segments of a URL.
	 *
	 * @param   array  &$segments  The segments of the URL to parse.
	 *
	 * @return  array  The URL attributes to be used by the application.
	 *
	 * @since  1.5
	 */
	public function parse(&$segments)
	{
		$item = $this->menu->getActive();
		$vars = array();
		$db = JFactory::getDbo();

		// Count route segments
		$count = count($segments);
		$vars['view'] = $segments[0];

		switch ($segments[0])
		{
			case "eventform":
					$vars['id'] = $segments[1];
			break;
			case "buy":
				if ($count == 2)
				{
					$vars['layout'] = "default";
					$vars['eventid'] = $segments[1];
				}
			break;
			case "event":
				if ($count == 2)
				{
					$vars['id'] = $segments[1];
				}
			break;
			case "orders":
				if ($count == 3)
				{
					$vars['layout'] = $segments[1];
					$vars['orderid'] = $segments[2];
					$vars['tmpl'] = 'component';
				}
			break;
		}

		return $vars;
	}
}
